-- Presentation-only UI overhaul for Gen1Recomp.
-- Native gameplay, battle logic, menu input, storage logic, and TM flow are preserved.
-- Custom rendering is feature-gated and falls back to native behavior when disabled.

local BattleState = require("src.battle.BattleState")
local EngineFont = require("src.render.Font")
local Growth = require("src.pokemon.Growth")
local Menu = require("src.ui.Menu")
local StartMenu = require("src.ui.StartMenu")
local BagMenu = require("src.ui.BagMenu")
local ListMenu = require("src.ui.ListMenu")
local PartyMenu = require("src.ui.PartyMenu")
local MoveLearnMenu = require("src.ui.MoveLearnMenu")
local Strings = require("src.core.Strings")
local TextBox = require("src.render.TextBox")
local ChoiceBox = require("src.ui.ChoiceBox")
local NamingScreen = require("src.ui.NamingScreen")
local BoxMenu = require("src.ui.BoxMenu")
local Boxes = require("src.pokemon.Boxes")
local QuantityBox = require("src.ui.QuantityBox")
local ShopMenu = require("src.ui.ShopMenu")
local Evolution = require("src.pokemon.Evolution")
local BagInventory = require("src.inventory.Bag")
local ItemEffects = require("src.inventory.ItemEffects")

local State = {
  activeBattle = nil,
  activeParty = nil,
  activeTMParty = nil,
  activeItemTargetParty = nil,
  activeMoveLearn = nil,
  activeTMPromptFlow = nil,
  activeStartMenu = nil,
  activeBagMenu = nil,
  activeBagActionMenu = nil,
  activeDialogueBox = nil,
  activeChoiceBox = nil,
  activePCMenu = nil,
  activePCList = nil,
  activePCActionMenu = nil,
  activePCAccessMenu = nil,
  activeBattleMoveLearn = nil,
  activeBattleMoveParty = nil,
  activeGoldBattleMoveLearn = nil,
  pendingGen2FieldLearn = nil,
  activeBattleStatBox = nil,
  activeShopMenu = nil,
  activeShopList = nil,
  activeShopQuantity = nil,
  locationBannerLastMap = nil,
  locationBannerName = nil,
  locationBannerPending = nil,
  locationBannerStarted = nil,
  titleIntroShown = false,
  titleMusicRegistered = false,
  titleMusicSession = false,
}


local modRef = nil
local GoldCompat = {
  enabled = false,
  game = nil,
  adapter = nil,
  generation = "gen1",
}

-- Safari ownership is shared by the embedded Colosseum renderer and the outer
-- lifecycle/HUD adapters. Keep this resolver on GoldCompat so calls on either
-- side of the renderer's nested scope use the same function.
function GoldCompat.resolvedSafariState(battle)
  if not battle then return nil end
  if type(battle.safari)=="table" then return battle.safari end
  local source=battle.__gen3Source or battle
  if source and type(source.safari)=="table" then return source.safari end
  local game=battle.game or (source and source.game)
  local safari=game and game.save and game.save.safari
  if type(safari)=="table" then return safari end
  return nil
end

function GoldCompat.humanizeIdentifier(value)
  local text=tostring(value or "")
  text=text:gsub("_+"," "):gsub("%-+"," ")
  text=text:gsub("(%l)(%u)","%1 %2")
  text=text:gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","")
  return text
end

function GoldCompat.experienceRatio(data,mon,generation,growthHint)
  if not (data and mon and mon.species) then return 0 end
  local def=data.pokemon and data.pokemon[mon.species]
  if not def then return 0 end
  local level=math.max(1,math.floor(tonumber(mon.level) or 1))
  local cap=(data.constants and data.constants.levelCap) or 100
  if level>=cap then return 1 end
  local total=tonumber(mon.experience or mon.exp or mon.xp)
  if not total then return 0 end

  local dexEntry=data.gen2Pokedex and data.gen2Pokedex.entries
    and data.gen2Pokedex.entries[mon.species]
  local base=type(def.baseStats)=="table" and def.baseStats or {}
  local rate=growthHint or def.growthRate or def.growth or def.growth_rate
    or def.growthGroup or def.experienceRate or base.growthRate or base.growth
    or (dexEntry and (dexEntry.growthRate or dexEntry.growth))
  local cur,nxt
  if generation=="gen2" or mon.experience~=nil then
    local okMon,Mon=pcall(require,"src.battle.gen2.Mon")
    if okMon and Mon and type(Mon.experienceForLevel)=="function" then
      -- Gold stores a growth-curve ID on the species record. Resolve that ID
      -- through Mon.growthFor before asking experienceForLevel; passing the ID
      -- itself silently falls back to a cubic curve and is why the Gen II HUD
      -- appeared empty or incorrect for non-medium-fast species.
      local growth=type(rate)=="table" and rate or nil
      if not growth and type(Mon.growthFor)=="function" then
        local okGrowth,value=pcall(Mon.growthFor,data,rate)
        if okGrowth then growth=value end
      end
      if growth then
        local okCur,a=pcall(Mon.experienceForLevel,growth,level)
        local okNext,b=pcall(Mon.experienceForLevel,growth,level+1)
        if okCur and okNext and type(a)=="number" and type(b)=="number"
            and b>a then
          cur,nxt=a,b
        end
      end
    end
  end
  if not (cur and nxt) then
    local okCur,a=pcall(Growth.expForLevel,rate,level,data.growth_rates)
    local okNext,b=pcall(Growth.expForLevel,rate,level+1,data.growth_rates)
    if okCur and okNext and type(a)=="number" and type(b)=="number" and b>a then
      cur,nxt=a,b
    end
  end
  if not (cur and nxt and nxt>cur) then return 0 end
  return math.max(0,math.min(1,(total-cur)/(nxt-cur)))
end

-- Forward-declared because the Gen II service adapters are defined before the
-- shared screen helpers later in this file. Without these lexical bindings,
-- Lua resolves early PC closures as globals and crashes on first draw.
local screenFeatureEnabled
local goldScreenEnabled
local callOriginal

-- Colosseum renderer is embedded in a nested scope rather than loaded with
-- require("colosseum_ui"). Gen1Recomp does not add each mod root to Lua's
-- package.path, so sibling Lua files are not require-able by bare module name.
-- The nested scope also avoids Lua's 200 top-level-local limit.
GoldCompat.ColosseumUI = (function()
-- Standalone Colosseum battle-presentation renderer for Gen1Recomp.
-- Owns only battle HUD, menu, and message rendering.

local BattleState = require("src.battle.BattleState")
local EngineFont = require("src.render.Font")
local PokemonSprites = require("src.pokemon.Sprites")
local Assets = require("src.render.Assets")
local PaletteFX = require("src.render.PaletteFX")
local Growth = require("src.pokemon.Growth")

local activeBattle = nil
local activeSourceBattle = nil
local modRef = nil

local fonts = {}
local portraitCache = {}
local colosseumIconCache = {}
local colosseumIconsEnabled = true

-- Supplied Pokemon Colosseum portrait atlas, extracted into one file per species.
-- These portraits deliberately replace the experimental live Stadium camera:
-- the original Colosseum artists already solved the composition problem.
local COLOSSEUM_ICON_FRAMES = {
  [1]=2,
  [2]=2,
  [3]=1,
  [4]=1,
  [5]=1,
  [6]=1,
  [7]=1,
  [8]=1,
  [9]=1,
  [10]=1,
  [11]=1,
  [12]=1,
  [13]=1,
  [14]=1,
  [15]=1,
  [16]=1,
  [17]=1,
  [18]=1,
  [19]=1,
  [20]=1,
  [21]=1,
  [22]=1,
  [23]=1,
  [24]=1,
  [25]=1,
  [26]=1,
  [27]=1,
  [28]=1,
  [29]=1,
  [30]=1,
  [31]=1,
  [32]=1,
  [33]=1,
  [34]=1,
  [35]=2,
  [36]=2,
  [37]=1,
  [38]=1,
  [39]=2,
  [40]=1,
  [41]=1,
  [42]=1,
  [43]=1,
  [44]=2,
  [45]=1,
  [46]=1,
  [47]=1,
  [48]=1,
  [49]=1,
  [50]=1,
  [51]=1,
  [52]=1,
  [53]=1,
  [54]=1,
  [55]=1,
  [56]=1,
  [57]=1,
  [58]=1,
  [59]=1,
  [60]=1,
  [61]=1,
  [62]=1,
  [63]=1,
  [64]=1,
  [65]=2,
  [66]=1,
  [67]=1,
  [68]=1,
  [69]=1,
  [70]=1,
  [71]=1,
  [72]=1,
  [73]=1,
  [74]=1,
  [75]=1,
  [76]=1,
  [77]=1,
  [78]=1,
  [79]=1,
  [80]=1,
  [81]=1,
  [82]=1,
  [83]=2,
  [84]=1,
  [85]=2,
  [86]=1,
  [87]=1,
  [88]=1,
  [89]=1,
  [90]=1,
  [91]=1,
  [92]=1,
  [93]=1,
  [94]=1,
  [95]=1,
  [96]=1,
  [97]=1,
  [98]=1,
  [99]=1,
  [100]=1,
  [101]=1,
  [102]=2,
  [103]=2,
  [104]=2,
  [105]=2,
  [106]=1,
  [107]=1,
  [108]=1,
  [109]=1,
  [110]=1,
  [111]=1,
  [112]=1,
  [113]=1,
  [114]=1,
  [115]=1,
  [116]=1,
  [117]=1,
  [118]=1,
  [119]=1,
  [120]=1,
  [121]=2,
  [122]=1,
  [123]=1,
  [124]=1,
  [125]=1,
  [126]=1,
  [127]=1,
  [128]=1,
  [129]=1,
  [130]=1,
  [131]=1,
  [132]=1,
  [133]=1,
  [134]=1,
  [135]=1,
  [136]=1,
  [137]=1,
  [138]=1,
  [139]=1,
  [140]=1,
  [141]=1,
  [142]=1,
  [143]=1,
  [144]=1,
  [145]=1,
  [146]=1,
  [147]=1,
  [148]=1,
  [149]=1,
  [150]=1,
  [151]=1,
}

-- Corrected official Colosseum portraits for fossil entries that were
-- corrupted in the original imported sheet. They are stored as base64 text so
-- mod.read() can load them portably from either a directory or a .zip package.
local COLOSSEUM_ICON_CORRECTIONS = {
  [139]={normal="assets/portrait_corrections/139.png",
    shiny="assets/portrait_corrections/139_shiny.png"},
  [141]={normal="assets/portrait_corrections/141.png",
    shiny="assets/portrait_corrections/141_shiny.png"},
}

local function colosseumIconFrame(game,mon)
  local dex=nil
  if game and game.data and game.data.pokemon and mon and mon.species then
    local def=game.data.pokemon[mon.species]
    dex=def and tonumber(def.dex) or nil
  end
  if not dex or dex<1 or dex>251 then return nil end

  -- Every species in the base Gen 1 and Gen 2 Pokédex now has at least one
  -- authentic Colosseum frame. Preserve the extra animated Kanto frames where
  -- supplied, and use frame one for the complete #001-#251 baseline.
  local count=COLOSSEUM_ICON_FRAMES[dex] or 1
  if count<=0 then
    -- This exact species is absent from the supplied Colosseum icon sheet.
    -- Never substitute another Pokemon: use the engine's correct sprite fallback.
    return nil
  end

  local shiny=mon and (mon.shiny or mon.isShiny)
  -- Alternate sheet frames often change facing rather than pose. Keep every
  -- species stable across battle, Party, and PC -- except Gloom (#044), whose
  -- harmless little side-to-side gag is intentionally retained.
  local now=love.timer and love.timer.getTime and love.timer.getTime() or 0
  local frame=(dex==44 and count>1) and ((math.floor(now/0.34)%count)+1) or 1
  local key=("%d:%d:%d"):format(dex,frame,shiny and 1 or 0)

  local cached=colosseumIconCache[key]
  if cached~=nil then return cached or nil end
  if not (modRef and type(modRef.read)=="function") then
    colosseumIconCache[key]=false
    return nil
  end

  local corrected=COLOSSEUM_ICON_CORRECTIONS[dex]
  local correction=corrected and (shiny and corrected.shiny or corrected.normal)
  local relative=correction or ("assets/portraits/%03d_%d%s.png"):format(
    dex,frame,shiny and "_shiny" or ""
  )
  -- Launcher mod API v2 sandboxes love.filesystem. Load packaged artwork
  -- through the owning mod's asset facade so directory installs and ZIP mounts
  -- resolve identically and remain inside the loader's asset cache.
  if not (modRef.assets and type(modRef.assets.image)=="function") then
    colosseumIconCache[key]=false
    return nil
  end

  local okImg,img=pcall(modRef.assets.image,modRef.assets,relative)
  if not (okImg and img) then
    colosseumIconCache[key]=false
    return nil
  end
  if img.setFilter then img:setFilter("linear","linear") end
  colosseumIconCache[key]=img
  return img
end


local dramatic = {
  V=nil,
  OverworldBattle=nil,
  Stadium=nil,
  StadiumMon=nil,
  Voxel3D=nil,
  portraitCache={},
}

local function clamp(v,lo,hi)
  if v<lo then return lo end
  if v>hi then return hi end
  return v
end

local function stateExists(game,wanted)
  if not (game and game.stack and game.stack.states and wanted) then return false end
  for _,state in ipairs(game.stack.states) do
    if state==wanted then return true end
  end
  return false
end

local function resolvedSafariState(battle)
  return GoldCompat.resolvedSafariState(battle)
end

local function supportedBattle(battle)
  -- Ordinary battles can use the full Colosseum renderer. Safari battles have
  -- a different engine shape (no active player battler), so they deliberately
  -- stay off this ownership path. Resolve Safari through both the battle and
  -- save schemas here: checking battle.safari alone misclassifies Gen I Safari
  -- encounters whose engine-owned state lives only at game.save.safari.
  return battle and not resolvedSafariState(battle) and not battle.demo
end

local function shownHP(b)
  if not b then return 0 end
  return math.max(0,math.floor(b.shownHP or (b.mon and b.mon.hp) or 0))
end

local function maxHP(b)
  return math.max(1,math.floor(
    (b and b.mon and b.mon.stats and b.mon.stats.hp) or 1
  ))
end


-- Match Gen1Recomp's own level-threshold math rather than estimating an EXP
-- percentage. This keeps the Colosseum HUD in lockstep with level-ups and
-- custom/modded growth curves.
local function expProgress(game,b)
  local mon=b and b.mon
  if not (game and game.data and mon and mon.species) then return 0 end
  -- This is the EXP banner the Colosseum renderer actually draws. Gen II's
  -- normalized battle proxy carries the presentation-safe 64-pixel value;
  -- reading mon.experience here bypassed every queue latch and exposed the
  -- core's immediately committed reward on the KO move.
  if activeBattle and activeBattle.__gen2 and b==activeBattle.player
      and type(activeBattle.shownExp)=="number" then
    return clamp(activeBattle.shownExp/64,0,1)
  end
  return GoldCompat.experienceRatio(game.data,mon,GoldCompat.generation)
end

local function expBar(game,b,x,y,w,h,u)
  local g=love.graphics
  local ratio=expProgress(game,b)

  -- Colosseum-style thin blue meter beneath the HP readout.
  g.setColor(0.055,0.075,0.080,0.98)
  g.rectangle("fill",x,y,w,h)

  g.setColor(0.31,0.34,0.31,0.95)
  g.setLineWidth(math.max(1,0.8*u))
  g.rectangle("line",x,y,w,h)

  if ratio>0 then
    g.setColor(0.20,0.52,0.92,1)
    g.rectangle("fill",x+u,y+u,math.max(0,(w-2*u)*ratio),math.max(1,h-2*u))
  end
end

local function displayName(b)
  local raw=b and (
    b.name
    or (b.mon and b.mon.nickname)
    or (b.mon and b.mon.name)
    or (b.mon and b.mon.species)
  )
  return tostring(raw or "POKéMON"):upper()
end

local function font(size)
  local profile=GoldCompat.activeTextProfile()
  -- Honor the same global text-size/profile multiplier as every outer UI
  -- surface. Previously the embedded Colosseum battle renderer changed font
  -- FACE but silently ignored TEXT SIZE and each profile's sizeMul.
  size=math.max(7,math.floor(size*GoldCompat.userTextScale()+0.5))
  -- "context" means OG STYLE: preserve this call site's original nearest
  -- filter exactly. Every other profile picks its own filter uniformly,
  -- overriding whatever this call site used to hardcode.
  local filter=(profile.filterMode=="context") and "nearest" or profile.filterMode
  local cacheKey=profile.id..":"..filter..":"..size
  if fonts[cacheKey] then return fonts[cacheKey] end

  local ok,f
  if profile.fontPath then
    ok,f=pcall(love.graphics.newFont,profile.fontPath,size,"normal")
  else
    -- No path: Love2D's built-in default typeface (SYSTEM SANS profile).
    ok,f=pcall(love.graphics.newFont,size)
  end
  if not ok or not f then f=love.graphics.getFont() end
  if f and f.setFilter then pcall(f.setFilter,f,filter,filter) end
  fonts[cacheKey]=f
  return f
end

local function text(str,x,y,size,color,align,width)
  local g=love.graphics
  g.setFont(font(size))
  local s=tostring(str or "")

  -- Small dark offset gives the console UI the heavy Pokemon-text read
  -- without changing the imported font itself.
  if color and (color[1]+color[2]+color[3])>1.55 then
    g.setColor(0,0,0,0.44)
    if align and width then g.printf(s,x+1,y+1,width,align)
    else g.print(s,x+1,y+1) end
  end

  g.setColor(
    color and color[1] or 1,
    color and color[2] or 1,
    color and color[3] or 1,
    color and (color[4] or 1) or 1
  )
  if align and width then g.printf(s,x,y,width,align)
  else g.print(s,x,y) end
end

local function scaleForWindow()
  local sw,sh=love.graphics.getDimensions()
  return clamp(math.min(sw/1280,sh/720),0.72,1.75)
end

-- This renderer is declared before the standalone settings facade below, so
-- read the option directly from the mod reference here.  Every responsive
-- battle-layout branch below is gated through this helper: desktop geometry
-- remains byte-for-byte on the old path whenever Mobile Battle UI is off.
local function mobileBattleUIEnabled()
  local enabled=false
  pcall(function()
    enabled=modRef and modRef.options and modRef.options.get
      and modRef.options:get("mobileBattleUI")==true or false
  end)
  return enabled
end

-- Mobile-only bottom console dock. Commands, move selection, and battle
-- dialogue all terminate on the same safe horizontal line. This keeps the
-- battlefield itself clear while reserving the lower corners for touch input.
-- Desktop geometry never calls this helper.
local function mobileBattleConsoleBottom(sw,sh,u)
  local portrait=sh>sw
  -- Mobile battle panels should yield the battlefield to the sprites first.
  -- Reserve only the densest part of the touch-control band; on portrait
  -- displays this intentionally permits a small amount of panel/control
  -- overlap rather than ever letting the command surface climb into a mon.
  local reserve=clamp(
    sh*(portrait and 0.19 or 0.12),
    portrait and 170 or 80,
    portrait and 300 or 170
  )
  return sh-reserve
end

-- -----------------------------------------------------------------------
-- Portrait resolution
-- -----------------------------------------------------------------------

local function paletteKey(data,species)
  local colors=PaletteFX.monPal(data,species)
  if not colors then return "none",nil end
  local name=PaletteFX.monPalName(data,species) or "MON"
  if PaletteFX.usesGbcPack and PaletteFX.usesGbcPack() then
    name="redpp:"..name
  end
  return name,colors
end

local function enginePortrait(game,mon)
  if not (game and game.data and mon and mon.species) then return nil end

  local def=game.data.pokemon and game.data.pokemon[mon.species]
  local vanillaPath=def and def.spriteFront
  local path,trueColor=PokemonSprites.path(
    game.data,mon.species,"front",{mon=mon,kind="battle"}
  )
  -- Colosseum icons are optional presentation. When they are disabled the
  -- battle pod must still resolve the player's equipped sprite package, and
  -- finally the ROM front sprite if no package owns the species.
  path=path or vanillaPath
  if not path then return nil end
  if vanillaPath and path~=vanillaPath then trueColor=true end

  local palName,colors
  if game.data.gen2Palettes then
    local okPal,Palettes=pcall(require,"src.world.gen2.Palettes")
    colors=okPal and Palettes and Palettes.monColors
      and Palettes.monColors(game.data.gen2Palettes,mon.species,mon.shiny) or nil
    palName="gen2:"..tostring(mon.species)..":"..tostring(mon.shiny)
  else
    palName,colors=paletteKey(game.data,mon.species)
  end
  local key=path..":"..(trueColor and "true" or palName)
  local cached=portraitCache[key]
  if cached~=nil then return cached or nil end

  local image
  if trueColor or not colors or not (love.image and love.image.newImageData) then
    image=Assets.image(path)
  else
    local data=Assets.imageData(path)
    if data then
      data:mapPixel(function(_,_,r,g,b,a)
        if a==0 then return r,g,b,a end
        local col = r>0.83 and colors[1]
          or r>0.5 and colors[2]
          or r>0.17 and colors[3]
          or colors[4]
        return col[1]/255,col[2]/255,col[3]/255,a
      end)
      image=love.graphics.newImage(data)
    end
  end

  if image and image.setFilter then image:setFilter("nearest","nearest") end
  portraitCache[key]=image or false
  return image
end

function dramatic.connect()
  if dramatic.V then return true end
  if not (modRef and modRef.find) then return false end

  local handle=modRef.find("DRAMATIC_SHAPE")
  local V=handle and handle.exports and handle.exports.lib
  if not (V and type(V.require)=="function") then return false end

  local okO,OverworldBattle=pcall(V.require,"OverworldBattle")
  local okS,Stadium=pcall(V.require,"Stadium")
  local okM,StadiumMon=pcall(V.require,"StadiumMon")
  local okV,Voxel3D=pcall(V.require,"Voxel3D")
  if not (okO and OverworldBattle) then return false end

  dramatic.V=V
  dramatic.OverworldBattle=OverworldBattle
  dramatic.Stadium=(okS and Stadium) or nil
  dramatic.StadiumMon=(okM and StadiumMon) or nil
  dramatic.Voxel3D=(okV and Voxel3D) or nil
  return true
end


local function drawStadiumPortrait(game,mon,x,y,w,h)
  if not colosseumIconsEnabled then return false,false end
  -- The supplied Colosseum portrait owns the pod; no live model camera is used.
  -- This makes framing deterministic for every Kanto species and removes the
  -- performance cost / giant-Pokemon failures of render-to-texture portraits.
  local img=colosseumIconFrame(game,mon)
  if not img then return false,false end

  local iw,ih=img:getDimensions()
  if not (iw and ih and iw>0 and ih>0) then return false,false end

  -- Remove the 1px source gutter symmetrically. The previous 41px crop removed
  -- more from the right/bottom and then added a downward bias, which made the
  -- otherwise square portraits sit visibly off-center in Party pods.
  -- Two pixels per edge restores the reference's fuller portrait scale while
  -- retaining symmetric centering.
  local crop=math.min(2,math.floor(math.min(iw,ih)*0.045+0.5))
  local cw=math.max(1,iw-crop*2)
  local ch=math.max(1,ih-crop*2)
  local quad=love.graphics.newQuad(crop,crop,cw,ch,iw,ih)

  local scale=math.min(w/cw,h/ch)
  local dw,dh=cw*scale,ch*scale
  local dx=x+(w-dw)/2
  local dy=y+(h-dh)/2

  love.graphics.setColor(1,1,1,1)
  love.graphics.draw(img,quad,dx,dy,0,scale,scale)
  return true,true
end

local function visibleBounds(img)
  if not img then return nil end
  local ok,data=pcall(function() return img:newImageData() end)
  if not (ok and data) then return nil end

  local w,h=data:getDimensions()
  local x0,y0,x1,y1=w,h,-1,-1
  for yy=0,h-1 do
    for xx=0,w-1 do
      local _,_,_,a=data:getPixel(xx,yy)
      if a and a>0.03 then
        if xx<x0 then x0=xx end
        if yy<y0 then y0=yy end
        if xx>x1 then x1=xx end
        if yy>y1 then y1=yy end
      end
    end
  end
  if x1<x0 or y1<y0 then return nil end
  return x0,y0,x1-x0+1,y1-y0+1
end

local portraitBounds={}

local function drawSpritePortrait(game,mon,x,y,w,h)
  local img=enginePortrait(game,mon)
  if not img then return false end

  local key=tostring(img)
  local b=portraitBounds[key]
  if b==nil then
    local x0,y0,bw,bh=visibleBounds(img)
    b=x0 and {x0,y0,bw,bh} or false
    portraitBounds[key]=b
  end

  local iw,ih=img:getDimensions()
  local sx0,sy0,sw,sh=0,0,iw,ih
  if b then sx0,sy0,sw,sh=b[1],b[2],b[3],b[4] end

  local scale=math.min((w*0.96)/sw,(h*0.96)/sh)
  local dx=x+(w-sw*scale)/2
  local verticalBias=math.max(2,math.floor(h*0.045+0.5))
  local dy=y+(h-sh*scale)/2+verticalBias

  local quad=love.graphics.newQuad(sx0,sy0,sw,sh,iw,ih)
  love.graphics.setColor(1,1,1,1)
  love.graphics.draw(img,quad,dx,dy,0,scale,scale)
  return true
end

-- -----------------------------------------------------------------------
-- Colosseum-ish shape language
-- -----------------------------------------------------------------------

local function polygon(...)
  love.graphics.polygon("fill",...)
end

local function statusPlateShape(x,y,w,h,side,u)
  local g=love.graphics
  local cut=12*u
  local x0,x1=x,x+w
  local y0,y1=y,y+h

  -- Shadow.
  g.setColor(0,0,0,0.40)
  polygon(
    x0+cut+4*u,y0+6*u,
    x1-cut+4*u,y0+6*u,
    x1+4*u,y0+cut+6*u,
    x1-cut+4*u,y1+6*u,
    x0+cut+4*u,y1+6*u,
    x0+4*u,y1-cut+6*u,
    x0+4*u,y0+cut+6*u
  )

  -- Entire status assembly is one dark molded shell.
  g.setColor(0.10,0.115,0.115,0.98)
  polygon(
    x0+cut,y0,
    x1-cut,y0,
    x1,y0+cut,
    x1-cut,y1,
    x0+cut,y1,
    x0,y1-cut,
    x0,y0+cut
  )

  -- Slight inner face; no cream/Gen-3-style card backing.
  local inset=3*u
  g.setColor(0.17,0.185,0.18,0.98)
  polygon(
    x0+cut+inset,y0+inset,
    x1-cut-inset,y0+inset,
    x1-inset,y0+cut,
    x1-cut-inset,y1-inset,
    x0+cut+inset,y1-inset,
    x0+inset,y1-cut,
    x0+inset,y0+cut
  )

  -- Header bevel.
  g.setColor(0.28,0.30,0.285,1)
  polygon(
    x0+18*u,y0+6*u,
    x1-18*u,y0+6*u,
    x1-12*u,y0+13*u,
    x0+12*u,y0+13*u
  )

  -- Thin warm metallic ridge, closer to the GameCube-era UI.
  g.setColor(0.77,0.69,0.39,0.95)
  g.setLineWidth(math.max(1,1.4*u))
  g.line(x0+18*u,y0+4*u,x1-19*u,y0+4*u)
end

local function portraitPod(x,y,size,u)
  local g=love.graphics
  local c=8*u

  g.setColor(0,0,0,0.42)
  polygon(
    x+c+4*u,y+5*u,
    x+size-c+4*u,y+5*u,
    x+size+4*u,y+c+5*u,
    x+size-c+4*u,y+size+5*u,
    x+c+4*u,y+size+5*u,
    x+4*u,y+size-c+5*u,
    x+4*u,y+c+5*u
  )

  g.setColor(0.08,0.095,0.095,1)
  polygon(
    x+c,y,
    x+size-c,y,
    x+size,y+c,
    x+size-c,y+size,
    x+c,y+size,
    x,y+size-c,
    x,y+c
  )

  g.setColor(0.30,0.32,0.30,1)
  polygon(
    x+c+2*u,y+2*u,
    x+size-c-2*u,y+2*u,
    x+size-2*u,y+c,
    x+size-c-2*u,y+size-2*u,
    x+c+2*u,y+size-2*u,
    x+2*u,y+size-c,
    x+2*u,y+c
  )

  g.setColor(0.035,0.045,0.045,1)
  polygon(
    x+c+5*u,y+5*u,
    x+size-c-5*u,y+5*u,
    x+size-5*u,y+c,
    x+size-c-5*u,y+size-5*u,
    x+c+5*u,y+size-5*u,
    x+5*u,y+size-c,
    x+5*u,y+c
  )
end


local function portraitPodOverlay(x,y,size,u)
  local g=love.graphics
  local c=7*u

  -- Full plated side rails: these are filled foreground pieces, not just lines,
  -- so the portrait reads as seated inside the HUD instead of hanging over it.
  g.setColor(0.18,0.20,0.19,1)
  g.polygon("fill",
    x,y+c, x+c,y, x+4*u,y+4*u, x+4*u,y+size-4*u,
    x+c,y+size, x,y+size-c)
  g.polygon("fill",
    x+size,y+c, x+size-c,y, x+size-4*u,y+4*u,
    x+size-4*u,y+size-4*u, x+size-c,y+size, x+size,y+size-c)

  -- Firm top/bottom metal lips.
  g.setColor(0.30,0.32,0.30,1)
  g.setLineWidth(math.max(1,2.2*u))
  g.line(x+c,y+1*u, x+size-c,y+1*u)
  g.line(x+c,y+size-1*u, x+size-c,y+size-1*u)

  -- Continuous dark keyline immediately around the artwork opening.
  local i=3*u
  local ic=4*u
  g.setColor(0.025,0.030,0.030,1)
  g.setLineWidth(math.max(1,1.8*u))
  g.line(x+ic+i,y+i, x+size-ic-i,y+i)
  g.line(x+size-ic-i,y+i, x+size-i,y+ic+i)
  g.line(x+size-i,y+ic+i, x+size-i,y+size-ic-i)
  g.line(x+size-i,y+size-ic-i, x+size-ic-i,y+size-i)
  g.line(x+size-ic-i,y+size-i, x+ic+i,y+size-i)
  g.line(x+ic+i,y+size-i, x+i,y+size-ic-i)
  g.line(x+i,y+size-ic-i, x+i,y+ic+i)
  g.line(x+i,y+ic+i, x+ic+i,y+i)

  -- Bright outside highlight restores the complete plated silhouette.
  g.setColor(0.40,0.42,0.39,0.95)
  g.setLineWidth(math.max(1,1.0*u))
  g.line(x+c,y, x+size-c,y)
  g.line(x,y+c, x,y+size-c)
  g.line(x+size,y+c, x+size,y+size-c)
end

local function hpColor(ratio)
  if ratio<=0.20 then return 0.89,0.19,0.12 end
  if ratio<=0.50 then return 0.95,0.69,0.13 end
  return 0.16,0.78,0.30
end

local function hpBar(x,y,w,h,b,u)
  local g=love.graphics
  local cur,max=shownHP(b),maxHP(b)
  local ratio=clamp(cur/max,0,1)

  g.setColor(0.02,0.03,0.03,1)
  g.rectangle("fill",x,y,w,h)

  g.setColor(0.38,0.40,0.35,1)
  g.rectangle("fill",x+1*u,y+1*u,w-2*u,h-2*u)

  local r,gg,bb=hpColor(ratio)
  g.setColor(r,gg,bb,1)
  local fill=math.max(0,(w-4*u)*ratio)
  if fill>0 then
    g.rectangle("fill",x+2*u,y+2*u,fill,h-4*u)
  end

  g.setColor(0.88,0.86,0.62,0.9)
  g.rectangle("fill",x,y,2*u,h)
end


local function battleParty(battle,side)
  if not battle then return nil end

  -- Presentation proxies (notably Gold) keep the authoritative party tables on
  -- their source BattleState/core battle object. Resolve all three layers so
  -- the counter is identical in both generations and throughout switch phases.
  local source=battle.__gen3Source or battle
  local core=(source and source.battle) or battle.battle or battle
  local function partyValue(...)
    for i=1,select("#",...) do
      local value=select(i,...)
      if type(value)=="table" and #value>0 then return value end
    end
  end

  if side=="enemy" then
    -- Gold always stores a one-member enemyParty, including wild encounters.
    -- Party existence therefore cannot distinguish a trainer. The battle's
    -- authoritative wild flag can, so stop before constructing the rail.
    if (core and core.wild) or (source and source.wild) or battle.wild then
      return nil
    end
    local enemyParty=partyValue(
      battle.enemyParty,
      source and source.enemyParty,
      core and core.enemyParty,
      battle.enemy and battle.enemy.party,
      source and source.enemy and source.enemy.party,
      core and core.enemy and core.enemy.party,
      source and source.enemyTrainer and source.enemyTrainer.party,
      core and core.enemyTrainer and core.enemyTrainer.party)
    if enemyParty then return enemyParty end

    -- No authoritative opposing party means this is a wild encounter (or a
    -- transition frame without trainer-party data). Do not invent a one-ball
    -- party rail for wild Pokémon.
    return nil
  end

  local playerParty=partyValue(
    battle.playerParty,battle.party,
    source and source.playerParty,source and source.party,
    core and core.playerParty,core and core.party,
    battle.player and battle.player.party,
    source and source.player and source.player.party)
  if playerParty then return playerParty end
  if battle.game and battle.game.player and type(battle.game.player.party)=="table" then
    return battle.game.player.party
  end
  return nil
end

local function drawPartyBall(cx,cy,r,mon)
  local g=love.graphics
  if type(mon)=="table" and mon.mon then mon=mon.mon end

  if mon then
    local alive=(tonumber(mon.hp) or 0)>0
    if alive then
      g.setColor(0.90,0.18,0.14,1)
      g.arc("fill","pie",cx,cy,r,math.pi,math.pi*2)
      g.setColor(0.97,0.97,0.92,1)
      g.arc("fill","pie",cx,cy,r,0,math.pi)
    else
      g.setColor(0.34,0.35,0.33,0.90)
      g.circle("fill",cx,cy,r)
    end

    g.setColor(0.035,0.04,0.04,1)
    g.setLineWidth(math.max(1,r*0.22))
    g.circle("line",cx,cy,r)
    g.line(cx-r,cy,cx+r,cy)

    if alive then
      g.setColor(0.97,0.97,0.92,1)
      g.circle("fill",cx,cy,r*0.28)
      g.setColor(0.035,0.04,0.04,1)
      g.circle("line",cx,cy,r*0.28)
    end
  else
    g.setColor(0.34,0.35,0.33,0.52)
    g.setLineWidth(math.max(1,r*0.20))
    g.circle("line",cx,cy,r)
    g.line(cx-r,cy,cx+r,cy)
  end
end

local function drawPartyCounter(battle,side,x,y,u)
  local party=battleParty(battle,side)
  -- Wild fights have no opposing party counter. Player counter still draws
  -- when a party reference is available.
  if not party then return end

  local r=3.0*u
  local gap=8.2*u
  local width=gap*5+2*r

  -- A tiny dark rail under the balls reproduces the compact console read
  -- without adding another large box.
  love.graphics.setColor(0.06,0.07,0.065,0.82)
  love.graphics.rectangle("fill",x-3*u,y-1.2*u,width+6*u,2.4*u)

  for i=1,6 do
    drawPartyBall(x+(i-1)*gap,y,r,party[i])
  end
end

local function statusText(b)
  local s=b and (b.shownStatus or (b.mon and b.mon.status))
  if not s or s=="" or s=="OK" then return nil end
  return tostring(s):upper()
end

local function drawColosseumGenderGlyph(x,y,size,gender)
  if gender~="male" and gender~="female" then return false end
  local G=love.graphics
  size=math.max(8,size or 10)
  local r=size*0.24
  local cx,cy=x+r,y+r
  G.push("all")
  G.setLineWidth(math.max(1.3,size*0.15))
  if gender=="female" then
    G.setColor(0.95,0.20,0.52,1)
    G.circle("line",cx,cy,r)
    G.line(cx,cy+r,cx,cy+r+size*0.34)
    local yy=cy+r+size*0.22
    G.line(cx-size*0.16,yy,cx+size*0.16,yy)
  else
    G.setColor(0.02,0.63,0.84,1)
    G.circle("line",cx,cy,r)
    local x2,y2=cx+r+size*0.28,cy-r-size*0.28
    G.line(cx+r*0.65,cy-r*0.65,x2,y2)
    G.line(x2-size*0.18,y2,x2,y2)
    G.line(x2,y2,x2,y2+size*0.18)
  end
  G.pop()
  return true
end

local function drawStatusCard(game,battle,b,side)
  if not b then return end

  local sw,sh=love.graphics.getDimensions()
  local u=scaleForWindow()
  local mobile=mobileBattleUIEnabled()

  -- Colosseum reference proportions: long shallow status bar + square portrait
  -- attached to the OUTER edge. Desktop keeps the established geometry. Mobile
  -- is allowed to compress the cards to the viewport and, only when a display
  -- is too narrow for two readable cards, stagger them into two top rows.
  -- User-adjustable HUD geometry. These settings intentionally affect only
  -- the Pokémon status assemblies; command/move/dialogue geometry is separate.
  -- Gen II's tuned NORMAL is slightly tighter than Gen I because its native
  -- battle sprites sit higher in the field and were brushing the status plate.
  local widthMode,heightMode,portraitMode="normal","normal","normal"
  pcall(function()
    if modRef and modRef.options and modRef.options.get then
      widthMode=tostring(modRef.options:get("battleHudWidth") or "normal")
      heightMode=tostring(modRef.options:get("battleHudHeight") or "normal")
      portraitMode=tostring(modRef.options:get("battleHudPortrait") or "normal")
    end
  end)
  local widthMul=(widthMode=="compact" and 0.80)
    or (widthMode=="wide" and 1.10)
    or (widthMode=="x-wide" and 1.20) or 1.00
  local heightMul=(heightMode=="compact" and 0.84)
    or (heightMode=="tall" and 1.08)
    or (heightMode=="x-tall" and 1.18) or 1.00
  local portraitMul=(portraitMode=="small" and 0.82)
    or (portraitMode=="large" and 1.08)
    or (portraitMode=="x-large" and 1.18) or 1.00
  if GoldCompat and GoldCompat.generation=="gen2" then
    if widthMode=="normal" then widthMul=0.94 end
    if heightMode=="normal" then heightMul=0.92 end
    if portraitMode=="normal" then portraitMul=0.90 end
  end

  local cardW=430*u*widthMul
  local cardH=78*u*heightMul
  local portrait=78*u*portraitMul
  local gap=4*u
  local margin=34*u
  local y=24*u
  local mobileStacked=false

  if mobile then
    margin=clamp(sw*0.024,12,30)
    gap=clamp(4*u,3,7)

    -- Reserve a real center gutter before deciding the card width.  This makes
    -- the two HUD assemblies mathematically incapable of crossing each other
    -- on phone aspect ratios rather than relying on one reference resolution.
    local centerGutter=clamp(14*u,9,20)
    local maxSideCard=(sw-margin*2-portrait*2-gap*2-centerGutter)/2
    local minimumReadable=clamp(250*u,190,310)

    if maxSideCard>=minimumReadable then
      cardW=math.min(cardW,maxSideCard)
    else
      mobileStacked=true
      cardW=math.min(cardW,sw-margin*2-portrait-gap)
    end

    y=margin
    if mobileStacked and side=="enemy" then
      -- Leave room for the player's detached EXP rail before the second card.
      y=y+cardH+clamp(27*u,20,38)
    end
  end

  local cardX,podX
  if side=="player" then
    cardX=margin
    podX=cardX+cardW+gap
  else
    cardX=sw-margin-cardW
    podX=cardX-portrait-gap
  end
  -- The pod matches the status plate height exactly.
  local podY=y

  statusPlateShape(cardX,y,cardW,cardH,side,u)

  -- Battle portraits are independently cosmetic. Disabling this option removes
  -- the entire pod/badge without changing the HP/status plate geometry or the
  -- portrait/icon behavior used anywhere outside the battle HUD.
  local showBattlePortraits=true
  pcall(function()
    if modRef and modRef.options and modRef.options.get then
      showBattlePortraits=(modRef.options:get("battlePortraits") ~= false)
    end
  end)
  if showBattlePortraits then
    portraitPod(podX,podY,portrait,u)

    -- Pull the artwork back just enough to expose a firm 3u plated edge.
    local portraitPad=3*u
    local px=podX+portraitPad
    local py=podY+portraitPad
    local pw=portrait-portraitPad*2
    local ph=portrait-portraitPad*2

    local stadiumDrawn,stadiumOwns=drawStadiumPortrait(game,b.mon,px,py,pw,ph)
    if not stadiumDrawn and not stadiumOwns then
      drawSpritePortrait(game,b.mon,px,py,pw,ph)
    end

    -- Critical ordering: artwork first, visible bevel/keyline last.
    portraitPodOverlay(podX,podY,portrait,u)
  end

  local textLeft=cardX+18*u
  local textRight=cardX+cardW-18*u
  local name=displayName(b)
  local level=(b.mon and b.mon.level) or "?"

  text(name,textLeft,y+7*u*heightMul,18*u*clamp(heightMul,0.88,1.08),{0.94,0.94,0.86,1})
  do
    local gender=(b and b.gender) or (b and b.mon and b.mon.gender)
    if gender=="male" or gender=="female" then
      local nameW=font(18*u*clamp(heightMul,0.88,1.08)):getWidth(tostring(name or ""))
      drawColosseumGenderGlyph(math.min(textLeft+nameW+5*u,textLeft+218*u),
        y+10*u*heightMul,11*u*clamp(heightMul,0.90,1.08),gender)
    end
  end
  text("Lv "..tostring(level),textRight-104*u,y+7*u*heightMul,16*u*clamp(heightMul,0.88,1.08),
       {0.94,0.94,0.86,1},"right",104*u)

  text("HP",textLeft,y+33*u*heightMul,12*u*clamp(heightMul,0.90,1.08),{0.84,0.75,0.40,1})
  hpBar(textLeft+34*u,y+35*u*heightMul,cardW-68*u,11*u*clamp(heightMul,0.86,1.08),b,u)

  local st=statusText(b)
  if st then
    text(st,textLeft,y+54*u*heightMul,11*u*clamp(heightMul,0.90,1.08),{0.95,0.76,0.28,1})
  end

  text(("%d / %d"):format(shownHP(b),maxHP(b)),
       textRight-122*u,y+52*u*heightMul,11*u*clamp(heightMul,0.90,1.08),
       {0.80,0.82,0.75,1},"right",122*u)

  if side=="player" then
    -- Detached EXP banner: narrower than the HP plate and hanging slightly
    -- below it, echoing the layered status-box construction of older Pokémon UIs.
    local expX=cardX+18*u
    local expY=y+cardH-2*u
    local expW=cardW-54*u
    local expH=16*u

    love.graphics.setColor(0.055,0.070,0.068,0.97)
    love.graphics.rectangle("fill",expX,expY,expW,expH)

    -- Small left-pointing notch gives the banner a distinct silhouette instead
    -- of reading as another row inside the HP panel.
    love.graphics.polygon("fill",
      expX-8*u,expY,
      expX,expY,
      expX,expY+expH,
      expX-5*u,expY+expH-4*u
    )

    love.graphics.setColor(0.23,0.26,0.24,1)
    love.graphics.setLineWidth(math.max(1,0.8*u))
    love.graphics.line(expX,expY,expX+expW,expY)
    love.graphics.line(expX,expY+expH,expX+expW-5*u,expY+expH)

    text("EXP",expX+8*u,expY+3*u,8*u,{0.52,0.69,0.92,1})
    expBar(game,b,expX+34*u,expY+5*u,expW-44*u,5*u,u)
  end

  -- Party Poké Balls sit just above the plate like the GameCube HUD.
  local partyX
  if side=="player" then
    partyX=cardX+20*u
  else
    partyX=cardX+cardW-20*u-(8.2*u*5+6*u)
  end
  drawPartyCounter(battle,side,partyX,y-8*u,u)
end

-- Bottom panels use a beveled long-console shape rather than rounded app cards.
local function consolePanel(x,y,w,h,u)
  local g=love.graphics
  local c=13*u

  g.setColor(0,0,0,0.36)
  polygon(
    x+c+5*u,y+6*u,x+w-c+5*u,y+6*u,
    x+w+5*u,y+c+6*u,x+w-c+5*u,y+h+6*u,
    x+c+5*u,y+h+6*u,x+5*u,y+h-c+6*u,x+5*u,y+c+6*u
  )

  g.setColor(0.095,0.11,0.105,0.91)
  polygon(
    x+c,y,x+w-c,y,x+w,y+c,
    x+w-c,y+h,x+c,y+h,x,y+h-c,x,y+c
  )

  g.setColor(0.50,0.52,0.47,0.90)
  g.setLineWidth(math.max(1,1.4*u))
  g.line(x+c+3*u,y+3*u,x+w-c-3*u,y+3*u)
  g.line(x+4*u,y+c+2*u,x+4*u,y+h-c-2*u)
end

local function selector(x,y,h,u)
  love.graphics.setColor(0.90,0.23,0.13,1)
  love.graphics.polygon("fill",
    x+8*u,y+h*0.50,
    x,y+h*0.28,
    x,y+h*0.72)
end

local function commandRect()
  local sw,sh=love.graphics.getDimensions()
  local u=scaleForWindow()

  if mobileBattleUIEnabled() then
    local portrait=sh>sw
    -- Keep the four battle commands in the open center band of the display.
    -- Touch D-pads and A/B clusters normally rise from the lower corners; a
    -- viewport-relative bottom reserve keeps this panel above them on both
    -- portrait and landscape layouts without assuming one device resolution.
    local sideInset=clamp(sw*0.035,12,28)
    local w=math.min(sw-sideInset*2,
      clamp(sw*(portrait and 0.76 or 0.52),320,portrait and 820 or 960))
    local h=clamp(sh*(portrait and 0.085 or 0.12),84,portrait and 140 or 138)
    local dockBottom=mobileBattleConsoleBottom(sw,sh,u)
    local x=(sw-w)/2
    -- Bottom-align to the same dock used by move selection and dialogue.
    -- The panel therefore lives below the sprites instead of in the middle of
    -- the battlefield, while leaving the lower touch-control cluster exposed.
    local y=clamp(dockBottom-h,
      clamp(sh*0.55,190,760),sh-h-clamp(12*u,10,22))
    return {x=x,y=y,w=w,h=h,u=u,mobile=true}
  end

  local w=clamp(690*u,500,1010)
  local h=clamp(100*u,76,155)
  return {x=(sw-w)/2,y=sh-h-24*u,w=w,h=h,u=u}
end

local function drawCommandMenu(battle)
  if battle.phase~="menu" then return end

  local r=commandRect()
  local u=r.u
  consolePanel(r.x,r.y,r.w,r.h,u)

  local labels=resolvedSafariState(battle)
      and {"SNAG","BAIT","ROCK","RUN"}
      or {"FIGHT","POKéMON","BAG","RUN"}
  local padX=26*u
  local padY=12*u
  local gapX=16*u
  local cellW=(r.w-padX*2-gapX)/2
  local cellH=(r.h-padY*2)/2

  for i,label in ipairs(labels) do
    local col=(i-1)%2
    local row=math.floor((i-1)/2)
    local x=r.x+padX+col*(cellW+gapX)
    local y=r.y+padY+row*cellH
    local selected=battle.menuIndex==i

    if selected then
      love.graphics.setColor(0.33,0.35,0.32,0.80)
      love.graphics.polygon("fill",
        x+8*u,y+2*u,x+cellW-5*u,y+2*u,
        x+cellW,y+cellH-2*u,x+8*u,y+cellH-2*u)
      selector(x-4*u,y,cellH,u)
    end

    text(label,x+14*u,y+cellH*0.18,17*u,
      selected and {0.97,0.94,0.76,1} or {0.76,0.79,0.72,1})
  end
end

local function drawSafariBattleStatus(battle)
  local state=resolvedSafariState(battle)
  if not state then return end
  local r=commandRect()
  local u=r.u
  local h=clamp(28*u,24,44)
  local y=r.y-h-5*u
  local x=r.x
  local w=r.w

  love.graphics.setColor(0,0,0,0.30)
  roundedRect("fill",x+4*u,y+4*u,w,h,6*u)
  love.graphics.setColor(0.025,0.075,0.074,0.94)
  roundedRect("fill",x,y,w,h,6*u)
  love.graphics.setColor(0.25,0.55,0.52,0.96)
  love.graphics.setLineWidth(math.max(1,1.1*u))
  roundedRect("line",x,y,w,h,6*u)

  text("SAFARI ZONE",x+16*u,y+5*u,12*u,{0.46,1.00,0.66,1})
  local balls=math.max(0,tonumber(state.balls) or 0)
  local steps=math.max(0,tonumber(state.steps) or 0)
  text("SAFARI BALLS  "..tostring(balls).."     STEPS  "..tostring(steps),
    x+w-16*u,y+5*u,11*u,{0.78,0.88,0.83,1},"right",w*0.55)
end

local function moveDef(battle,mv)
  return battle and battle.data and battle.data.moves and mv
      and battle.data.moves[mv.id] or nil
end

local function moveName(battle,mv)
  local d=moveDef(battle,mv)
  local value=(d and d.name) or GoldCompat.humanizeIdentifier(mv and mv.id)
  return tostring(value~="" and value or "—"):upper()
end

local function moveType(battle,mv)
  local d=moveDef(battle,mv)
  local t=d and (d.type or d.moveType or d.damageType)
  if type(t)=="table" then t=t.name or t.id end
  local label=GoldCompat.humanizeIdentifier(t or "—"):upper()
  local cleaned=label:gsub(" TYPE$","")
  return cleaned
end

local function movePP(battle,mv)
  local d=moveDef(battle,mv)
  return tonumber(mv and mv.pp) or 0,
    tonumber(d and d.pp) or tonumber(mv and mv.pp) or 0
end

local function drawMoveMenu(battle)
  if battle.phase~="moveSelect"
      or not (battle.player and battle.player.curMoves) then
    return
  end

  local sw,sh=love.graphics.getDimensions()
  local u=scaleForWindow()
  local mobile=mobileBattleUIEnabled()
  local w,h,x,y

  if mobile then
    local portrait=sh>sw
    local sideInset=clamp(sw*0.035,12,28)
    w=math.min(sw-sideInset*2,
      clamp(sw*(portrait and 0.84 or 0.62),360,portrait and 940 or 1180))
    h=clamp(sh*(portrait and 0.105 or 0.16),100,175)
    local dockBottom=mobileBattleConsoleBottom(sw,sh,u)
    x=(sw-w)/2
    -- Move selection occupies the exact lower console lane used by battle
    -- dialogue. Its top edge changes with panel height, but the bottom edge is
    -- fixed, preventing the menu from covering either combatant sprite.
    y=clamp(dockBottom-h,
      clamp(sh*0.54,185,750),sh-h-clamp(12*u,10,22))
  else
    w=clamp(820*u,590,1180)
    h=clamp(132*u,100,200)
    x=(sw-w)/2
    y=sh-h-22*u
  end

  consolePanel(x,y,w,h,u)

  -- Selected-mon tab protrudes from the upper edge like the GameCube UI.
  -- On mobile keep that rise shallow so the tab cannot become the one piece
  -- that reaches back into the battlefield after the main panel is docked.
  local tabRise=(mobile and 9 or 17)*u
  love.graphics.setColor(0.19,0.21,0.20,0.95)
  love.graphics.polygon("fill",
    x+25*u,y-tabRise,x+205*u,y-tabRise,
    x+218*u,y,x+18*u,y)
  text(displayName(battle.player),x+37*u,y-tabRise+2*u,13*u,
    {0.85,0.86,0.78,1})

  local moves=battle.player.curMoves
  local padX=25*u
  local top=y+12*u
  local gapX=14*u
  local cellW=(w-padX*2-gapX)/2
  local cellH=(h-24*u)/2

  for i=1,4 do
    local mv=moves[i]
    local col=(i-1)%2
    local row=math.floor((i-1)/2)
    local cx=x+padX+col*(cellW+gapX)
    local cy=top+row*cellH
    local selected=battle.moveIndex==i

    if selected then
      love.graphics.setColor(0.32,0.34,0.31,0.82)
      love.graphics.polygon("fill",
        cx+7*u,cy+2*u,cx+cellW-5*u,cy+2*u,
        cx+cellW,cy+cellH-3*u,cx+7*u,cy+cellH-3*u)
      selector(cx-4*u,cy,cellH,u)
    end

    if mv then
      local pp,maxpp=movePP(battle,mv)
      text(moveName(battle,mv),cx+14*u,cy+4*u,14*u,
        selected and {0.98,0.94,0.73,1} or {0.79,0.81,0.74,1})
      text(moveType(battle,mv),cx+14*u,cy+24*u,10*u,{0.52,0.55,0.50,1})
      text(("PP %d/%d"):format(pp,maxpp),
        cx+cellW-101*u,cy+23*u,10*u,{0.63,0.65,0.59,1},"right",91*u)
    else
      text("—",cx+14*u,cy+9*u,14*u,{0.46,0.48,0.44,1})
    end
  end
end

local function messageLinesForBattle(battle)
  if not battle then return {} end

  -- Prefer the unified mod's existing battle-message adapter. It already
  -- understands Gen 1's rolling/typewriter window and Gen 2's Gold message
  -- proxy, so Colosseum does not invent a second interpretation of battle flow.
  if GoldCompat and type(GoldCompat.messagePageFullLines)=="function" then
    local ok,lines=pcall(GoldCompat.messagePageFullLines,battle)
    if ok and type(lines)=="table" and #lines>0 then
      return lines
    end
  end

  -- Gold presentation proxies carry the active sentence directly.
  local direct=battle.message
      or (battle.current and battle.current.text)
  if direct and tostring(direct)~="" then
    local out={}
    for line in tostring(direct):gmatch("[^\n\v]+") do
      out[#out+1]=line
    end
    if #out==0 then out[1]=tostring(direct) end
    return out
  end

  -- Last-resort compatibility with the legacy string-based `shown` payload.
  local out={}
  for _,line in ipairs(battle.shown or {}) do
    if type(line)=="string" then
      out[#out+1]=line
    elseif type(line)=="table" then
      local chars={}
      for _,v in ipairs(line) do
        if type(v)=="string" then chars[#chars+1]=v end
      end
      if #chars>0 then out[#out+1]=table.concat(chars) end
    end
  end
  return out
end

local function drawConsoleMessageLines(lines,waiting,frame)
  if type(lines)~="table" or #lines==0 then return false end
  local sw,sh=love.graphics.getDimensions()
  local u=scaleForWindow()
  local mobile=false
  pcall(function()
    mobile=modRef and modRef.options and modRef.options.get
      and modRef.options:get("mobileBattleUI")==true or false
  end)
  local portrait=sh>sw

  -- Dialogue deliberately occupies the same centered lower-stage footprint as
  -- the Colosseum move panel. Battle commands disappear while messages own the
  -- flow, leaving one consistent GameCube-style conversation surface.
  local hasSecond=lines[2] and tostring(lines[2])~=""
  local lineSize=clamp(16*u,13,26)
  local lineGap=clamp(27*u,22,42)
  local mobilePadX=clamp(22*u,16,30)
  local mobilePadY=clamp(11*u,8,16)
  local maxLineW=0
  if mobile then
    local f=font(lineSize)
    for i=1,math.min(2,#lines) do
      maxLineW=math.max(maxLineW,f:getWidth(tostring(lines[i] or "")))
    end
  end
  local w=mobile
      and clamp(maxLineW+mobilePadX*2+34*u,
        250,sw*(portrait and 0.84 or 0.58))
      or clamp(820*u,590,1180)
  local textBlockH=hasSecond and (lineGap+lineSize) or lineSize
  local h=mobile
      and clamp(textBlockH+mobilePadY*2,48,96)
      or clamp(108*u,82,165)
  local x=(sw-w)/2
  local y
  if mobile then
    -- Dialogue is the anchor for the mobile lower-console lane. Commands and
    -- moves share this same bottom edge so transitions never jump upward over
    -- the Pokémon sprites.
    y=mobileBattleConsoleBottom(sw,sh,u)-h
  else
    y=sh-h-22*u
  end

  consolePanel(x,y,w,h,u)

  local padX=mobile and mobilePadX or 30*u
  local padY=mobile and mobilePadY or 18*u
  local contentW=w-padX*2
  local color={0.88,0.90,0.82,1}

  -- Use a maximum of the current two-line battle page, matching native battle
  -- pacing. Longer source strings remain engine-owned and advance normally.
  text(tostring(lines[1] or ""),x+padX,y+padY,lineSize,
    color,"left",contentW)
  if lines[2] and tostring(lines[2])~="" then
    text(tostring(lines[2]),x+padX,y+padY+lineGap,lineSize,
      color,"left",contentW)
  end

  -- Match the rest of the mod's battle continue semantics without taking input
  -- ownership away from either generation.
  if waiting and ((tonumber(frame) or 0)%60)<30 then
    love.graphics.setColor(0.90,0.23,0.13,1)
    local cx=x+w-34*u
    local cy=y+h-22*u
    love.graphics.polygon("fill",
      cx,cy,cx+12*u,cy,cx+6*u,cy+8*u)
  end
  -- render.hud runs after Gen I has finished compositing the frame. Unlike the
  -- battle renderer, the overworld dialogue caller does not surround this
  -- shared helper with push("all")/pop(). Leaving the continuation cursor's
  -- red color active therefore tinted the NEXT frame's world canvas red. The
  -- TextBox blink counter advances on the logic clock, so 4x speed turned that
  -- leaked state into the rapid full-screen red strobe seen in captures.
  love.graphics.setColor(1,1,1,1)
  return true
end

local function drawMessage(battle)
  if battle.phase~="messages" then return end

  local lines=messageLinesForBattle(battle)
  if #lines==0 then return end

  return drawConsoleMessageLines(lines,
    battle.msgWaiting or battle.msgPrompt
      or (battle.current and battle.current.done),
    battle.frame)
end

local function drawBattlePresentation(game)
  local battle=activeBattle
  local source=activeSourceBattle or battle
  if not supportedBattle(battle) or not stateExists(game,source) then
    activeBattle=nil
    activeSourceBattle=nil
    return false
  end

  love.graphics.push("all")

  if battle.player and not battle.showPlayerBack then
    drawStatusCard(game,battle,battle.player,"player")
  end
  if battle.enemy and not battle.showEnemyTrainer
      and not battle.enemySendingOut then
    drawStatusCard(game,battle,battle.enemy,"enemy")
  end

  drawMessage(battle)
  drawSafariBattleStatus(battle)
  drawCommandMenu(battle)
  drawMoveMenu(battle)

  love.graphics.pop()
  return true
end


local function drawSafariPresentation(game,battle,source)
  -- The overlay payload is not guaranteed to be the exact table stored on the
  -- stack (Gen I can pass its core battle object). Foreground/lifetime checks
  -- are already performed by the outer HUD owner, so requiring table identity
  -- here incorrectly suppresses the entire Safari presentation.
  if not battle or not resolvedSafariState(battle) then
    return false
  end

  -- Safari is presentation-only here: native BattleState remains authoritative
  -- for encounter setup, catch odds, bait/rock, flee, counters, and naming.
  -- We only draw the pieces Safari actually owns, avoiding every player-battler
  -- assumption made by the full battle renderer.
  battle.__colosseumSafariRenderErrors=
    battle.__colosseumSafariRenderErrors or {}

  -- Never wrap the entire Safari frame in one push. If one component raises,
  -- the outer renderer catches it and the matching pop would be skipped,
  -- leaking a graphics state every frame until Pipelines.lua aborts at maximum
  -- stack depth. Each component now owns a guaranteed push/pop pair instead.
  local function component(name,draw)
    local depthBefore=nil
    if type(love.graphics.getStackDepth)=="function" then
      local okDepth,value=pcall(love.graphics.getStackDepth)
      if okDepth then depthBefore=value end
    end
    love.graphics.push("all")
    local ok,err=pcall(draw)
    if depthBefore~=nil then
      -- Also unwind a nested component push if that component itself raised
      -- before restoring its graphics state.
      while love.graphics.getStackDepth()>depthBefore do
        love.graphics.pop()
      end
    else
      love.graphics.pop()
    end
    if not ok and not battle.__colosseumSafariRenderErrors[name] then
      battle.__colosseumSafariRenderErrors[name]=tostring(err)
      if modRef and modRef.log then
        modRef.log("error","Colosseum Safari "..name.." failed: "..tostring(err))
      end
    end
    return ok
  end

  component("enemy HUD",function()
    if battle.enemy and not battle.showEnemyTrainer
        and not battle.enemySendingOut then
      drawStatusCard(game,battle,battle.enemy,"enemy")
    end
  end)
  component("message",function() drawMessage(battle) end)
  component("status rail",function() drawSafariBattleStatus(battle) end)
  component("command menu",function() drawCommandMenu(battle) end)
  return true
end

local ColosseumUI = {}

function ColosseumUI.install(mod)
  modRef=mod
  dramatic.connect()
  if mod and mod.log then
    mod.log:info("Colosseum battle UI renderer loaded")
  end
end

function ColosseumUI.draw(game,presentationBattle,sourceBattle)
  if not supportedBattle(presentationBattle) then return false end
  activeBattle=presentationBattle
  activeSourceBattle=sourceBattle or presentationBattle
  return drawBattlePresentation(game) and true or false
end

function ColosseumUI.drawSafari(game,presentationBattle,sourceBattle)
  if not GoldCompat.safariPresentationEnabled() then return false end
  if not presentationBattle or not resolvedSafariState(presentationBattle) then
    return false
  end
  local source=sourceBattle or presentationBattle
  activeBattle=presentationBattle
  activeSourceBattle=source
  return drawSafariPresentation(game,presentationBattle,source) and true or false
end

function ColosseumUI.setIconsEnabled(enabled)
  colosseumIconsEnabled=enabled~=false
end

function ColosseumUI.drawPortrait(game,mon,x,y,w,h)
  return drawStadiumPortrait(game,mon,x,y,w,h)
end

function ColosseumUI.drawDialogue(lines,waiting,frame)
  return drawConsoleMessageLines(lines,waiting,frame)
end

function ColosseumUI.supported(battle)
  return supportedBattle(battle)
end

return ColosseumUI

end)()

local DexUI = { active=nil, action=nil, entry=nil }

function GoldCompat.isGen2Game(game)
  if not game then return GoldCompat.generation=="gen2" end
  local data=game.data
  return GoldCompat.generation=="gen2"
      or (data and (data.gen2MenuGfx or data.gen2Icons or data.gen2Sprites
          or data.gen2Pokedex))
      or game.generation==2
      or tostring(game.version or ""):lower()=="gold"
end

function GoldCompat.isGen2BattleState(state)
  return state and state.battle and state.game
      and type(state.shownHp)=="table"
      and type(state.shownMon)=="table"
end

function GoldCompat.sourceBattleState(battle)
  return battle and (battle.__gen3Source or battle) or nil
end

function GoldCompat.goldBattlePhase(state)
  local phase=state and state.phase or nil
  if phase=="moves" or phase=="choose-forget" then return "moveSelect" end
  if phase=="menu" then return "menu" end
  if phase=="done" or phase=="submenu" then return phase end
  -- Gold carries intro, resolving, level/move-learning questions, switch
  -- questions and refusal lines through one message surface.
  return "messages"
end

function GoldCompat.goldStatus(mon)
  if not mon then return nil end
  if (mon.hp or 0)<=0 then return "FNT" end
  local s=tostring(mon.status or ""):lower()
  if s=="" or s=="nil" then return nil end
  if s=="poison" or s=="toxic" or s=="psn" then return "PSN" end
  if s=="burn" or s=="brn" then return "BRN" end
  if s=="freeze" or s=="frz" then return "FRZ" end
  if s=="paralyze" or s=="paralysis" or s=="par" then return "PAR" end
  if s=="sleep" or s=="slp" then return "SLP" end
  return tostring(mon.status):upper()
end

function GoldCompat.presentBattleState(state)
  if not GoldCompat.isGen2BattleState(state) then return state end
  local core=state.battle or {}
  local data=state.game and state.game.data or {}
  local shown=state.shownMon or {}
  local shownHp=state.shownHp or {}

  -- advanceQueue owns the explicit lethal-damage -> experience-prompt latch.
  -- Do not infer timing from live HP/expAnim here: both core values may change
  -- before the player has seen the faint and reward messages.
  state.__gen3uiExpDisplayPixels=state.__gen3uiKoExpHold~=nil
      and state.__gen3uiKoExpHold or (state.shownExp or 0)

  local function side(name)
    local live=core[name]
    local mon=shown[name] or live
    if not mon then return nil end

    local gender=(mon and mon.gender) or (live and live.gender)
    if gender~="male" and gender~="female" then
      local source=live or mon
      local def=source and source.species and data.pokemon
        and data.pokemon[source.species]
      if def and source and source.dvs then
        local okMon,Mon=pcall(require,"src.battle.gen2.Mon")
        if okMon and Mon and type(Mon.gender)=="function" then
          local ok,value=pcall(Mon.gender,def,source.dvs,{
            species=source.species, level=source.level,
          })
          if ok and (value=="male" or value=="female") then gender=value end
        end
      end
    end

    return {
      mon=mon,
      live=live,
      gender=gender,
      shownHP=shownHp[name] ~= nil and shownHp[name] or mon.hp,
      shownStatus=GoldCompat.goldStatus(mon),
      curMoves=mon.moves or {},
      disabledSlot=state.disabledSlot or state.disabledMoveSlot,
      fainted=(mon.hp or 0)<=0,
    }
  end

  local phase=GoldCompat.goldBattlePhase(state)
  local proxy={
    __gen2=true,
    __gen3Source=state,
    game=state.game,
    data=data,
    player=side("player"),
    enemy=side("enemy"),
    party=core.party,
    playerParty=core.party or state.playerParty,
    enemyParty=core.enemyParty or state.enemyParty,
    phase=phase,
    menuIndex=state.menuIndex or 1,
    moveIndex=(state.phase=="choose-forget" and state.forgetIndex)
        or state.moveIndex or 1,
    moveSwapIndex=state.moveSwapIndex,
    safari=(type(state.safari)=="table" and state.safari)
      or (state.game and state.game.save and type(state.game.save.safari)=="table"
        and state.game.save.safari) or nil,
    demo=state.tutorial,
    frame=state.frame or 0,
    showEnemyTrainer=state.showEnemyTrainer,
    showPlayerBack=state.showPlayerTrainer,
    enemySendingOut=false,
    introBalls=false,
    introSlide=0,
    shownExp=state.__gen3uiExpDisplayPixels
        or state.shownExp or 0,
    shownLevel=state.shownLevel,
    message=state.message,
    messageTimer=state.messageTimer or 0,
    messagePages=state.messagePages,
    current=state.message and {
      text=state.message,
      done=(state.messageTimer or 0)<=0,
    } or nil,
    shown={},
    msgWaiting=(state.message and (state.messageTimer or 0)<=0) or false,
    msgPrompt=(state.phase=="ask-nickname" or state.phase=="ask-forget"
        or state.phase=="stop-learning" or state.phase=="ask-shift"),
  }
  return proxy
end

function GoldCompat.openGoldUISettings(game)
  if not (game and game.stack) then return end
  local okChrome,Chrome=pcall(require,"src.ui.gen2.Chrome")
  if not (okChrome and Chrome) then return end

  local state={
    game=game,
    isOpaque=false,
    index=1,
    scroll=0,
    rows=DexUI.rowsForGame(game),
    __gen3uiGoldOverlayKind="ui-settings",
  }

  function state:update()
    local input=self.game and self.game.input
    if not input then return end
    local count=#self.rows
    if input:wasPressed("up") then
      self.index=self.index>1 and self.index-1 or count
    elseif input:wasPressed("down") then
      self.index=self.index<count and self.index+1 or 1
    elseif input:wasPressed("a") then
      DexUI.activateUIRow(self.game,self.rows[self.index])
    elseif input:wasPressed("b") or input:wasPressed("start") then
      self.game.stack:pop()
      return
    end
    local visible=7
    if self.index<=self.scroll then self.scroll=self.index-1 end
    if self.index>self.scroll+visible then self.scroll=self.index-visible end
    self.scroll=math.max(0,math.min(self.scroll,math.max(0,count-visible)))
  end

  function state:draw()
    -- Suppress native Gen 2 Chrome. This state renders through widescreen using
    -- the same cream/dark/blue language as Gold OPTIONS.
    return
  end

  function state:drawsWidescreen() return false end
  function state:wantsFillScale() return false end
  function state:drawWidescreen() return end

  game.stack:push(state)
end
local spritePortraitResolver = (function()
  -- One self-contained resolver scope. Keeping these locals inside this
  -- anonymous function avoids Lua's 200-local limit for the main mod chunk.
  local PokemonSprites_ = require("src.pokemon.Sprites")
  local Assets_ = require("src.render.Assets")
  local PaletteFX_ = require("src.render.PaletteFX")

  local R = {
    mod = nil,
    cache = {},
    ba = nil,
    baV = nil,
    baSets = {},
  }

  local function settingValue(setting)
    if setting and type(setting.get) == "function" then
      local ok, value = pcall(setting.get, setting)
      if ok then return value end
    end
    return nil
  end

  local function connectBattleArts()
    if R.ba and R.baV then return R.ba, R.baV end
    local mod = R.mod
    if not (mod and mod.find) then return nil end

    local okHandle, handle = pcall(mod.find, "BATTLE_ART_VOXEL_FORK")
    if not (okHandle and handle and type(handle.exports) == "table") then
      return nil
    end

    local V = handle.exports.lib
    if type(V) ~= "table" or type(V.require) ~= "function" then return nil end

    local okBA, BA = pcall(V.require, "BattleArt")
    if not (okBA and type(BA) == "table") then return nil end

    R.ba, R.baV = BA, V
    return BA, V
  end

  local function battleArtsSet(V, generation)
    local cached = R.baSets[generation]
    if cached ~= nil then return cached or nil end
    if type(V.data) ~= "function" then
      R.baSets[generation] = false
      return nil
    end
    local ok, data = pcall(V.data, "animated_battle_sprites_" .. generation)
    R.baSets[generation] = (ok and data) or false
    return ok and data or nil
  end

  local function prepareBattleArtsFrame(BA, data)
    if type(BA.prepareData) == "function" then
      local displayMode = "default"
      if type(BA.displayMode) == "function" then
        local okMode, mode = pcall(BA.displayMode)
        if okMode and mode then displayMode = mode end
      end
      local ok, image = pcall(BA.prepareData, data, displayMode)
      if ok and image then return image end
    end

    local ok, image = pcall(love.graphics.newImage, data)
    if ok and image and image.setFilter then image:setFilter("nearest","nearest") end
    return ok and image or nil
  end

  local function battleArtsImageData(V, relative)
    local owner = V and V.mod
    if not (owner and owner.assets and type(owner.assets.path) == "function") then
      return nil
    end

    -- Cross-mod sprite reads also have to honor the v2 sandbox. Ask Battle
    -- Arts for its own safe asset path, then let love.image decode that file.
    local okPath, full = pcall(owner.assets.path, owner.assets, relative)
    if not (okPath and type(full) == "string") then return nil end
    local okData, data = pcall(love.image.newImageData, full)
    return okData and data or nil
  end

  local function battleArtsAnimatedFrame(BA, V, species, generation)
    local set = battleArtsSet(V, generation)
    local def = set and set[tostring(species or ""):upper()]
    def = def and def.front
    if not (def and def.image) then return nil end

    local key = "ba:read:" .. tostring(generation) .. ":" .. tostring(species)
    local cached = R.cache[key]
    if cached ~= nil then
      return cached or nil
    end

    local image
    local ok = pcall(function()
      -- Read the PNG through Battle Arts' own exported mod API object.
      -- Loader:_api binds mod:read() to that mod's path, so no cross-mod VFS
      -- path probing or filesystem getInfo call is involved.
      local sheet = battleArtsImageData(V, def.image)
      if not sheet then return end

      local sw, sh = sheet:getDimensions()
      local x, y, width, height
      local cells = def.cells
      local autoColumns = tonumber(def.autoColumns)

      if cells and cells[1] then
        local c = cells[1]
        x, y = tonumber(c.x) or 0, tonumber(c.y) or 0
        width, height = tonumber(c.width), tonumber(c.height)
      elseif autoColumns then
        if autoColumns < 1 or autoColumns % 1 ~= 0 or sw % autoColumns ~= 0 then return end
        x, y = 0, 0
        width, height = sw / autoColumns, sh
      else
        x, y = 0, 0
        width, height = tonumber(def.width), tonumber(def.height)
      end

      if not (width and height and width >= 1 and height >= 1) then return end
      x, y = math.floor(x + 0.5), math.floor(y + 0.5)
      width, height = math.floor(width + 0.5), math.floor(height + 0.5)
      if x < 0 or y < 0 or x + width > sw or y + height > sh then return end

      local frame = love.image.newImageData(width, height)
      frame:paste(sheet, 0, 0, x, y, width, height)
      image = prepareBattleArtsFrame(BA, frame)
    end)

    R.cache[key] = (ok and image) or false
    return ok and image or nil
  end

  local function battleArtsPortrait(mon)
    local BA, V = connectBattleArts()
    if not (BA and V and mon and mon.species) then return nil end

    local mode = settingValue(BA.setting)
    if mode == "rom" then return nil end

    local species = mon.species
    local function slug(value)
      local name = tostring(value or ""):lower()
      name = name:gsub("♀", "-f"):gsub("♂", "-m")
      name = name:gsub("['’%.]", "")
      name = name:gsub("[^%w]+", "-"):gsub("^-+", ""):gsub("-+$", "")
      return name
    end
    local name = slug(species)

    local function preparedRelative(relative)
      local key = "ba:file:" .. relative
      local cached = R.cache[key]
      if cached ~= nil then return cached or nil end
      local data = battleArtsImageData(V, relative)
      local image = data and prepareBattleArtsFrame(BA, data) or nil
      R.cache[key] = image or false
      return image
    end

    local generation = settingValue(BA.frontAnimationSetting)

    -- Battle Arts' MODDED mode only owns a picture when its matching shiny
    -- override exists; otherwise normal pokemon.sprite ownership wins.
    if type(BA.prefersModded) == "function" then
      local okModded, modded = pcall(BA.prefersModded)
      if okModded and modded then
        if mode == "animated" and tostring(generation or ""):match("^gen[1-5]$") then
          return preparedRelative(
            "assets/battle/front-animated/shiny/" .. generation .. "/" .. name .. ".png")
        elseif mode == "static" then
          return preparedRelative(
            "assets/battle/front-static/shiny/" .. name .. ".png")
        end
        return nil
      end
    end

    if mode == "static" then
      return preparedRelative("assets/battle/front-static/" .. name .. ".png")
    end

    if mode ~= "animated" then return nil end
    if not tostring(generation or ""):match("^gen[1-5]$") then return nil end

    if generation == "gen1" then
      return preparedRelative(
        "assets/battle/front-animated/gen1/" .. name .. ".png")
    end

    return battleArtsAnimatedFrame(BA, V, species, generation)
  end

  local function enginePalette(data, species, mon)
    -- Gold's normal front sprites are grayscale source art plus the species'
    -- native two-color battle palette. Use the same Gen 2 palette resolver
    -- the battle renderer uses, instead of the Gen 1/SGB mon palette helper.
    if GoldCompat.generation=="gen2" then
      local okPal,Palettes=pcall(require,"src.world.gen2.Palettes")
      -- IMPORTANT: Gold's Pokémon battle palettes live in game.data.gen2Palettes.
      -- This is the exact table src/ui/gen2/BattleState.lua stores as
      -- self.palettes before calling Palettes.monColors().
      local paletteData=data and data.gen2Palettes
      local colors=okPal and Palettes
        and type(Palettes.monColors)=="function"
        and Palettes.monColors(paletteData,species,mon and mon.shiny)
        or nil
      if colors then
        return "gen2-native-pal:"..tostring(species)..":"..tostring(mon and mon.shiny),colors
      end
    end

    local colors = PaletteFX_.monPal(data, species)
    if not colors then return "none", nil end
    local name = PaletteFX_.monPalName(data, species) or "MON"
    if PaletteFX_.usesGbcPack() then name = "redpp:" .. name end
    return name, colors
  end

  -- Gold's extracted ROM fronts are opaque 2bpp-style images: colour 0 is a
  -- white paper field, not alpha.  Remove only the light-neutral component
  -- connected to the image edge BEFORE palette mapping.  Doing this here is
  -- important: once colour 0 has been converted through the species palette,
  -- later menu renderers can no longer reliably distinguish the ROM matte from
  -- legitimate light markings inside the Pokemon silhouette.
  local function stripGen2NativeMatte(imageData)
    if GoldCompat.generation ~= "gen2" or not imageData then return imageData end
    local iw, ih = imageData:getDimensions()
    if not (iw and ih and iw > 0 and ih > 0) then return imageData end

    local qx, qy, seen = {}, {}, {}
    local head, tail = 1, 0
    local function removable(px, py)
      local r,g,b,a = imageData:getPixel(px,py)
      a = a or 0
      if a < 0.08 then return true end
      local hi = math.max(r or 0,g or 0,b or 0)
      local lo = math.min(r or 0,g or 0,b or 0)
      -- Raw Gold front sprites are hard-edged, so a conservative near-white
      -- threshold removes the paper field without eating pale body pixels.
      return a > 0.70 and lo > 0.82 and hi - lo < 0.12
    end
    local function enqueue(px,py)
      if px < 0 or py < 0 or px >= iw or py >= ih then return end
      local key = py * iw + px + 1
      if seen[key] or not removable(px,py) then return end
      seen[key] = true
      tail = tail + 1
      qx[tail], qy[tail] = px, py
    end

    for px=0,iw-1 do enqueue(px,0); enqueue(px,ih-1) end
    for py=1,ih-2 do enqueue(0,py); enqueue(iw-1,py) end
    while head <= tail do
      local px,py = qx[head],qy[head]
      head = head + 1
      local r,g,b = imageData:getPixel(px,py)
      imageData:setPixel(px,py,r,g,b,0)
      enqueue(px-1,py); enqueue(px+1,py)
      enqueue(px,py-1); enqueue(px,py+1)
    end
    return imageData
  end

  local function enginePortrait(game, mon, kind)
    local data = game and game.data
    local def = data and data.pokemon and data.pokemon[mon.species]
    local vanillaPath = def and def.spriteFront
    local path, trueColor = PokemonSprites_.path(
      data, mon.species, "front", { mon=mon, kind=kind or "battle" })
    if not path then return nil end

    -- If another sprite package replaces the live front path, display that
    -- authored image as-is instead of forcing Gold's native 4-shade palette
    -- back over it. Vanilla paths keep their normal Gold palette behavior.
    if vanillaPath and path ~= vanillaPath then
      trueColor = true
    end

    local palName, colors = enginePalette(data, mon.species, mon)
    local key = "engine:" .. path .. ":" .. (trueColor and "truecolor" or palName)
    local cached = R.cache[key]
    if cached ~= nil then
      return cached or nil, trueColor and true or false
    end

    local image
    local nativeGold = GoldCompat.generation == "gen2"
      and vanillaPath and path == vanillaPath
      and love.image and love.image.newImageData
    if nativeGold then
      -- Work from ImageData even when no palette is available so the opaque
      -- ROM paper never survives into Summary/Pokedex/PC portrait textures.
      local frame = Assets_.imageData(path)
      if frame then
        stripGen2NativeMatte(frame)
        if not trueColor and colors then
          frame:mapPixel(function(_,_,r,g,b,a)
            if a == 0 then return r,g,b,a end
            local col = r > 0.83 and colors[1]
              or r > 0.5 and colors[2]
              or r > 0.17 and colors[3]
              or colors[4]
            return col[1]/255, col[2]/255, col[3]/255, a
          end)
        end
        image = love.graphics.newImage(frame)
      end
    elseif trueColor or not colors or not (love.image and love.image.newImageData) then
      image = Assets_.image(path)
    else
      local data = Assets_.imageData(path)
      if data then
        data:mapPixel(function(_,_,r,g,b,a)
          if a == 0 then return r,g,b,a end
          local col = r > 0.83 and colors[1]
            or r > 0.5 and colors[2]
            or r > 0.17 and colors[3]
            or colors[4]
          return col[1]/255, col[2]/255, col[3]/255, a
        end)
        image = love.graphics.newImage(data)
      end
    end

    if image and image.setFilter then image:setFilter("nearest","nearest") end
    R.cache[key] = image or false
    return image, trueColor and true or false
  end

  function R.install(mod)
    R.mod = mod
    connectBattleArts()
    return true
  end

  function R.resolve(game, mon, kind)
    if not (game and game.data and mon and mon.species) then return nil end

    -- All front-art consumers use the SAME precedence as battle. If Battle
    -- Arts currently owns the front sprite, menus/PC/Pokédex use that exact
    -- image too. Otherwise fall through to the live pokemon.sprite resolver.
    -- This keeps presentation-only UI synchronized with the player's equipped
    -- sprite package instead of inventing a separate menu-art source.
    local BA = R.ba
    local image = battleArtsPortrait(mon)
    if image then
      -- Battle Arts already records the alpha-visible bounds for every image
      -- prepared through BattleArt.prepareData(). Pass those bounds to the UI
      -- so portrait sizing is based on the Pokemon itself instead of the
      -- surrounding transparent canvas. This is especially important for the
      -- Gen 4 collection, where authored canvas occupancy varies by species.
      local meta
      local mode = BA and settingValue(BA.setting)
      local generation = BA and settingValue(BA.frontAnimationSetting)
      if mode == "animated" and generation == "gen4"
          and BA and type(BA.metrics) == "function" then
        local okMetrics, metrics = pcall(BA.metrics, image)
        if okMetrics and type(metrics) == "table"
            and metrics.x0 and metrics.x1 and metrics.y0 and metrics.y1 then
          meta = {
            x0 = metrics.x0, x1 = metrics.x1,
            y0 = metrics.y0, y1 = metrics.y1,
          }
        end
      end
      meta = meta or {}
      -- Battle Arts PNGs are authored color assets. Always mark the exact
      -- resolved image true-color so the global palette pass cannot turn
      -- Party/PC/Pokédex portraits back into grayscale.
      meta.trueColor = true
      return image, meta
    end

    local image,trueColor=enginePortrait(game,mon,kind)
    return image, image and {trueColor=trueColor and true or false} or nil
  end

  return R
end)()

local function clearBattleUIState()
  State.activeBattle=nil
  State.activeBattleMoveLearn=nil
  State.activeBattleMoveParty=nil
  State.activeBattleStatBox=nil
end

local function clearPokemonUIState()
  State.activeParty=nil
  State.activeTMParty=nil
  State.activeItemTargetParty=nil
  State.activeMoveLearn=nil
  State.activeTMPromptFlow=nil
end

local function clearOverworldMenuState()
  State.activeStartMenu=nil
  State.activeBagMenu=nil
  State.activeBagActionMenu=nil
end

local function clearPCUIState()
  State.activePCAccessMenu=nil
  State.activePCMenu=nil
  State.activePCList=nil
  State.activePCActionMenu=nil
end

local function clearShopUIState()
  State.activeShopMenu=nil
  State.activeShopList=nil
  State.activeShopQuantity=nil
end


local UI_TEXT_SCALE = 1.08

-- -------------------------------------------------------------------------
-- Text profiles
-- -------------------------------------------------------------------------
-- A curated bundle of font source + filtering + size + weight, selectable
-- as one named choice rather than several independent sliders someone has
-- to tune blind. OG STYLE is byte-for-byte what this mod always shipped:
-- same font file, same per-call-site filter choice (some call sites used
-- "nearest", others "linear", by design -- filterMode="context" preserves
-- that exact split instead of flattening it), sizeMul=1.0, and weight left
-- fully in the existing TEXT THICKNESS setting's hands. Every other profile
-- applies its filter uniformly across every text surface instead, so
-- switching away from OG reads as one consistent, deliberate choice rather
-- than a mix of old per-site defaults.
--
-- Only "system_sans" is a genuinely different typeface (Love2D's built-in
-- default font) -- this mod doesn't bundle any other font files, so the
-- other four profiles vary size/weight/filtering on the same PLAINPIXEL
-- source rather than claiming to be different type families they aren't.
local TEXT_PROFILES = {
  og = {
    id="og", label="OG STYLE",
    fontPath=EngineFont.PLAINPIXEL, filterMode="context",
    sizeMul=1.00, weightOverride=nil,
  },
  crisp_large = {
    id="crisp_large", label="CRISP & LARGE",
    fontPath=EngineFont.PLAINPIXEL, filterMode="nearest",
    sizeMul=1.20, weightOverride=nil,
  },
  smooth_reader = {
    id="smooth_reader", label="SMOOTH READER",
    fontPath=EngineFont.PLAINPIXEL, filterMode="linear",
    sizeMul=1.10, weightOverride=nil,
  },
  bold_contrast = {
    id="bold_contrast", label="BOLD HIGH-CONTRAST",
    fontPath=EngineFont.PLAINPIXEL, filterMode="linear",
    sizeMul=1.30, weightOverride=1.35,
  },
  system_sans = {
    id="system_sans", label="SYSTEM SANS",
    fontPath=false, filterMode="linear",
    sizeMul=1.05, weightOverride=nil,
  },
}
local TEXT_PROFILE_ORDER={
  "og","crisp_large","smooth_reader","bold_contrast","system_sans",
}
local TEXT_PROFILE_DISPLAY={}
for id,profile in pairs(TEXT_PROFILES) do
  TEXT_PROFILE_DISPLAY[id]=profile.label
end

local SCREEN_TOGGLE_SPECS = {
  {key="revampedTrainerCardUI",    label="TRAINER CARD UI"},
  {key="revampedSaveUI",           label="SAVE SCREEN UI"},
  {key="revampedOptionsUI",        label="OPTIONS SCREEN UI"},
  {key="revampedModsUI",           label="MOD MANAGER UI"},
  {key="revampedPokegearUI",       label="POKéGEAR UI", gen="gen2"},
  {key="revampedLevelUpUI",        label="LEVEL-UP STATS UI"},
  {key="revampedBagUI",            label="BAG UI"},
  {key="revampedItemPCUI",         label="ITEM STORAGE PC UI"},
  {key="revampedMoveManagerUI",    label="MOVE MANAGER UI"},
  {key="revampedStarterUI",        label="STARTER SELECTION UI"},
  {key="revampedNamingUI",         label="NAMING SCREEN UI"},
  {key="revampedSafariUI",         label="SAFARI ZONE UI"},
  {key="revampedEvolutionUI",      label="EVOLUTION / EGG UI"},
  {key="revampedHeldItemUI",       label="HELD ITEM UI"},
  {key="revampedLocationBannerUI", label="AREA BANNER UI"},
  {key="revampedClockUI",          label="CLOCK SETUP UI", gen="gen2"},
  {key="revampedServiceMenusUI",   label="SERVICE / EVENT MENUS", gen="gen2"},
  {key="revampedMailUI",           label="MAIL UI", gen="gen2"},
  {key="revampedBankUI",           label="MOM'S BANK UI", gen="gen2"},
  {key="revampedDayCareUI",        label="DAY CARE UI", gen="gen2"},
  {key="revampedElevatorUI",       label="ELEVATOR UI", gen="gen2"},
  {key="revampedDecorationUI",     label="DECORATION UI", gen="gen2"},
  {key="revampedPrizeUI",          label="PRIZE MENU UI", gen="gen2"},
  {key="revampedContestUI",        label="CONTEST UI", gen="gen2"},
  {key="revampedMoveDeleterUI",    label="MOVE DELETER UI", gen="gen2"},
  {key="revampedScriptMenuUI",     label="SCRIPT CHOICE UI", gen="gen2"},
  {key="revampedTradeUI",          label="TRADE UI", gen="gen2"},
  {key="revampedPhotoStudioUI",    label="PHOTO STUDIO UI", gen="gen2"},
  {key="revampedUnownPrinterUI",   label="UNOWN PRINTER UI", gen="gen2"},
  {key="revampedHallOfFameUI",     label="HALL OF FAME UI", gen="gen2"},
  {key="revampedDiplomaUI",        label="DIPLOMA UI", gen="gen2"},
  {key="revampedMapRadioUI",       label="MAP / RADIO UI", gen="gen2"},
}

local OPTION_DEFAULTS = {
  colosseumBattleUI = true,
  battlePortraits = true,
  colosseumPokemonMenu = true,
  colosseumIcons = true,
  colosseumTitleIntro = true,
  revampedOverworldMenus = true,
  revampedPokeMartUI = true,
  revampedPokemonPC = true,
  revampedPokedex = true,
  revampedDialogueBoxes = true,
  hideNativeBattleUI = false,
  mobileBattleUI = false,
  battleHudWidth = "normal",
  battleHudHeight = "normal",
  battleHudPortrait = "normal",
  uiTextSize = "normal",
  uiTextWeight = "normal",
  uiTextProfile = "og",
  uiBoxScale = "normal",
  uiBorderColor = "cyan",
  uiBorderStyle = "rounded",
}
for _,spec in ipairs(SCREEN_TOGGLE_SPECS) do
  OPTION_DEFAULTS[spec.key]=true
end

local function optionValue(key)
  if modRef and modRef.options and modRef.options.get then
    local ok, value = pcall(modRef.options.get, modRef.options, key)
    if ok and value ~= nil then return value end
  end
  return OPTION_DEFAULTS[key]
end

local function featureEnabled(key)
  return optionValue(key) ~= false
end

-- Central standalone theme adapter. The mature donor renderers deliberately
-- remain responsible for data, geometry and native-flow ownership, but every
-- legacy neutral surface is translated into one Colosseum material language.
-- Texture draws keep an exact white tint, so Pokémon/item artwork is untouched.
function GoldCompat.colosseumColor(r,g,b,a)
  a=a==nil and 1 or a
  local function near(x,y) return math.abs(x-y)<0.022 end

  -- Cream/light Gen 3 paper -> translucent black-teal glass.
  if (r>=0.985 or (r>=0.925 and r<=0.955))
      and g>0.88 and b<0.985 then
    return 0.025,0.060,0.065,math.min(a,0.92)
  end

  -- Remaining warm near-white card fills use either normal glass or the red
  -- selected-card material. printText normalizes off-white glyphs first.
  if r>=0.96 and r<0.985 and g>0.93 and b<0.95 then
    if r>=0.972 and b<0.915 then
      return 0.48,0.075,0.045,math.min(a,0.94)
    end
    return 0.035,0.080,0.082,math.min(a,0.80)
  end

  -- Exact neutral dark geometry becomes the deepest glass layer. Text colors
  -- are lifted separately inside printText(), where their role is unambiguous.
  if near(r,g) and near(g,b) and r>=0.052 and r<=0.088 then
    return 0.012,0.030,0.034,math.min(a,0.84)
  end

  -- Warm-black structural fills become deep teal rather than paper borders.
  if r<=0.095 and g<=0.095 and b<g then
    return 0.018,0.040,0.044,math.min(a,0.84)
  end

  -- Old selected black rows become the Colosseum red focus treatment.
  if near(r,g) and near(g,b) and r>0.088 and r<0.115 then
    return 0.62,0.10,0.065,math.min(a,0.90)
  end

  -- Neutral card rims and secondary fills become steel.
  if math.abs(r-g)<0.035 and math.abs(g-b)<0.045
      and r>=0.105 and r<=0.48 then
    if r<0.18 then return 0.20,0.34,0.34,math.min(a,0.96) end
    if r<0.32 then return 0.55,0.67,0.65,a end
    return 0.42,0.66,0.67,a
  end

  -- Donor gold/brown accents become the red-orange Colosseum focus rim.
  if r>0.42 and g>0.30 and g<0.72 and b<0.32 then
    return 0.96,0.25,0.12,a
  end

  return r,g,b,a
end

function GoldCompat.withColosseumSkin(fn,...)
  if type(fn)~="function" then return end
  if GoldCompat.colosseumSkinDepth and GoldCompat.colosseumSkinDepth>0 then
    return fn(...)
  end

  local graphics=love and love.graphics
  if not (graphics and graphics.setColor) then return fn(...) end
  local nativeSetColor=graphics.setColor
  local nativeRectangle=graphics.rectangle
  GoldCompat.colosseumSkinDepth=1
  graphics.setColor=function(r,g,b,a)
    if type(r)=="table" then
      a=r[4]; b=r[3]; g=r[2]; r=r[1]
    end
    if type(r)~="number" or type(g)~="number" or type(b)~="number" then
      return nativeSetColor(r,g,b,a)
    end
    local nr,ng,nb,na=GoldCompat.colosseumColor(r,g,b,a)
    return nativeSetColor(nr,ng,nb,na)
  end

  -- Colosseum screens are hanging panels, never opaque donor canvases.
  -- Suppress only exact full-frame fills while the shared skin is active.
  if nativeRectangle then
    graphics.rectangle=function(mode,x,y,w,h,...)
      if mode=="fill" and x==0 and y==0 then
        local sw,sh=graphics.getDimensions()
        local logicalFrame=(w==160 and h==144)
        local windowFrame=(math.abs((w or 0)-sw)<1
          and math.abs((h or 0)-sh)<1)
        if logicalFrame or windowFrame then return end
      end
      return nativeRectangle(mode,x,y,w,h,...)
    end
  end

  local ok,a,b,c=pcall(fn,...)
  graphics.setColor=nativeSetColor
  if nativeRectangle then graphics.rectangle=nativeRectangle end
  GoldCompat.colosseumSkinDepth=0
  if not ok then error(a) end
  return a,b,c
end

function GoldCompat.battlePresentationEnabled()
  -- Colosseum is a complete battle presentation mode, not a child that
  -- requires the normal Gen 3 BATTLE UI toggle to also be ON.
  --
  -- STRICT NATIVE UI BLOCK is a hard guarantee, not just another native-
  -- suppression hook: every native-vs-Colosseum decision in the file reads
  -- THIS function, so folding the strict toggle in here (rather than only
  -- at each individual suppression site) means turning it on forces our
  -- presentation to own the whole battle screen -- regardless of the
  -- separate BATTLE UI toggle's state, and regardless of what any other
  -- installed mod (Battle Arts, Dramaless Shape, etc.) does with its own
  -- sprite/HUD presentation, since those mods' native-suppression hooks in
  -- this file are gated on this same function.
  return featureEnabled("colosseumBattleUI")
    or featureEnabled("hideNativeBattleUI")
end

function GoldCompat.pokemonPresentationEnabled()
  -- Colosseum Party is a complete, independent presentation mode. The normal
  -- POKéMON MENU toggle remains the fallback when Colosseum Party is off.
  return featureEnabled("colosseumPokemonMenu")
end

function GoldCompat.bagPresentationEnabled()
  return featureEnabled("revampedOverworldMenus")
    and featureEnabled("revampedBagUI")
end

function GoldCompat.strictNativeUiEnabled()
  -- STRICT NATIVE UI BLOCK is the master guarantee that no unclaimed
  -- cartridge-era menu chrome is allowed to surface. Individual purpose-built
  -- toggles still select their richer renderers; this only supplies a
  -- Colosseum fallback for otherwise-unclaimed gameplay UI.
  return featureEnabled("hideNativeBattleUI")
end

function GoldCompat.itemPcPresentationEnabled()
  return featureEnabled("revampedPokemonPC")
    and featureEnabled("revampedItemPCUI")
end

function GoldCompat.moveManagerPresentationEnabled()
  return GoldCompat.pokemonPresentationEnabled()
    and featureEnabled("revampedMoveManagerUI")
end

function GoldCompat.starterPresentationEnabled()
  return GoldCompat.pokemonPresentationEnabled()
    and featureEnabled("revampedStarterUI")
end

function GoldCompat.namingPresentationEnabled()
  return featureEnabled("revampedNamingUI")
    and (featureEnabled("revampedDialogueBoxes")
      or featureEnabled("revampedOverworldMenus"))
end

function GoldCompat.evolutionPresentationEnabled()
  return GoldCompat.pokemonPresentationEnabled()
    and featureEnabled("revampedEvolutionUI")
end

function GoldCompat.heldItemPresentationEnabled()
  return GoldCompat.pokemonPresentationEnabled()
    and featureEnabled("revampedHeldItemUI")
end

function GoldCompat.serviceFlowPresentationEnabled()
  return featureEnabled("revampedServiceMenusUI")
    and (featureEnabled("revampedOverworldMenus")
      or featureEnabled("revampedDialogueBoxes"))
end

function GoldCompat.clockPresentationEnabled()
  return featureEnabled("revampedClockUI")
    and (featureEnabled("revampedOverworldMenus")
      or featureEnabled("revampedDialogueBoxes"))
end

function GoldCompat.safariPresentationEnabled()
  return featureEnabled("revampedSafariUI")
end

function GoldCompat.locationBannerPresentationEnabled()
  return featureEnabled("revampedOverworldMenus")
    and featureEnabled("revampedLocationBannerUI")
end

function GoldCompat.battlePresentationEnabledFor(battle)
  local safari=battle and GoldCompat.resolvedSafariState(battle) or nil
  if not safari then
    local game=(battle and battle.game) or GoldCompat.game
    safari=game and game.save and type(game.save.safari)=="table"
      and game.save.safari or nil
  end
  if safari then
    return GoldCompat.battlePresentationEnabled()
      and GoldCompat.safariPresentationEnabled()
  end
  return GoldCompat.battlePresentationEnabled()
end

function GoldCompat.ownsNativeBattleLayer(state)
  if not state then return false end
  local battle=state
  if not (battle.player or battle.enemy or battle.phase) then
    local game=state.game or (modRef and modRef.game) or GoldCompat.game
    battle=game and battleStateInStack(game) or nil
  end
  return battle and (GoldCompat.battlePresentationEnabledFor(battle)
    or featureEnabled("hideNativeBattleUI")) or false
end

function GoldCompat.patchShapeHudCompat(modId,patchFlag,logLabel)
  if GoldCompat.generation~="gen1" or not (modRef and modRef.find) then return end
  local handle=modRef.find(modId)
  local V=handle and handle.exports and handle.exports.lib
  if not (V and type(V.require)=="function") then return end

  local ok,OverworldBattle=pcall(V.require,"OverworldBattle")
  if not (ok and OverworldBattle) then return end

  -- Shape-family renderers may reinstall their battle hooks at battle start.
  -- Keep our UI ownership as a tiny outer adapter around whichever implementation
  -- is currently active instead of assuming a one-time patch will stay last.
  local slot="__colosseumUiCompat_"..tostring(patchFlag)
  local compat=OverworldBattle[slot]
  if type(compat)~="table" then
    compat={}
    OverworldBattle[slot]=compat
  end

  local snap=OverworldBattle.snapHUDs
  if type(snap)=="function" and snap~=compat.snapWrapper then
    local inner=snap
    local wrapper=function(battle,shot,...)
      if GoldCompat.ownsNativeBattleLayer(battle) then return false end
      return inner(battle,shot,...)
    end
    compat.snapWrapper=wrapper
    OverworldBattle.snapHUDs=wrapper
  end

  local panels=OverworldBattle.drawHudPanels
  if type(panels)=="function" and panels~=compat.panelWrapper then
    local inner=panels
    local wrapper=function(battle,...)
      if GoldCompat.ownsNativeBattleLayer(battle) then return end
      return inner(battle,...)
    end
    compat.panelWrapper=wrapper
    OverworldBattle.drawHudPanels=wrapper
  end

  if not compat.logged and modRef.log then
    compat.logged=true
    modRef.log:info("Colosseum UI: "..logLabel.." battle-HUD compatibility active")
  end
end

function GoldCompat.installBattlePredicateGuard(class,name,slot)
  if not (type(class)=="table" and type(class[name])=="function") then return false end
  local current=class[name]
  if current==State[slot] then return false end
  local inner=current
  local wrapper=function(self,...)
    if GoldCompat.ownsNativeBattleLayer(self) then return false end
    return inner(self,...)
  end
  State[slot]=wrapper
  class[name]=wrapper
  return true
end

function GoldCompat.installGen1HudDrawGuard()
  if type(BattleState.drawHUDs)~="function" then return false end
  local current=BattleState.drawHUDs
  if current==State.__colosseumGen1HudDrawGuard then return false end
  local inner=current
  local wrapper=function(self,...)
    if GoldCompat.ownsNativeBattleLayer(self) then
      -- drawHUDs also owns transient party-ball rows that sit outside the
      -- launcher's status_hud_visible predicate. Keep any lifecycle work the
      -- renderer attached to the method, but make every legacy HUD pixel inert.
      local g=love.graphics
      g.push("all")
      g.setScissor(0,0,0,0)
      local ok,result=pcall(inner,self,...)
      g.pop()
      if not ok then error(result) end
      return result
    end
    return inner(self,...)
  end
  State.__colosseumGen1HudDrawGuard=wrapper
  BattleState.drawHUDs=wrapper
  return true
end

function GoldCompat.installBattleUiFirewall()
  -- The launcher hooks remain the primary contract. These method-level guards
  -- are intentionally narrow fallbacks for renderer mods that cache or replace
  -- battle draw functions after mod load. They only answer the two visibility
  -- predicates (plus Gen I's HUD-only draw method for party-ball chrome).
  if GoldCompat.generation=="gen1" then
    GoldCompat.installBattlePredicateGuard(BattleState,"bottomUIVisible",
      "__colosseumGen1BottomPredicate")
    GoldCompat.installBattlePredicateGuard(BattleState,"statusHUDVisible",
      "__colosseumGen1StatusPredicate")
    GoldCompat.installGen1HudDrawGuard()

    -- Reassert renderer-owned HUD capture seams too. This is safe to call many
    -- times; patchShapeHudCompat only adds a new outer wrapper if another mod
    -- has actually displaced the previous one.
    GoldCompat.patchShapeHudCompat(
      "DRAMALESS_SHAPE","dramaless","Dramaless Shape")
    GoldCompat.patchShapeHudCompat(
      "DRAMATIC_SHAPE","dramatic","Dramatic Shape 1.8")
  else
    local okGold,GoldBattleState=pcall(require,"src.ui.gen2.BattleState")
    if okGold and type(GoldBattleState)=="table" then
      GoldCompat.installBattlePredicateGuard(GoldBattleState,"bottomUIVisible",
        "__colosseumGen2BottomPredicate")
      GoldCompat.installBattlePredicateGuard(GoldBattleState,"statusHUDVisible",
        "__colosseumGen2StatusPredicate")
    end
  end
end

function GoldCompat.colosseumPartyGridIndex(index,count,direction)
  if count<1 then return 1 end
  index=math.max(1,math.min(tonumber(index) or 1,count))
  local row=math.floor((index-1)/2)
  local col=(index-1)%2

  if direction=="left" or direction=="right" then
    local other=row*2+(1-col)+1
    return other<=count and other or index
  end

  local step=direction=="up" and -1 or direction=="down" and 1
  if not step then return index end
  local rows=math.ceil(count/2)
  for offset=1,rows do
    local other=((row+step*offset)%rows)*2+col+1
    if other<=count then return other end
  end
  return index
end

function GoldCompat.activeTextProfile()
  local id=tostring(optionValue("uiTextProfile") or "og")
  return TEXT_PROFILES[id] or TEXT_PROFILES.og
end

function GoldCompat.userTextScale()
  local v=tostring(optionValue("uiTextSize") or "normal")
  local base=1.00
  if v=="small" then base=0.90
  elseif v=="large" then base=1.12
  elseif v=="x-large" then base=1.24 end
  return base*GoldCompat.activeTextProfile().sizeMul
end

function GoldCompat.userTextWeight()
  local profile=GoldCompat.activeTextProfile()
  if profile.weightOverride then return profile.weightOverride end
  local v=tostring(optionValue("uiTextWeight") or "normal")
  if v=="thin" then return 0.00 end
  if v=="bold" then return 0.90 end
  return 0.45
end

function GoldCompat.userBoxScale()
  local v=tostring(optionValue("uiBoxScale") or "normal")
  if v=="compact" then return 0.86 end
  if v=="large" then return 1.08 end
  if v=="x-large" then return 1.14 end
  return 1.00
end

function GoldCompat.dialogueLayoutScale()
  local textScale=GoldCompat.userTextScale()
  local boxScale=GoldCompat.userBoxScale()
  local textGrowth=math.max(0,textScale-1)

  -- Dialogue grows with large text instead of keeping a fixed shell and
  -- clipping. Compact remains meaningful, but never wins over readability.
  local heightScale=math.max(boxScale,1+textGrowth*1.85)
  local widthScale=math.max(1,boxScale)*(1+textGrowth*0.28)
  return widthScale,heightScale
end


DexUI.uiRows={
  {key="colosseumBattleUI",label="BATTLE UI",kind="toggle"},
  {key="battlePortraits",label="BATTLE PORTRAITS",kind="toggle"},
  {key="colosseumPokemonMenu",label="POKéMON MENU",kind="toggle"},
  {key="colosseumIcons",label="COLOSSEUM ICONS",kind="toggle"},
  {key="colosseumTitleIntro",label="MENU INTRO",kind="toggle"},
  {key="revampedOverworldMenus",label="OVERWORLD MENUS",kind="toggle"},
  {key="revampedPokeMartUI",label="POKéMART UI",kind="toggle"},
  {key="revampedPokemonPC",label="POKéMON PC",kind="toggle"},
  {key="revampedPokedex",label="POKéDEX",kind="toggle"},
  {key="revampedDialogueBoxes",label="DIALOGUE",kind="toggle"},
  {key="hideNativeBattleUI",label="STRICT NATIVE UI BLOCK",kind="toggle"},
  {key="mobileBattleUI",label="MOBILE BATTLE UI",kind="toggle"},
  {key="battleHudWidth",label="BATTLE HUD WIDTH",kind="choice",
    values={"compact","normal","wide","x-wide"}},
  {key="battleHudHeight",label="BATTLE HUD HEIGHT",kind="choice",
    values={"compact","normal","tall","x-tall"}},
  {key="battleHudPortrait",label="BATTLE PORTRAIT SIZE",kind="choice",
    values={"small","normal","large","x-large"}},
  {key="uiTextProfile",label="TEXT PROFILE",kind="choice",
    values=TEXT_PROFILE_ORDER,display=TEXT_PROFILE_DISPLAY},
  {key="uiTextSize",label="TEXT SIZE",kind="choice",
    values={"small","normal","large","x-large"}},
  {key="uiTextWeight",label="TEXT THICKNESS",kind="choice",
    values={"thin","normal","bold"}},
  {key="uiBoxScale",label="UI BOX SIZE",kind="choice",
    values={"compact","normal","large","x-large"}},
  {key="uiBorderColor",label="BORDER COLOR",kind="choice",
    values={"gold","red","orange","yellow","green","cyan","blue","purple",
      "pink","brown","gray","white","black"}},
  {key="uiBorderStyle",label="BORDER STYLE",kind="choice",
    values={"classic","rounded","sharp"}},
}
for _,spec in ipairs(SCREEN_TOGGLE_SPECS) do
  table.insert(DexUI.uiRows,{
    key=spec.key,
    label=spec.label,
    kind="toggle",
    gen=spec.gen,
  })
end

function DexUI.rowsForGame(game)
  local generation=GoldCompat.generation
  local rows={}
  for _,row in ipairs(DexUI.uiRows) do
    if not row.gen or row.gen==generation then
      rows[#rows+1]=row
    end
  end
  return rows
end

function DexUI.setOption(game,key,value)
  local loader=game and game.mods
  if not loader then return false end

  loader.modOptions=loader.modOptions or {}
  local bucket=loader.modOptions["colosseum_ui_overhaul"]
  if not bucket then
    bucket={}
    loader.modOptions["colosseum_ui_overhaul"]=bucket
  end
  bucket[key]=value

  -- Persist through the same options file used by the mod manager. The public
  -- options facade is intentionally read-only at runtime, so this in-game UI
  -- uses the engine-owned SaveData serializer rather than inventing storage.
  local okSave=pcall(function()
    local SaveData=require("src.core.SaveData")
    local fs=loader.fs
    if not (fs and fs.write) then return end
    local opts=SaveData.loadOptions(fs)
    opts.modOptions=opts.modOptions or {}
    opts.modOptions["colosseum_ui_overhaul"]=opts.modOptions["colosseum_ui_overhaul"] or {}
    opts.modOptions["colosseum_ui_overhaul"][key]=value
    SaveData.saveOptions(opts,fs)
  end)

  -- Match ManagerState's runtime notification contract when available.
  pcall(function()
    if loader.events and loader.events.emit then
      loader.events:emit("mod.options_changed",
        {mod="colosseum_ui_overhaul",key=key,value=value})
    end
  end)

  return okSave or true
end

function DexUI.optionDisplay(row)
  local value=optionValue(row.key)
  if row.kind=="toggle" then
    return value~=false and "ON" or "OFF"
  end
  if row.display then
    local mapped=row.display[value]
    if mapped then return tostring(mapped) end
  end
  return tostring(value or ""):upper()
end

function DexUI.activateUIRow(game,row)
  if not row then return end
  if row.kind=="toggle" then
    DexUI.setOption(game,row.key,not featureEnabled(row.key))
    return
  end

  if row.kind=="choice" and row.values and #row.values>0 then
    local current=optionValue(row.key)
    local index=1
    for i,value in ipairs(row.values) do
      if value==current then index=i break end
    end
    index=index<#row.values and index+1 or 1
    DexUI.setOption(game,row.key,row.values[index])
  end
end


local function bagStateForMenu(game)
  if not (game and game.stack and game.stack.states) then return nil end
  for i=#game.stack.states,1,-1 do
    local state = game.stack.states[i]
    if state and state.__gen3uiBag then
      return state
    end
  end
  return nil
end


local function stateExistsInStack(game, target)
  if not (game and game.stack and game.stack.states and target) then return false end
  for _,state in ipairs(game.stack.states) do
    if state == target then return true end
  end
  return false
end

function GoldCompat.colosseumPartyFlowActive(game)
  if not featureEnabled("colosseumPokemonMenu") then return false end
  if not (game and game.stack and game.stack.states) then return false end
  for _,state in ipairs(game.stack.states) do
    if state and (state.__gen3uiColosseumParty
        or state==State.activeParty
        or state==State.activeTMParty
        or state==State.activeItemTargetParty) then
      return true
    end
  end
  return State.activeBattleMoveParty~=nil
      and State.activeBattleMoveLearn~=nil
      and stateExistsInStack(game,State.activeBattleMoveLearn)
end

local function battleStateInStack(game)
  if not (game and game.stack and game.stack.states) then return nil end
  for i=#game.stack.states,1,-1 do
    local state=game.stack.states[i]
    if getmetatable(state)==BattleState
        or state==State.activeBattle
        or GoldCompat.isGen2BattleState(state) then
      return state
    end
  end
  return nil
end

local function makeBattleMovePartyState(game,moveMenu)
  if not (game and moveMenu and moveMenu.mon) then return nil end

  local party=(game.save and game.save.party) or {}
  local selected=1
  for i,mon in ipairs(party) do
    if mon==moveMenu.mon then
      selected=i
      break
    end
  end

  local state={
    game=game,
    party=party,
    index=selected,
    selected=selected,
    blink=0,
    keepOpen=true,
    __gen3uiBattleMoveParty=true,
  }

  -- drawPartyFinal expects this method on a real PartyMenu.
  function state:bottomMessage()
    return "Choose a move to replace."
  end

  return state
end

-- Gold does not push src.ui.MoveLearnMenu during battle. Its BattleState owns
-- the complete ForgetMove flow in-place through pendingLearn/forgetIndex.
-- Adapt those authoritative fields to the same small presentation contract the
-- Party renderer already consumes for TM/HM and Gen I battle move learning.
local function makeGoldBattleMovePartyState(game,battleState)
  local learn=battleState and battleState.pendingLearn
  local battle=battleState and battleState.battle
  local party=(battle and battle.party) or (game.save and game.save.party) or {}
  local index=learn and tonumber(learn.index) or 1
  index=math.max(1,math.min(index,math.max(1,#party)))
  local mon=party[index]
  if not (learn and mon) then return nil,nil end

  local adapter={
    game=game,
    mon=mon,
    -- Gold queues the fully constructed move entry, not merely its id.
    newMoveId=type(learn.move)=="table"
      and (learn.move.id or learn.move.moveId or learn.move.move)
      or learn.move,
    index=math.max(1,tonumber(battleState.forgetIndex) or 1),
    selecting=true,
    __goldBattleState=battleState,
  }
  local state={
    game=game,party=party,index=index,selected=index,blink=0,keepOpen=true,
    __gen3uiBattleMoveParty=true,
    __gen3uiGoldBattleMoveParty=true,
  }
  function state:bottomMessage() return "Choose a move to replace." end
  return state,adapter
end

-- This was referenced by name at the in-battle move-learn render dispatch
-- but never actually defined anywhere in the file, so every call silently
-- failed via pcall -- which is why that flow appeared broken (falling
-- through to whatever the battle's own move-select UI last showed, i.e.
-- the active battler's moves, instead of the Pokémon actually learning the
-- new move). GoldCompat.drawColosseumParty already has a complete, working
-- presentation for this exact moment (its __gen3uiBattleMoveParty branch:
-- full party grid with the learning Pokémon's card selected, its current
-- moves shown in the detail panel with the pending replacement highlighted
-- and the new move named) -- makeBattleMovePartyState() above was already
-- built specifically to feed that path, so route into it directly instead
-- of maintaining a second, separate renderer.
local function drawBattleMoveLearnFinal(battle,moveMenu)
  local partyState=State.activeBattleMoveParty
  if not (partyState and partyState.game) then return false end
  return GoldCompat.drawGoldPartyMenu(partyState,
    love.graphics.getWidth(),love.graphics.getHeight())
end


local function shopMenuLabel(item)
  return tostring(item and item.label or ""):upper()
end

local function shopMainItems(items)
  if type(items)~="table" or #items~=3 then return false end
  return shopMenuLabel(items[1])=="BUY"
      and shopMenuLabel(items[2])=="SELL"
      and shopMenuLabel(items[3])=="QUIT"
end


local function shopStateInStack(game)
  if not (game and game.stack and game.stack.states) then return nil end
  for i=#game.stack.states,1,-1 do
    local state=game.stack.states[i]
    if state and (state.__gen3uiShopList or state.__gen3uiShopMain) then
      return state
    end
  end
  return nil
end

local function pcMenuLabel(item)
  return tostring(item and item.label or ""):upper()
end

local function pcAccessItems(items)
  if type(items)~="table" or #items<2 then return false end
  local hits=0
  for _,item in ipairs(items) do
    local label=pcMenuLabel(item)
    if label:find("PC",1,true) or label=="LOG OFF" then hits=hits+1 end
  end
  return hits>=2 and pcMenuLabel(items[#items])=="LOG OFF"
end

local function pcMainItems(items)
  if type(items)~="table" or #items<4 then return false end
  local labels={}
  for i,item in ipairs(items) do labels[i]=pcMenuLabel(item) end
  return labels[1]:find("WITHDRAW",1,true)
      and labels[2]:find("DEPOSIT",1,true)
      and labels[3]:find("RELEASE",1,true)
      and labels[4]:find("CHANGE BOX",1,true)
end

local function pcActionItems(items)
  if type(items)~="table" or #items<3 then return false end
  local a=pcMenuLabel(items[1])
  return (a=="WITHDRAW" or a=="DEPOSIT")
      and pcMenuLabel(items[2])=="STATS"
      and pcMenuLabel(items[3])=="CANCEL"
end

-- Player item-storage PC. Gen I exposes these through generic Menu/ListMenu
-- states, while Gold has a dedicated ItemPcMenu. Keep the Gen I recognizers
-- narrow so ordinary Bag, Mart, and arbitrary mod lists are never claimed.
local function pcItemRootItems(items)
  if type(items)~="table" or #items<4 then return false end
  local labels={}
  for i,item in ipairs(items) do labels[i]=pcMenuLabel(item) end
  if labels[1]~="WITHDRAW ITEM" or labels[2]~="DEPOSIT ITEM"
      or labels[3]~="TOSS ITEM" then return false end
  local last=labels[#labels]
  return last=="LOG OFF" or last=="TURN OFF"
end

function GoldCompat.pcItemListTitle(title)
  local t=tostring(title or ""):upper()
  return t=="WITHDRAW ITEM" or t=="DEPOSIT ITEM" or t=="TOSS ITEM"
end

local function pcItemListStateInStack(game)
  if not (game and game.stack and game.stack.states) then return nil end
  for i=#game.stack.states,1,-1 do
    local state=game.stack.states[i]
    if state and state.__gen3uiPCItemList then return state end
  end
  return nil
end

function GoldCompat.pcListTitle(title)
  local t=tostring(title or ""):upper()
  if t=="PARTY (DEPOSIT)" or t=="CHANGE BOX" then return true end
  if t:match("^BOX %d+ %(WITHDRAW%)$") then return true end
  if t:match("^BOX %d+ %(RELEASE%)$") then return true end
  return false
end

local function isPCOwnedState(state)
  return state and (
    state.__gen3uiPCAccess
    or state.__gen3uiPCMain
    or state.__gen3uiPCList
    or state.__gen3uiPCAction
    or state.__gen3uiPCItemRoot
    or state.__gen3uiPCItemList
  )
end

local function pcStateInStack(game)
  if not (game and game.stack and game.stack.states) then return nil end
  for i=#game.stack.states,1,-1 do
    local state=game.stack.states[i]
    if isPCOwnedState(state) then return state end
  end
  return nil
end


function GoldCompat.supportedOverworldMenuState(state)
  if not state then return false end

  -- These are the menu classes for which this mod has complete replacement
  -- renderers. Everything else fails safely to the native implementation.
  if state.__gen3uiStart then return true end
  if state.__gen3uiHangingOptions then return true end
  if state.__gen3uiHangingMods then return true end
  if state.__gen3uiHangingTrainer then return true end
  if getmetatable(state)==BagMenu then return true end
  if getmetatable(state)==PartyMenu then return true end
  if getmetatable(state)==MoveLearnMenu then return true end
  if state.__gen3uiPokedex then return true end
  if state.__gen3uiPokedexAction then return true end
  if state.__gen3uiDexEntry then return true end

  -- Bag item action menus are marked explicitly by our own hook.
  if state.__gen3uiBagAction or state.__gen3uiBag then return true end
  if isPCOwnedState(state) then return true end
  if state.__gen3uiShopMain or state.__gen3uiShopList
      or state.__gen3uiShopQuantity then return true end

  return false
end


local function canIntegrateMoveLearn(game, moveMenu)
  if not GoldCompat.pokemonPresentationEnabled() then return false end
  if not (State.activeTMParty and moveMenu and moveMenu.mon) then return false end
  if not stateExistsInStack(game, State.activeTMParty) then return false end

  local party = State.activeTMParty.party or (game.save and game.save.party) or {}
  local selected = math.max(1, math.min(State.activeTMParty.index or 1, #party))
  return party[selected] == moveMenu.mon
end

local function installVerifiedOptions(mod)
  modRef = mod

  -- This exact row format is consumed by ManagerState's options screen:
  -- type=toggle, key, label, default.
  local optionDefs={
    {
      key = "colosseumBattleUI",
      type = "toggle",
      label = "BATTLE UI",
      default = true,
    },
    {
      key = "battlePortraits",
      type = "toggle",
      label = "BATTLE PORTRAITS",
      default = true,
    },
    {
      key = "colosseumPokemonMenu",
      type = "toggle",
      label = "POKéMON MENU",
      default = true,
    },
    {
      key = "colosseumIcons",
      type = "toggle",
      label = "COLOSSEUM ICONS",
      default = true,
    },
    {
      key = "colosseumTitleIntro",
      type = "toggle",
      label = "MENU INTRO",
      default = true,
    },
    {
      key = "revampedOverworldMenus",
      type = "toggle",
      label = "OVERWORLD MENUS",
      default = true,
    },
    {
      key = "revampedPokeMartUI",
      type = "toggle",
      label = "POKéMART UI",
      default = true,
    },
    {
      key = "revampedPokemonPC",
      type = "toggle",
      label = "POKéMON PC UI",
      default = true,
    },
    {
      key = "revampedPokedex",
      type = "toggle",
      label = "POKéDEX UI",
      default = true,
    },
    {
      key = "revampedDialogueBoxes",
      type = "toggle",
      label = "DIALOGUE / TEXT BOXES",
      default = true,
    },
    {
      key = "hideNativeBattleUI",
      type = "toggle",
      label = "STRICT NATIVE BATTLE UI BLOCK",
      default = false,
    },
    {
      key = "mobileBattleUI",
      type = "toggle",
      label = "MOBILE BATTLE UI",
      default = false,
    },
    {
      key = "battleHudWidth",
      type = "choice",
      label = "BATTLE HUD WIDTH",
      default = "normal",
      choices = {
        {"COMPACT","compact"},
        {"NORMAL","normal"},
        {"WIDE","wide"},
        {"X-WIDE","x-wide"},
      },
    },
    {
      key = "battleHudHeight",
      type = "choice",
      label = "BATTLE HUD HEIGHT",
      default = "normal",
      choices = {
        {"COMPACT","compact"},
        {"NORMAL","normal"},
        {"TALL","tall"},
        {"X-TALL","x-tall"},
      },
    },
    {
      key = "battleHudPortrait",
      type = "choice",
      label = "BATTLE PORTRAIT SIZE",
      default = "normal",
      choices = {
        {"SMALL","small"},
        {"NORMAL","normal"},
        {"LARGE","large"},
        {"X-LARGE","x-large"},
      },
    },
    {
      key = "uiTextProfile",
      type = "choice",
      label = "TEXT PROFILE",
      default = "og",
      choices = {
        {"OG STYLE","og"},
        {"CRISP & LARGE","crisp_large"},
        {"SMOOTH READER","smooth_reader"},
        {"BOLD HIGH-CONTRAST","bold_contrast"},
        {"SYSTEM SANS","system_sans"},
      },
    },
    {
      key = "uiTextSize",
      type = "choice",
      label = "TEXT SIZE",
      default = "normal",
      choices = {
        {"SMALL","small"},
        {"NORMAL","normal"},
        {"LARGE","large"},
        {"X-LARGE","x-large"},
      },
    },
    {
      key = "uiTextWeight",
      type = "choice",
      label = "TEXT THICKNESS",
      default = "normal",
      choices = {
        {"THIN","thin"},
        {"NORMAL","normal"},
        {"BOLD","bold"},
      },
    },
    {
      key = "uiBoxScale",
      type = "choice",
      label = "UI BOX SIZE",
      default = "normal",
      choices = {
        {"COMPACT","compact"},
        {"NORMAL","normal"},
        {"LARGE","large"},
        {"X-LARGE","x-large"},
      },
    },
    {
      key = "uiBorderColor",
      type = "choice",
      label = "BORDER COLOR",
      default = "gold",
      choices = {
        {"GOLD", "gold"},
        {"RED", "red"},
        {"ORANGE", "orange"},
        {"YELLOW", "yellow"},
        {"GREEN", "green"},
        {"CYAN", "cyan"},
        {"BLUE", "blue"},
        {"PURPLE", "purple"},
        {"PINK", "pink"},
        {"BROWN", "brown"},
        {"GRAY", "gray"},
        {"WHITE", "white"},
        {"BLACK", "black"},
      },
    },
    {
      key = "uiBorderStyle",
      type = "choice",
      label = "BORDER STYLE",
      default = "classic",
      choices = {
        {"CLASSIC", "classic"},
        {"DOUBLE", "double"},
        {"BOLD", "bold"},
        {"DASHED", "dashed"},
        {"DOTTED", "dotted"},
        {"STRIPED", "striped"},
        {"CHECKER", "checker"},
        {"MINIMAL", "minimal"},
      },
    },
  }
  for _,spec in ipairs(SCREEN_TOGGLE_SPECS) do
    optionDefs[#optionDefs+1]={
      key=spec.key,
      type="toggle",
      label=spec.label,
      default=true,
    }
  end
  mod.options:define(optionDefs)

  if mod.log then
    mod.log:info("Colosseum Inspired UI Overhaul: options registered")
  end
end


local fonts = {}
local vanillaTextPatched = false
local overworldUIPatched = false
local overworldFonts = {}
local partyRenderOX, partyRenderOY, partyRenderScale = 0, 0, 1

-- -------------------------------------------------------------------------
-- Helpers
-- -------------------------------------------------------------------------

local function clamp(v, lo, hi)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local function shownHP(b)
  if not b then return 0 end
  return math.max(0, math.floor(b.shownHP or (b.mon and b.mon.hp) or 0))
end

local function maxHP(b)
  return math.max(1, math.floor(
    (b and b.mon and (b.mon.maxHp
      or (b.mon.stats and b.mon.stats.hp))) or 1
  ))
end

local function expRatio(battle, battler)
  local mon = battler and battler.mon
  if not (battle and battle.data and mon) then return 0 end
  -- Gold's BattleState deliberately chases experience through shownExp as a
  -- 64-pixel presentation value.  The core commits mon.experience as soon as
  -- the KO is resolved, before the faint line and EXP event have played; using
  -- that live total makes our bar jump during the finishing move.  Follow the
  -- same staged value as Gold's native HUD for the player's active battler.
  if battle.__gen2 and battler==battle.player
      and type(battle.shownExp)=="number" then
    return battle.shownExp/64
  end
  return GoldCompat.experienceRatio(battle.data,mon,
    (battle.__gen2 or GoldCompat.generation=="gen2") and "gen2" or "gen1")
end

function GoldCompat.safeExpRatio(battle, battler)
  local ok, value = pcall(expRatio, battle, battler)
  if not ok or type(value) ~= "number" or value ~= value then
    return 0
  end
  return clamp(value, 0, 1)
end

local function battleInStack(game, battle)
  battle=GoldCompat.sourceBattleState(battle)
  if not (game and game.stack and game.stack.states and battle) then return false end
  for _, state in ipairs(game.stack.states) do
    if state == battle then return true end
  end
  return false
end

local function topState(game)
  if not (game and game.stack) then return nil end
  if game.stack.top then
    local ok,state=pcall(game.stack.top,game.stack)
    if ok and state then return state end
  end
  local states=game.stack.states
  return states and states[#states] or nil
end

function GoldCompat.namingScreenOwnsForeground(game)
  local top=topState(game)
  if not top then return false end

  -- Current Gen1Recomp NamingScreen uses this metatable. screenId keeps this
  -- safe for registered/mod-provided naming screens following Screens' contract.
  return getmetatable(top)==NamingScreen
      or top.screenId=="NamingScreen"
      or top.screenId=="naming"
end

local function battleOwnsForeground(game, battle)
  battle=GoldCompat.sourceBattleState(battle)
  if not (game and game.stack and battle) then return false end
  local top = game.stack.top and game.stack:top()
      or (game.stack.states and game.stack.states[#game.stack.states])
  return top == battle
end

local function shouldDrawStatusHUD(game, battle)
  -- Bag, Party, Summary, Naming, etc. are pushed above BattleState. When one
  -- owns the foreground, no battle status chrome should leak over it.
  if not battleOwnsForeground(game, battle) then return false end

  -- Move selection is a full battle-owned menu rather than a battlefield
  -- prompt. Its larger panel intentionally gets the full lower-right region.
  if battle.phase == "moveSelect" or battle.phase == "mimicSelect" then
    return false
  end

  return true
end

local function enemyVisible(battle)
  if not battle or not battle.enemy then return false end
  if battle.__gen2 then
    local src=battle.__gen3Source
    return src and src.showEnemyHud and not battle.showEnemyTrainer
        and not battle.enemy.fainted
  end
  if battle.showEnemyTrainer or battle.enemySendingOut then return false end
  if battle.enemy.fainted or battle.introBalls then return false end
  if battle.growInScale and battle:growInScale(battle.enemy) then return false end
  return (battle.introSlide or 0) == 0
end

local function playerVisible(battle)
  if not battle or not battle.player then return false end
  if battle.__gen2 then
    local src=battle.__gen3Source
    return src and src.showPlayerHud and not battle.showPlayerBack
        and not battle.player.fainted
  end
  if GoldCompat.resolvedSafariState(battle) or battle.demo or battle.showPlayerBack then return false end
  return (battle.introSlide or 0) == 0
end

local function statusText(battle, battler)
  if not battler or not battler.shownStatus then return nil end
  if battle and battle.statusLabel then
    local ok, label = pcall(battle.statusLabel, battle,
      { status = battler.shownStatus })
    if ok and label and label ~= "" then return tostring(label):upper() end
  end
  return tostring(battler.shownStatus):upper()
end

local function statusColor(label)
  label = tostring(label or ""):upper()
  if label:find("PSN", 1, true) or label:find("TOX", 1, true) then
    return 0.54, 0.18, 0.67, 1
  elseif label:find("PAR", 1, true) then
    return 0.84, 0.59, 0.04, 1
  elseif label:find("BRN", 1, true) then
    return 0.84, 0.26, 0.09, 1
  elseif label:find("FRZ", 1, true) then
    return 0.13, 0.52, 0.76, 1
  elseif label:find("SLP", 1, true) then
    return 0.34, 0.37, 0.42, 1
  end
  return 0.26, 0.26, 0.24, 1
end

local function hpColor(ratio)
  if ratio > 0.50 then return 0.24, 0.79, 0.42, 1 end
  if ratio > 0.20 then return 0.94, 0.68, 0.09, 1 end
  return 0.88, 0.17, 0.12, 1
end

-- -------------------------------------------------------------------------
-- Vanilla battle text/menu visual suppression
-- -------------------------------------------------------------------------

local function runDrawInvisible(fn, self, ...)
  -- Do not skip an engine/mod draw method just because we own its pixels.
  -- Some presentation methods also advance presentation state (for example
  -- BattleState:drawTextArea decays scrollPx). Run them with an empty scissor
  -- so their lifecycle stays native while no legacy pixels reach the frame.
  local g=love.graphics
  g.push("all")
  g.setScissor(0,0,0,0)
  local ok,result=pcall(fn,self,...)
  g.pop()
  if not ok then error(result) end
  return result
end

local function patchVanillaTextDrawing()
  -- Do not take ownership of BattleState.draw itself. StadiumBattleFX,
  -- Dramatic Shape and camera/presentation mods legitimately wrap that method.
  -- The UI overhaul only owns the native UI predicates/HUD-only seam.
  if vanillaTextPatched then return end
  vanillaTextPatched=true
  GoldCompat.installBattleUiFirewall()
end

-- -------------------------------------------------------------------------
-- Assets and smooth screen fonts
-- -------------------------------------------------------------------------

local function font(size)
  local profile=GoldCompat.activeTextProfile()
  size = math.max(4, math.floor(size + 0.5))
  -- "context" means OG STYLE: preserve this call site's original linear
  -- filter exactly. Every other profile picks its own filter uniformly.
  local filter=(profile.filterMode=="context") and "linear" or profile.filterMode
  local cacheKey=profile.id..":"..filter..":"..size
  if fonts[cacheKey] then return fonts[cacheKey] end

  local ok, f
  if profile.fontPath then
    ok, f = pcall(love.graphics.newFont, profile.fontPath, size, "normal")
  else
    -- No path: Love2D's built-in default typeface (SYSTEM SANS profile).
    ok, f = pcall(love.graphics.newFont, size)
  end
  if not ok or not f then
    local fallback = love.graphics.getFont()
    fonts[cacheKey] = fallback
    return fallback
  end

  if f.setFilter then pcall(f.setFilter, f, filter, filter) end
  fonts[cacheKey] = f
  return f
end

local function printText(text, x, y, size, color, align, width)
  local g = love.graphics
  local scaledSize=math.max(4,(tonumber(size) or 4)*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local f = font(scaledSize)
  local old = g.getFont()
  g.setFont(f)

  text = tostring(text or "")
  color = color or {0.11,0.12,0.11,1}
  local shadow = {0.14,0.16,0.13,0.24}

  if GoldCompat.colosseumSkinDepth and GoldCompat.colosseumSkinDepth>0
      and type(color)=="table" then
    local r,gc,b=color[1] or 0,color[2] or 0,color[3] or 0
    local hi=math.max(r,gc,b)
    local lo=math.min(r,gc,b)
    if hi>0.88 and hi-lo<0.12 then
      color={0.98,0.99,0.97,color[4] or 1}
      shadow={0.005,0.012,0.014,0.58}
    elseif hi-lo<0.085 and hi<0.56 then
      if hi<0.20 then
        color={0.97,0.98,0.95,color[4] or 1}
      else
        color={0.63,0.78,0.76,color[4] or 1}
      end
      shadow={0.005,0.012,0.014,0.58}
    end
  end

  if width then
    g.setColor(shadow)
    g.printf(text, x+1, y+1, width, align or "left")
    g.setColor(color)
    g.printf(text, x, y, width, align or "left")
    -- Subtle second pass gives the thin pixel font a little more body without
    -- turning it into an obviously bold face.
    g.printf(text, x+GoldCompat.userTextWeight(), y, width, align or "left")
  else
    g.setColor(shadow)
    g.print(text, x+1, y+1)
    g.setColor(color)
    g.print(text, x, y)
    g.print(text, x+GoldCompat.userTextWeight(), y)
  end

  if old then g.setFont(old) end
  g.setColor(1,1,1,1)
end


local function fittedDialogueMetrics(lines, preferred, minimum, maxWidth, maxHeight)
  local size=math.max(minimum or 4,preferred or 4)
  local floorSize=math.max(4,minimum or 4)
  local visible=math.max(1,#(lines or {}))

  while size > floorSize do
    local f=font(size*UI_TEXT_SCALE*GoldCompat.userTextScale())
    local fitsWidth=true
    for i=1,visible do
      if f:getWidth(tostring(lines[i] or "")) + 4 > maxWidth then
        fitsWidth=false
        break
      end
    end

    -- Use the font's ACTUAL line box rather than assuming fontSize == height.
    local glyphH=f:getHeight()
    local lineH=math.ceil(glyphH*1.10)
    local blockH=glyphH + math.max(0,visible-1)*lineH

    if fitsWidth and blockH <= maxHeight then
      return size,glyphH,lineH,blockH
    end
    size=size-1
  end

  local f=font(floorSize*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local glyphH=f:getHeight()
  local lineH=math.ceil(glyphH*1.08)
  local blockH=glyphH + math.max(0,visible-1)*lineH
  return floorSize,glyphH,lineH,blockH
end

-- BattleState.current.text is already the actual localized, human-readable
-- message string. The engine only converts it to glyph codes for the vanilla
-- typewriter. Using the source string avoids lossy reverse-charmap decoding.
local function splitBattleMessageText(text)
  text=tostring(text or "")
  local out={}
  local pos=1
  while true do
    local s,e=text:find("[\n\v]",pos)
    if not s then
      out[#out+1]=text:sub(pos)
      break
    end
    out[#out+1]=text:sub(pos,s-1)
    pos=e+1
  end
  return out
end

function GoldCompat.revealedGlyphText(source, count)
  source=tostring(source or "")
  count=math.max(0,tonumber(count) or 0)
  if count==0 then return "" end

  -- EngineFont.split uses the exact active Gen1Recomp charmap, so multi-byte
  -- glyphs such as é and mod-provided glyph sequences stay intact.
  local spans=EngineFont.split(source)
  if count>=#spans then return source end
  local last=spans[count]
  return last and source:sub(1,last.to) or ""
end

local function messageLines(battle)
  if battle and battle.__gen2 then
    local msg=tostring(battle.message or
      (battle.current and battle.current.text) or "")
    if msg=="" then return battle.__gen3VisibleMessageLines or {} end
    local out={}
    for line in msg:gmatch("[^\n\v]+") do out[#out+1]=line end
    if #out==0 then out[1]=msg end
    battle.__gen3VisibleMessageLines=out
    battle.__gen3FullMessageLines=out
    return out
  end

  -- BattleState.shown is THE engine's rendered rolling two-line window.
  -- Do not reconstruct CONT/newline state ourselves. `shown` already accounts
  -- for typing progress, beginMsgLine(), CONT scrolling, and sayChoice pages.
  local shown=battle and battle.shown or nil
  local source=battle and battle.current and battle.current.text or nil

  if shown and source and #shown>0 then
    local sourceLines=splitBattleMessageText(source)
    local lineIndex=math.max(1,tonumber(battle.lineIndex) or 1)
    local firstSource=math.max(1,lineIndex-#shown+1)
    local out={}

    local pageComplete =
      battle.msgWaiting
      or battle.msgPrompt
      or battle.msgHold
      or (battle.current and battle.current.done)

    for visibleIndex,codes in ipairs(shown) do
      local sourceIndex=firstSource+visibleIndex-1
      local full=sourceLines[sourceIndex] or ""

      -- At the completed/waiting state the source string is authoritative.
      -- Turbo/fast-forward can advance shown-code bookkeeping a frame behind
      -- the visible page, which previously dropped the final few glyphs.
      -- Keep this function faithful to native typewriter line ownership.
      -- Completed pages are rewrapped later in drawDialogue using the actual
      -- display font and content width.
      out[#out+1]=GoldCompat.revealedGlyphText(full,#(codes or {}))
    end

    battle.__gen3VisibleMessageLines=out
    return out
  end

  -- Animations may deliberately retain the prior typed page after current is
  -- cleared; mirror BattleState.drawTextArea's msgHold behavior.
  return (battle and battle.__gen3VisibleMessageLines) or {}
end

function GoldCompat.messagePageFullLines(battle)
  if battle and battle.__gen2 then
    return messageLines(battle)
  end
  local source=battle and battle.current and battle.current.text or nil
  local shown=battle and battle.shown or nil
  if not source or not shown or #shown==0 then
    return battle and battle.__gen3FullMessageLines or {}
  end

  local sourceLines=splitBattleMessageText(source)
  local lineIndex=math.max(1,tonumber(battle.lineIndex) or 1)
  local firstSource=math.max(1,lineIndex-#shown+1)
  local out={}
  for i=1,#shown do
    out[#out+1]=sourceLines[firstSource+i-1] or ""
  end

  battle.__gen3FullMessageLines=out
  return out
end

local function wrapCompletedBattleLines(sourceLines,size,maxWidth)
  local f=font(size*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local out={}

  for _,line in ipairs(sourceLines or {}) do
    line=tostring(line or "")
    local _,wrapped=f:getWrap(line,math.max(1,maxWidth))
    if type(wrapped)=="table" and #wrapped>0 then
      for _,part in ipairs(wrapped) do
        out[#out+1]=part
      end
    else
      out[#out+1]=line
    end
  end

  if #out==0 then out[1]="" end
  return out
end

function GoldCompat.fittedCompletedDialogue(sourceLines,preferred,minimum,maxWidth,maxHeight)
  local size=math.max(minimum or 4,preferred or 4)
  local floorSize=math.max(4,(minimum or 4)*0.88)

  while size>floorSize do
    local wrapped=wrapCompletedBattleLines(sourceLines,size,maxWidth)
    local f=font(size*UI_TEXT_SCALE*GoldCompat.userTextScale())
    local glyphH=f:getHeight()
    local lineH=math.ceil(glyphH*1.10)
    local visible=math.min(2,#wrapped)
    local blockH=glyphH + math.max(0,visible-1)*lineH

    if #wrapped<=2 and blockH<=maxHeight then
      return size,glyphH,lineH,blockH,wrapped
    end
    size=size-1
  end

  local wrapped=wrapCompletedBattleLines(sourceLines,floorSize,maxWidth)
  local f=font(floorSize*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local glyphH=f:getHeight()
  local lineH=math.ceil(glyphH*1.08)
  local visible=math.min(2,#wrapped)
  local blockH=glyphH + math.max(0,visible-1)*lineH
  return floorSize,glyphH,lineH,blockH,wrapped
end


local function displayName(battler)
  local raw = battler and (
    battler.name
    or (battler.mon and battler.mon.nickname)
    or (battler.mon and battler.mon.name)
  )
  return tostring(raw or "POKEMON")
end

local function roundedRect(mode, x, y, w, h, r)
  love.graphics.rectangle(mode, x, y, w, h, r, r)
end

local UI_BORDER_COLORS = {
  gold   = {0.72,0.58,0.30,1},
  red    = {0.78,0.18,0.16,1},
  orange = {0.90,0.43,0.12,1},
  yellow = {0.88,0.72,0.14,1},
  green  = {0.19,0.62,0.30,1},
  cyan   = {0.14,0.65,0.70,1},
  blue   = {0.18,0.42,0.78,1},
  purple = {0.48,0.27,0.68,1},
  pink   = {0.82,0.37,0.57,1},
  brown  = {0.47,0.30,0.17,1},
  gray   = {0.46,0.47,0.45,1},
  white  = {0.91,0.91,0.87,1},
  black  = {0.08,0.08,0.07,1},
}

function GoldCompat.currentBorderColor()
  return UI_BORDER_COLORS[optionValue("uiBorderColor")] or UI_BORDER_COLORS.gold
end

local function setCurrentBorderColor(alpha)
  local c = GoldCompat.currentBorderColor()
  love.graphics.setColor(c[1],c[2],c[3],alpha or 1)
end

function GoldCompat.currentBorderStyle()
  return optionValue("uiBorderStyle") or "classic"
end

local function borderLine(x,y,w,h,r)
  if r and r > 0 then
    roundedRect("line",x,y,w,h,r)
  else
    love.graphics.rectangle("line",x,y,w,h)
  end
end

local function drawUnifiedBorder(x,y,w,h,r)
  local g = love.graphics
  local style = GoldCompat.currentBorderStyle()
  r = r or 0
  setCurrentBorderColor(1)
  g.setLineWidth(1)

  if style == "minimal" then
    g.line(x+3,y+h-3,x+w-3,y+h-3)

  elseif style == "double" then
    borderLine(x+2,y+2,w-4,h-4,math.max(0,r-1))
    borderLine(x+4,y+4,w-8,h-8,math.max(0,r-2))

  elseif style == "bold" then
    g.setLineWidth(3)
    borderLine(x+3,y+3,w-6,h-6,math.max(0,r-2))

  elseif style == "dashed" then
    for xx=x+3,x+w-5,6 do
      g.line(xx,y+3,math.min(xx+3,x+w-3),y+3)
      g.line(xx,y+h-3,math.min(xx+3,x+w-3),y+h-3)
    end
    for yy=y+3,y+h-5,6 do
      g.line(x+3,yy,x+3,math.min(yy+3,y+h-3))
      g.line(x+w-3,yy,x+w-3,math.min(yy+3,y+h-3))
    end

  elseif style == "dotted" then
    for xx=x+3,x+w-3,5 do
      g.points(xx,y+3)
      g.points(xx,y+h-3)
    end
    for yy=y+3,y+h-3,5 do
      g.points(x+3,yy)
      g.points(x+w-3,yy)
    end

  elseif style == "striped" then
    for xx=x+3,x+w-7,7 do
      g.polygon("fill",xx,y+2,xx+3,y+2,xx+6,y+5,xx+3,y+5)
      g.polygon("fill",xx,y+h-5,xx+3,y+h-5,xx+6,y+h-2,xx+3,y+h-2)
    end
    g.rectangle("fill",x+2,y+3,2,h-6)
    g.rectangle("fill",x+w-4,y+3,2,h-6)

  elseif style == "checker" then
    for xx=x+3,x+w-5,5 do
      if math.floor((xx-x)/5)%2 == 0 then
        g.rectangle("fill",xx,y+2,3,3)
        g.rectangle("fill",xx,y+h-5,3,3)
      end
    end
    for yy=y+3,y+h-5,5 do
      if math.floor((yy-y)/5)%2 == 1 then
        g.rectangle("fill",x+2,yy,3,3)
        g.rectangle("fill",x+w-5,yy,3,3)
      end
    end

  else -- classic
    borderLine(x+3,y+3,w-6,h-6,math.max(0,r-2))
  end

  g.setLineWidth(1)
  g.setColor(1,1,1,1)
end


-- -------------------------------------------------------------------------
-- Status HUD
-- -------------------------------------------------------------------------

local function hudScale()
  local sw,sh=love.graphics.getDimensions()
  local raw=math.min(sw/430,sh/245)

  local scale
  if raw <= 4.5 then
    scale=clamp(raw,2.85,3.85)
  else
    scale=clamp(3.85 + (raw-4.5)*0.72,3.85,7.0)
  end
  return scale*GoldCompat.userBoxScale()
end

local function drawPlate(x, y, w, h, s)
  local g = love.graphics
  local radius = 7*s

  -- Deep teal cast shadow.
  g.setColor(0.11,0.22,0.21,0.78)
  roundedRect("fill", x+4*s, y+5*s, w, h, radius)

  -- Globally selected border color.
  setCurrentBorderColor(1)
  roundedRect("fill", x-1.2*s, y-1.2*s, w+2.4*s, h+2.4*s, radius+1*s)

  -- Dark green-gray frame.
  g.setColor(0.24,0.31,0.28,1)
  roundedRect("fill", x, y, w, h, radius)

  -- Cream face.
  g.setColor(0.965,0.945,0.86,1)
  roundedRect("fill", x+2.4*s, y+2.4*s, w-4.8*s, h-4.8*s, radius-1.5*s)

  -- Inner highlight.
  g.setColor(1.0,0.99,0.94,0.9)
  g.setLineWidth(math.max(1.2,0.7*s))
  roundedRect("line", x+4*s, y+4*s, w-8*s, h-8*s, radius-2*s)
  drawUnifiedBorder(x,y,w,h,radius)
end

local function drawStyledHP(x, y, w, h, battler)
  local g = love.graphics
  local hp, mx = shownHP(battler), maxHP(battler)
  local ratio = clamp(hp / mx, 0, 1)

  -- Dark HP capsule.
  local badgeW = h * 1.95
  g.setColor(0.18,0.31,0.29,1)
  roundedRect("fill", x, y, badgeW, h, h*0.38)

  -- Center HP against the actual capsule/bar geometry. The old y+h*0.00
  -- offset made the label ride high relative to the HP bar.
  local hpTextSize = h*0.68
  local hpFont = font(hpTextSize*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local hpTextH = hpFont and hpFont:getHeight() or hpTextSize

  -- Keep a little breathing room inside the badge and bias the label upward.
  -- Pixel fonts visually sit lower than their nominal bounding box, so a
  -- slight negative offset looks centered against the HP bar.
  local hpPadX = h*0.18
  local hpTextY = y + math.max(0,(h-hpTextH)*0.5) - h*0.10
  printText("HP", x+hpPadX, hpTextY, hpTextSize,
            {0.96,0.72,0.18,1},"center",badgeW-hpPadX*2)

  local bx = x + badgeW - h*0.20
  local bw = w - badgeW + h*0.20

  g.setColor(0.18,0.24,0.22,1)
  roundedRect("fill", bx,y,bw,h,h*0.38)
  g.setColor(0.73,0.72,0.62,1)
  roundedRect("fill", bx+2,y+2,bw-4,h-4,math.max(2,h*0.27))

  local innerW = math.max(0,bw-4)
  local fillW = innerW * ratio
  if hp > 0 then fillW = math.max(2,fillW) end
  if fillW > 0 then
    local r,gg,b,a = hpColor(ratio)
    g.setColor(r,gg,b,a)
    roundedRect("fill", bx+2,y+2,fillW,h-4,math.max(2,h*0.25))
    g.setColor(math.min(1,r+0.18),math.min(1,gg+0.18),
               math.min(1,b+0.18),0.80)
    roundedRect("fill",bx+4,y+3,math.max(0,fillW-4),
                math.max(2,(h-4)*0.28),2)
  end
end

function GoldCompat.drawEXPRow(plateX, plateY, plateW, plateH, battle, battler, s)
  local g = love.graphics
  local ratio = GoldCompat.safeExpRatio(battle, battler)

  -- Exact player-plate-relative geometry.
  local left = plateX + 7*s
  local right = plateX + plateW - 6*s
  local labelW = 22*s
  local barH = 4.6*s
  local rowY = plateY + plateH - 9*s

  -- EXP label: warm Gen III yellow.
  pcall(printText, "EXP", left, rowY - 0.9*s,
        3.9*s, {0.86,0.64,0.08,1})

  -- Rail begins after label and stretches to the right plate inset.
  local barX = left + labelW
  local barW = math.max(8*s, right - barX)

  -- Outer dark teal capsule.
  g.setColor(0.10,0.20,0.23,1)
  roundedRect("fill", barX, rowY, barW, barH, 2.0*s)

  -- Blue-tinted empty track so the EXP row is recognizable even at 0%.
  local pad = 0.9*s
  local ix = barX + pad
  local iy = rowY + pad
  local iw = math.max(1, barW - pad*2)
  local ih = math.max(1, barH - pad*2)

  g.setColor(0.18,0.31,0.43,1)
  roundedRect("fill", ix, iy, iw, ih, 1.2*s)

  -- Live blue EXP fill.
  local fw = iw * ratio
  if fw > 0 then
    g.setColor(0.03,0.39,0.96,1)
    roundedRect("fill", ix, iy, fw, ih, 1.2*s)

    -- Cyan highlight gives it the FireRed/GBA gloss.
    g.setColor(0.40,0.80,1.00,0.98)
    roundedRect("fill",
                ix + 0.4*s,
                iy + 0.25*s,
                math.max(0, fw - 0.8*s),
                math.max(1, ih*0.30),
                0.4*s)
  end

  g.setColor(1,1,1,1)
end

local function directBattleGender(battle,sideName,side)
  local data=(battle and battle.data)
      or (battle and battle.game and battle.game.data)
      or {}
  local src=GoldCompat.sourceBattleState(battle)
  if src and src.game and src.game.data then data=src.game.data end

  local okMon,Mon=pcall(require,"src.battle.gen2.Mon")

  local function resolve(mon)
    if type(mon)~="table" then return nil end
    local g=mon.gender
    if g=="male" or g=="female" then return g end

    local species=mon.species or mon.id
    local dvs=mon.dvs
    local def=species and data and data.pokemon and data.pokemon[species]
    if okMon and Mon and type(Mon.gender)=="function" and def and dvs then
      local ok,value=pcall(Mon.gender,def,dvs,{
        species=species,
        level=mon.level,
      })
      if ok and (value=="male" or value=="female") then return value end
    end
    return nil
  end

  -- Presentation facade first.
  local candidates={
    side,
    side and side.live,
    side and side.mon,
    side and side.active,
    side and side.current,
    side and side.pokemon,
  }

  -- Then inspect the real Gen 2 battle state. Different beta revisions have
  -- used both player/enemy keys and 1/2 slots for shownMon.
  if src then
    local idx=(sideName=="player") and 1 or 2
    local shown=src.shownMon
    candidates[#candidates+1]=type(shown)=="table" and shown[sideName] or nil
    candidates[#candidates+1]=type(shown)=="table" and shown[idx] or nil

    local core=src.battle
    local coreSide=core and core[sideName]
    candidates[#candidates+1]=coreSide
    candidates[#candidates+1]=coreSide and coreSide.mon
    candidates[#candidates+1]=coreSide and coreSide.active
    candidates[#candidates+1]=coreSide and coreSide.current
  end

  for _,candidate in ipairs(candidates) do
    local g=resolve(candidate)
    if g then return g end
  end
  return nil
end

local function battleNameWidth(text,size)
  local ok,w=pcall(function()
    local f=font((tonumber(size) or 4)*UI_TEXT_SCALE*GoldCompat.userTextScale())
    return f and f:getWidth(tostring(text or "")) or 0
  end)
  if ok and tonumber(w) then return w end
  return #tostring(text or "")*(tonumber(size) or 4)*0.55
end

local function drawEnemyHUD(battle, s)
  if not enemyVisible(battle) then return end

  local margin=7*s
  local w,h=112*s,31*s
  local sw=love.graphics.getWidth()
  -- Corner layout: enemy always owns the upper-left edge.
  local x=margin
  local y=margin
  local b=battle.enemy

  drawPlate(x,y,w,h,s)

  local textColor={0.11,0.12,0.11,1}
  local enemyName=displayName(b)
  printText(enemyName,x+7*s,y+2.0*s,6.4*s,textColor)
  do
    -- presentBattleState already stamps the live Gen2 mon's gender onto this
    -- side facade. Keep the glyph in a fixed reserved slot between name/level
    -- so font measurement can never suppress it.
    local gender=b and b.gender
    if gender~="male" and gender~="female" then
      gender=directBattleGender(battle,"enemy",b)
    end
    if gender=="male" or gender=="female" then
      -- Sit immediately after the rendered Pokémon name, with a hard cap that
      -- leaves the Lv. field untouched.
      local nameX=x+7*s
      local nameW=battleNameWidth(enemyName,6.4*s)
      local gx=math.min(nameX+nameW+1.5*s, x+56*s)
      local gy=y+5.35*s
      local iconSize=math.max(9,math.min(12,3.0*s))
      GoldCompat.drawGenderIcon(gx,gy,iconSize,gender)
    end
  end
  printText("Lv."..tostring((b.mon and b.mon.level) or "?"),
            x+64*s,y+2.2*s,5.5*s,textColor,"right",39*s)

  drawStyledHP(x+7*s,y+14.5*s,97*s,7*s,b)

  local status=statusText(battle,b)
  if status then
    local r,g,bb,aa=statusColor(status)
    printText(status,x+8*s,y+22.0*s,3.8*s,{r,g,bb,aa})
  end
end

local function drawPlayerHUD(battle, s, commandRect)
  if not playerVisible(battle) then return end

  local sw=love.graphics.getWidth()
  local w,h=116*s,45*s
  local margin=7*s
  local x=sw-w-margin
  local y=commandRect.y-h-6*s
  local b=battle.player

  -- Core geometry first. These are intentionally not dependent on font rendering.
  drawPlate(x,y,w,h,s)
  drawStyledHP(x+8*s,y+13.8*s,101*s,7.2*s,b)

  -- EXP is a core HUD primitive now, not a decorative tail-end draw.
  -- It renders before any potentially failing status/number typography.
  GoldCompat.drawEXPRow(x, y, w, h, battle, b, s)

  local textColor={0.11,0.12,0.11,1}

  -- Name and level are independently protected.
  pcall(function()
    local playerName=displayName(b)
    printText(playerName,x+8*s,y+1.8*s,6.4*s,textColor)
  end)

  do
    local gender=b and b.gender
    if gender~="male" and gender~="female" then
      gender=directBattleGender(battle,"player",b)
    end
    if gender=="male" or gender=="female" then
      local playerName=displayName(b)
      local nameX=x+8*s
      local nameW=battleNameWidth(playerName,6.4*s)
      local gx=math.min(nameX+nameW+1.5*s, x+58*s)
      local gy=y+5.15*s
      local iconSize=math.max(9,math.min(12,3.0*s))
      GoldCompat.drawGenderIcon(gx,gy,iconSize,gender)
    end
  end
  pcall(function()
    printText("Lv."..tostring((b.mon and b.mon.level) or "?"),
              x+65*s,y+2.1*s,5.4*s,textColor,"right",41*s)
  end)

  -- Status cannot stop HP numbers or EXP.
  pcall(function()
    local status=statusText(battle,b)
    if status then
      local r,g,bb,aa=statusColor(status)
      local lg=love.graphics
      lg.setColor(r,g,bb,0.12)
      roundedRect("fill",x+8*s,y+22.2*s,25*s,7.0*s,2.4*s)
      printText(status,x+10*s,y+22.0*s,3.8*s,{r,g,bb,aa})
      lg.setColor(1,1,1,1)
    end
  end)

  -- Numeric HP is also isolated.
  pcall(function()
    local hpText=tostring(shownHP(b)).." / "..tostring(maxHP(b))
    printText(hpText,x+55*s,y+21.8*s,4.4*s,textColor,"right",53*s)
  end)
end

function GoldCompat.drawBattleGenderOverlay(battle,s,commandRect)
  return false
end

-- -------------------------------------------------------------------------
-- Responsive command + dialogue panels
-- -------------------------------------------------------------------------

local function battleMenuScale()
  local sw,sh=love.graphics.getDimensions()
  local raw=math.min(sw/1280,sh/720)

  local scale
  if raw <= 1.5 then
    scale=clamp(raw,0.68,1.18)
  else
    scale=clamp(1.18 + (raw-1.5)*0.75,1.18,2.30)
  end

  return scale*GoldCompat.userBoxScale()
end

local function commandGeometry()
  local sw, sh = love.graphics.getDimensions()
  local u = battleMenuScale()

  local w = clamp(600*u,390,1380)
  local h = clamp(210*u,145,485)
  local margin = clamp(24*u,14,56)

  return { x=sw-w-margin, y=sh-h-margin, w=w, h=h, u=u }
end

function GoldCompat.dialogueGeometry()
  local sw, sh = love.graphics.getDimensions()

  -- Dialogue uses the same bottom footprint as the command panel but is wider.
  local mobile=featureEnabled("mobileBattleUI")
  local portrait=sh>sw
  local w
  local h
  local margin
  if mobile then
    -- A centered safe-zone card stays clear of the bottom control cluster
    -- used by common portrait and landscape mobile overlays.
    w=clamp(sw*(portrait and 0.82 or 0.46),260,portrait and 600 or 720)
    h=clamp(sh*(portrait and 0.082 or 0.088),68,108)
    margin=clamp(sw*0.018,12,24)
  else
    w=clamp(sw*0.58*0.90*0.94,650,1040*0.90*0.94)
    h=clamp(sh*0.118*1.13*1.10,96*1.08*1.08,128*1.13*1.10)
    margin=clamp(sw*0.018,20,36)
  end

  local widthScale,heightScale=GoldCompat.dialogueLayoutScale()
  w=math.min(sw-margin*2,w*widthScale)
  h=math.min(sh-margin*2,h*heightScale)
  local x=mobile and (sw-w)*0.5 or margin
  local y=mobile and (sh-h)*0.5 or (sh-h-margin)
  return { x=x, y=y, w=w, h=h }
end


local function drawPanelBase(rect)
  local g = love.graphics

  g.setColor(0.02,0.03,0.04,0.42)
  roundedRect("fill", rect.x+8, rect.y+10, rect.w, rect.h, 17)

  g.setColor(0.95,0.95,0.92,0.98)
  roundedRect("fill", rect.x, rect.y, rect.w, rect.h, 15)

  g.setLineWidth(2.5)
  g.setColor(0.18,0.21,0.25,0.95)
  roundedRect("line", rect.x+1.25, rect.y+1.25, rect.w-2.5, rect.h-2.5, 14)
end

local function drawCommandMenu(battle)
  if not (battle and battle.phase == "menu" and not battle.demo) then return end

  local rect = commandGeometry()
  drawPanelBase(rect)

  local g = love.graphics
  local u = rect.u or battleMenuScale()
  local pad = 15*u
  local gap = 11*u
  local cellW = (rect.w-pad*2-gap)/2
  local cellH = (rect.h-pad*2-gap)/2

  -- Preserve engine semantics: 1 FIGHT, 2 PKMN, 3 ITEM, 4 RUN.
  local labels=battle.safari
    and {"SNAG","BAIT","ROCK","RUN"}
    or {"FIGHT","POKéMON","BAG","RUN"}
  local options = {
    {index=1, label=labels[1], col=0,row=0},
    {index=2, label=labels[2], col=1,row=0},
    {index=3, label=labels[3], col=0,row=1},
    {index=4, label=labels[4], col=1,row=1},
  }

  for _, opt in ipairs(options) do
    local x = rect.x+pad+opt.col*(cellW+gap)
    local y = rect.y+pad+opt.row*(cellH+gap)
    local selected = battle.menuIndex == opt.index

    if selected then
      g.setColor(0.16,0.30,0.42,1)
      roundedRect("fill", x,y,cellW,cellH,10*u)
      g.setColor(0.95,0.36,0.17,1)
      roundedRect("fill", x+6*u,y+7*u,5*u,cellH-14*u,2*u)
      printText(opt.label, x+18*u, y+cellH*0.12, cellH*0.43,
                {0.98,0.98,0.96,1}, "center", cellW-28*u)
    else
      g.setColor(0.86,0.87,0.84,1)
      roundedRect("fill", x,y,cellW,cellH,10*u)
      g.setColor(0.97,0.97,0.95,1)
      roundedRect("fill", x+2*u,y+2*u,cellW-4*u,cellH-4*u,8*u)
      printText(opt.label, x+10*u, y+cellH*0.12, cellH*0.43,
                {0.12,0.14,0.16,1}, "center", cellW-20*u)
    end
  end
end

local function drawSafariBattleRail(battle)
  if not battle then return end
  local safari=(type(battle.safari)=="table" and battle.safari)
    or (battle.game and battle.game.save and type(battle.game.save.safari)=="table"
      and battle.game.save.safari)
  if not safari then return end
  local rect=commandGeometry()
  local u=rect.u or battleMenuScale()
  local h=clamp(27*u,24,48)
  local y=math.max(10,rect.y-h-7*u)
  local g=love.graphics
  g.setColor(0.02,0.03,0.04,0.38)
  roundedRect("fill",rect.x+5,y+5,rect.w,h,9*u)
  g.setColor(0.045,0.10,0.105,0.96)
  roundedRect("fill",rect.x,y,rect.w,h,9*u)
  g.setColor(0.30,0.61,0.58,0.98)
  g.setLineWidth(math.max(1,1.2*u))
  roundedRect("line",rect.x,y,rect.w,h,9*u)
  local balls=math.max(0,tonumber(safari.balls) or 0)
  local steps=math.max(0,tonumber(safari.steps) or 0)
  printText("SAFARI ZONE",rect.x+15*u,y+5*u,11*u,{0.48,1.00,0.68,1})
  printText("SAFARI BALLS  "..balls.."     STEPS  "..steps,
    rect.x+rect.w*0.43,y+5*u,10*u,{0.78,0.88,0.83,1},"right",rect.w*0.53)
end

local function drawDialogue(battle)
  if not (battle and battle.phase == "messages") then return end
  if battle.__gen2 then
    if not battle.message or tostring(battle.message)=="" then return end
  elseif not (battle.current or battle.animPlaying or battle.msgHold
      or #(battle.shown or {}) > 0) then
    return
  end

  local rect = GoldCompat.dialogueGeometry()
  drawPanelBase(rect)

  local g = love.graphics
  local lines = messageLines(battle)
  local fullLines = GoldCompat.messagePageFullLines(battle)
  local textColor = {0.12,0.14,0.16,1}
  local pageComplete =
    battle.msgWaiting
    or battle.msgPrompt
    or battle.msgHold
    or (battle.current and battle.current.done)
  -- Reserve extra pixels for the 0.45px weight pass and raster rounding.
  -- Without this, a line that mathematically fits exactly can lose its last
  -- one or two glyphs at the right scissor edge.
  local contentW = math.max(1, rect.w-60)
  local preferred = clamp(rect.h*0.36,34,50)
  local minimum = math.max(18,preferred*0.62)

  -- Font metrics are chosen from the COMPLETE current page, not from the
  -- characters revealed so far. Typewriter progression therefore never
  -- changes font size or line spacing mid-message.
  local innerTop = 10
  local innerBottom = 22
  local innerH = math.max(1,rect.h-innerTop-innerBottom)

  local metricSource=(#fullLines>0 and fullLines or lines)
  local metricKey=tostring(battle.current and battle.current.text or "")
      .."|"..table.concat(metricSource,"\n")
      .."|"..tostring(pageComplete)
      .."|text="..tostring(optionValue("uiTextSize"))
      .."|weight="..tostring(optionValue("uiTextWeight"))
      .."|box="..tostring(optionValue("uiBoxScale"))
      .."|w="..tostring(math.floor(rect.w+0.5))
      .."|h="..tostring(math.floor(rect.h+0.5))

  if not battle.__gen3MetricCache
      or battle.__gen3MetricCache.key~=metricKey then
    local size,glyphH,lineH,blockH,wrapped

    if pageComplete then
      size,glyphH,lineH,blockH,wrapped=GoldCompat.fittedCompletedDialogue(
        metricSource,preferred,minimum,contentW,innerH)
    else
      size,glyphH,lineH,blockH=fittedDialogueMetrics(
        metricSource,preferred,minimum,contentW,innerH)
    end

    battle.__gen3MetricCache={
      key=metricKey,size=size,glyphH=glyphH,lineH=lineH,blockH=blockH,
      wrapped=wrapped,
    }
  end

  local metrics=battle.__gen3MetricCache
  local size,glyphH,lineH,blockH=
    metrics.size,metrics.glyphH,metrics.lineH,metrics.blockH

  if pageComplete and metrics.wrapped then
    lines=metrics.wrapped
  end
  local visible=math.min(2,#lines)

  local x = rect.x+24

  -- Fixed safe baselines. Dynamic vertical centering was vulnerable to
  -- fractional font-height rounding on some renderer/scaling combinations,
  -- which let line two touch or cross the bottom border.
  local firstY = rect.y + 13
  local secondY = rect.y + rect.h - glyphH - 18

  g.setScissor(
    math.floor(rect.x+18),
    math.floor(rect.y+8),
    math.floor(rect.w-36),
    math.floor(rect.h-18)
  )

  if visible >= 1 then
    printText(lines[1],x,firstY,size,textColor,"left",contentW)
  end
  if visible >= 2 then
    printText(lines[2],x,secondY,size,textColor,"left",contentW)
  end

  g.setScissor()

  if (battle.msgWaiting or battle.msgPrompt)
      and battle.frame % 60 < 30 then
    -- clean modern continue marker
    local g = love.graphics
    g.setColor(0.20,0.31,0.42,1)
    local cx = rect.x+rect.w-31
    local cy = rect.y+rect.h-22
    g.polygon("fill", cx,cy, cx+13,cy, cx+6.5,cy+9)
  end
end


-- -------------------------------------------------------------------------
-- Modern move selection
-- -------------------------------------------------------------------------

function GoldCompat.moveGeometry()
  local sw, sh = love.graphics.getDimensions()
  local u = battleMenuScale()

  local w = clamp(720*u,470,1660)
  local h = clamp(300*u,205,690)
  local margin = clamp(24*u,14,56)

  return {
    x = sw - w - margin,
    y = sh - h - margin,
    w = w,
    h = h,
    u = u,
  }
end

function GoldCompat.moveTypeName(def)
  if not def then return "—" end
  local t = def.type or def.moveType or def.damageType
  if type(t) == "table" then
    t = t.name or t.id
  end
  if not t then return "—" end
  local cleaned=GoldCompat.humanizeIdentifier(t):upper():gsub(" TYPE$","")
  return cleaned
end

local function moveMaxPP(def, mv)
  if mv and (mv.maxPP or mv.maxPp) then return mv.maxPP or mv.maxPp end
  if def and def.pp then return def.pp end
  return mv and mv.pp or 0
end

local function drawMoveSelect(battle)
  if not (battle and battle.phase == "moveSelect"
      and battle.player and battle.player.curMoves) then
    return
  end

  local rect = GoldCompat.moveGeometry()
  drawPanelBase(rect)

  local moves = battle.player.curMoves
  local u = rect.u or battleMenuScale()
  local pad = 16*u
  local gap = 8*u
  local infoH = 50*u
  local listTop = rect.y + pad
  local listBottom = rect.y + rect.h - pad - infoH - 7*u
  local rowH = (listBottom - listTop - gap * 3) / 4

  local g = love.graphics

  for i = 1, 4 do
    local mv = moves[i]
    local y = listTop + (i - 1) * (rowH + gap)
    local selected = battle.moveIndex == i
    local disabled = battle.player.disabledSlot == i
    local marked = battle.moveSwapIndex == i

    if selected then
      g.setColor(0.16, 0.30, 0.42, 1)
      roundedRect("fill", rect.x + pad, y, rect.w - pad*2, rowH, 9*u)
      g.setColor(0.95, 0.36, 0.17, 1)
      roundedRect("fill", rect.x + pad + 6*u, y + 6*u, 5*u, rowH - 12*u, 2*u)
    else
      g.setColor(0.86, 0.87, 0.84, 1)
      roundedRect("fill", rect.x + pad, y, rect.w - pad*2, rowH, 9)
      g.setColor(0.97, 0.97, 0.95, 1)
      roundedRect("fill", rect.x + pad + 2*u, y + 2*u,
                  rect.w - pad*2 - 4*u, rowH - 4*u, 7*u)
    end

    if mv then
      local def = battle.data.moves[mv.id]
      local label = def and def.name or GoldCompat.humanizeIdentifier(mv.id)
      local curPP = mv.pp or 0
      local maxPP = moveMaxPP(def, mv)

      local textColor = selected and {0.98,0.98,0.96,1}
                                  or {0.12,0.14,0.16,1}
      if disabled then
        textColor = selected and {1.00,0.78,0.72,1}
                             or {0.62,0.30,0.26,1}
      end

      local nameSize = clamp(rowH * 0.40, 16*u, 34*u)
      printText(label, rect.x + pad + 18*u, y + rowH*0.13,
                nameSize, textColor)

      local ppText = ("%d / %d"):format(curPP, maxPP)
      printText(ppText, rect.x + rect.w - pad - 138*u, y + rowH*0.15,
                clamp(rowH*0.30, 13*u, 26*u), textColor, "right", 126*u)

      if marked then
        printText("MOVE", rect.x + rect.w - pad - 215*u, y + rowH*0.17,
                  clamp(rowH*0.25, 11*u, 21*u),
                  selected and {0.98,0.84,0.34,1} or {0.64,0.46,0.08,1})
      end
    else
      printText("—", rect.x + pad + 18*u, y + rowH*0.13,
                clamp(rowH*0.34, 14*u, 28*u),
                selected and {0.98,0.98,0.96,0.5}
                         or {0.35,0.36,0.37,0.55})
    end
  end

  local selectedMove = moves[battle.moveIndex]
  if selectedMove then
    local def = battle.data.moves[selectedMove.id]
    local typeText = "TYPE  " .. GoldCompat.moveTypeName(def)
    local ppText = ("PP  %d / %d"):format(
      selectedMove.pp or 0, moveMaxPP(def, selectedMove))

    local infoY = rect.y + rect.h - pad - infoH
    g.setColor(0.90,0.91,0.89,1)
    roundedRect("fill", rect.x + pad, infoY, rect.w - pad*2, infoH, 9*u)

    printText(typeText, rect.x + pad + 16*u, infoY + 7*u,
              23*u, {0.20,0.22,0.24,1})
    printText(ppText, rect.x + rect.w - pad - 190*u, infoY + 7*u,
              23*u, {0.20,0.22,0.24,1}, "right", 175*u)

    if battle.player.disabledSlot == battle.moveIndex then
      printText("DISABLED", rect.x + rect.w/2 - 62*u, infoY + 10*u,
                17*u, {0.70,0.20,0.16,1}, "center", 124*u)
    elseif selectedMove.pp <= 0 then
      printText("NO PP", rect.x + rect.w/2 - 54*u, infoY + 10*u,
                17*u, {0.70,0.20,0.16,1}, "center", 108*u)
    end
  end
end


-- -------------------------------------------------------------------------
-- Cohesive overworld UI alpha
-- -------------------------------------------------------------------------


-- Same Plain Pixel source as the battle HUD, but sized for the native 160x144
-- menu canvas so overworld UI and battle UI read as one continuous system.
function GoldCompat.owFont(size)
  size = math.max(7, math.floor(size + 0.5))
  if overworldFonts[size] then return overworldFonts[size] end
  local ok, f = pcall(love.graphics.newFont,
    EngineFont.PLAINPIXEL, size, "normal")
  if not ok or not f then
    local fallback = love.graphics.getFont()
    overworldFonts[size] = fallback
    return fallback
  end
  if f.setFilter then pcall(f.setFilter, f, "nearest", "nearest") end
  overworldFonts[size] = f
  return f
end

function GoldCompat.owText(text, x, y, size, color, align, width)
  local g = love.graphics
  local f = GoldCompat.owFont(size)
  local old = g.getFont()
  g.setFont(f)

  text = tostring(text or "")
  color = color or {0.08,0.08,0.08,1}

  -- Integer-aligned, single-pass text for maximum menu clarity.
  x = math.floor(x + 0.5)
  y = math.floor(y + 0.5)

  if width then
    g.setColor(color)
    g.printf(text, x, y, math.floor(width + 0.5), align or "left")
  else
    g.setColor(color)
    g.print(text, x, y)
  end

  if old then g.setFont(old) end
  g.setColor(1,1,1,1)
end


local function owStatus(mon)
  if (mon.hp or 0) <= 0 then return "FNT" end
  if mon.status then return tostring(mon.status):upper() end
  return nil
end


-- Restrained FireRed/LeafGreen-style overworld panel.
-- Unlike the battle HUD, START/Bag intentionally avoid heavy beveling/cards.
function GoldCompat.frlgMenuPanel(x, y, w, h)
  local g = love.graphics

  -- Tiny shadow, then green/olive edge, then warm white face.
  g.setColor(0.10,0.16,0.13,0.45)
  g.rectangle("fill", x+2, y+2, w, h)

  g.setColor(0.20,0.20,0.18,1)
  g.rectangle("fill", x, y, w, h)

  g.setColor(0.985,0.982,0.95,1)
  g.rectangle("fill", x+2, y+2, w-4, h-4)

  -- Light inner line gives the flat GBA panel a little HD definition.
  g.setColor(1.0,0.995,0.96,1)
  g.rectangle("line", x+3, y+3, w-6, h-6)

  g.setColor(1,1,1,1)
end

function GoldCompat.frlgSelection(x, y, w, h)
  local g = love.graphics
  -- FRLG-style restrained selection: charcoal field, white text.
  g.setColor(0.13,0.13,0.12,1)
  g.rectangle("fill", x, y, w, h)

  -- Thin light edge instead of a colored accent stripe.
  g.setColor(0.86,0.86,0.82,1)
  g.rectangle("line", x+0.5, y+0.5, w-1, h-1)

  g.setColor(1,1,1,1)
end

local martUIPatched=false
GoldCompat.openGen1MartSellBag=GoldCompat.openGen1MartSellBag

local function installMartUI()
  if martUIPatched then return end
  martUIPatched=true

  -- New launcher builds keep Gen I mart ownership in ShopMenu. Tag the root
  -- menu at that authoritative constructor as well as through Menu.new below;
  -- this makes the hanging BUY / SELL / QUIT flow resilient to other mods that
  -- wrap generic Menu construction before or after us.
  if ShopMenu and type(ShopMenu.new)=="function"
      and not ShopMenu.__colosseumMartRootPatched then
    ShopMenu.__colosseumMartRootPatched=true
    local nativeShopNew=ShopMenu.new
    ShopMenu.new=function(game,stock,onQuit,...)
      local menu=nativeShopNew(game,stock,onQuit,...)
      if menu then
        menu.__gen3uiShopMain=true
        if featureEnabled("revampedPokeMartUI") then menu.isOpaque=false end
        -- Gen I SELL now enters the exact same categorized custom Bag used by
        -- the field/start-menu flow.  ShopMenu's stock/buy transaction remains
        -- native; only SELL presentation/selection is redirected to that Bag
        -- state, with native Bag inventory/money as the authority.
        if GoldCompat.generation=="gen1" and menu.items and menu.items[2] then
          local sellRow=menu.items[2]
          local nativeSellSelect=sellRow.onSelect
          sellRow.keepOpen=true
          sellRow.onSelect=function()
            if featureEnabled("revampedPokeMartUI") and GoldCompat.openGen1MartSellBag then
              return GoldCompat.openGen1MartSellBag(game)
            end
            if nativeSellSelect then return nativeSellSelect() end
          end
        end
      end
      return menu
    end
  end

  -- Quantity confirmation belongs to the same hanging Mart stack.
  QuantityBox.isOpaque=false

  -- Quantity selection remains native input/update logic; only presentation
  -- is deferred to the final Mart/Item-PC renderer. Mark at construction time
  -- when the authoritative item-storage list is already under the new box, so
  -- the first frame cannot flash native chrome.
  if not QuantityBox.__gen3uiPCItemNewPatched then
    QuantityBox.__gen3uiPCItemNewPatched=true
    local originalQuantityNew=QuantityBox.new
    QuantityBox.new=function(game,opts)
      local box=originalQuantityNew(game,opts)
      if GoldCompat.itemPcPresentationEnabled() and pcItemListStateInStack(game) then
        box.__gen3uiPCItemQuantity=true
      end
      return box
    end
  end

  local originalQuantityDraw=QuantityBox.draw
  QuantityBox.draw=function(self)
    if self.__gen3uiShopSellQuantity and featureEnabled("revampedPokeMartUI") then
      return
    end
    local pcItems=pcItemListStateInStack(self.game)
    if GoldCompat.itemPcPresentationEnabled() and pcItems then
      self.__gen3uiPCItemQuantity=true
      return
    end

    local shop=shopStateInStack(self.game)
    if featureEnabled("revampedPokeMartUI")
        and shop and shop.__gen3uiShopList then
      self.__gen3uiShopQuantity=true
      State.activeShopQuantity=self
      return
    end
    if State.activeShopQuantity==self then State.activeShopQuantity=nil end
    return originalQuantityDraw(self)
  end
end


local GEN1_BAG_POCKETS={
  {id="ITEM",label="ITEMS"},
  {id="BALL",label="BALLS"},
  {id="KEY_ITEM",label="KEY"},
  {id="TM_HM",label="TM/HM"},
}

local function gen1BagPocketFor(game,id)
  local def=game and game.data and game.data.items and game.data.items[id]
  if def and def.machine then return "TM_HM" end
  local okBall,isBall=pcall(ItemEffects.isBall,id)
  if okBall and isBall then return "BALL" end
  if def and def.keyItem then return "KEY_ITEM" end
  return "ITEM"
end

local function gen1BagRowsForPocket(list,pocketId)
  local game=list and list.game
  local save=game and game.save
  local rows={}
  if not (game and save) then return rows end

  for _,id in ipairs(BagInventory.order(save) or {}) do
    local count=save.inventory and save.inventory[id]
    if count and count>0 and gen1BagPocketFor(game,id)==pocketId then
      local def=game.data.items and game.data.items[id]
      rows[#rows+1]={
        value=id,
        label=(def and def.name) or id,
        right="x"..tostring(count),
      }
    end
  end
  return rows
end

local function gen1BagRefresh(list,preserveId)
  if not list then return end
  local pocket=GEN1_BAG_POCKETS[list.__gen3uiBagPocketIndex or 1]
      or GEN1_BAG_POCKETS[1]
  local rows=gen1BagRowsForPocket(list,pocket.id)

  -- IMPORTANT: never replace list.items here. BagMenu/ListMenu owns that flat
  -- native array and several native item actions/reorder paths expect its
  -- indices to match Bag.order(). The categorized UI gets a parallel view.
  list.__gen3uiBagViewRows=rows

  local oldIndex=list.__gen3uiBagViewIndex or 1
  local nextIndex=nil
  if preserveId then
    for i,row in ipairs(rows) do
      if row.value==preserveId then
        nextIndex=i
        break
      end
    end
  end

  if #rows==0 then
    list.__gen3uiBagViewIndex=1
    list.__gen3uiBagViewScroll=0
    return
  end

  local index=nextIndex or math.max(1,math.min(oldIndex,#rows))
  local visible=6
  local scroll=math.max(0,math.min(
    list.__gen3uiBagViewScroll or 0,
    math.max(0,#rows-visible)))

  if index-scroll<1 then
    scroll=index-1
  elseif index-scroll>visible then
    scroll=index-visible
  end

  list.__gen3uiBagViewIndex=index
  list.__gen3uiBagViewScroll=math.max(0,
    math.min(scroll,math.max(0,#rows-visible)))
end

local function gen1BagViewSelected(list)
  local rows=list and list.__gen3uiBagViewRows or nil
  if not rows then return nil end
  return rows[list.__gen3uiBagViewIndex or 1]
end

local function gen1BagNativeIndexForId(list,id)
  if not (list and id) then return nil end
  for i,row in ipairs(list.items or {}) do
    if row and row.value==id then return i end
  end
  return nil
end

local function gen1BagMoveView(list,delta)
  local rows=list.__gen3uiBagViewRows or {}
  local count=#rows
  if count==0 then return false end

  local oldIndex=list.__gen3uiBagViewIndex or 1
  local index=oldIndex+delta
  -- Gen 1's normal ListMenu does not wrap unless explicitly enabled.
  index=math.max(1,math.min(count,index))
  if index==oldIndex then return false end
  list.__gen3uiBagViewIndex=index

  local visible=6
  local scroll=list.__gen3uiBagViewScroll or 0
  if index-scroll<1 then
    scroll=index-1
  elseif index-scroll>visible then
    scroll=index-visible
  end
  list.__gen3uiBagViewScroll=math.max(0,
    math.min(scroll,math.max(0,count-visible)))
  return true
end

local function gen1BagDescription(list)
  local row=gen1BagViewSelected(list)
  if not row then return "Choose an item." end
  local game=list.game
  local def=game and game.data and game.data.items and game.data.items[row.value]
  if def and def.machine then
    local move=game.data.moves and game.data.moves[def.machine.move]
    return "Teaches "..tostring((move and move.name)
      or GoldCompat.humanizeIdentifier(def.machine.move) or "a move").."."
  end
  if def and (def.description or def.desc) then
    return tostring(def.description or def.desc)
  end
  local pocket=gen1BagPocketFor(game,row.value)
  if pocket=="BALL" then return "Used to catch wild POKéMON." end
  if pocket=="KEY_ITEM" then return "An important KEY ITEM." end
  return "Choose an item."
end

-- Dedicated Gen 1 categorized-Bag TM/HM path.
function GoldCompat.gen1BagUseMachine(list,id)
  local game=list and list.game
  local def=game and game.data and game.data.items and game.data.items[id]
  if not (game and def and def.machine) then return false end

  local TextBox=require("src.render.TextBox")
  local Screens=require("src.ui.Screens")
  local Strings=require("src.core.Strings")
  local moveDef=game.data.moves and game.data.moves[def.machine.move]
  local moveName=(moveDef and moveDef.name)
    or GoldCompat.humanizeIdentifier(def.machine.move)
  local booted=def.machine.kind=="HM"
      and "Booted up an HM!" or Strings("Booted up a TM!")

  local function showMessages(msgs,onDone)
    if not msgs or #msgs==0 then
      if onDone then onDone() end
      return
    end
    game.stack:push(TextBox.new(game,table.concat(msgs,"\f"),onDone))
  end

  local function teachTo(mon)
    local result,payload=ItemEffects.use(
      game.data,game.save,id,mon,nil,nil,game.overworld)

    if result~="learn" and result~="learnkept" then
      showMessages(payload)
      return
    end

    local taughtMove=payload
    local taughtDef=game.data.moves[taughtMove]
    local function markTaught()
      pcall(function()
        require("src.world.PikachuFollower")
          .modifyHappiness(game.save,"USEDTMHM",mon)
      end)
    end
    local function consumeTM()
      if result=="learn" then BagInventory.remove(game.save,id,1) end
    end

    list:close()

    if #mon.moves<4 then
      table.insert(mon.moves,{id=taughtMove,pp=taughtDef.pp})
      consumeTM()
      markTaught()
      local monDef=game.data.pokemon[mon.species]
      showMessages({
        Strings("%s learned\n%s!",
          mon.nickname or (monDef and monDef.name) or mon.species,
          taughtDef.name)
      })
    else
      Screens.push(game,"MoveLearnMenu",mon,taughtMove,function(learned)
        if learned then
          consumeTM()
          markTaught()
        end
      end)
    end
  end

  showMessages({booted,Strings("It contained\n%s!",moveName)},function()
    Screens.push(game,"PartyMenu",{
      pickOnly=true,
      tmhm={move=def.machine.move,kind=def.machine.kind},
      onSwitch=function(mon) teachTo(mon) end,
    })
  end)
  return true
end

local function gen1BagGoldAdapter(list)
  local pocketIndex=list.__gen3uiBagPocketIndex or 1
  local pocket=GEN1_BAG_POCKETS[pocketIndex] or GEN1_BAG_POCKETS[1]
  local adapter={
    index=list.__gen3uiBagViewIndex or 1,
    scroll=list.__gen3uiBagViewScroll or 0,
    rows={},
    visibleRows=6,
  }
  function adapter:pocket() return pocket end
  function adapter:description()
    if list.__gen3uiShopSellBag then
      return list.__gen3uiShopSellMessage or "Choose an item to sell."
    end
    return gen1BagDescription(list)
  end

  for _,row in ipairs(list.__gen3uiBagViewRows or {}) do
    local def=list.game.data.items and list.game.data.items[row.value]
    local count=list.game.save.inventory
      and list.game.save.inventory[row.value] or 1
    local out={
      id=row.value,
      name=row.label or row.value,
      count=count,
      showCount=true,
    }

    if def and def.machine then
      -- Shared Gen 1 / Gen 2 presentation: always show the move taught.
      local move=list.game.data.moves and list.game.data.moves[def.machine.move]
      out.teaches=(move and move.name)
        or GoldCompat.humanizeIdentifier(def.machine.move)
      out.showCount=false
    end

    adapter.rows[#adapter.rows+1]=out
  end
  return adapter
end


-- Gen I Mart SELL using the real custom Bag state --------------------------------
GoldCompat.openGen1MartSellBag=function(game)
  if not (game and game.stack and game.save) then return end

  local list=BagMenu.new(game,{})
  if not list then return end
  list.__gen3uiShopSellBag=true
  list.isOpaque=false
  list.title="SELL"
  list.__gen3uiShopSellMessage="Choose an item to sell."

  local function rebuildFlatItems()
    local rebuilt={}
    for _,id in ipairs(BagInventory.order(game.save) or {}) do
      local count=game.save.inventory and game.save.inventory[id]
      if count and count>0 then
        local def=game.data and game.data.items and game.data.items[id]
        rebuilt[#rebuilt+1]={
          value=id,
          label=(def and def.name) or id,
          right="x"..tostring(count),
        }
      end
    end
    list.items=rebuilt
    list.index=math.max(1,math.min(list.index or 1,math.max(1,#rebuilt)))
  end

  -- Preserve Bag SELECT/reorder semantics only outside Mart SELL; SELL should
  -- never accidentally enter the field Bag's USE/TOSS machinery.
  list.onSelectKey=nil
  list.onChoose=function(item)
    if not item then return end
    local id=item.value
    local def=game.data and game.data.items and game.data.items[id]
    if not def or def.keyItem or tostring(id):find("^HM_") then
      list.__gen3uiShopSellMessage="I can't put a price on that."
      return
    end

    local unit=math.floor((tonumber(def.price) or 0)/2)
    local maxQty=(game.save.inventory and game.save.inventory[id]) or 1
    local qbox
    qbox=QuantityBox.new(game,{
      max=maxQty,
      unitPrice=unit,
      onDone=function(qty)
        if not qty then
          list.__gen3uiShopSellMessage="Choose an item to sell."
          return
        end
        local total=unit*qty
        list.__gen3uiShopSellMessage=("I can pay you ¥%d for that."):format(total)
        local choice
        choice=ChoiceBox.new(game,function(yes)
          if not yes then
            list.__gen3uiShopSellMessage="Choose an item to sell."
            return
          end
          game.save.money=(tonumber(game.save.money) or 0)+total
          BagInventory.remove(game.save,id,qty)
          rebuildFlatItems()
          gen1BagRefresh(list,nil)
          list.__gen3uiShopSellMessage="Thank you!"
        end)
        if choice then
          choice.__gen3uiShopSellChoice=true
          choice.isOpaque=false
          game.stack:push(choice)
        end
      end,
    })
    if qbox then
      qbox.__gen3uiShopSellQuantity=true
      qbox.isOpaque=false
      game.stack:push(qbox)
    end
  end

  rebuildFlatItems()
  gen1BagRefresh(list,nil)
  game.stack:push(list)
  return list
end

local function installOverworldUI(mod)
  if overworldUIPatched then return end
  overworldUIPatched = true

  -- Mark only the real START menu instance. Menu is generic and used in many
  -- places; the custom renderer branches exclusively on this marker.
  local originalStartNew = StartMenu.new
  StartMenu.new = function(game)
    local menu = originalStartNew(game)
    menu.__gen3uiStart = true
    menu.__gen3uiNativeOpaque=menu.isOpaque
    if featureEnabled("revampedOverworldMenus") then menu.isOpaque=false end

    -- Safari Zone StartMenu installs a per-instance draw override that appends
    -- the cartridge's top-left STEPS/BALL box after the generic menu draw. That
    -- bypasses our Menu.draw suppression and leaves a redundant native fragment
    -- behind the Colosseum START overlay. Preserve it only for toggle-off/native
    -- mode; while our START UI is active, this instance is presentation-silent.
    local nativeStartInstanceDraw=rawget(menu,"draw")
    if type(nativeStartInstanceDraw)=="function" then
      menu.__colosseumNativeInstanceDraw=nativeStartInstanceDraw
      menu.draw=function(self,...)
        if featureEnabled("revampedOverworldMenus") then
          self.isOpaque=false
          State.activeStartMenu=self
          return
        end
        self.isOpaque=self.__gen3uiNativeOpaque
        return nativeStartInstanceDraw(self,...)
      end
    end

    -- The UI settings panel is an in-place mode of the real START menu.
    -- This guarantees the overworld remains beneath it and avoids a second
    -- state / generic options renderer entirely.
    local normalItems=menu.items
    local normalMaxVisible=menu.maxVisible
    local normalRowStep=menu.rowStep
    local normalIndex=menu.index
    local normalScroll=menu.scroll
    local baseUpdate=menu.update

    local function enterUISettings()
      menu.__gen3uiUISettings=true
      menu.items={}
      for _,row in ipairs(DexUI.rowsForGame(game)) do
        local captured=row
        menu.items[#menu.items+1]={
          label=captured.label,
          keepOpen=true,
          __gen3uiUIRow=captured,
          onSelect=function()
            DexUI.activateUIRow(game,captured)
          end,
        }
      end
      menu.index=1
      menu.scroll=0
      menu.rowStep=1
      menu.maxVisible=8
      menu:clampScroll()
    end

    local function leaveUISettings()
      menu.__gen3uiUISettings=nil
      menu.items=normalItems
      menu.rowStep=normalRowStep
      menu.maxVisible=normalMaxVisible
      menu.index=math.max(1,math.min(normalIndex or 1,#normalItems))
      menu.scroll=normalScroll or 0
      menu:clampScroll()
    end

    -- The hook-created UI row is already in normalItems. Mark it keepOpen so
    -- Menu:update does not pop START before its action switches presentation.
    for _,entry in ipairs(normalItems) do
      if entry.__gen3uiUIEntry or tostring(entry.label or ""):upper()=="UI" then
        entry.keepOpen=true
        entry.onSelect=enterUISettings
        entry.__gen3uiUIEntry=true
      end
    end

    menu.update=function(self,dt)
      if self.__gen3uiUISettings then
        local input=game.input
        if input and (input:wasPressed("b") or input:wasPressed("start")) then
          if input:wasPressed("b") then
            pcall(function()
              require("src.core.Sound").play(game.data,"Press_AB")
            end)
          end
          leaveUISettings()
          return
        end

        -- A/Up/Down remain native Menu behavior. Every settings row is
        -- keepOpen, so selecting a toggle updates it without closing START.
        baseUpdate(self,dt)
        return
      end

      baseUpdate(self,dt)
      normalIndex=self.index
      normalScroll=self.scroll
    end

    return menu
  end

  local originalMenuDraw = Menu.draw
  Menu.draw = function(self)
    if self.__gen3uiPokedexAction and featureEnabled("revampedPokedex")
        and not self.__gen3uiPokedexActionRenderFailed then
      DexUI.action=self
      return
    end

    if self.__gen3uiBagAction and GoldCompat.bagPresentationEnabled() then
      State.activeBagActionMenu=self
      return
    end

    if self.__gen3uiStart then
      if not featureEnabled("revampedOverworldMenus") then
        self.isOpaque=self.__gen3uiNativeOpaque
        State.activeStartMenu = nil
        return originalMenuDraw(self)
      end
      State.activeStartMenu = self
      return
    end

    if featureEnabled("revampedPokeMartUI")
        and self.__gen3uiShopMain
        and not self.__gen3uiMartRenderFailed then
      State.activeShopMenu=self
      return
    elseif self.__gen3uiShopMain and self.__gen3uiMartRenderFailed then
      return originalMenuDraw(self)
    end

    if featureEnabled("revampedPokemonPC") then
      if self.__gen3uiPCItemRoot and GoldCompat.itemPcPresentationEnabled() then
        State.activePCMenu=self
        State.activePCAccessMenu=nil
        State.activePCActionMenu=nil
        return
      elseif self.__gen3uiPCAccess then
        State.activePCAccessMenu=self
        State.activePCMenu=nil
        State.activePCActionMenu=nil
        return
      elseif self.__gen3uiPCMain then
        State.activePCMenu=self
        State.activePCAccessMenu=nil
        State.activePCActionMenu=nil
        return
      elseif self.__gen3uiPCAction then
        State.activePCActionMenu=self
        return
      end
    end

    -- Generic Menu is also used for Bag item actions such as USE / TOSS.
    if GoldCompat.bagPresentationEnabled() then
      local bag = bagStateForMenu(self.game)
      if bag then
        State.activeBagActionMenu = self
        return
      end
    end

    State.activeBagActionMenu = nil
    State.activeShopMenu = nil
    State.activeShopList = nil
    State.activeShopQuantity = nil
    if GoldCompat.strictNativeUiEnabled() and featureEnabled("revampedOverworldMenus") then
      self.isOpaque=false
      State.activeGenericMenu=self
      return
    end
    if State.activeGenericMenu==self then State.activeGenericMenu=nil end
    return originalMenuDraw(self)
  end

  -- Player-PC TOSS ITEM pushes a bare native ChoiceBox above the item list.
  -- Suppress only that PC-owned presentation; ChoiceBox input/hold timing stays
  -- untouched and the final PC renderer paints the YES/NO confirmation.
  if not ChoiceBox.__gen3uiPCItemChoicePatched then
    ChoiceBox.__gen3uiPCItemChoicePatched=true
    local originalPCItemChoiceDraw=ChoiceBox.draw
    ChoiceBox.draw=function(self,...)
      local under=pcItemListStateInStack(self.game)
      if GoldCompat.itemPcPresentationEnabled() and under then
        self.__gen3uiPCItemChoice=true
        return
      end
      self.__gen3uiPCItemChoice=nil
      return originalPCItemChoiceDraw(self,...)
    end
  end

  -- Native Pokédex DATA page stays authoritative for update/A/B behavior.
  -- We only mark instances and suppress their opaque vanilla presentation.
  local dexEntryOK,DexEntryMenu=pcall(require,"src.ui.DexEntryMenu")
  if dexEntryOK and DexEntryMenu and DexEntryMenu.new
      and not DexEntryMenu.__gen3uiWrapped then
    DexEntryMenu.__gen3uiWrapped=true

    local originalDexEntryNew=DexEntryMenu.new
    DexEntryMenu.new=function(game,speciesOrOpts,onDone)
      local entry=originalDexEntryNew(game,speciesOrOpts,onDone)
      if entry then
        entry.__gen3uiDexEntry=true
        entry.isOpaque=false
        DexUI.entry=entry
        local species=type(speciesOrOpts)=="table"
          and (speciesOrOpts.species or speciesOrOpts[1]) or speciesOrOpts
        local forceOwned=type(speciesOrOpts)=="table"
          and speciesOrOpts.forceOwned==true
        local starter={BULBASAUR=true,CHARMANDER=true,SQUIRTLE=true,
          CHIKORITA=true,CYNDAQUIL=true,TOTODILE=true,PIKACHU=true,EEVEE=true}
        if forceOwned and starter[tostring(species or ""):upper()]
            and GoldCompat.starterPresentationEnabled() then
          entry.__colosseumStarterDexPreview=true
        end
      end
      return entry
    end

    -- Gen I opens StarterDex before the actual yes/no question. The starter
    -- card already contains the resolved sprite/name/type, so retaining that
    -- hidden page only creates an unexplained extra A press. Auto-complete ONLY
    -- the forceOwned starter preview; ordinary Pokédex DATA pages are unchanged.
    if DexEntryMenu.update and not DexEntryMenu.__colosseumStarterUpdateWrapped then
      DexEntryMenu.__colosseumStarterUpdateWrapped=true
      local originalDexEntryUpdate=DexEntryMenu.update
      DexEntryMenu.update=function(self,dt,...)
        if self.__colosseumStarterDexPreview and not self.__colosseumStarterDexDone
            and GoldCompat.starterPresentationEnabled() then
          self.__colosseumStarterDexDone=true
          if DexUI.entry==self then DexUI.entry=nil end
          if self.game and self.game.stack then self.game.stack:pop() end
          if self.onDone then self.onDone() end
          return
        end
        return originalDexEntryUpdate(self,dt,...)
      end
    end

    if DexEntryMenu.draw then
      local originalDexEntryDraw=DexEntryMenu.draw
      DexEntryMenu.draw=function(self)
        if featureEnabled("revampedPokedex")
            and not self.__gen3uiDexEntryRenderFailed then
          DexUI.entry=self
          return
        end
        return originalDexEntryDraw(self)
      end
    end
  end

  -- Mark Bag-created ListMenu instances so shops/dex/PC lists remain vanilla.
  local originalBagNew = BagMenu.new
  BagMenu.new = function(game, opts)
    local list = originalBagNew(game, opts)
    list.__gen3uiBag = true

    if GoldCompat.generation=="gen1" and GoldCompat.bagPresentationEnabled() then
      list.isOpaque=false
      list.__gen3uiCategorizedBag=true
      list.__gen3uiBagPocketIndex=1
      list.__gen3uiBagViewIndex=1
      list.__gen3uiBagViewScroll=0

      -- Pocket switching is presentation-only. Native ListMenu never receives
      -- Left/Right while the categorized UI is active.
      list.pageJump=false

      -- We mirror ListMenu's public repeat defaults for the visual cursor.
      list.__gen3uiBagRepeatDelay=list.repeatDelay or 16
      list.__gen3uiBagRepeatRate=list.repeatRate or 4
      list.__gen3uiBagViewHoldDir=nil
      list.__gen3uiBagViewHoldFrames=0

      local nativeUpdate=list.update

      local function selectedViewId(self)
        local row=gen1BagViewSelected(self)
        return row and row.value or nil
      end

      local function syncNativeSelection(self)
        local id=selectedViewId(self)
        local nativeIndex=gen1BagNativeIndexForId(self,id)
        if nativeIndex then
          self.index=nativeIndex
          -- Native scroll is irrelevant visually, but keep it valid for
          -- item subflows/mod hooks that inspect the Bag ListMenu.
          local nativeRows=self.rows or 7
          if self.index-(self.scroll or 0)>nativeRows then
            self.scroll=self.index-nativeRows
          elseif self.index-(self.scroll or 0)<1 then
            self.scroll=self.index-1
          end
        end
        return id,nativeIndex
      end

      local function moveView(self,dir)
        local moved=gen1BagMoveView(self,dir=="up" and -1 or 1)
        if moved then
          pcall(function()
            require("src.core.Sound").play(self.game.data,"Press_AB")
          end)
        end
        return moved
      end

      list.update=function(self,dt)
        if not GoldCompat.bagPresentationEnabled() then
          return nativeUpdate(self,dt)
        end

        local input=self.game and self.game.input
        local preserve=selectedViewId(self)
        gen1BagRefresh(self,preserve)

        if not input then return end

        -- ---------------------------------------------------------------
        -- Horizontal pocket navigation.
        -- ---------------------------------------------------------------
        local leftEdge=input:wasPressed("left")
        local rightEdge=input:wasPressed("right")
        local leftDown=input:isDown("left")
        local rightDown=input:isDown("right")

        if not leftDown and not rightDown then
          self.__gen3uiBagPocketHeld=nil
        end

        local pocketDir=nil
        if leftEdge or (leftDown and self.__gen3uiBagPocketHeld~="left") then
          pocketDir="left"
        elseif rightEdge or (rightDown and self.__gen3uiBagPocketHeld~="right") then
          pocketDir="right"
        end

        if pocketDir then
          self.__gen3uiBagPocketHeld=pocketDir
          if pocketDir=="left" then
            self.__gen3uiBagPocketIndex=
              ((self.__gen3uiBagPocketIndex-2)%#GEN1_BAG_POCKETS)+1
          else
            self.__gen3uiBagPocketIndex=
              (self.__gen3uiBagPocketIndex%#GEN1_BAG_POCKETS)+1
          end

          self.__gen3uiBagViewIndex=1
          self.__gen3uiBagViewScroll=0
          self.__gen3uiBagViewHoldDir=nil
          self.__gen3uiBagViewHoldFrames=0
          self.swapIndex=nil
          gen1BagRefresh(self,nil)

          pcall(function()
            require("src.core.Sound").play(self.game.data,"Press_AB")
          end)
          return
        end

        -- ---------------------------------------------------------------
        -- Vertical navigation: one authoritative visual cursor.
        -- This mirrors ListMenu's edge/repeat behavior but never mutates the
        -- native flat inventory index until an actual item action is invoked.
        -- ---------------------------------------------------------------
        local moved=false
        if input:wasPressed("up") then
          moved=moveView(self,"up")
          self.__gen3uiBagViewHoldDir="up"
          self.__gen3uiBagViewHoldFrames=0
        elseif input:wasPressed("down") then
          moved=moveView(self,"down")
          self.__gen3uiBagViewHoldDir="down"
          self.__gen3uiBagViewHoldFrames=0
        elseif self.keyRepeat then
          -- Match native ListMenu exactly: held-direction repeat is opt-in.
          -- The normal Gen 1 Bag does NOT enable keyRepeat, so an ordinary
          -- press advances exactly one row and a held key does not race.
          local dir=self.__gen3uiBagViewHoldDir
          if dir and input:isDown(dir) then
            self.__gen3uiBagViewHoldFrames=
              (self.__gen3uiBagViewHoldFrames or 0)+1
            local delay=self.repeatDelay or 16
            local rate=self.repeatRate or 4
            local after=self.__gen3uiBagViewHoldFrames-delay
            if after>=0 and after%rate==0 then
              moved=moveView(self,dir)
            end
          else
            self.__gen3uiBagViewHoldDir=nil
            self.__gen3uiBagViewHoldFrames=0
          end
        else
          self.__gen3uiBagViewHoldDir=nil
          self.__gen3uiBagViewHoldFrames=0
        end
        if moved then return end

        -- ---------------------------------------------------------------
        -- Native actions. Translate the visual item to its flat native index
        -- immediately before delegating, so BagMenu's existing USE/TOSS/TM,
        -- quantity, target, consumption and mod hooks stay intact.
        -- ---------------------------------------------------------------
        if input:wasPressed("a") then
          local visualRow=gen1BagViewSelected(self)
          local selectedId=visualRow and visualRow.value or nil
          local selectedDef=selectedId and self.game and self.game.data
              and self.game.data.items and self.game.data.items[selectedId]

          -- TM/HMs must never pass through the generic field-item dispatcher.
          -- Run their actual boot -> target -> teach sequence directly.
          if selectedDef and selectedDef.machine and not self.__gen3uiShopSellBag then
            if not self.noSound and self.game and self.game.data then
              pcall(function()
                require("src.core.Sound").play(self.game.data,"Press_AB")
              end)
            end
            GoldCompat.gen1BagUseMachine(self,selectedId)
            return
          end

          -- Ordinary Items / Balls / Key Items use BagMenu's original
          -- onChoose callback, but with the EXACT categorized item ID.
          -- This avoids a second ListMenu input pass and eliminates any chance
          -- of the flat native cursor resolving a different item (for example
          -- a KEY ITEM dispatching an HM action).
          local _,nativeIndex=syncNativeSelection(self)
          if type(self.onChoose)=="function" and selectedId then
            if not self.noSound and self.game and self.game.data then
              pcall(function()
                require("src.core.Sound").play(self.game.data,"Press_AB")
              end)
            end
            local def=self.game.data.items and self.game.data.items[selectedId]
            self.onChoose({
              value=selectedId,
              label=(def and def.name) or selectedId,
              right="x"..tostring(
                (self.game.save.inventory and
                 self.game.save.inventory[selectedId]) or 1),
            },self)
            return
          end

          -- Compatibility fallback only if another mod removed onChoose.
          if nativeIndex then return nativeUpdate(self,dt) end
          return
        elseif input:wasPressed("select") then
          local selectedId=selectedViewId(self)
          syncNativeSelection(self)
          local result=nativeUpdate(self,dt)
          gen1BagRefresh(self,selectedId)
          return result
        elseif input:wasPressed("b") then
          -- B is entirely native: close the Bag and run its onCancel path.
          return nativeUpdate(self,dt)
        end

        -- No actionable input this frame. Do not run native navigation:
        -- keeping its flat cursor dormant prevents any competing movement.
      end

      gen1BagRefresh(list,nil)
    end
    return list
  end

  local originalListDraw = ListMenu.draw
  ListMenu.draw = function(self)
    if self.__gen3uiPPMovePicker then
      if GoldCompat.pokemonPresentationEnabled() then
        self.isOpaque=false
        State.activePPMoveList=self
        State.activeGenericList=nil
        return
      end
      if State.activePPMoveList==self then State.activePPMoveList=nil end
      return originalListDraw(self)
    end

    if self.__gen3uiShopList then
      if self.__gen3uiMartRenderFailed then
        return originalListDraw(self)
      end
      if featureEnabled("revampedPokeMartUI") then
        State.activeShopList=self
        State.activeBagMenu=nil
        State.activePCList=nil
        return
      end
      State.activeShopList=nil
      return originalListDraw(self)
    end

    if self.__gen3uiPokedex then
      if not featureEnabled("revampedPokedex")
          or self.__gen3uiPokedexRenderFailed then
        DexUI.active=nil
        return originalListDraw(self)
      end
      DexUI.active=self
      State.activeBagMenu=nil
      State.activePCList=nil
      return
    end

    if self.__gen3uiPCItemList then
      if GoldCompat.itemPcPresentationEnabled() then
        State.activePCList=self
        State.activeBagMenu=nil
        return
      end
      State.activePCList=nil
      return originalListDraw(self)
    end

    if self.__gen3uiPCList then
      if featureEnabled("revampedPokemonPC") then
        State.activePCList=self
        State.activeBagMenu=nil
        return
      end
      State.activePCList=nil
      return originalListDraw(self)
    end

    if not GoldCompat.bagPresentationEnabled() then
      State.activeBagMenu=nil
      return originalListDraw(self)
    end

    if self.__gen3uiBag then
      State.activeBagMenu=self
      State.activePCList=nil
      return
    end

    State.activeBagMenu=nil
    State.activePCList=nil
    if GoldCompat.strictNativeUiEnabled() and featureEnabled("revampedOverworldMenus") then
      self.isOpaque=false
      State.activeGenericList=self
      return
    end
    if State.activeGenericList==self then State.activeGenericList=nil end
    return originalListDraw(self)
  end

  -- Native SummaryMenu owns STATS/MOVES input and page transitions.
  -- Suppress only its vanilla drawing and defer our presentation to render.hud.
  local SummaryMenu = require("src.ui.SummaryMenu")
  local originalSummaryNew = SummaryMenu.new
  local originalSummaryDraw = SummaryMenu.draw
  local originalSummaryUpdate = SummaryMenu.update
  local originalSummaryOpaque = SummaryMenu.isOpaque

  SummaryMenu.isOpaque=false
  SummaryMenu.new = function(...)
    local self=originalSummaryNew(...)
    if self then
      self.isOpaque=GoldCompat.pokemonPresentationEnabled()
        and false or originalSummaryOpaque
    end
    return self
  end

  SummaryMenu.draw = function(self)
    if GoldCompat.pokemonPresentationEnabled() then
      DexUI.summary=self
      return
    end
    self.isOpaque=originalSummaryOpaque
    if DexUI.summary==self then DexUI.summary=nil end
    return originalSummaryDraw(self)
  end

  SummaryMenu.update = function(self,dt)
    -- Launcher API v2 resolves the visible stack before draw(). Keep the
    -- replacement summary non-opaque during update as well so the overworld /
    -- battle beneath it survives every frame, including the first handoff.
    if GoldCompat.pokemonPresentationEnabled() then self.isOpaque=false end
    -- Both cartridge generations use the same direct three-tier contract in
    -- the overhaul: Left/Right select STATUS, MOVES, PROFILE; Up/Down switches
    -- the viewed party member; B returns. Native close behavior remains the
    -- authority, but A no longer advances or accidentally dismisses a page.
    if GoldCompat.pokemonPresentationEnabled()
        and self.game and self.mon and self.game.input then
      local input=self.game.input
      if self.__colosseumMoveManager then
        if GoldCompat.moveManagerPresentationEnabled() then
          return GoldCompat.updateMoveManager(self,input)
        end
        self.__colosseumMoveManager=nil
      end
      if input:wasPressed("b") then
        return originalSummaryUpdate(self,dt)
      elseif input:wasPressed("left") then
        self.page=((math.max(1,tonumber(self.page) or 1)+1)%3)+1
        self.__colosseumTmPage=1
        return
      elseif input:wasPressed("right") then
        self.page=(math.max(1,tonumber(self.page) or 1)%3)+1
        self.__colosseumTmPage=1
        return
      elseif input:wasPressed("select") and self.page==2
          and GoldCompat.moveManagerPresentationEnabled() then
        GoldCompat.openMoveManager(self)
        return
      elseif input:wasPressed("select") and self.page==3 then
        local pages=math.max(1,tonumber(self.__colosseumTmPages) or 1)
        self.__colosseumTmPage=((tonumber(self.__colosseumTmPage) or 1)%pages)+1
        return
      end

      local party=self.game.save and self.game.save.party
      if type(party)=="table" and #party>1 then
        local current=nil
        for i,m in ipairs(party) do
          if m==self.mon then
            current=i
            break
          end
        end

        if current then
          local delta=0
          if input:wasPressed("up") then
            delta=-1
          elseif input:wasPressed("down") then
            delta=1
          end

          if delta~=0 then
            local nextIndex=((current-1+delta)%#party)+1
            local nextMon=party[nextIndex]
            if nextMon then
              self.mon=nextMon
              self.__colosseumTmPage=1

              -- Our renderer resolves the active sprite dynamically, so no
              -- SummaryMenu sprite cache rebuild is needed. Match the native
              -- summary-opening feel by playing the newly selected cry.
              pcall(function()
                require("src.core.Sound").playCry(self.game.data,nextMon.species)
              end)
              return
            end
          end
        end
      end

      if input:wasPressed("a") then return end
    end

    return originalSummaryUpdate(self,dt)
  end

  -- TM/HM target picking should remain on the Party screen through the
  -- teach/replace-move flow, matching the original games. PartyMenu already
  -- supports this behavior through keepOpen; opt TM/HM pickers into it.
  local originalPartyNew = PartyMenu.new
  local originalPartyUpdate = PartyMenu.update
  PartyMenu.new = function(game, opts)
    opts = opts or {}
    if opts.tmhm then
      opts.keepOpen = true
    end

    local party = originalPartyNew(game, opts)

    if featureEnabled("colosseumPokemonMenu") then
      -- The reference layout must reveal the live battle/overworld beneath it
      -- from the first frame, before PartyMenu.draw is reached.
      party.isOpaque=false
      party.__gen3uiColosseumParty=true
    end

    if opts.tmhm then
      party.__gen3uiKeepTMBackground = true
      party.__gen3uiCustomPartyOwned = true
      party.isOpaque = false
      State.activeTMParty = party
      State.activeItemTargetParty = party
      State.activeBagActionMenu = nil
      State.activeBagMenu = nil
    elseif opts.pickOnly and not opts.battle then
      party.__gen3uiItemTarget = true
      party.__gen3uiCustomPartyOwned = true
      party.isOpaque = false

      local bag=bagStateForMenu(game)
      local row=bag and bag.items and bag.items[bag.index or 1]
      party.__gen3uiTargetItem=row and row.value or nil

      State.activeItemTargetParty = party
      State.activeParty = party
      State.activeBagActionMenu = nil
      State.activeBagMenu = nil
    end

    return party
  end

  PartyMenu.update = function(self,dt)
    if featureEnabled("colosseumPokemonMenu") then self.isOpaque=false end
    if not featureEnabled("colosseumPokemonMenu") then
      return originalPartyUpdate(self,dt)
    end

    local input=self.game and self.game.input
    local party=self.party or (self.game and self.game.save
      and self.game.save.party) or {}
    if not input or self.submenu or self.heal or #party<1 then
      return originalPartyUpdate(self,dt)
    end

    local direction=input:wasPressed("left") and "left"
      or input:wasPressed("right") and "right"
      or input:wasPressed("up") and "up"
      or input:wasPressed("down") and "down"
    if not direction then return originalPartyUpdate(self,dt) end

    -- The native Gen 1 list is vertical. Hide this frame's direction edge
    -- only while native update handles animation/A/B and every gameplay flow,
    -- then apply the two-column visual mapping exactly once.
    local pressed=input.pressed or {}
    local saved={
      left=pressed.left,right=pressed.right,
      up=pressed.up,down=pressed.down,
    }
    pressed.left=nil; pressed.right=nil; pressed.up=nil; pressed.down=nil
    local ok,result=pcall(originalPartyUpdate,self,dt)
    pressed.left=saved.left; pressed.right=saved.right
    pressed.up=saved.up; pressed.down=saved.down
    if not ok then error(result) end

    self.index=GoldCompat.colosseumPartyGridIndex(
      self.index,#party,direction)
    if self.game then self.game.partyMenuSavedIndex=self.index end
    return result
  end

  -- Track MoveLearnMenu from creation so native prompt pages can retain the
  -- revamped Party screen underneath before actual move selection begins.
  local originalMoveLearnNew = MoveLearnMenu.new
  MoveLearnMenu.new = function(game, mon, newMoveId, onDone)
    -- Preserve the engine constructor EXACTLY. Dropping newMoveId/onDone corrupts
    -- the state and crashes once actual move replacement begins.
    local menu = originalMoveLearnNew(game, mon, newMoveId, onDone)
    if State.activeTMParty and menu and menu.mon and canIntegrateMoveLearn(game, menu) then
      State.activeTMPromptFlow = menu
    end
    return menu
  end

  -- The replacement choices are presented as a horizontal strip in the
  -- Colosseum party deck. Mirror left/right onto the native vertical cursor
  -- edges while retaining up/down for controller and accessibility parity.
  local originalMoveLearnUpdate = MoveLearnMenu.update
  MoveLearnMenu.update = function(self,dt)
    local input=self.game and self.game.input
    local pressed=input and input.pressed
    if self.selecting and GoldCompat.pokemonPresentationEnabled()
        and type(pressed)=="table" then
      local savedUp,savedDown=pressed.up,pressed.down
      if pressed.left and not pressed.up then pressed.up=pressed.left end
      if pressed.right and not pressed.down then pressed.down=pressed.right end
      local ok,result=pcall(originalMoveLearnUpdate,self,dt)
      pressed.up,pressed.down=savedUp,savedDown
      if not ok then error(result) end
      return result
    end
    return originalMoveLearnUpdate(self,dt)
  end

  -- TM move replacement uses the engine's native MoveLearnMenu INPUT/LOGIC,
  -- but during a kept-open TM Party flow its standalone draw is suppressed.
  -- The active selection is rendered inside the Party detail panel instead.
  local originalMoveLearnDraw = MoveLearnMenu.draw
  MoveLearnMenu.draw = function(self)
    if canIntegrateMoveLearn(self.game, self) then
      State.activeTMPromptFlow = self
      if self.selecting then
        State.activeMoveLearn = self
        return
      end
    end

    -- Level-up move learning inside battle reuses the custom Pokémon-menu
    -- presentation. Native MoveLearnMenu still owns every input/callback.
    local battle=battleStateInStack(self.game)
    if GoldCompat.battlePresentationEnabledFor(battle)
        and GoldCompat.pokemonPresentationEnabled()
        and battle
        and self.selecting then
      State.activeBattleMoveLearn=self
      State.activeBattleMoveParty=makeBattleMovePartyState(self.game,self)
      State.activeBattle=battle
      return
    end

    if State.activeMoveLearn == self then State.activeMoveLearn = nil end
    if State.activeBattleMoveLearn == self then
      State.activeBattleMoveLearn=nil
      State.activeBattleMoveParty=nil
    end
    return originalMoveLearnDraw(self)
  end

  -- Pokémon selection: full visual replacement, existing input/state unchanged.
  -- Uses Gen1Recomp's own icon renderer so sprite/mon mods remain compatible.
  local originalPartyDraw = PartyMenu.draw
  PartyMenu.draw = function(self)
    if not GoldCompat.pokemonPresentationEnabled() then
      State.activeParty = nil
      State.activeTMParty = nil
      State.activeMoveLearn = nil
      State.activeTMPromptFlow = nil
      return originalPartyDraw(self)
    end
    if featureEnabled("colosseumPokemonMenu") then
      self.isOpaque=false
      self.__gen3uiColosseumParty=true
    else
      self.__gen3uiColosseumParty=nil
    end
    State.activeParty = self
    if self.__gen3uiItemTarget or self.__gen3uiKeepTMBackground then
      State.activeItemTargetParty = self
    end
  end
  local StatBox=BattleState.StatBox
  if StatBox and StatBox.draw and not StatBox.__gen3uiWrapped then
    StatBox.__gen3uiWrapped=true
    local originalStatDraw=StatBox.draw
    StatBox.draw=function(self)
      local battle=battleStateInStack(self.game)
      if not ((GoldCompat.battlePresentationEnabledFor(battle)
          or featureEnabled("hideNativeBattleUI")) and battle and self.mon) then
        if State.activeBattleStatBox==self then State.activeBattleStatBox=nil end
        return originalStatDraw(self)
      end

      State.activeBattleStatBox=self
      State.activeBattle=battle

      -- StatBox is a pushed 160x144 battle state. Draw here at its guaranteed
      -- native callback, but use Gen1Recomp's own pixel Font so the renderer's
      -- final upscale remains crisp instead of magnifying a smooth font.
      local g=love.graphics
      local s=self.mon.stats or {}
      local def=battle.data and battle.data.pokemon
          and battle.data.pokemon[self.mon.species]
      local name=self.mon.nickname or (def and def.name) or "POKéMON"

      local wide=false
      if battle.wideLayout then
        local ok,value=pcall(battle.wideLayout,battle)
        wide=ok and value or false
      end

      -- Anchor to the right side of either classic or wide battle canvas.
      local canvasW=wide and 304 or 160
      local w,h=84,56
      local x=canvasW-w-14
      local y=144-h-14

      g.push("all")

      -- Opaque charcoal outer plate.
      g.setColor(0.10,0.10,0.09,1)
      g.rectangle("fill",x,y,w,h)

      -- Cream paper.
      g.setColor(0.98,0.965,0.90,1)
      g.rectangle("fill",x+2,y+2,w-4,h-4)

      -- Gold inner border.
      g.setColor(0.66,0.50,0.20,1)
      g.rectangle("line",x+3,y+3,w-6,h-6)

      -- Native pixel typography. Font.draw uses the exact Gen1Recomp glyph
      -- renderer and therefore survives integer/fractional battle scaling cleanly.
      g.setColor(0.08,0.08,0.07,1)

      -- Pokémon name gets the full card width. Never hard-truncate it.
      -- Scale only this header if a long name exceeds the available width.
      local title=tostring(name or "POKéMON")
      local titleMaxW=w-12
      local titleScale=math.min(1,titleMaxW/math.max(1,#title*8))

      if titleScale<0.999 then
        g.push()
        g.translate(x+6,y+6)
        g.scale(titleScale,titleScale)
        EngineFont.draw(title,0,0)
        g.pop()
      else
        EngineFont.draw(title,x+6,y+6)
      end

      -- Level gets its own compact badge sitting above the card.
      local levelTag="Lv."..tostring(self.mon.level or "?")
      local levelW=#levelTag*8 + 10
      local levelX=x+w-levelW
      local levelY=y-11

      g.setColor(0.10,0.10,0.09,1)
      g.rectangle("fill",levelX,levelY,levelW,12)
      g.setColor(0.98,0.965,0.90,1)
      g.rectangle("fill",levelX+2,levelY+2,levelW-4,8)
      g.setColor(0.66,0.50,0.20,1)
      g.rectangle("line",levelX+2,levelY+2,levelW-4,8)
      g.setColor(0.08,0.08,0.07,1)
      EngineFont.draw(levelTag,levelX+5,levelY+2)

      g.setColor(0.66,0.50,0.20,1)
      g.rectangle("fill",x+5,y+18,w-10,1)
      g.setColor(0.08,0.08,0.07,1)

      local rows={
        {"ATK",s.attack or 0},
        {"DEF",s.defense or 0},
        {"SPD",s.speed or 0},
        {"SPC",s.special or 0},
      }

      for i,row in ipairs(rows) do
        local yy=y+22+(i-1)*8

        if i%2==1 then
          g.setColor(0.90,0.88,0.80,1)
          g.rectangle("fill",x+4,yy-1,w-8,8)
        end

        g.setColor(0.08,0.08,0.07,1)
        EngineFont.draw(row[1],x+7,yy)
        local value=("%3d"):format(row[2])
        EngineFont.draw(value,x+w-7-(#value*8),yy)
      end

      -- Native-style continue hint; input remains StatBox:update unchanged.

      g.setColor(1,1,1,1)
      g.pop()
    end
  end

  -- Strict-mode coverage for gameplay states that bypass Menu/ListMenu.
  -- Native update/callback logic remains authoritative; only draw ownership is
  -- replaced, and opacity is fixed at construction time for API-v2 stacks.
  for _,spec in ipairs({
      {"src.ui.TownMap","activeTownMap","revampedOverworldMenus"},
      {"src.ui.PicBox","activePicBox","revampedOverworldMenus"},
      {"src.ui.Diploma","activeDiploma","revampedPokedex"},
      {"src.ui.HallOfFame","activeHallOfFame","revampedOverworldMenus"},
      {"src.ui.BindingsMenu","activeBindings","revampedOptionsUI"},
      {"src.ui.QuarantineReport","activeQuarantine","revampedOverworldMenus"},
    }) do
    local ok,cls=pcall(require,spec[1])
    if ok and cls and type(cls.draw)=="function" and not cls.__colosseumStrictWrapped then
      cls.__colosseumStrictWrapped=true
      cls.__colosseumOriginalDraw=cls.draw
      local key,toggle=spec[2],spec[3]
      if type(cls.new)=="function" then
        cls.__colosseumOriginalNew=cls.new
        cls.new=function(...)
          local obj=cls.__colosseumOriginalNew(...)
          if obj and GoldCompat.strictNativeUiEnabled() and featureEnabled(toggle) then
            obj.isOpaque=false
          end
          return obj
        end
      end
      cls.draw=function(self,...)
        if GoldCompat.strictNativeUiEnabled() and featureEnabled(toggle) then
          self.isOpaque=false
          State[key]=self
          return
        end
        if State[key]==self then State[key]=nil end
        return cls.__colosseumOriginalDraw(self,...)
      end
    end
  end

  if mod and mod.log then
    pcall(function()
      mod.log("info", "Colosseum Inspired UI Overhaul: overworld menu layer active")
    end)
  end
end


-- -------------------------------------------------------------------------
-- Final-pass FRLG overworld menus
-- -------------------------------------------------------------------------

local function uiTopState(game, state)
  if not (game and game.stack and game.stack.states and state) then return false end
  local top = (game.stack.top and game.stack:top()) or game.stack.states[#game.stack.states]
  return top == state
end


local function findBagStateInStack(game)
  return bagStateForMenu(game)
end

local function finalCanvas()
  local sw, sh = love.graphics.getDimensions()
  local raw = math.min(sw / 160, sh / 144)
  local scale = math.floor(raw)
  if scale < 1 then scale = raw end

  -- UI BOX SIZE is intentionally allowed to exceed the full 160x144
  -- fit-scale slightly. Most hanging panels have generous logical margins,
  -- so this makes LARGE / X-LARGE visibly meaningful without changing their
  -- internal layout. COMPACT still shrinks normally.
  local boxScale=GoldCompat.userBoxScale()
  if boxScale>1 then
    scale=math.min(scale*boxScale,raw*1.14)
  else
    scale=scale*boxScale
  end

  local ox = math.floor((sw - 160*scale) * 0.5 + 0.5)
  local oy = math.floor((sh - 144*scale) * 0.5 + 0.5)
  return ox, oy, scale
end

-- Colosseum service menus are flat hardware rails that run off the right side
-- of the logical screen. They deliberately avoid the donor UI's rounded card
-- silhouette while retaining the hanging, translucent overworld treatment.
local function drawColosseumRunoffPanel(x,y,w,h,headerH)
  local g=love.graphics
  local right=math.min(162,x+w+6)
  headerH=headerH or 14
  g.setColor(0.00,0.01,0.015,0.34)
  g.polygon("fill",x+5,y+3,right,y+3,right,y+h+3,x+5,y+h+3,
    x,y+h-2,x,y+8)
  -- Lift the glass above the underlying field without making it opaque. The
  -- previous near-black fill swallowed unselected START labels on dark maps.
  g.setColor(0.030,0.105,0.108,0.88)
  g.polygon("fill",x+5,y,right,y,right,y+h,x+5,y+h,x,y+h-5,x,y+5)
  g.setColor(0.040,0.175,0.165,0.80)
  g.polygon("fill",x+4,y+3,right,y+3,right,y+headerH,x+7,y+headerH,
    x+3,y+headerH-4)
  g.setColor(0.36,0.63,0.61,0.95)
  g.setLineWidth(1.2)
  g.line(x+6,y,right,y)
  g.line(x+6,y+h,right,y+h)
  g.line(x,y+6,x,y+h-6)
  g.setColor(0.12,0.45,0.38,0.86)
  g.rectangle("fill",x+8,y+headerH,right-x-10,1)
end

local function drawColosseumRunoffSelection(x,y,w,h)
  local g=love.graphics
  local right=math.min(162,x+w+5)
  g.setColor(0.075,0.285,0.275,0.96)
  g.polygon("fill",x+6,y,right,y,right,y+h,x+6,y+h,x+2,y+h*0.5)
  g.setColor(1.00,0.34,0.16,1)
  g.polygon("fill",x+5,y+h*0.5,x+1,y+h*0.22,x+1,y+h*0.78)
end

-- Full-screen interfaces must honor the real display bounds at every UI box
-- size. Hanging/overworld panels continue to use finalCanvas(), which retains
-- its intentional slight Large/X-Large overscan.
local function safeFullCanvas(marginPx)
  local sw,sh=love.graphics.getDimensions()
  local margin=marginPx or 4
  local rail=GoldCompat.dexActionRailActive and 56 or 0
  -- Reserve a matching phantom rail on the right. This keeps the Pokédex
  -- itself centered when the real action rail appears on its left instead of
  -- centering the asymmetric combined assembly and shoving the Dex sideways.
  local raw=math.min((sw-margin*2)/(160+rail*2),(sh-margin*2)/144)
  local base=math.floor(math.min(sw/160,sh/144))
  if base<1 then base=math.min(sw/160,sh/144) end
  local requested=base*GoldCompat.userBoxScale()
  local scale=math.min(requested,raw)
  if scale<=0 then scale=raw end
  local ox=math.floor((sw-160*scale)*0.5+0.5)
  local oy=math.floor((sh-144*scale)*0.5+0.5)
  return ox,oy,scale
end

local function finalText(text, lx, ly, logicalSize, color, ox, oy, sc, align, logicalWidth)
  local sx = math.floor(ox + lx*sc + 0.5)
  local sy = math.floor(oy + ly*sc + 0.5)
  local pxSize = math.max(4, math.floor(logicalSize*sc + 0.5))
  local pxWidth = logicalWidth and math.floor(logicalWidth*sc + 0.5) or nil

  love.graphics.push("all")
  love.graphics.origin()
  printText(text, sx, sy, pxSize, color, align, pxWidth)
  if pxSize >= 10 and GoldCompat.userTextWeight()>=0.40 then
    printText(text, sx+1, sy, pxSize, color, align, pxWidth)
  end
  love.graphics.pop()
end

local function finalTextWidth(text, logicalSize, sc)
  local pxSize = math.max(4, math.floor(logicalSize*sc + 0.5))
  return font(pxSize*UI_TEXT_SCALE*GoldCompat.userTextScale()):getWidth(tostring(text or "")) / math.max(sc,0.001)
end

-- Option values are user-selected readability settings, so they must remain
-- readable without being allowed to reflow into the next row. Love's printf
-- wraps text when a width is supplied; fit first, then print a single line.
local function finalTextFitted(text,lx,ly,preferred,minSize,color,ox,oy,sc,align,width,maxHeight)
  text=tostring(text or "")
  local size=preferred
  local function tooLarge(candidate)
    if finalTextWidth(text,candidate,sc)>width-1 then return true end
    if maxHeight then
      local pxSize=math.max(4,math.floor(candidate*sc+0.5))
      local logicalH=font(pxSize*UI_TEXT_SCALE*GoldCompat.userTextScale()):getHeight()
        / math.max(sc,0.001)
      if logicalH>maxHeight then return true end
    end
    return false
  end
  while size>minSize and tooLarge(size) do
    size=size-0.10
  end
  finalText(text,lx,ly,math.max(minSize,size),color,ox,oy,sc,align,width)
end


local function drawShopPanel(x,y,w,h,selected)
  local g=love.graphics
  g.setColor(0.14,0.14,0.13,1)
  roundedRect("fill",x,y,w,h,3)
  g.setColor(selected and {0.975,0.955,0.88,1}
                      or {0.99,0.985,0.955,1})
  roundedRect("fill",x+2,y+2,w-4,h-4,2)
  if selected then
    g.setColor(0.72,0.58,0.28,1)
    roundedRect("line",x+3,y+3,w-6,h-6,2)
  end
end

local function shopMoney(game)
  return tonumber(game and game.save and game.save.money) or 0
end

local function drawShopMainFinal(game,state)
  local g=love.graphics
  local ox,oy,sc=finalCanvas()
  local items=state.items or {}
  local count=#items
  if count<1 then return end

  -- The first Mart choice is an overworld popup, matching START / UI OPTIONS.
  -- Native BUY/SELL/QUIT actions remain untouched; only presentation changes.
  local rowH=12
  local w=64
  local h=count*rowH+20
  local x=92
  local y=math.max(5,math.floor((144-h)/2))

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.05,0.05,0.05,0.35)
  g.rectangle("fill",x+2,y+2,w,h)
  g.setColor(0.08,0.08,0.07,1)
  g.rectangle("fill",x,y,w,h)
  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",x+2,y+2,w-4,h-4)
  drawUnifiedBorder(x,y,w,h,0)

  g.setColor(0.10,0.10,0.09,1)
  g.rectangle("fill",x+4,y+4,w-8,11)

  for i,item in ipairs(items) do
    local yy=y+17+(i-1)*rowH
    if i==(state.index or 1) then
      g.setColor(0.10,0.10,0.09,1)
      g.rectangle("fill",x+4,yy,w-8,rowH-1)
    end
  end
  g.pop()

  finalText("POKé MART",x+8,y+5,4.15,{1,1,1,1},ox,oy,sc)

  for i,item in ipairs(items) do
    local yy=y+17+(i-1)*rowH
    local selected=i==(state.index or 1)
    local label=tostring(item.label or "")
    if label:upper()=="QUIT" then label="EXIT" end
    finalText(label,x+9,yy+1,4.5,
      selected and {1,1,1,1} or {0.05,0.05,0.05,1},
      ox,oy,sc)
  end
end

function GoldCompat.shopFirstVisible(state)
  local rows=5
  local n=#(state.items or {})
  local selected=math.max(1,math.min(state.index or 1,math.max(1,n)))
  local first=math.max(1,selected-rows+1)
  if n>rows then first=math.min(first,n-rows+1) end
  return first,selected,rows
end

function GoldCompat.cleanItemDescription(desc)
  desc=tostring(desc or "")
  desc=desc:gsub("\r\n","\n"):gsub("\r","\n")

  -- Gen II ROM text uses <NEXT> as a two-row cursor jump. Some descriptions
  -- also hyphenate a word only to fit the original narrow Game Boy text box.
  desc=desc:gsub("([%a]+)%-<NEXT>%-?([%a]+)",function(a,b)
    if b:lower()=="type" then return a.."-"..b end
    return a..b
  end)
  desc=desc:gsub("<NEXT>"," ")
  desc=desc:gsub("\n"," ")
  desc=desc:gsub("%s+"," ")
  desc=desc:gsub("%s+([%.,!%?;:])","%1")
  desc=desc:gsub("^%s+",""):gsub("%s+$","")

  -- "(HOLD)" is cartridge/menu metadata. Turn it into readable prose.
  if desc:match("%s*%(HOLD%)%s*$") then
    desc=desc:gsub("%s*%(HOLD%)%s*$","")
    desc=desc:gsub("[%s%.]+$","")
    desc=desc.." when held."
  end

  return desc
end

local function drawShopListFinal(game,state)
  -- BUY is a compact hanging list over the live overworld.  The native
  -- ListMenu remains the transaction/input authority; this renderer only
  -- replaces the old full-screen mart surface.
  local title=tostring(state.title or "SHOP"):upper()
  if title=="SELL" then
    return drawShopSellBagFinal(game,state)
  end

  local ox,oy,sc=finalCanvas()
  local g=love.graphics
  local first,selected,rows=GoldCompat.shopFirstVisible(state)
  local visible=0
  for row=1,rows do if state.items and state.items[first+row-1] then visible=visible+1 end end
  visible=math.max(1,visible)

  local rowH=13
  local x=63
  local y=14
  local w=92
  -- Keep the BUY list and selected-item description as two distinct hanging
  -- surfaces. The list no longer reserves footer rows for description text.
  local h=22+visible*rowH+7

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)
  g.setColor(0.01,0.02,0.02,0.34)
  roundedRect("fill",x+2,y+2,w,h,6)
  g.setColor(0.025,0.065,0.068,0.94)
  roundedRect("fill",x,y,w,h,6)
  g.setColor(0.38,0.58,0.56,0.96)
  roundedRect("line",x,y,w,h,6)

  g.setColor(0.015,0.035,0.036,0.98)
  roundedRect("fill",x+5,y+5,w-10,13,4)

  for row=1,visible do
    local idx=first+row-1
    local yy=y+22+(row-1)*rowH
    if idx==selected then
      g.setColor(0.64,0.13,0.075,0.92)
      roundedRect("fill",x+5,yy-1,w-10,rowH-1,4)
    end
  end
  g.pop()

  finalText("POKé MART — BUY",x+9,y+7,3.55,{0.72,0.92,0.85,1},ox,oy,sc)
  local money=("¥%d"):format(shopMoney(game))
  local mw=finalTextWidth(money,3.45,sc)
  finalText(money,x+w-8-mw,y+7,3.45,{0.72,0.92,0.85,1},ox,oy,sc)

  for row=1,visible do
    local idx=first+row-1
    local item=state.items and state.items[idx]
    if item then
      local yy=y+22+(row-1)*rowH
      local selectedRow=idx==selected
      finalTextFitted(tostring(item.label or ""),x+10,yy+1,3.7,2.7,
        selectedRow and {1,1,1,1} or {0.73,0.86,0.81,1},
        ox,oy,sc,"left",54,rowH-2)
      if item.right then
        local right=tostring(item.right)
        local rw=finalTextWidth(right,3.45,sc)
        finalText(right,x+w-9-rw,yy+1,3.45,
          selectedRow and {1,1,1,1} or {0.58,0.76,0.70,1},ox,oy,sc)
      end
    end
  end

  -- The selected item's description gets its own dedicated hanging glass
  -- card directly beneath BUY. This avoids footer/help text colliding with
  -- the item rows and keeps the hierarchy consistent with the Gen I Mart.
  local footer=GoldCompat.cleanItemDescription(state.footer or "")
  if footer=="" then footer="Select an item." end
  local dx,dy,dw,dh=x,y+h+3,w,25

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)
  g.setColor(0.01,0.02,0.02,0.30)
  roundedRect("fill",dx+2,dy+2,dw,dh,5)
  g.setColor(0.025,0.065,0.068,0.92)
  roundedRect("fill",dx,dy,dw,dh,5)
  g.setColor(0.38,0.58,0.56,0.96)
  roundedRect("line",dx,dy,dw,dh,5)
  g.setColor(0.015,0.035,0.036,0.96)
  roundedRect("fill",dx+5,dy+5,dw-10,dh-10,3)
  g.pop()

  local pages=TextBox.paginate(footer,28)
  local lines=(pages and pages[1]) or {}
  for i=1,math.min(2,#lines) do
    finalTextFitted(tostring(lines[i]),dx+8,dy+6+(i-1)*8,2.65,1.95,
      {0.84,0.94,0.90,1},ox,oy,sc,"left",dw-16,8)
  end
end

function GoldCompat.drawShopQuantityFinal(game,shop,qty)
  if shop.__gen3uiShopSell then
    drawShopSellBagFinal(game,shop)
  else
    drawShopListFinal(game,shop)
  end
  local ox,oy,sc=finalCanvas()
  local g=love.graphics
  g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
  drawShopPanel(83,73,68,28,true)
  g.pop()

  finalText("HOW MANY?",90,78,3.2,{0.28,0.27,0.23,1},ox,oy,sc)
  finalText(("×%02d"):format(qty.qty or 1),91,87,5.0,{0.06,0.06,0.06,1},ox,oy,sc)
  if qty.unitPrice then
    local total=(qty.qty or 1)*qty.unitPrice
    local amount=("¥%d"):format(total)
    local aw=finalTextWidth(amount,4.6,sc)
    finalText(amount,144-aw,87,4.6,{0.06,0.06,0.06,1},ox,oy,sc)
  end
end

function GoldCompat.drawStartFinal(game, state)
  local g = love.graphics
  local ox,oy,sc = finalCanvas()

  if state.__gen3uiUISettings then
    local visible=math.min(state.maxVisible or #state.items,#state.items)
    local rowH=11
    local w=104
    local h=visible*rowH+20
    local x=52
    local y=math.max(4,math.floor((144-h)/2))

    g.push("all")
    g.translate(ox,oy)
    g.scale(sc,sc)

    -- Same floating panel language as START, simply widened for label/value
    -- pairs. The overworld remains fully visible behind it.
    drawColosseumRunoffPanel(x,y,w,h,16)

    for row=1,visible do
      local item=state.items[state.scroll+row]
      if not item then break end
      local yy=y+18+(row-1)*rowH
      if (state.scroll+row)==state.index then
        drawColosseumRunoffSelection(x+3,yy-1,w-3,rowH-1)
      end
    end
    g.pop()

    finalText("UI OPTIONS",x+9,y+6,4.7,{1,1,1,1},ox,oy,sc)

    for row=1,visible do
      local item=state.items[state.scroll+row]
      if not item then break end
      local yy=y+18+(row-1)*rowH
      local selected=(state.scroll+row)==state.index
      local cfg=item.__gen3uiUIRow
      local value=cfg and DexUI.optionDisplay(cfg) or ""
      finalTextFitted(item.label,x+8,yy+1,3.2,1.65,
        selected and {1,1,1,1} or {0.73,0.86,0.81,1},
        ox,oy,sc,"left",49,rowH-2)
      finalTextFitted(value,x+59,yy+1,3.1,1.45,
        selected and {1,1,1,1} or {0.55,0.78,0.69,1},
        ox,oy,sc,"right",45,rowH-2)
    end

    finalText("A: CHANGE   B: BACK",x+8,y+h-6,2.55,
      {0.62,0.79,0.72,1},ox,oy,sc)
    return
  end

  local visible = (state.maxVisible and math.min(state.maxVisible, #state.items)) or #state.items

  -- Derive the menu shell from the active profile's real glyph metrics. Large
  -- profiles receive taller rows and a wider panel; each label then fits within
  -- that row in both dimensions instead of inheriting OG's fixed 60x12 cells.
  local metricPx=math.max(4,math.floor(4.2*sc+0.5))
  local metricH=font(metricPx*UI_TEXT_SCALE*GoldCompat.userTextScale()):getHeight()
    / math.max(sc,0.001)
  local rowH=clamp(math.ceil(metricH+3),12,16)
  local widest=0
  for _,item in ipairs(state.items or {}) do
    widest=math.max(widest,finalTextWidth(item.label or "",4.2,sc))
  end
  local w=clamp(math.ceil(widest+20),60,88)
  local h = visible*rowH + 8
  local x = 156-w
  local y = math.max(3, math.floor((144-h)/2))

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  drawColosseumRunoffPanel(x,y,w,h,0)

  for row=1,visible do
    local item = state.items[state.scroll + row]
    if not item then break end
    local ry = y + 4 + (row-1)*rowH
    if (state.scroll + row) == state.index then
      drawColosseumRunoffSelection(x+3,ry,w-3,rowH-1)
    end
  end
  g.pop()

  for row=1,visible do
    local item = state.items[state.scroll + row]
    if not item then break end
    local ry = y + 4 + (row-1)*rowH
    local selected = (state.scroll + row) == state.index
    finalTextFitted(item.label,x+9,ry+1,4.2,2.2,
      selected and {1,1,1,1} or {0.74,0.87,0.82,1},
      ox,oy,sc,"left",w-15,rowH-2)
  end
end


function GoldCompat.drawBagActionFinal(game, state)
  local g = love.graphics
  local ox,oy,sc = finalCanvas()

  local items = state.items or {}
  local count = #items
  if count < 1 then return end

  local rowH = 12
  local w = 48
  local h = count*rowH + 8
  local x = 107
  local y = math.max(5, 105 - h)

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.01,0.02,0.02,0.35)
  roundedRect("fill",x+2,y+2,w,h,6)
  g.setColor(0.025,0.065,0.068,0.78)
  roundedRect("fill",x,y,w,h,6)
  g.setColor(0.38,0.58,0.56,0.96)
  roundedRect("line",x,y,w,h,6)

  for i=1,count do
    local ry = y + 4 + (i-1)*rowH
    if i == (state.index or 1) then
      g.setColor(0.64,0.13,0.075,0.90)
      roundedRect("fill",x+4,ry,w-8,rowH-1,4)
    end
  end

  g.pop()

  for i=1,count do
    local item = items[i]
    local label = item and (item.label or item.text or tostring(item)) or ""
    local ry = y + 4 + (i-1)*rowH
    local selected = i == (state.index or 1)

    finalText(label,x+9,ry+1,5,
      selected and {1,1,1,1} or {0.04,0.04,0.04,1},
      ox,oy,sc)
  end
end

local function drawBagFinal(game, state)
  if GoldCompat.generation=="gen1"
      and state and state.__gen3uiCategorizedBag
      and GoldCompat.drawGoldPack then
    local result=GoldCompat.drawGoldPack(gen1BagGoldAdapter(state),
      love.graphics.getWidth(),love.graphics.getHeight(),false)
    if state.__gen3uiShopSellBag then
      local ox,oy,sc=finalCanvas()
      finalText("POKé MART — SELL",5,8,3.2,{0.72,0.92,0.85,1},ox,oy,sc)
      local money=("¥%d"):format(shopMoney(game))
      finalText(money,5,16,3.7,{0.84,0.94,0.90,1},ox,oy,sc)
    end
    return result
  end

  -- Legacy fallback for non-Gen1 callers.
  local g = love.graphics
  local ox,oy,sc = finalCanvas()
  local x,y,w,h = 5,5,150,134

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)
  g.setColor(0.08,0.08,0.07,1)
  g.rectangle("fill",x,y,w,h)
  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",x+2,y+2,w-4,h-4)
  drawUnifiedBorder(x,y,w,h,0)
  g.pop()

  finalText(Strings("BAG"),x+9,y+5,6,
    {0.04,0.04,0.04,1},ox,oy,sc)
end

local function drawShopSellBagFinal(game,state)
  -- SELL is inventory browsing, so present the live Shop ListMenu through the
  -- same Gen 3 Bag layout used elsewhere in this mod. Do NOT construct a fake
  -- BagMenu: BagMenu.new has runtime/state side effects and native renderers may
  -- draw into the 160x144 canvas directly.
  if state.scroll==nil then state.scroll=0 end
  if state.rows==nil then state.rows=7 end
  drawBagFinal(game,state)

  -- Small Mart context overlay; transaction logic remains native.
  local ox,oy,sc=finalCanvas()
  local money=("¥%d"):format(shopMoney(game))
  local mw=finalTextWidth(money,4.1,sc)
  finalText("SELL",9,6,4.1,{0.26,0.24,0.19,1},ox,oy,sc)
  finalText(money,150-mw,6,4.1,{0.12,0.12,0.11,1},ox,oy,sc)
  return true
end


-- -------------------------------------------------------------------------
-- Final-pass FRLG Party screen
-- -------------------------------------------------------------------------

local function partyTopState(game, party)
  if not (game and game.stack and game.stack.states and party) then return false end
  local top = (game.stack.top and game.stack:top()) or game.stack.states[#game.stack.states]
  return top == party
end


local function partyInStack(game, party)
  if not (game and game.stack and game.stack.states and party) then return false end
  for _,state in ipairs(game.stack.states) do
    if state == party then return true end
  end
  return false
end

local STONE_ITEM_IDS={
  FIRE_STONE=true,
  WATER_STONE=true,
  THUNDER_STONE=true,
  LEAF_STONE=true,
  MOON_STONE=true,
}

local function itemTargetIsStone(state)
  return state and STONE_ITEM_IDS[state.__gen3uiTargetItem] == true
end

function GoldCompat.stoneAllowedForMon(game,state,mon)
  if not (game and state and mon and itemTargetIsStone(state)) then
    return false
  end

  local ok,target=pcall(Evolution.pendingFor,game,mon,{
    kind="item",
    item=state.__gen3uiTargetItem,
  })
  return ok and target ~= nil
end


local function partyShouldRenderBehindTM(game, party)
  if not party then return false end
  if not party.keepOpen then return false end
  if not (party.tmhm or party.__gen3uiKeepTMBackground) then return false end
  return partyInStack(game, party)
end


local function partyLogicalCanvas()
  local sw, sh = love.graphics.getDimensions()
  local raw = math.min(sw / 160, sh / 144)

  -- Integer scaling preserves the battle font's pixel structure.
  -- Only fall back to fractional scaling on very small windows.
  local scale = math.floor(raw)
  if scale < 1 then scale = raw end

  local ox = math.floor((sw - 160*scale) * 0.5 + 0.5)
  local oy = math.floor((sh - 144*scale) * 0.5 + 0.5)
  return ox, oy, scale
end

local function partySlotPanel(x,y,w,h,selected)
  local g = love.graphics
  g.setColor(0.14,0.14,0.13,1)
  roundedRect("fill",x,y,w,h,3)
  g.setColor(selected and {0.975,0.955,0.88,1} or {0.99,0.985,0.955,1})
  roundedRect("fill",x+2,y+2,w-4,h-4,2)
  if selected then
    g.setColor(0.72,0.58,0.28,1)
    roundedRect("line",x+3,y+3,w-6,h-6,2)
  end
end

local function partyHPBarFinal(x,y,w,mon)
  local g = love.graphics
  local maxhp = math.max(1, mon.stats and mon.stats.hp or 1)
  local ratio = clamp((mon.hp or 0)/maxhp,0,1)
  g.setColor(0.10,0.10,0.09,1)
  roundedRect("fill",x,y,w,4,1.5)
  g.setColor(0.78,0.76,0.63,1)
  roundedRect("fill",x+1,y+1,w-2,2,1)
  local fill = (w-2)*ratio
  if (mon.hp or 0)>0 then fill = math.max(1,fill) end
  if fill>0 then
    local r,gg,b,a = hpColor(ratio)
    g.setColor(r,gg,b,a)
    roundedRect("fill",x+1,y+1,fill,2,1)
  end
end


-- Party UI deliberately uses the exact battle typography implementation.
-- These wrappers exist only so Party layout code remains readable.
local function partyTextWidth(text, size)
  -- Convert the full-resolution battle-font width back into logical Party units
  -- so existing FRLG layout calculations (right alignment, columns) still work.
  local sc = math.max(0.001, partyRenderScale or 1)
  -- Global readability polish: a deliberately small bump, not a redesign.
  local pxSize = math.max(4, math.floor(size * sc + 0.5))
  return font(pxSize*UI_TEXT_SCALE*GoldCompat.userTextScale()):getWidth(tostring(text or "")) / sc
end

local function partyText(text, x, y, size, color, align, width)
  -- Critical difference from previous builds:
  -- Party geometry is inside a scaled 160x144 transform, but text is NOT.
  -- Drop to screen coordinates and call the exact battle printText() renderer.
  local g = love.graphics
  local sc = math.max(0.001, partyRenderScale or 1)

  local sx = math.floor((partyRenderOX or 0) + x * sc + 0.5)
  local sy = math.floor((partyRenderOY or 0) + y * sc + 0.5)
  local pxSize = math.max(4, math.floor(size * sc + 0.5))
  local pxWidth = width and math.floor(width * sc + 0.5) or nil

  g.push("all")
  g.origin()
  printText(text, sx, sy, pxSize, color, align, pxWidth)
  g.pop()
end


local function partyExpRatio(game, mon)
  if not (game and game.data and mon) then return 0 end
  return GoldCompat.experienceRatio(game.data,mon,
    GoldCompat.isGen2Game(game) and "gen2" or "gen1")
end

function GoldCompat.drawPartyExpBar(game, mon, x, y, w)
  local g = love.graphics
  local ratio = partyExpRatio(game, mon)

  g.setColor(0.10,0.18,0.24,1)
  roundedRect("fill", x, y, w, 4, 1.5)

  g.setColor(0.14,0.28,0.38,1)
  roundedRect("fill", x+1, y+1, w-2, 2, 1)

  local fill = (w-2) * ratio
  if fill > 0 then
    g.setColor(0.08,0.48,0.96,1)
    roundedRect("fill", x+1, y+1, fill, 2, 1)
  end

  g.setColor(1,1,1,1)
end

local function partyMoveName(game, move)
  if not move then return "---" end

  local id = move.id or move.move or move.name or move
  if type(id) == "string" then
    local def = game.data.moves and game.data.moves[id]
    return (def and def.name) or GoldCompat.humanizeIdentifier(id)
  end

  local def = game.data.moves and game.data.moves[id]
  return (def and def.name) or tostring(id or "---")
end

local function partyMovePP(game, move)
  if not move then return "" end
  local pp = move.pp
  local maxpp = move.maxPP or move.ppMax

  if maxpp == nil then
    local id = move.id or move.move or move.name or move
    local def = game.data.moves and game.data.moves[id]
    maxpp = def and def.pp
  end

  if pp ~= nil and maxpp ~= nil then
    return tostring(pp).."/"..tostring(maxpp)
  elseif maxpp ~= nil then
    return tostring(maxpp)
  end
  return ""
end

local function partyStat(mon, ...)
  local stats = mon and mon.stats or {}
  local keys = {...}
  for _,key in ipairs(keys) do
    local v = stats[key]
    if v ~= nil then return v end
  end
  return "-"
end

function GoldCompat.drawColosseumPortrait(game,mon,x,y,w,h)
  local useIcons=featureEnabled("colosseumIcons")
  if GoldCompat.ColosseumUI and GoldCompat.ColosseumUI.setIconsEnabled then
    pcall(GoldCompat.ColosseumUI.setIconsEnabled,useIcons)
  end
  if useIcons and GoldCompat.ColosseumUI and GoldCompat.ColosseumUI.drawPortrait then
    local ok,drew=pcall(GoldCompat.ColosseumUI.drawPortrait,game,mon,x,y,w,h)
    if ok and drew then return true end
  end
  -- The Colosseum Party renderer is currently inside the logical 160x144
  -- transform, while drawCleanResolvedPortrait deliberately resets to screen
  -- coordinates. Convert the pod rect before entering that fallback; passing
  -- logical coordinates directly is what stranded tiny sprites at desktop 0,0.
  local ox,oy,sc=partyLogicalCanvas()
  local ok,drew=pcall(GoldCompat.drawCleanResolvedPortrait,
    game,mon,ox+x*sc,oy+y*sc,w*sc,h*sc,"summary")
  return ok and drew or false
end


-- Colosseum Party keeps the native PartyMenu/MoveLearn/TM/item state intact
-- and replaces presentation only. The six-card field follows the GameCube
-- reference closely; the selected data deck underneath adds the mature Gen 3
-- UI's moves, PP, EXP, held item, status and readable stat coverage without
-- removing anything from the reference composition.
function GoldCompat.drawColosseumParty(game, state)
  if not (game and state) then return false end

  local party=state.party or (game.save and game.save.party) or {}
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc
  state.isOpaque=false
  state.__gen3uiColosseumParty=true

  local function panel(x,y,w,h,selected,alpha)
    g.setColor(0.015,0.025,0.030,0.48)
    roundedRect("fill",x+1.5,y+1.5,w,h,3)
    g.setColor(0.055,0.105,0.115,alpha or 0.86)
    roundedRect("fill",x,y,w,h,3)
    g.setColor(selected and {0.78,0.14,0.10,0.98}
      or {0.45,0.57,0.55,0.96})
    roundedRect("line",x,y,w,h,3)
    g.setColor(selected and {0.98,0.34,0.18,0.96}
      or {0.12,0.22,0.22,0.92})
    roundedRect("line",x+1.4,y+1.4,w-2.8,h-2.8,2)
  end

  local function icon(mon,x,y,w,h)
    g.setColor(0.015,0.025,0.030,0.92)
    roundedRect("fill",x,y,w,h,2)
    g.setColor(0.36,0.46,0.44,0.96)
    roundedRect("line",x,y,w,h,2)

    -- Colosseum's source icons are intentionally tight facial crops. A modest
    -- inner margin keeps those portraits expressive without pressing eyes and
    -- snouts directly against the pod rim.
    if GoldCompat.drawColosseumPortrait(game,mon,x+2,y+2,w-4,h-4) then return end

    g.push("all")
    g.translate(x+1,y+1)
    if type(state.drawIcon)=="function" then
      pcall(state.drawIcon,state,mon,0,0)
    else
      pcall(PartyMenu.drawIcon,game,mon,0,0,false,state.blink or 0)
    end
    g.pop()
  end

  local function maxHPFor(mon)
    return math.max(1,tonumber(mon and (mon.maxHp
      or (mon.stats and mon.stats.hp))) or 1)
  end

  local function definition(mon)
    if not mon then return nil end
    local defs=state.pokemon or (game.data and game.data.pokemon)
    return defs and defs[mon.species] or nil
  end

  local function displayName(mon)
    local def=definition(mon)
    return tostring(mon and (mon.isEgg and "EGG"
      or mon.nickname or (def and def.name) or mon.species) or "POKéMON")
  end

  local function itemName(mon)
    if not (mon and mon.item and mon.item~=0 and mon.item~="") then
      return "NONE"
    end
    local items=state.items or (game.data and game.data.items)
    local def=items and items[mon.item]
    return tostring((def and def.name) or mon.item)
  end

  local function targetLabel(mon)
    if state.tmhm then
      local move=state.tmhm.move or state.tmhm
      local def=definition(mon)
      local able=false
      for _,moveId in ipairs((def and def.tmhm) or {}) do
        if moveId==move then able=true break end
      end
      return able and "ABLE" or "NOT ABLE",
        able and {0.38,0.95,0.52,1} or {1.00,0.40,0.32,1}
    end
    if state.__gen3uiItemTarget and itemTargetIsStone(state) then
      local able=GoldCompat.stoneAllowedForMon(game,state,mon)
      return able and "ALLOWED" or "NOT ALLOWED",
        able and {0.38,0.95,0.52,1} or {1.00,0.40,0.32,1}
    end
    return nil,nil
  end

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  if #party==0 then
    panel(29,54,102,30,true,0.90)
    partyText("No POKéMON!",45,64,5,{0.98,0.98,0.94,1})
    g.pop()
    return true
  end

  local selected=clamp(state.index or 1,1,#party)
  local selectedMon=party[selected]
  local cardW,cardH=74,23
  local cardXs={5,81}
  local cardYs={5,31,57}

  for i=1,6 do
    local col=(i-1)%2+1
    local row=math.floor((i-1)/2)+1
    local x,y=cardXs[col],cardYs[row]
    local mon=party[i]

    if mon then
      local isSelected=i==selected
      panel(x,y,cardW,cardH,isSelected,0.84)
      icon(mon,x+2,y+2,19,19)

      local name=displayName(mon)
      local nameSize=2.85
      local nameMax=33
      while nameSize>1.75 and partyTextWidth(name,nameSize)>nameMax do
        nameSize=nameSize-0.12
      end
      partyText(name,x+23,y+3,nameSize,{0.98,0.98,0.94,1},"left",nameMax)

      if not mon.isEgg then
        local level="Lv"..tostring(mon.level or "?")
        partyText(level,x+cardW-17,y+3,2.35,{0.94,0.86,0.42,1},"left",14)

        local gender=GoldCompat.genderSymbol(mon)
        if gender then
          local gx=math.min(x+23+partyTextWidth(name,nameSize)+1,x+cardW-21)
          pcall(GoldCompat.drawGenderIcon,ox+gx*sc,oy+(y+3)*sc,7,gender)
        end

        local hpMax=maxHPFor(mon)
        local hpNow=math.max(0,tonumber(mon.hp) or 0)
        local hpText=tostring(hpNow).."/"..tostring(hpMax)
        local valueW=partyTextWidth(hpText,1.95)
        local barX=x+23
        local valueX=x+cardW-3-valueW
        local barW=math.max(12,valueX-barX-2)
        partyHPBarFinal(barX,y+13,barW,mon)
        partyText(hpText,valueX,y+12,1.95,{0.98,0.98,0.94,1})

        local target,colr=targetLabel(mon)
        local status=owStatus(mon)
        if target then
          partyText(target,x+23,y+17,1.75,colr,"left",cardW-26)
        elseif status then
          partyText(status,x+23,y+17,1.75,
            status=="FNT" and {1.00,0.35,0.28,1} or {0.92,0.54,1.00,1})
        end
      end
    else
      panel(x,y,cardW,cardH,false,0.50)
      partyText("—",x+35,y+8,3,{0.56,0.64,0.62,0.72})
    end
  end

  -- Additive selected-Pokémon data retained from the mature Party UI.
  local dx,dy,dw,dh=5,83,150,44
  panel(dx,dy,dw,dh,true,0.88)
  local selectedName=displayName(selectedMon)
  partyText(selectedName,dx+5,dy+3,3.0,{0.98,0.98,0.94,1},"left",38)
  partyText("Lv"..tostring(selectedMon.level or "?"),dx+45,dy+3,2.5,
    {0.94,0.86,0.42,1})

  local selectedStatus=owStatus(selectedMon) or "OK"
  partyText(selectedStatus,dx+62,dy+3,2.15,
    selectedStatus=="FNT" and {1.00,0.35,0.28,1} or {0.72,0.84,0.80,1})
  local held="HELD  "..itemName(selectedMon)
  local heldSize=2.15
  while heldSize>1.55 and partyTextWidth(held,heldSize)>49 do
    heldSize=heldSize-0.10
  end
  partyText(held,dx+96,dy+3,heldSize,{0.78,0.84,0.80,1},"left",49)

  partyText("EXP",dx+5,dy+10,1.9,{0.36,0.72,1.00,1})
  GoldCompat.drawPartyExpBar(game,selectedMon,dx+16,dy+11,43)
  partyText("MOVES",dx+63,dy+10,1.9,{0.78,0.84,0.80,1})

  local learn=state.__gen3uiGoldBattleMoveParty
      and State.activeGoldBattleMoveLearn or State.activeMoveLearn
  local battleLearn=State.activeBattleMoveLearn
  if state.__gen3uiBattleMoveParty and battleLearn and battleLearn.selecting then
    learn=battleLearn
  end
  local ppPicker=state.__gen3uiPPMoveParty and State.activePPMoveList or nil
  if ppPicker then
    learn={selecting=true,mon=selectedMon,index=ppPicker.index or 1,__ppItem=true}
  end
  local replacing=learn and learn.selecting and learn.mon==selectedMon
  if replacing and not learn.__ppItem then
    local newDef=game.data and game.data.moves and game.data.moves[learn.newMoveId]
    local newName=(newDef and newDef.name)
      or GoldCompat.humanizeIdentifier(learn.newMoveId or "MOVE")
    local incoming="NEW  "..newName
    local incomingSize=1.9
    while incomingSize>1.35 and partyTextWidth(incoming,incomingSize)>70 do
      incomingSize=incomingSize-0.10
    end
    partyText(incoming,dx+76,dy+10,incomingSize,{1.00,0.76,0.30,1},"left",70)
  end

  local moves=selectedMon.moves or {}
  local moveX,moveY=dx+4,dy+16
  local moveGap=2
  local moveW=(dw-8-moveGap*3)/4
  local moveH=13
  for i=1,4 do
    local mx=moveX+(i-1)*(moveW+moveGap)
    local picked=replacing and (learn.index or 1)==i
    g.setColor(picked and {0.54,0.12,0.08,0.96} or {0.02,0.04,0.045,0.78})
    roundedRect("fill",mx,moveY,moveW,moveH,1.5)
    g.setColor(picked and {1.00,0.34,0.18,1} or {0.28,0.40,0.39,0.96})
    roundedRect("line",mx,moveY,moveW,moveH,1.5)

    local entry=moves[i]
    local moveName=partyMoveName(game,entry)
    local pp=partyMovePP(game,entry)
    local moveSize=2.2
    while moveSize>1.35 and partyTextWidth(moveName,moveSize)>moveW-3 do
      moveSize=moveSize-0.10
    end
    partyText(moveName,mx+1.5,moveY+2,moveSize,
      {0.98,0.98,0.94,1},"center",moveW-3)
    if pp~="" then
      partyText(pp,mx+1.5,moveY+8,1.55,{0.66,0.75,0.72,1},"center",moveW-3)
    end
  end

  local stats
  if GoldCompat.generation=="gen2" then
    stats={
      {"ATK",partyStat(selectedMon,"attack","atk")},
      {"DEF",partyStat(selectedMon,"defense","def")},
      {"SPD",partyStat(selectedMon,"speed","spd")},
      {"SPA",partyStat(selectedMon,"specialAttack","spAtk","special")},
      {"SDF",partyStat(selectedMon,"specialDefense","spDef","special")},
    }
  else
    stats={
      {"ATK",partyStat(selectedMon,"attack","atk")},
      {"DEF",partyStat(selectedMon,"defense","def")},
      {"SPD",partyStat(selectedMon,"speed","spd")},
      {"SPC",partyStat(selectedMon,"special","spc","specialAttack")},
    }
  end
  local statW=(dw-8)/#stats
  for i,stat in ipairs(stats) do
    local sx=dx+4+(i-1)*statW
    local text=stat[1].." "..tostring(stat[2])
    partyText(text,sx,dy+32,1.9,{0.78,0.84,0.80,1},"center",statW)
  end

  -- Reference-style split prompt and Exit blocks.
  panel(5,130,117,10,false,0.88)
  panel(125,130,30,10,false,0.88)
  local prompt
  if replacing then
    local count=#moves
    prompt=(learn.index or 1)>count and "Cancel move learning?"
      or "Choose a move to replace."
  elseif state.switchFrom then
    prompt="Move to where?"
  elseif state.__gen3uiItemTarget and itemTargetIsStone(state) then
    prompt="Use stone on which POKéMON?"
  elseif state.__gen3uiItemTarget then
    prompt="Use item on which POKéMON?"
  elseif type(state.bottomMessage)=="function" then
    local ok,value=pcall(state.bottomMessage,state)
    prompt=ok and value or nil
  end
  prompt=tostring(prompt or state.prompt or "Choose a POKéMON.")
    :gsub("<PK><MN>","POKéMON"):gsub("\n"," ")
  local promptSize=2.7
  while promptSize>1.7 and partyTextWidth(prompt,promptSize)>107 do
    promptSize=promptSize-0.10
  end
  partyText(prompt,9,133,promptSize,{0.98,0.98,0.94,1},"left",107)
  partyText("B: EXIT",128,133,2.25,{0.98,0.98,0.94,1},"center",24)

  -- Both generations retain their native submenu objects and actions.
  local submenuItems=state.subItems
  local submenuIndex=state.subIndex
  if type(state.submenu)=="table"
      and type(state.submenu.items)=="table" then
    submenuItems=state.submenu.items
    submenuIndex=state.submenu.index
  end
  if state.submenu and submenuItems then
    local count=#submenuItems
    local sw=42
    local sh=math.min(64,6+count*10)
    local leftMargin=math.max(0,ox/sc)
    -- Widescreen has a natural rail beside the 160x144 party canvas. Use it
    -- for actions so STATS/MOVES never cover the selected-Pokémon data deck.
    -- On narrow 4:3 windows, dock above the left party column instead.
    local sx=leftMargin>=sw+4 and -(sw+3) or 5
    -- Center the widescreen action rail vertically beside the Party deck.
    -- Its former y=83 anchor packed six-item menus against (and sometimes
    -- beyond) the bottom edge at larger UI/text profiles.
    local sy=leftMargin>=sw+4 and math.max(18,(144-sh)*0.5) or 5
    panel(sx,sy,sw,sh,true,0.96)
    for i,entry in ipairs(submenuItems) do
      local yy=sy+3+(i-1)*10
      local picked=i==(submenuIndex or 1)
      if picked then
        g.setColor(0.62,0.14,0.09,0.96)
        roundedRect("fill",sx+3,yy,sw-6,9,1.5)
      end
      local label=type(entry)=="table"
        and (entry.label or entry.name or entry.id) or entry
      partyText(tostring(label or ""),sx+6,yy+2,2.6,
        picked and {1,1,1,1} or {0.86,0.90,0.88,1},"left",sw-10)
    end
  end

  g.setColor(1,1,1,1)
  g.pop()
  return true
end


function GoldCompat.drawPartyMoveReplace(game, mon, x, y, w, h, learn)
  if not (mon and learn) then return end

  local g = love.graphics
  local moves = mon.moves or {}
  local moveId = learn.newMoveId
  local newDef = moveId and game.data.moves[moveId] or nil
  local newName = (newDef and newDef.name)
    or GoldCompat.humanizeIdentifier(moveId or "MOVE")

  -- Repaint the ENTIRE information region every frame. This is intentionally
  -- opaque so no text from the normal details panel or native MoveLearnMenu
  -- can remain visible underneath the integrated replacement interface.
  local areaX = x + 6
  local areaY = y + 63
  local areaW = w - 12
  local areaH = h - 67

  g.setColor(0.99,0.975,0.90,1)
  g.rectangle("fill",areaX,areaY,areaW,areaH)

  g.setColor(0.70,0.68,0.59,1)
  g.rectangle("fill",x+7,y+64,w-14,1)

  partyText("REPLACE MOVE",x+8,y+65,3,{0.16,0.16,0.14,1})

  -- Incoming move occupies a fixed header row.
  partyText("NEW",x+8,y+70,2,{0.46,0.34,0.10,1})
  local incoming = newName
  if #incoming > 12 then incoming = incoming:sub(1,11).."." end
  partyText(incoming,x+20,y+69,3,{0.06,0.06,0.06,1})

  -- Four fixed rows, with enough vertical separation that no fifth/cancel
  -- state can collide with move text.
  local moveTop = y + 76
  local rowH = 6
  local rowX = x + 7
  local rowW = w - 14
  local ppRight = x + w - 7
  local selected = math.max(1,math.min(learn.index or 1,#moves+1))

  for i=1,4 do
    local mv = moves[i]
    local my = moveTop + (i-1)*rowH
    local isSelected = (i == selected)

    if isSelected then
      g.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",rowX,my-1,rowW,6,1)
    end

    if mv then
      local name = partyMoveName(game,mv)
      if #name > 12 then name = name:sub(1,11).."." end
      local col = isSelected and {1,1,1,1} or {0.06,0.06,0.06,1}
      partyText(name,x+10,my,2,col)

      local pp = partyMovePP(game,mv)
      if pp ~= "" then
        local pw = partyTextWidth(pp,2)
        partyText(pp,ppRight-pw,my,2,
          isSelected and {1,1,1,1} or {0.20,0.20,0.18,1})
      end
    else
      partyText("---",x+10,my,2,
        isSelected and {1,1,1,1} or {0.38,0.38,0.34,1})
    end
  end

  -- No CANCEL label is ever drawn in this panel. The native fifth cursor
  -- position still exists logically and is represented only by the bottom prompt.
  g.setColor(1,1,1,1)
end

local function drawPartyDetails(game, mon, x, y, w, h)
  if not mon then return end

  local g = love.graphics
  local moves = mon.moves or {}

  -- Details begin directly under EXP.
  local detailDividerY = y + 64
  g.setColor(0.70,0.68,0.59,1)
  g.rectangle("fill", x+7, detailDividerY, w-14, 1)

  partyText("MOVES", x+8, detailDividerY+2, 3, {0.16,0.16,0.14,1})

  -- Compact four-row move block.
  local moveTop = detailDividerY + 7
  local moveRowH = 4
  local ppRight = x + w - 7

  for i=1,4 do
    local m = moves[i]
    local my = moveTop + (i-1)*moveRowH
    local name = partyMoveName(game,m)
    local pp = partyMovePP(game,m)

    if #name > 12 then
      name = name:sub(1,11).."."
    end

    partyText(name, x+8, my, 3, {0.06,0.06,0.06,1})

    if pp ~= "" then
      local pw = partyTextWidth(pp, 2)
      partyText(pp, ppRight-pw, my, 2, {0.20,0.20,0.18,1})
    end
  end

  -- Stats stay in a fixed footer, isolated from moves.
  local statsDividerY = y + h - 13
  g.setColor(0.74,0.72,0.64,1)
  g.rectangle("fill", x+7, statsDividerY, w-14, 1)

  local stats = {
    {"ATK", partyStat(mon,"attack","atk")},
    {"DEF", partyStat(mon,"defense","def")},
    {"SPD", partyStat(mon,"speed","spd")},
    {"SPC", partyStat(mon,"special","spc","specialAttack")},
  }

  local innerX = x + 7
  local innerW = w - 14
  local colW = innerW / 4
  local labelY = statsDividerY + 1
  local valueY = statsDividerY + 4

  for i,s in ipairs(stats) do
    local colX = innerX + (i-1)*colW
    local label = s[1]
    local value = tostring(s[2])

    local lw = partyTextWidth(label, 2)
    local vw = partyTextWidth(value, 3)

    partyText(label, colX + (colW-lw)/2, labelY, 2, {0.25,0.25,0.22,1})
    partyText(value, colX + (colW-vw)/2, valueY, 3, {0.06,0.06,0.06,1})
  end
end


local function pokedexSeenCount(save)
  -- Gen1Recomp's authoritative Pokédex save structure is:
  --   save.pokedex.seen
  --   save.pokedex.owned
  -- The UI should mirror the game's actual Pokédex flags directly rather than
  -- infer progress from party/storage contents or alternate field names.
  local seen=save and save.pokedex and save.pokedex.seen
  if type(seen)~="table" then return 0 end

  local count=0
  for _ in pairs(seen) do
    count=count+1
  end
  return count
end

local function pokedexOwnedCount(save)
  local owned=save and save.pokedex and save.pokedex.owned
  if type(owned)~="table" then return 0 end
  local count=0
  for _ in pairs(owned) do count=count+1 end
  return count
end

function GoldCompat.totalStoredPokemon(save)
  if not save then return 0 end

  -- Prefer the canonical Boxes container when available, but remain
  -- defensive for save-format/mod variations.
  local boxes=save.boxes
      or save.pcBoxes
      or save.storage
      or save.pokemonBoxes

  if type(boxes)=="table" then
    local total=0
    for _,box in pairs(boxes) do
      if type(box)=="table" then
        -- Some formats wrap entries under .pokemon/.mons/.slots.
        local entries=box.pokemon or box.mons or box.slots or box
        if type(entries)=="table" then
          for _,mon in pairs(entries) do
            if type(mon)=="table" and (mon.species or mon.nickname or mon.level) then
              total=total+1
            end
          end
        end
      end
    end
    return total
  end

  -- Last-resort: current active box only, better than showing nonsense.
  local ok,active=pcall(Boxes.active,save)
  if ok and type(active)=="table" then return #active end

  return 0
end

function GoldCompat.pcSelectedMon(game,state)
  if not state then return nil end

  if state.__gen3uiPCList then
    local title=tostring(state.title or ""):upper()
    local source=nil
    if title=="PARTY (DEPOSIT)" then
      source=game.save and game.save.party or {}
    elseif title:find("(WITHDRAW)",1,true) or title:find("(RELEASE)",1,true) then
      source=Boxes.active(game.save)
    end
    if source then
      local index=math.max(1,math.min(state.index or 1,#source))
      return source[index]
    end
  end

  return nil
end

local function drawPCBackground(game,title,subtitle)
  local g=love.graphics
  -- One shared PC shell for both generations. The old cobalt donor card is
  -- deliberately gone; this is the same flat steel/green glass used by the
  -- standalone Colosseum service menus.
  drawColosseumRunoffPanel(2,3,156,135,18)
  g.setColor(0.006,0.028,0.031,0.84)
  g.polygon("fill",7,24,162,24,162,126,11,126,7,122)
  g.setColor(0.19,0.46,0.43,0.72)
  g.line(8,24,159,24)
  local headerTitle=title or "POKéMON PC"
  local titleSize=4.2
  local titleLimit=subtitle and 104 or 140
  while titleSize>2.8 and partyTextWidth(headerTitle,titleSize)>titleLimit do
    titleSize=titleSize-0.15
  end
  partyText(headerTitle,9,9,titleSize,{0.91,1.00,0.94,1},"left",titleLimit)

  if subtitle and subtitle~="" then
    local tw=partyTextWidth(subtitle,2.5)
    partyText(subtitle,151-tw,11,2.5,{0.49,0.86,0.69,1})
  end
end

local function drawPCGlassPanel(x,y,w,h,selected)
  local g=love.graphics
  g.setColor(selected and {0.055,0.27,0.24,0.96}
    or {0.008,0.047,0.051,0.84})
  roundedRect("fill",x,y,w,h,2.3)
  g.setColor(selected and {0.27,0.96,0.51,1}
    or {0.24,0.51,0.49,0.88})
  g.setLineWidth(selected and 1.45 or 0.9)
  roundedRect("line",x,y,w,h,2.3)
  if selected then
    g.setColor(1.00,0.36,0.16,1)
    g.polygon("fill",x+1,y+h*0.5,x-2,y+h*0.30,x-2,y+h*0.70)
  end
end

local function drawPCCompactIcon(game,mon,x,y,w,h,selected,blink)
  local useColosseumIcons=featureEnabled("colosseumIcons")
  if GoldCompat.ColosseumUI and GoldCompat.ColosseumUI.setIconsEnabled then
    pcall(GoldCompat.ColosseumUI.setIconsEnabled,useColosseumIcons)
  end
  local iconDrew=false
  if useColosseumIcons and GoldCompat.ColosseumUI
      and GoldCompat.ColosseumUI.drawPortrait then
    -- The supplied Colosseum portraits are intentionally tight head shots.
    -- A small inset keeps jaws/horns from touching compact PC row borders.
    local ok,drew=pcall(GoldCompat.ColosseumUI.drawPortrait,game,mon,
      x+1,y+0.75,w-2,h-1.5)
    iconDrew=ok and drew==true
  end
  if not iconDrew then
    PartyMenu.drawIcon(game,mon,x,y,selected,blink or 0)
  end
  return iconDrew
end

local function pcItemName(game,id)
  local def=game and game.data and game.data.items and game.data.items[id]
  local name=(def and def.name) or id or "ITEM"
  return GoldCompat.humanizeIdentifier(name):upper()
end

local function pcItemRowsFromMap(game,source,skipBadges)
  local rows={}
  for id,count in pairs(source or {}) do
    local n=tonumber(count) or 0
    if n>0 then
      local isBadge=false
      if skipBadges and BagInventory and type(BagInventory.isBadge)=="function" then
        local ok,value=pcall(BagInventory.isBadge,id)
        isBadge=ok and value==true
      end
      if not isBadge then
        local def=game and game.data and game.data.items and game.data.items[id]
        rows[#rows+1]={
          id=id, name=pcItemName(game,id), count=n,
          order=(def and tonumber(def.index)) or math.huge,
          description=def and def.description or nil,
        }
      end
    end
  end
  table.sort(rows,function(a,b)
    if a.order~=b.order then return a.order<b.order end
    if a.name~=b.name then return a.name<b.name end
    return tostring(a.id)<tostring(b.id)
  end)
  return rows
end

-- Item Storage must draw in the exact order the native selector is actually
-- navigating. Gen I's PlayerPC ListMenu sorts ids lexically, while the visual
-- inventory helper above sorts by item index; drawing the latter during a
-- transfer made the cursor appear to skip/jump over early rows. Rebuild the
-- visible pane from the authoritative menu rows whenever one exists.
local function pcItemRowsFromNativeList(game,items,source)
  local rows={}
  for _,item in ipairs(items or {}) do
    local id=item and (item.value or item.id)
    if id then
      local raw=source and source[id]
      local count=tonumber(raw)
      if not count and item.right then
        count=tonumber(tostring(item.right):match("(%d+)$"))
      end
      count=count or tonumber(item.count) or 1
      if count>0 then
        local def=game and game.data and game.data.items and game.data.items[id]
        rows[#rows+1]={
          id=id,
          name=pcItemName(game,id),
          count=count,
          order=(def and tonumber(def.index)) or math.huge,
          description=def and def.description or nil,
        }
      end
    end
  end
  return rows
end

local function pcItemRowsForState(game,state,mode,bagRows,pcRows,save)
  if not state then return bagRows,pcRows,nil end

  -- Gen I withdraw/deposit/toss are generic ListMenu states. Their item order
  -- is the selector order and therefore must also be the visual order.
  if state.__gen3uiPCItemList then
    if mode=="DEPOSIT" then
      bagRows=pcItemRowsFromNativeList(game,state.items,(save or {}).inventory)
    elseif mode=="WITHDRAW" or mode=="TOSS" then
      pcRows=pcItemRowsFromNativeList(game,state.items,(save or {}).pcItems)
    end
  end

  -- Gold DEPOSIT owns a native PACK chooser. Only the current pocket is
  -- actionable at a time, so show that pocket in the left pane instead of
  -- presenting unrelated rows that the current cursor cannot reach.
  local pocketLabel=nil
  if mode=="DEPOSIT" and state.pack then
    local pack=state.pack
    local nativeRows={}
    for _,row in ipairs(pack.rows or {}) do
      local id=row and (row.id or row.value)
      if id then
        nativeRows[#nativeRows+1]={
          id=id,
          name=pcItemName(game,id),
          count=tonumber(row.count) or tonumber((save or {}).inventory and (save or {}).inventory[id]) or 1,
          description=row.description,
        }
      end
    end
    bagRows=nativeRows
    if type(pack.pocket)=="function" then
      local ok,pocket=pcall(pack.pocket,pack)
      if ok and pocket then pocketLabel=tostring(pocket.label or pocket.id or "") end
    end
  end

  return bagRows,pcRows,pocketLabel
end

local function pcItemRowIndex(rows,id)
  if not id then return nil end
  for i,row in ipairs(rows or {}) do
    if row.id==id then return i end
  end
  return nil
end

local function pcItemStateMode(state)
  local explicit=tostring(state and state.__gen3uiPCItemMode or ""):upper()
  if explicit~="" then return explicit end
  local phase=tostring(state and state.phase or "menu"):upper()
  if phase=="WITHDRAW" or phase=="DEPOSIT" or phase=="TOSS" then return phase end
  return "MENU"
end

local function pcItemSelectedId(state,mode)
  if not state then return nil end
  if state.__gen3uiPCItemList then
    local item=state.items and state.items[state.index or 1]
    return item and (item.value or item.id) or nil
  end
  if mode=="DEPOSIT" and state.pack then
    local pack=state.pack
    local row=pack.rows and pack.rows[pack.index or 1]
    return row and (row.id or row.value) or nil
  end
  if (mode=="WITHDRAW" or mode=="TOSS") and state.rows then
    local row=state.rows[state.listIndex or 1]
    return row and (row.id or row.value) or nil
  end
  return nil
end

local function pcItemActionEntries(state)
  if not state then return nil end
  if state.__gen3uiPCItemRoot then return state.items end
  if type(state.entries)=="table" then return state.entries end
  -- Gen I's three transfer lists are separate ListMenu states. Recreate only
  -- their visual action rail here so moving deeper into Item Storage does not
  -- make the redesigned PC header disappear; the PlayerPC Menu underneath
  -- remains the authority for actual actions and callbacks.
  if state.__gen3uiPCItemList then
    return {
      { label="WITHDRAW ITEM" },
      { label="DEPOSIT ITEM" },
      { label="TOSS ITEM" },
      { label="LOG OFF" },
    }
  end
  return nil
end

local function pcItemFooterText(game,state,mode,selectedId)
  local function joinLines(lines)
    if type(lines)~="table" then return nil end
    local bits={}
    for _,line in ipairs(lines) do
      if line~=nil then bits[#bits+1]=GoldCompat.cleanPcText(tostring(line)) end
    end
    if #bits>0 then return table.concat(bits," "):gsub("%s+"," ") end
    return nil
  end

  -- Gen II owns quantity and toss-confirm prompts inside ItemPcMenu itself.
  -- Keep those prompts in the redesigned footer while the custom selector is
  -- on top, instead of falling back to the original bottom text window.
  local qtyPrompt=state and state.qtyState and joinLines(state.qtyState.prompt)
  if qtyPrompt then return qtyPrompt end
  local confirmPrompt=state and state.confirm and joinLines(state.confirm.prompt)
  if confirmPrompt then return confirmPrompt end

  local footer=state and state.footer
  if type(footer)=="table" then footer=table.concat(footer," ") end
  if footer and tostring(footer)~="" then
    return GoldCompat.cleanPcText(tostring(footer)):gsub("\n"," "):gsub("%s+"," ")
  end
  if state and state.message and state.message.pages then
    local page=state.message.pages[state.message.page or 1] or {}
    local message=joinLines(page)
    if message then return message end
  end
  local name=selectedId and pcItemName(game,selectedId) or nil
  if mode=="WITHDRAW" then return name and ("Withdraw "..name.."?") or "Choose an item to withdraw." end
  if mode=="DEPOSIT" then return name and ("Deposit "..name.."?") or "Choose an item from your BAG." end
  if mode=="TOSS" then return name and ("Toss "..name.."?") or "Choose a stored item to toss." end
  return "Choose an Item Storage action."
end

local function drawPCItemActionRail(state,mode)
  local entries=pcItemActionEntries(state)
  if not entries or #entries==0 then return end
  local G=love.graphics
  local x,y,w,h=6,17.2,148,11.2
  local gap=1.35
  local cellW=(w-gap*(#entries-1))/#entries
  local selectedIndex=state.index or 1

  for i,entry in ipairs(entries) do
    local cx=x+(i-1)*(cellW+gap)
    local label=tostring(entry.label or entry.id or "")
      :gsub("<PK><MN>","POKéMON"):gsub("#MON","POKéMON")
      :gsub(" ITEM$","")
    if label=="MAIL BOX" then label="MAIL" end
    local selected=(mode=="MENU" and i==selectedIndex)
      or (mode~="MENU" and label:upper():find(mode,1,true)~=nil)

    G.setColor(selected and {0.055,0.26,0.235,0.99} or {0.010,0.050,0.053,0.92})
    roundedRect("fill",cx,y,cellW,h,1.9)
    G.setColor(selected and {0.28,0.96,0.57,1} or {0.18,0.43,0.40,0.92})
    G.setLineWidth(selected and 1.35 or 0.9)
    roundedRect("line",cx,y,cellW,h,1.9)

    -- Keep selection geometry OUT of the label area.  A short orange marker
    -- on the lower edge reads clearly on mobile without covering any letters.
    if selected then
      G.setColor(1.00,0.35,0.16,1)
      roundedRect("fill",cx+cellW*0.34,y+h-1.25,cellW*0.32,1.0,0.45)
    end

    local size=2.18
    while size>1.55 and partyTextWidth(label,size)>cellW-4 do size=size-0.08 end
    partyText(label,cx+2,y+3.05,size,
      selected and {0.99,1.00,0.99,1} or {0.76,0.88,0.85,1},
      "center",cellW-4)
  end
end

local function pcItemVisualKind(game,row)
  local id=GoldCompat.humanizeIdentifier(row and row.id or ""):upper()
  local def=game and game.data and game.data.items and row and game.data.items[row.id]
  local pocket=def and tostring(def.pocket or ""):upper() or ""
  if (def and (def.machine or def.teaches or def.tmNumber))
      or id:match("^TM%d") or id:match("^HM%d") then
    return "machine"
  end
  local okBall,isBall=pcall(ItemEffects.isBall,row and row.id)
  if pocket=="BALL" or (okBall and isBall) or id:find("BALL",1,true) then
    return "ball"
  end
  if id:find("BERRY",1,true) then return "berry" end
  if id:find("POTION",1,true) or id:find("HEAL",1,true)
      or id:find("ANTIDOTE",1,true) or id:find("AWAKEN",1,true)
      or id:find("RESTORE",1,true) or id:find("REVIVE",1,true)
      or id:find("PARLYZ",1,true) or id:find("PARALY",1,true) then
    return "heal"
  end
  if id:find("X ATTACK",1,true) or id:find("X DEFEND",1,true)
      or id:find("X SPEED",1,true) or id:find("X SPECIAL",1,true)
      or id:find("DIRE HIT",1,true) or id:find("GUARD SPEC",1,true) then
    return "battle"
  end
  if pocket=="KEY_ITEM" or (def and def.keyItem) then return "key" end
  return "item"
end

-- Small, resolution-independent item pictograms.  They are deliberately
-- generic category marks rather than replacement item art, so Gen I and Gold
-- can share the same storage layout without assuming an external icon atlas.
local function drawPCItemIcon(game,row,cx,cy,r,selected)
  local G=love.graphics
  local kind=pcItemVisualKind(game,row)
  local edge=selected and {1.00,0.48,0.20,1} or {0.34,0.78,0.70,1}
  local face=selected and {0.98,0.74,0.31,0.96} or {0.31,0.62,0.58,0.96}
  local dark={0.02,0.08,0.085,1}
  G.setLineWidth(0.85)

  if kind=="ball" then
    G.setColor(face); G.circle("fill",cx,cy,r)
    G.setColor(edge); G.circle("line",cx,cy,r)
    G.line(cx-r,cy,cx+r,cy)
    G.setColor(dark); G.circle("fill",cx,cy,math.max(0.8,r*0.30))
    G.setColor(edge); G.circle("line",cx,cy,math.max(0.8,r*0.30))
  elseif kind=="heal" then
    G.setColor(face); roundedRect("fill",cx-r*0.68,cy-r*0.48,r*1.36,r*1.24,0.7)
    G.setColor(edge); roundedRect("line",cx-r*0.68,cy-r*0.48,r*1.36,r*1.24,0.7)
    G.rectangle("fill",cx-r*0.30,cy-r*0.85,r*0.60,r*0.35)
    G.setColor(dark)
    G.rectangle("fill",cx-0.40,cy-r*0.18,0.80,r*0.62)
    G.rectangle("fill",cx-r*0.31,cy+0.02,r*0.62,0.80)
  elseif kind=="berry" then
    G.setColor(face); G.circle("fill",cx-0.8,cy+0.5,r*0.72)
    G.circle("fill",cx+1.0,cy+0.7,r*0.62)
    G.setColor(edge); G.circle("line",cx-0.8,cy+0.5,r*0.72)
    G.setColor(face); G.polygon("fill",cx,cy-r*0.2,cx+r*0.75,cy-r*0.75,cx+r*0.15,cy-r*0.82)
  elseif kind=="machine" then
    G.setColor(face); roundedRect("fill",cx-r,cy-r*0.72,r*2,r*1.44,0.8)
    G.setColor(edge); roundedRect("line",cx-r,cy-r*0.72,r*2,r*1.44,0.8)
    G.setColor(dark); G.circle("fill",cx,cy,r*0.34)
    G.setColor(edge); G.circle("line",cx,cy,r*0.34)
  elseif kind=="key" then
    G.setColor(face); G.circle("line",cx-r*0.35,cy-r*0.20,r*0.48)
    G.setLineWidth(1.1); G.line(cx,cy,cx+r*0.90,cy+r*0.65)
    G.line(cx+r*0.55,cy+r*0.40,cx+r*0.88,cy+r*0.12)
  elseif kind=="battle" then
    G.setColor(face)
    G.polygon("fill",cx,cy-r,cx+r*0.82,cy-r*0.22,cx+r*0.52,cy+r,cx-r*0.52,cy+r,cx-r*0.82,cy-r*0.22)
    G.setColor(edge)
    G.polygon("line",cx,cy-r,cx+r*0.82,cy-r*0.22,cx+r*0.52,cy+r,cx-r*0.52,cy+r,cx-r*0.82,cy-r*0.22)
    G.line(cx-r*0.34,cy,cx+r*0.34,cy)
    G.line(cx,cy-r*0.34,cx,cy+r*0.34)
  else
    G.setColor(face); roundedRect("fill",cx-r*0.78,cy-r*0.78,r*1.56,r*1.56,0.8)
    G.setColor(edge); roundedRect("line",cx-r*0.78,cy-r*0.78,r*1.56,r*1.56,0.8)
    G.line(cx-r*0.46,cy,cx+r*0.46,cy)
  end
  G.setColor(1,1,1,1)
end

local function drawPCItemBagColumn(game,rows,selectedId,mode,pocketLabel)
  local G=love.graphics
  local x,y,w,h=6,29,61,95
  drawPCGlassPanel(x,y,w,h,false)

  partyText("BAG",x+5,y+4,2.95,{0.43,1.00,0.64,1})
  local countText=tostring(#rows).." STACKS"
  partyText(countText,x+w-5-partyTextWidth(countText,1.72),y+5.1,1.72,
    {0.58,0.80,0.75,1})

  local listTop=y+15
  local visible=8
  if mode=="DEPOSIT" and pocketLabel and pocketLabel~="" then
    local clean=tostring(pocketLabel):upper()
      :gsub("POKé BALLS","BALLS"):gsub("POKE BALLS","BALLS")
    partyText("<  "..clean.."  >",x+5,y+10.2,2.05,{0.92,1.00,0.95,1},"center",w-10)
    partyText("LEFT / RIGHT : POCKET",x+5,y+15.3,1.48,{0.53,0.78,0.73,1},"center",w-10)
    listTop=y+23
    visible=7
  end

  local selectedPos=pcItemRowIndex(rows,selectedId)
  local first=1
  if selectedPos and selectedPos>visible then first=selectedPos-visible+1 end
  if #rows>visible then first=math.min(first,#rows-visible+1) end
  local rowStep=(h-(listTop-y)-6)/math.max(1,visible)

  for r=1,visible do
    local idx=first+r-1
    local row=rows[idx]
    local yy=listTop+(r-1)*rowStep
    if row then
      local selected=(mode=="DEPOSIT" and row.id==selectedId)
      if selected then
        -- Dedicated cursor gutter: selection never occupies the item-name box.
        G.setColor(0.055,0.29,0.26,0.98)
        roundedRect("fill",x+3,yy-1,w-6,rowStep-0.9,1.6)
        G.setColor(0.25,0.80,0.68,0.78)
        roundedRect("line",x+3,yy-1,w-6,rowStep-0.9,1.6)
        G.setColor(1.00,0.35,0.16,1)
        G.polygon("fill",x+8,yy+rowStep*0.43,x+4.6,yy+rowStep*0.22,x+4.6,yy+rowStep*0.64)
      end

      local nameX=x+11
      local qty="×"..tostring(row.count)
      local qtySize=1.72
      local qtyW=partyTextWidth(qty,qtySize)
      local nameMax=x+w-6-qtyW-nameX-2
      local size=2.15
      while size>1.55 and partyTextWidth(row.name,size)>nameMax do size=size-0.08 end
      partyText(row.name,nameX,yy+1.0,size,
        selected and {0.99,1.00,0.99,1} or {0.80,0.91,0.88,1},"left",nameMax)
      partyText(qty,x+w-5-qtyW,yy+1.35,qtySize,
        selected and {1.00,0.88,0.43,1} or {0.60,0.82,0.76,1})
    end
  end

  if #rows==0 then
    partyText("EMPTY",x+5,y+50,2.7,{0.49,0.70,0.66,1},"center",w-10)
  end
  if first>1 then partyText("▲",x+w-8,listTop-1,1.65,{0.43,0.86,0.72,1}) end
  if first+visible-1<#rows then
    partyText("▼",x+w-8,y+h-8,1.65,{0.43,0.86,0.72,1})
  end
end

local function drawPCItemStorageBadges(game,rows,selectedId,mode)
  local x,y,w,h=70,29,84,95
  drawPCGlassPanel(x,y,w,h,false)
  partyText("PC STORAGE",x+5,y+4,2.90,{0.43,1.00,0.64,1})
  local countText=tostring(#rows).." / 50"
  partyText(countText,x+w-5-partyTextWidth(countText,1.72),y+5.1,1.72,
    {0.58,0.80,0.75,1})

  local selectedPos=pcItemRowIndex(rows,selectedId)
  local cols,visible=2,8
  local first=1
  if selectedPos then first=math.floor((selectedPos-1)/visible)*visible+1 end
  local gap=1.7
  local cellW=(w-7-gap*(cols-1))/cols
  local cellH=18.8

  for slot=1,visible do
    local idx=first+slot-1
    local row=rows[idx]
    local col=(slot-1)%cols
    local rr=math.floor((slot-1)/cols)
    local bx=x+3+col*(cellW+gap)
    local by=y+14+rr*(cellH+2)
    local selected=row and (mode=="WITHDRAW" or mode=="TOSS")
      and row.id==selectedId
    drawPCGlassPanel(bx,by,cellW,cellH,selected)

    if row then
      drawPCItemIcon(game,row,bx+6.6,by+9.3,3.5,selected)

      local qty="×"..tostring(row.count)
      local qtySize=1.58
      local qtyW=partyTextWidth(qty,qtySize)
      partyText(qty,bx+cellW-2.2-qtyW,by+1.4,qtySize,
        selected and {1.00,0.88,0.43,1} or {0.62,0.83,0.77,1})

      local nameX=bx+12.4
      local nameWidth=cellW-14.2
      local nameSize=1.86
      while nameSize>1.48 and partyTextWidth(row.name,nameSize)>nameWidth*1.72 do
        nameSize=nameSize-0.08
      end
      -- printf is allowed to use a second line for long names.  Two-column
      -- badges give the text enough room to stay readable instead of shrinking
      -- every stored item into the old three-column microtype.
      partyText(row.name,nameX,by+5.0,nameSize,
        selected and {0.99,1.00,0.99,1} or {0.82,0.92,0.89,1},
        "left",nameWidth)
    else
      partyText("—",bx+2,by+6.5,2.0,{0.28,0.51,0.49,0.52},"center",cellW-4)
    end
  end

  if first>1 then partyText("▲",x+w-8,y+12,1.65,{0.43,0.86,0.72,1}) end
  if first+visible-1<#rows then
    partyText("▼",x+w-8,y+h-8,1.65,{0.43,0.86,0.72,1})
  end
end

local function drawPCItemStorageFinal(game,state,suppressFooter)
  local ox,oy,sc=partyLogicalCanvas()
  local G=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  local save=(state and state.save) or (game and game.save) or {}
  local mode=pcItemStateMode(state)
  local selectedId=pcItemSelectedId(state,mode)
  local bagRows=pcItemRowsFromMap(game,save.inventory,true)
  local pcRows=pcItemRowsFromMap(game,save.pcItems,false)
  local totalBagStacks=#bagRows
  local pocketLabel
  bagRows,pcRows,pocketLabel=pcItemRowsForState(
    game,state,mode,bagRows,pcRows,save)

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  drawPCBackground(game,"ITEM STORAGE",
    ("BAG %d   PC %d"):format(totalBagStacks,#pcRows))
  drawPCItemActionRail(state,mode)
  drawPCItemBagColumn(game,bagRows,selectedId,mode,pocketLabel)
  drawPCItemStorageBadges(game,pcRows,selectedId,mode)

  if not suppressFooter then
    G.setColor(0.004,0.025,0.028,0.95)
    roundedRect("fill",6,126.5,148,10,2.5)
    G.setColor(0.22,0.51,0.48,0.90)
    roundedRect("line",6,126.5,148,10,2.5)
    local footer=pcItemFooterText(game,state,mode,selectedId)
    local size=2.10
    while size>1.55 and partyTextWidth(footer,size)>137 do size=size-0.1 end
    partyText(footer,9,128.7,size,{0.97,1.00,0.98,1},"left",137)
  end
  G.pop()
end

local function drawPCItemQuantityOverlay(qty)
  local ox,oy,sc=partyLogicalCanvas()
  local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  local x,y,w,h=58,92,44,25
  drawPCGlassPanel(x,y,w,h,true)
  partyText("HOW MANY?",x+7,y+5,2.15,{0.72,0.92,0.86,1})
  local value=("×%02d"):format(tonumber(qty and qty.qty) or 1)
  partyText(value,x+12,y+13,3.4,{0.99,1.00,0.98,1})
  G.pop()
end

local function drawPCItemChoiceOverlay(choice)
  local ox,oy,sc=partyLogicalCanvas()
  local G=love.graphics
  local index=(choice and (choice.index or choice.choice)) or 1
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  local x,y,w,h=113,88,39,31
  drawPCGlassPanel(x,y,w,h,false)
  for i,label in ipairs({"YES","NO"}) do
    local yy=y+5+(i-1)*11
    if i==index then drawColosseumRunoffSelection(x+4,yy-1,w-8,9) end
    partyText(label,x+11,yy+1,2.35,
      i==index and {0.99,1.00,0.98,1} or {0.65,0.82,0.77,1})
  end
  G.pop()
end

local function drawPCAccessFinal(game,state,suppressFooter)
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local items=state.items or {}
  local count=#items
  local w=69
  local rowH=math.min(11.5,86/math.max(1,count))
  local h=17+count*rowH
  local x=87
  local y=10
  drawColosseumRunoffPanel(x,y,w,h,12)
  g.setColor(0.006,0.028,0.031,0.87)
  g.polygon("fill",x+5,y+15,162,y+15,162,y+h-4,x+8,y+h-4,x+5,y+h-7)

  for i,item in ipairs(items) do
    local yy=y+17+(i-1)*rowH
    local selected=i==(state.index or 1)
    if selected then
      drawColosseumRunoffSelection(x+4,yy-3,w-8,10)
    end
    local label=tostring(item.label or "")
      :gsub("<PK><MN>","POKéMON"):gsub("#MON","POKéMON")
    partyText(label,x+10,yy,4,
      selected and {0.98,1.00,0.96,1} or {0.64,0.81,0.76,1})
  end

  partyText("PC ACCESS",x+10,y+5,2.8,{0.38,1.00,0.55,1})

  if not suppressFooter then
  local bx,by,bw,bh=8,111,144,25
  g.setColor(0.004,0.021,0.024,0.94)
  g.polygon("fill",bx+4,by,bx+bw,by,bx+bw+3,by+4,
    bx+bw,by+bh,bx+4,by+bh,bx,by+bh-4,bx,by+4)
  g.setColor(0.31,0.61,0.59,0.94)
  g.line(bx+5,by,bx+bw-1,by)
  g.line(bx+5,by+bh,bx+bw-1,by+bh)
  local prompt=tostring(state.prompt or "Access whose PC?")
    :gsub("<PK><MN>","POKéMON"):gsub("#MON","POKéMON")
  partyText(prompt,bx+7,by+7,3.5,{0.92,0.98,0.94,1},"left",bw-14)
  end

  g.pop()
end

local function drawPCMainFinal(game,state,suppressFooter)
  -- Gen I and Gen II deliberately share one PC root renderer. Only their
  -- native state/callback objects differ underneath this display facade.
  if GoldCompat.drawGoldPcRoot then
    return GoldCompat.drawGoldPcRoot({
      game=game,
      save=(state and state.save) or (game and game.save),
      entries=(state and (state.items or state.entries)) or {},
      index=(state and state.index) or 1,
      picking=state and state.picking,
      pickIndex=state and state.pickIndex,
      message=state and state.message,
      __colosseumSuppressFooter=suppressFooter,
    },suppressFooter)
  end
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local box=Boxes.active(game.save)
  drawPCBackground(game,"POKéMON PC",
    ("BOX %d   %d/%d"):format(game.save.currentBox or 1,#box,Boxes.CAPACITY))

  -- Left information panel mirrors the selected-Pokémon menu's visual frame.
  local lx,ly,lw,lh=4,23,72,96
  partySlotPanel(lx,ly,lw,lh,true)
  partyText("STORAGE",lx+7,ly+6,5,{0.06,0.06,0.06,1})
  partyText(("BOX %d"):format(game.save.currentBox or 1),lx+7,ly+18,6,
    {0.06,0.06,0.06,1})
  partyText(("%d / %d POKéMON"):format(#box,Boxes.CAPACITY),
    lx+7,ly+29,4,{0.18,0.18,0.16,1})
  partyText(("PARTY  %d / 6"):format(#(game.save.party or {})),
    lx+7,ly+37,4,{0.18,0.18,0.16,1})

  -- At-a-glance storage summary. The action list already exists on the right,
  -- so this space is more useful for persistent player/storage information.
  local seenCount=pokedexSeenCount(game.save)
  local ownedCount=pokedexOwnedCount(game.save)
  local pcTotal=GoldCompat.totalStoredPokemon(game.save)

  partyText("POKéDEX",lx+7,ly+52,3,{0.30,0.28,0.22,1})
  partyText(tostring(seenCount).." SEEN",lx+9,ly+59,4.4,{0.08,0.08,0.08,1})
  partyText(tostring(ownedCount).." OWNED",lx+36,ly+59,4.4,{0.08,0.08,0.08,1})

  partyText("TOTAL IN PC",lx+7,ly+72,3,{0.30,0.28,0.22,1})
  partyText(tostring(pcTotal).." POKéMON",lx+9,ly+79,5,{0.08,0.08,0.08,1})

  -- Right action list.
  local rx,ry,rw,rh=80,23,76,96
  partySlotPanel(rx,ry,rw,rh,false)
  local items=state.items or {}
  local rowH=13
  for i,item in ipairs(items) do
    local y=ry+5+(i-1)*rowH
    local selected=i==(state.index or 1)
    if selected then
      g.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",rx+4,y-1,rw-8,10,2)
      g.setColor(0.62,0.48,0.20,1)
      roundedRect("line",rx+5,y,rw-10,8,2)
    end
    local label=tostring(item.label or "")
      :gsub("<PK><MN>","POKéMON")
    partyText(label,rx+8,y,3,
      selected and {0.98,0.97,0.92,1} or {0.06,0.06,0.06,1})
  end

  -- Footer follows the same dark instruction strip as Party.
  if not suppressFooter then
    g.setColor(0.08,0.08,0.08,1)
    g.rectangle("fill",4,127,152,13)
    partyText("Choose a PC action.",9,129,4,{0.98,0.98,0.96,1})
  end

  g.pop()
end

local function drawPCListFinal(game,state,suppressFooter)
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local title=tostring(state.title or "POKéMON PC")
  drawPCBackground(game,title,
    ("BOX %d"):format(game.save.currentBox or 1))

  local mon=state.__colosseumPcSelected or GoldCompat.pcSelectedMon(game,state)
  local lx,ly,lw,lh=4,23,69,101
  partySlotPanel(lx,ly,lw,lh,true)

  if mon then
    local def=game.data.pokemon[mon.species]
    local name=mon.nickname or (def and def.name) or "POKéMON"
    partyText(name,lx+7,ly+5,6,{0.06,0.06,0.06,1})

    local lv="Lv."..tostring(mon.level or "?")
    local lvw=partyTextWidth(lv,5)
    partyText(lv,lx+lw-7-lvw,ly+6,5,{0.06,0.06,0.06,1})

    local drew=GoldCompat.drawCleanResolvedPortrait(
      game,mon,lx+8,ly+16,30,27,"pc")
    if not drew then
      PartyMenu.drawIcon(game,mon,lx+7,ly+19,true,state.blink or 0)
    end

    -- Box Pokémon can have incomplete stats; keep details defensive.
    local maxhp=mon.stats and mon.stats.hp
    if maxhp then
      local hp=("%d/%d"):format(mon.hp or 0,math.max(1,maxhp))
      local hpw=partyTextWidth(hp,4)
      local hpX=lx+lw-7-hpw
      partyText("HP",lx+9,ly+44,4,{0.08,0.08,0.08,1})
      partyHPBarFinal(lx+21,ly+45,math.max(18,hpX-(lx+21)-3),mon)
      partyText(hp,hpX,ly+44,4,{0.08,0.08,0.08,1})
    else
      partyText("STORED POKéMON",lx+9,ly+45,3,{0.28,0.28,0.24,1})
    end

    drawPartyDetails(game,mon,lx,ly,lw,lh)
  else
    partyText("NO POKéMON",lx+16,ly+46,5,{0.25,0.25,0.22,1})
  end

  -- Right storage/party list uses the Party slot language.
  local items=state.items or {}
  local rx,rw=77,79
  local selectedIndex=math.max(1,math.min(state.index or 1,math.max(1,#items)))

  -- The native ListMenu selection can move beyond the first six entries while
  -- some versions/mod stacks leave state.scroll unchanged. Derive the visible
  -- six-row window directly from the live selection so the right panel always
  -- scrolls with the cursor.
  local firstVisible=1
  if selectedIndex>6 then
    firstVisible=selectedIndex-5
  end
  if #items>6 then
    firstVisible=math.min(firstVisible,#items-5)
  end
  firstVisible=math.max(1,firstVisible)

  for row=1,6 do
    local itemIndex=firstVisible+row-1
    local item=items[itemIndex]
    local y=23+(row-1)*17
    if item then
      local selected=itemIndex==selectedIndex
      partySlotPanel(rx,y,rw,16,selected)
      local label=tostring(item.label or "")
      partyText(label,rx+7,y+3,3,
        {0.06,0.06,0.06,1},"left",rw-14)
    else
      partySlotPanel(rx,y,rw,16,false)
    end
  end

  if not suppressFooter then
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,127,152,13)
  local up=tostring(state.title or ""):upper()
  local footer="Choose a POKéMON."
  if up:find("WITHDRAW",1,true) then
    footer="Withdraw which POKéMON?"
  elseif up:find("DEPOSIT",1,true) then
    footer="Deposit which POKéMON?"
  elseif up:find("RELEASE",1,true) then
    footer="Release which POKéMON?"
  elseif up=="CHANGE BOX" then
    footer="Choose a BOX."
  end
  partyText(footer,9,129,4,{0.98,0.98,0.96,1},"left",142)
  end

  g.pop()
end

local function drawPCActionFinal(game,state,suppressFooter)
  -- Preserve the PC list underneath, then draw a compact themed action card.
  local under=nil
  if game and game.stack and game.stack.states then
    for i=#game.stack.states-1,1,-1 do
      local s=game.stack.states[i]
      if s and s.__gen3uiPCList then under=s break end
    end
  end
  if under then drawPCListFinal(game,under,suppressFooter) end

  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc
  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local x,y,w=105,74,48
  local items=state.items or {}
  local h=8+#items*12
  drawPCGlassPanel(x,y,w,h,false)
  for i,item in ipairs(items) do
    local yy=y+5+(i-1)*12
    local selected=i==(state.index or 1)
    if selected then
      drawColosseumRunoffSelection(x+3,yy-1,w-6,9)
    end
    partyText(tostring(item.label or ""),x+8,yy,3,
      selected and {0.98,1.00,0.96,1} or {0.65,0.82,0.77,1})
  end
  g.pop()
end

local drawPCListFinalLegacy=drawPCListFinal

local function drawPCBadgeListFinal(game,state,suppressFooter)
  local title=GoldCompat.cleanPcText(tostring(state.title or "POKéMON PC"))
    :gsub("<PK><MN>","POKéMON"):gsub("#MON","POKéMON")
  if title:upper()=="CHANGE BOX" then
    return drawPCListFinalLegacy(game,state,suppressFooter)
  end
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  drawPCBackground(game,title,("BOX %d"):format(game.save.currentBox or 1))

  local mon=state.__colosseumPcSelected or GoldCompat.pcSelectedMon(game,state)
  local lx,ly,lw,lh=6,25,51,100
  drawPCGlassPanel(lx,ly,lw,lh,false)
  if mon then
    local def=game.data.pokemon and game.data.pokemon[mon.species]
    local name=tostring(mon.nickname or (def and def.name) or "POKéMON")
    local nameSize=3.2
    while nameSize>2.0 and partyTextWidth(name,nameSize)>lw-27 do
      nameSize=nameSize-0.15
    end
    partyText(name,lx+5,ly+4,nameSize,{0.97,0.99,1.00,1},"left",lw-27)
    local lv="Lv."..tostring(mon.level or "?")
    partyText(lv,lx+lw-4-partyTextWidth(lv,2.4),ly+5,2.4,{0.98,0.84,0.35,1})

    g.setColor(0.01,0.04,0.07,0.72)
    roundedRect("fill",lx+5,ly+13,lw-10,27,3)
    g.setColor(0.34,0.69,0.78,0.86)
    roundedRect("line",lx+5,ly+13,lw-10,27,3)
    -- Resolve the user's installed front sprite, but remove the opaque white
    -- ROM matte before compositing it onto the glass inspector.
    g.pop()
    local drew=GoldCompat.drawCleanResolvedPortrait(game,mon,
      ox+(lx+8)*sc,oy+(ly+14)*sc,(lw-16)*sc,25*sc,"pc")
    g.push("all")
    g.translate(ox,oy)
    g.scale(sc,sc)
    if not drew then
      PartyMenu.drawIcon(game,mon,lx+17,ly+18,true,state.blink or 0)
    end

    local maxhp=tonumber(mon.maxHp) or (mon.stats and tonumber(mon.stats.hp))
    if maxhp and maxhp>0 then
      local hpNow=tonumber(mon.hp) or maxhp
      local hp=("%d/%d"):format(hpNow,maxhp)
      partyText("HP",lx+5,ly+43,2.2,{0.55,0.90,0.95,1})
      g.setColor(0.01,0.04,0.05,0.88)
      roundedRect("fill",lx+14,ly+44,lw-19,3,1.5)
      local ratio=math.max(0,math.min(1,hpNow/maxhp))
      local r,gg,b=hpColor(ratio)
      g.setColor(r,gg,b,1)
      roundedRect("fill",lx+15,ly+45,math.max(1,(lw-21)*ratio),1.2,0.6)
      partyText(hp,lx+lw-5-partyTextWidth(hp,2.0),ly+48,2.0,
        {0.90,0.97,0.98,1})
    end

    partyText("MOVES",lx+5,ly+56,2.0,{0.48,0.89,1.00,1})
    for i=1,4 do
      local move=mon.moves and mon.moves[i]
      local moveName=partyMoveName(game,move)
      local pp=partyMovePP(game,move)
      local yy=ly+61+(i-1)*6
      local size=2.15
      while size>1.5 and partyTextWidth(moveName,size)>lw-18 do size=size-0.12 end
      partyText(moveName,lx+6,yy,size,{0.94,0.97,0.96,1},"left",lw-18)
      if pp~="" then
        partyText(pp,lx+lw-5-partyTextWidth(pp,1.55),yy+1,1.55,
          {0.66,0.82,0.85,1})
      end
    end

    partyText("STATS",lx+5,ly+81.5,2.0,{0.40,0.96,0.60,1})
    local gen2Stats=GoldCompat.isGen2Game(game)
      or (mon.stats and mon.stats.specialDefense~=nil)
    local statRows
    if gen2Stats then
      statRows={
        {"ATK",partyStat(mon,"attack","atk"),"DEF",partyStat(mon,"defense","def")},
        {"SPA",partyStat(mon,"specialAttack","spAtk"),"SDF",partyStat(mon,"specialDefense","spDef")},
        {"SPD",partyStat(mon,"speed","spd"),nil,nil},
      }
    else
      statRows={
        {"ATK",partyStat(mon,"attack","atk"),"DEF",partyStat(mon,"defense","def")},
        {"SPD",partyStat(mon,"speed","spd"),"SPC",partyStat(mon,"special","spc","specialAttack")},
      }
    end
    for i,row in ipairs(statRows) do
      local yy=ly+86.5+(i-1)*4.8
      partyText(row[1].." "..tostring(row[2]),lx+6,yy,1.68,{0.91,0.97,0.94,1})
      if row[3] then
        local right=row[3].." "..tostring(row[4])
        partyText(right,lx+lw-5-partyTextWidth(right,1.68),yy,1.68,
          {0.91,0.97,0.94,1})
      end
    end
  else
    partyText("SELECT A",lx+12,ly+42,2.8,{0.72,0.90,0.94,1})
    partyText("BADGE",lx+15,ly+50,3.4,{0.96,0.99,1.00,1})
  end

  local items=state.items or {}
  local upperTitle=title:upper()
  local pcMode=tostring(state.__colosseumPcMode or ""):upper()
  local source=state.__colosseumPcSource or {}
  if not state.__colosseumPcSource and upperTitle=="PARTY (DEPOSIT)" then
    source=game.save and game.save.party or {}
  elseif not state.__colosseumPcSource and (upperTitle:find("(WITHDRAW)",1,true)
      or upperTitle:find("(RELEASE)",1,true)) then
    source=Boxes.active(game.save)
  end
  local selectedIndex=math.max(1,math.min(state.index or 1,math.max(1,#items)))
  local gridCount=math.min(20,#source)
  local gx,gy,gw,gh=60,25,94,100
  drawPCGlassPanel(gx,gy,gw,gh,false)
  local partyDeposit=(pcMode=="DEPOSIT"
    or upperTitle:find("DEPOSIT",1,true)~=nil) and #source<=6
  if partyDeposit then
    -- Party deposit is a six-member decision, not storage. Draw only real
    -- party members as horizontal records; unused PC-box cells disappear.
    local rowH=13.8
    local gap=1.55
    for idx,badgeMon in ipairs(source) do
      if idx>6 then break end
      local bx=gx+3
      local by=gy+3+(idx-1)*(rowH+gap)
      local bw=gw-6
      local selected=idx==selectedIndex
      drawPCGlassPanel(bx,by,bw,rowH,selected)
      drawPCCompactIcon(game,badgeMon,bx+2,by+1.2,12.5,11.2,
        selected,state.blink or 0)

      local badgeDef=game.data.pokemon and game.data.pokemon[badgeMon.species]
      local badgeName=tostring(badgeMon.nickname or (badgeDef and badgeDef.name) or "POKéMON")
      local nameSize=2.15
      while nameSize>1.45 and partyTextWidth(badgeName,nameSize)>35 do
        nameSize=nameSize-0.10
      end
      partyText(badgeName,bx+18,by+2,nameSize,{0.95,0.99,1.00,1},"left",35)
      local badgeLevel="Lv"..tostring(badgeMon.level or "?")
      partyText(badgeLevel,bx+56,by+2,1.75,{1.00,0.84,0.31,1})

      local maxhp=tonumber(badgeMon.maxHp)
        or (badgeMon.stats and tonumber(badgeMon.stats.hp))
      if maxhp and maxhp>0 then
        local hpNow=tonumber(badgeMon.hp) or maxhp
        local ratio=math.max(0,math.min(1,hpNow/maxhp))
        g.setColor(0.01,0.03,0.04,0.92)
        roundedRect("fill",bx+18,by+9,bw-43,2.4,1.2)
        local r,gg,b=hpColor(ratio)
        g.setColor(r,gg,b,1)
        roundedRect("fill",bx+18.5,by+9.5,math.max(1,(bw-44)*ratio),1.3,0.65)
        local hp=("%d/%d"):format(hpNow,maxhp)
        partyText(hp,bx+bw-3-partyTextWidth(hp,1.55),by+8.3,1.55,
          {0.82,0.94,0.96,1})
      end
    end
  else
  local cols,rows=4,5
  local gap=1.5
  local cellW=(gw-6-gap*(cols-1))/cols
  local cellH=(gh-6-gap*(rows-1))/rows
  for idx=1,cols*rows do
    local col=(idx-1)%cols
    local row=math.floor((idx-1)/cols)
    local bx=gx+3+col*(cellW+gap)
    local by=gy+3+row*(cellH+gap)
    local badgeMon=source[idx]
    local selected=idx==selectedIndex and idx<=gridCount
    drawPCGlassPanel(bx,by,cellW,cellH,selected)
    if badgeMon then
      local badgeDef=game.data.pokemon and game.data.pokemon[badgeMon.species]
      local badgeName=tostring(badgeMon.nickname or (badgeDef and badgeDef.name) or "POKéMON")
      -- Storage badges intentionally use the optional Colosseum icon pack.
      -- The large inspector above stays on the game's resolved front sprite.
      local useColosseumIcons=featureEnabled("colosseumIcons")
      if GoldCompat.ColosseumUI and GoldCompat.ColosseumUI.setIconsEnabled then
        pcall(GoldCompat.ColosseumUI.setIconsEnabled,useColosseumIcons)
      end
      local iconDrew=false
      if useColosseumIcons and GoldCompat.ColosseumUI
          and GoldCompat.ColosseumUI.drawPortrait then
        local ok,drew=pcall(GoldCompat.ColosseumUI.drawPortrait,
          game,badgeMon,bx+2,by+2,cellW-4,cellH-7)
        iconDrew=ok and drew==true
      end
      if not iconDrew then
        PartyMenu.drawIcon(game,badgeMon,bx+3,by+2,selected,state.blink or 0)
      end
      local badgeLevel="Lv"..tostring(badgeMon.level or "?")
      local levelSize=1.35
      local levelW=partyTextWidth(badgeLevel,levelSize)
      g.setColor(0.01,0.03,0.05,0.78)
      roundedRect("fill",bx+cellW-levelW-2.2,by+1.3,levelW+1.5,3.5,1)
      partyText(badgeLevel,bx+cellW-levelW-1.5,by+2,levelSize,
        {1.00,0.84,0.31,1})
      local badgeSize=1.65
      while badgeSize>1.15 and partyTextWidth(badgeName,badgeSize)>cellW-3 do
        badgeSize=badgeSize-0.10
      end
      partyText(badgeName,bx+1.5,by+cellH-4.2,badgeSize,
        {0.95,0.99,1.00,1},"center",cellW-3)
    else
      partyText("-",bx+(cellW-partyTextWidth("-",2))/2,by+cellH/2-2,2,
        {0.28,0.55,0.64,0.70})
    end
  end
  end

  local footer=state.__colosseumPcFooter or "Choose a POKéMON."
  if not suppressFooter then
  if pcMode=="WITHDRAW" or upperTitle:find("WITHDRAW",1,true) then
    footer="Withdraw which POKéMON?"
  elseif pcMode=="DEPOSIT" or upperTitle:find("DEPOSIT",1,true) then
    footer="Deposit which POKéMON?"
  elseif pcMode=="RELEASE" or upperTitle:find("RELEASE",1,true) then
    footer="Release which POKéMON?"
  elseif upperTitle=="CHANGE BOX" then
    footer="Choose a BOX."
  end
  footer=GoldCompat.cleanPcText(footer)
    :gsub("<PK><MN>","POKéMON"):gsub("#MON","POKéMON")
  local cancelSelected=selectedIndex>gridCount
  g.setColor(cancelSelected and {0.055,0.27,0.24,0.96}
    or {0.006,0.035,0.039,0.92})
  roundedRect("fill",6,127,148,9,2.5)
  g.setColor(cancelSelected and {0.27,0.96,0.51,1}
    or {0.25,0.57,0.54,0.9})
  roundedRect("line",6,127,148,9,2.5)
  partyText(footer,9,129,2.15,{0.96,0.99,1.00,1},"left",112)
  partyText(cancelSelected and "A: BACK" or "B: BACK",130,129,1.9,
    {0.77,0.92,0.96,1})
  end

  g.pop()
end

-- Keep every native PC action and passthrough intact; only swap the renderer.
drawPCListFinal=drawPCBadgeListFinal

local function drawPartyFinal(game, state)
  if featureEnabled("colosseumPokemonMenu") then
    return GoldCompat.drawColosseumParty(game,state)
  end

  local party = state.party or (game.save and game.save.party) or {}
  local ox,oy,sc = partyLogicalCanvas()
  local g = love.graphics

  -- Text helpers use these to escape the logical transform and render with
  -- battle-quality typography directly in final screen pixels.
  partyRenderOX, partyRenderOY, partyRenderScale = ox, oy, sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.94,0.93,0.87,1)
  g.rectangle("fill",0,0,160,144)

  -- Header
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,4,152,16)
  g.setColor(0.99,0.985,0.955,1)
  g.rectangle("fill",5,5,150,14)
  partyText(Strings("POKéMON"),10,6,6,{0.06,0.06,0.06,1})

  if #party == 0 then
    GoldCompat.owText(Strings("No POKéMON!"),12,62,10,{0.06,0.06,0.06,1})
    g.pop()
    return
  end

  local selected = clamp(state.index or 1,1,#party)
  local mon = party[selected]
  local def = mon and game.data.pokemon[mon.species]

  -- Large selected detail panel on left.
  local lx,ly,lw,lh = 4,23,74,101
  partySlotPanel(lx,ly,lw,lh,true)

  if mon then
    -- Large selected portrait uses the active FRONT battle sprite. The six
    -- party entries on the right intentionally remain standard menu icons.
    local drewBattlePortrait = GoldCompat.drawCleanResolvedPortrait(
      game, mon,
      lx+7, ly+15,
      31, 27,
      "summary"
    )
    if not drewBattlePortrait then
      -- Defensive fallback for a missing/invalid battle asset.
      PartyMenu.drawIcon(game,mon,lx+6,ly+18,true,state.blink or 0)
    end


    local name = mon.nickname or (def and def.name) or "POKéMON"
    partyText(name,lx+7,ly+5,6,{0.06,0.06,0.06,1})

    local lv = "Lv."..tostring(mon.level or "?")
    local lvw = partyTextWidth(lv,5)
    partyText(lv,lx+lw-7-lvw,ly+6,5,{0.06,0.06,0.06,1})

    -- HP mirrors the EXP row's visual rhythm, but reserves a right-side
    -- value slot so current/max HP stays on the same line as the bar.
    local hpY = ly + 43
    local hpLabelX = lx + 9
    local hpBarX = lx + 21

    local hp = ("%d/%d"):format(mon.hp or 0,
      math.max(1,mon.stats and mon.stats.hp or 1))
    local hpw = partyTextWidth(hp,4)
    local hpValueX = lx + lw - 7 - hpw
    local hpBarW = math.max(18, hpValueX - hpBarX - 3)

    partyText("HP",hpLabelX,hpY,4,{0.08,0.08,0.08,1})
    partyHPBarFinal(hpBarX,hpY+1,hpBarW,mon)
    partyText(hp,hpValueX,hpY,4,{0.08,0.08,0.08,1})

    local st = owStatus(mon)
    if st then
      partyText(st,lx+9,ly+51,4,
        st=="FNT" and {0.52,0.10,0.08,1} or {0.40,0.15,0.44,1})
    end

    -- Live Party EXP, matching the battle HUD's blue language.
    partyText("EXP",lx+9,ly+58,3,{0.34,0.45,0.50,1})
    GoldCompat.drawPartyExpBar(game,mon,lx+21,ly+59,lw-29)

    local integratedLearn = State.activeMoveLearn
    if state.__gen3uiGoldBattleMoveParty then
      integratedLearn=State.activeGoldBattleMoveLearn
    end
    local goldIntegrated=state.__gen3uiGoldBattleMoveParty
      and integratedLearn and integratedLearn.mon==mon
    local battleIntegrated =
      State.activeBattleMoveLearn
      and State.activeBattleMoveLearn.selecting
      and State.activeBattleMoveLearn.mon == mon
      and state.__gen3uiBattleMoveParty

    if battleIntegrated then
      integratedLearn=State.activeBattleMoveLearn
    end

    if integratedLearn and integratedLearn.selecting
        and integratedLearn.mon == mon
        and (goldIntegrated or battleIntegrated
          or canIntegrateMoveLearn(game, integratedLearn)) then
      GoldCompat.drawPartyMoveReplace(game,mon,lx,ly,lw,lh,integratedLearn)
    else
      drawPartyDetails(game,mon,lx,ly,lw,lh)
    end
  end

  -- All six Pokémon are always listed on the right, including the selected one.
  local rx,rw = 80,76
  local slotH,gap = 16,1
  for i,m in ipairs(party) do
    if i > 6 then break end
    local y = 23 + (i-1)*(slotH+gap)
    local isSelected = i == selected
    local d = game.data.pokemon[m.species]

    -- Selected row gets dark highlight, others stay light.
    if isSelected then
      g.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",rx,y,rw,slotH,3)
      g.setColor(0.985,0.975,0.92,1)
      roundedRect("fill",rx+2,y+2,rw-4,slotH-4,2)
      -- Party screen is intentionally theme-locked.
      g.setColor(0.62,0.48,0.20,1)
      roundedRect("line",rx+3,y+3,rw-6,slotH-6,2)
      g.setColor(1,1,1,1)
    else
      partySlotPanel(rx,y,rw,slotH,false)
    end

    PartyMenu.drawIcon(game,m,rx+2,y,false,state.blink or 0)

    local name = m.nickname or (d and d.name) or "POKéMON"
    partyText(name,rx+19,y+1,4,{0.06,0.06,0.06,1})

    local lv = "Lv."..tostring(m.level or "?")
    local lvw = partyTextWidth(lv,5)
    partyText(lv,rx+rw-4-lvw,y+1,4,{0.06,0.06,0.06,1})

    if state.tmhm then
      local canLearn = false
      local monDef = game.data.pokemon[m.species]
      for _,moveId in ipairs((monDef and monDef.tmhm) or {}) do
        if moveId == state.tmhm.move then
          canLearn = true
          break
        end
      end

      local ableText = canLearn and "ABLE" or "NOT ABLE"
      local ableW = partyTextWidth(ableText,3)
      partyText(ableText,rx+rw-5-ableW,y+8,3,
        canLearn and {0.16,0.42,0.20,1} or {0.46,0.14,0.12,1})

    elseif state.__gen3uiItemTarget and itemTargetIsStone(state) then
      local allowed=GoldCompat.stoneAllowedForMon(game,state,m)
      local allowedText=allowed and "ALLOWED" or "NOT ALLOWED"
      local allowedW=partyTextWidth(allowedText,3)
      partyText(allowedText,rx+rw-5-allowedW,y+8,3,
        allowed and {0.16,0.42,0.20,1} or {0.46,0.14,0.12,1})

    else
      partyText("HP",rx+19,y+8,3,{0.10,0.10,0.09,1})
      partyHPBarFinal(rx+31,y+10,rw-35,m)
    end
  end

  -- Bottom prompt.
  g.setColor(0.10,0.10,0.10,1)
  g.rectangle("fill",4,127,152,13)
  local prompt
  local promptLearn=state.__gen3uiGoldBattleMoveParty
      and State.activeGoldBattleMoveLearn or State.activeMoveLearn
  local promptIntegrated=promptLearn and promptLearn.selecting
      and canIntegrateMoveLearn(game,promptLearn)

  if state.__gen3uiGoldBattleMoveParty and promptLearn then
    promptIntegrated=true
  elseif state.__gen3uiBattleMoveParty
      and State.activeBattleMoveLearn
      and State.activeBattleMoveLearn.selecting then
    promptLearn=State.activeBattleMoveLearn
    promptIntegrated=true
  end

  if state.__gen3uiPPMoveParty and State.activePPMoveList then
    prompt = "Choose a move for the item."
  elseif promptLearn and promptIntegrated then
    local moveId = promptLearn.newMoveId
    local nd = moveId and game.data.moves[moveId] or nil
    local nn = (nd and nd.name)
      or GoldCompat.humanizeIdentifier(moveId or "MOVE")
    local moveCount = #(promptLearn.mon and promptLearn.mon.moves or {})
    if (promptLearn.index or 1) > moveCount then
      prompt = "CANCEL"
    else
      prompt = "Choose move to replace with "..nn.."."
    end
  elseif state.__gen3uiItemTarget and itemTargetIsStone(state) then
    prompt = "Use stone on which POKéMON?"
  elseif state.__gen3uiItemTarget then
    prompt = "Use item on which POKéMON?"
  else
    prompt = tostring(state:bottomMessage() or ""):gsub("\n"," ")
  end
  partyText(prompt,9,129,6,{1,1,1,1})

  -- Existing submenu.
  if state.submenu and state.subItems then
    local count=#state.subItems
    local sw=62
    local sh=math.min(66,6+count*12)
    local sx=160-sw-5
    local sy=math.max(5,124-sh)
    GoldCompat.frlgMenuPanel(sx,sy,sw,sh)

    for si,entry in ipairs(state.subItems) do
      local yy=sy+4+(si-1)*12
      if si==state.subIndex then
        GoldCompat.frlgSelection(sx+3,yy,sw-6,11)
        partyText(entry.label,sx+8,yy+1,6,{1,1,1,1})
      else
        partyText(entry.label,sx+8,yy+1,6,{0.06,0.06,0.06,1})
      end
    end
  end

  g.setColor(1,1,1,1)
  g.pop()
end

-- -------------------------------------------------------------------------

-- -------------------------------------------------------------------------
-- Final-HUD themed dialogue / choice overlay
-- -------------------------------------------------------------------------

function GoldCompat.dialogueVisibleText(box, shownIndex)
  local shown = box.shown and box.shown[shownIndex]
  if not shown then return "" end

  local page = box.pages and box.pages[box.pageIndex]
  if not page then return "" end

  local sourceIndex = box.lineIndex - (#box.shown - shownIndex)
  local source = page[sourceIndex] or ""
  local spans = EngineFont.split(source)

  local count = math.min(#shown, #spans)
  if count <= 0 then return "" end
  return source:sub(1, spans[count].to)
end


function GoldCompat.isGen1SavePromptBox(box)
  if GoldCompat.generation~="gen1" or not box then return false end
  local parts={}
  for _,page in ipairs(box.pages or {}) do
    for _,line in ipairs(page or {}) do parts[#parts+1]=tostring(line) end
  end
  local all=table.concat(parts," "):upper()
  if not all:find("SAVE",1,true) then return false end
  -- Gen1Recomp revisions phrase the summary differently (POKéDEX versus
  -- POKéMON, PLAY TIME versus TIME). Require SAVE plus two summary markers
  -- instead of one exact four-word fingerprint.
  local markers=0
  if all:find("BADGE",1,true) then markers=markers+1 end
  if all:find("POK",1,true) then markers=markers+1 end
  if all:find("TIME",1,true) then markers=markers+1 end
  if all:find("PLAYER",1,true) or all:find("NAME",1,true) then markers=markers+1 end
  return markers>=2
end

function GoldCompat.savePresentationStats(game,save,summary)
  save=save or (game and game.save) or {}
  local player=save.player or {}
  local dex=save.pokedex or {}
  local seen=GoldCompat.countTruthy and GoldCompat.countTruthy(dex.seen) or 0
  local caughtSet=dex.caught or dex.owned or {}
  local caught=summary and tonumber(summary.caught) or nil
  if caught==nil then
    caught=0
    for _,owned in pairs(caughtSet) do if owned then caught=caught+1 end end
  end
  if seen<caught then seen=caught end

  local badges=summary and tonumber(summary.badges) or nil
  if badges==nil and GoldCompat.generation=="gen2" then
    badges=GoldCompat.trainerBadgeCount and GoldCompat.trainerBadgeCount(player.badges)
      or 0
  elseif badges==nil then
    badges=0
    pcall(function()
      badges=require("src.inventory.Badges").count(game.data,save)
    end)
  end

  local play
  if summary and summary.hours~=nil then
    play=("%d:%02d"):format(summary.hours or 0,summary.minutes or 0)
  elseif type(save.playTime)=="table" then
    play=("%d:%02d"):format(save.playTime.hours or 0,save.playTime.minutes or 0)
  else
    local seconds=math.floor(tonumber(save.playTime) or 0)
    play=("%d:%02d"):format(math.floor(seconds/3600),math.floor(seconds/60)%60)
  end
  return {
    name=tostring((summary and summary.name) or player.name or save.name or "PLAYER"),
    play=play,seen=seen,caught=caught,badges=badges or 0,
  }
end

function GoldCompat.drawColosseumSavePanel(game,save,choice,summary,prompt)
  local stats=GoldCompat.savePresentationStats(game,save,summary)
  local ox,oy,sc=finalCanvas()
  local G=love.graphics
  local x,y,w,h=38,9,116,126

  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  -- Hanging cobalt console based on Colosseum's save terminal, with enough
  -- translucency to keep the active overworld visible behind it.
  G.setColor(0.00,0.01,0.04,0.42); roundedRect("fill",x+2,y+3,w,h,6)
  G.setColor(0.025,0.10,0.26,0.88); roundedRect("fill",x,y,w,h,6)
  G.setColor(0.10,0.32,0.72,0.55); roundedRect("fill",x+2,y+2,w-4,h-4,5)
  G.setColor(0.28,0.67,1.00,0.90); roundedRect("line",x,y,w,h,6)

  G.setColor(0.01,0.04,0.11,0.94)
  G.polygon("fill",x+4,y+4,x+72,y+4,x+78,y+10,x+72,y+17,x+4,y+17)
  G.setColor(0.26,0.68,1.00,0.95); G.rectangle("fill",x+6,y+18,w-12,1)

  -- Elliptical record display from the reference screen.
  G.setColor(0.015,0.055,0.20,0.82)
  G.ellipse("fill",x+82,y+69,27,41)
  G.setColor(0.18,0.40,0.82,0.84)
  G.ellipse("line",x+82,y+69,27,41)

  -- Dedicated YES/NO module; the native save state still owns confirmation.
  G.setColor(0.01,0.05,0.14,0.90); roundedRect("fill",x+7,y+61,39,38,4)
  G.setColor(0.24,0.60,0.92,0.95); roundedRect("line",x+7,y+61,39,38,4)
  for i=1,2 do
    local yy=y+68+(i-1)*14
    if tonumber(choice)==i then
      G.setColor(0.14,0.42,0.72,0.95); roundedRect("fill",x+11,yy-2,30,10,2)
      G.setColor(0.94,0.20,0.16,1)
      G.polygon("fill",x+10,yy+3,x+7,yy,x+7,yy+6)
    end
  end
  G.pop()

  finalText("SAVE",x+9,y+8,4.1,{0.30,0.72,1.00,1},ox,oy,sc)
  finalText(tostring(prompt or "Would you like to save your progress?"),
    x+8,y+25,2.45,{0.70,0.90,1.00,1},ox,oy,sc,"left",100)
  finalText("YES",x+17,y+69,3.1,tonumber(choice)==1 and {1,1,1,1}
    or {0.66,0.84,0.95,1},ox,oy,sc)
  finalText("NO",x+17,y+83,3.1,tonumber(choice)==2 and {1,1,1,1}
    or {0.66,0.84,0.95,1},ox,oy,sc)

  local rows={{"NAME",stats.name},{"PLAY TIME",stats.play},
    {"POKéDEX",stats.seen},{"POKéMON CAUGHT",stats.caught},
    {"BADGES",stats.badges}}
  for i,row in ipairs(rows) do
    local yy=y+38+(i-1)*13
    finalText(row[1],x+58,yy,1.75,{0.98,0.85,0.31,1},ox,oy,sc,"left",31)
    finalText(tostring(row[2]),x+88,yy,2.15,{0.54,0.82,1.00,1},
      ox,oy,sc,"right",16)
  end
  finalText("A  CONFIRM     B  CANCEL",x+9,y+115,1.85,
    {0.68,0.87,0.98,1},ox,oy,sc,"left",96)
  return true
end

function GoldCompat.drawGen1SavePrompt(box)
  local game=box and box.game
  local save=game and game.save
  if not save then return false end
  GoldCompat.__activeSavePromptBox=box
  return GoldCompat.drawColosseumSavePanel(game,save,nil,nil,
    "Would you like to save your progress?")
end

local function drawDialogueThemeLegacy(box)
  if featureEnabled("revampedSaveUI") and GoldCompat.isGen1SavePromptBox(box) then
    return GoldCompat.drawGen1SavePrompt(box)
  end
  local g = love.graphics
  local sw,sh = g.getDimensions()
  -- Match the centered, hanging battle-message geometry. This deliberately
  -- avoids stretching overworld dialogue from edge to edge on wide screens.
  local sc=clamp(math.min(sw/1280,sh/720),0.72,1.75)
  local widthScale,heightScale=GoldCompat.dialogueLayoutScale()
  local mobile=featureEnabled("mobileBattleUI")
  local portrait=sh>sw
  local margin=math.floor(22*sc+0.5)
  local targetW=(mobile
      and clamp(sw*(portrait and 0.82 or 0.46),260,portrait and 600 or 720)
      or clamp(820*sc,590,1180))*widthScale
  local targetH=(mobile
      and clamp(sh*(portrait and 0.082 or 0.088),68,108)
      or clamp(108*sc,82,165))*heightScale
  local w=math.floor(math.min(sw-margin*2,targetW)+0.5)
  local h=math.floor(math.min(sh-margin*2,targetH)+0.5)
  local x=math.floor((sw-w)*0.5+0.5)
  local y=math.floor((mobile and (sh-h)*0.5 or sh-h-margin)+0.5)

  g.push("all")
  g.origin()

  local colosseum=GoldCompat.colosseumPartyFlowActive(box and box.game)
    or featureEnabled("colosseumBattleUI")
  g.setColor(0.04,0.04,0.04,colosseum and 0.48 or 0.30)
  roundedRect("fill",x+3*sc,y+4*sc,w,h,13*sc)
  g.setColor(colosseum and {0.055,0.105,0.115,0.82} or {0.08,0.08,0.07,1})
  roundedRect("fill",x,y,w,h,13*sc)
  g.setColor(colosseum and {0.025,0.045,0.050,0.76} or {0.99,0.985,0.95,1})
  roundedRect("fill",x+4*sc,y+4*sc,w-8*sc,h-8*sc,10*sc)
  if colosseum then
    g.setColor(0.44,0.68,0.68,1)
    g.setLineWidth(math.max(2,2*sc))
    roundedRect("line",x+4*sc,y+4*sc,w-8*sc,h-8*sc,10*sc)
  else
    drawUnifiedBorder(x,y,w,h,0)
  end

  local off = box.scrollPx or 0
  local preferred=clamp(math.floor(16*sc+0.5),13,26)
  local minimum=math.max(10,math.floor(preferred*0.68+0.5))
  local textX=math.floor(x+30*sc+0.5)
  local contentW=math.max(1,math.floor(w-60*sc+0.5))
  local shown = box.shown or {}
  local visible = math.min(2,#shown)
  local texts = {}
  local sourceTexts={}
  local page=box.pages and box.pages[box.pageIndex]

  for i=1,visible do
    texts[i] = GoldCompat.dialogueVisibleText(box,i)
    local sourceIndex=(tonumber(box.lineIndex) or #shown)-(#shown-i)
    sourceTexts[i]=page and tostring(page[sourceIndex] or "") or texts[i]
  end

  local innerTop=math.max(8,math.floor(18*sc+0.5))
  local innerBottom=math.max(8,math.floor(18*sc+0.5))
  local innerH=math.max(1,h-innerTop-innerBottom)

  -- Size against the complete source while letters are revealing so the
  -- typewriter effect no longer shifts or resizes midway through a sentence.
  local pageComplete=box.waiting or box.done
  local pxSize,glyphH,lineH,blockH,drawLines
  if pageComplete then
    pxSize,glyphH,lineH,blockH,drawLines=GoldCompat.fittedCompletedDialogue(
      sourceTexts,preferred,minimum,contentW,innerH)
  else
    pxSize,glyphH,lineH,blockH=fittedDialogueMetrics(
      sourceTexts,preferred,minimum,contentW,innerH)
    drawLines=texts
  end
  visible=math.min(2,#drawLines)

  local firstY=y+innerTop+math.max(0,(innerH-blockH)*0.5)+off

  -- Same metric-driven layout as battle dialogue.
  g.setScissor(
    math.floor(x+22*sc),
    math.floor(y+innerTop-1),
    math.floor(w-44*sc),
    math.floor(innerH+2)
  )
  for i=1,visible do
    local ty=math.floor(firstY+(i-1)*lineH+0.5)
    printText(drawLines[i] or "",textX,ty,pxSize,
      colosseum and {0.88,0.90,0.82,1} or {0.04,0.04,0.04,1},
      "left",contentW)
  end
  g.setScissor()

  if (box.waiting or (box.done and not box.choice and not box.auto and not box.stay))
      and (box.blink or 0) < 30 then
    printText("▼",math.floor(x+w-34*sc),math.floor(y+h-25*sc),
      math.max(10,math.floor(12*sc+0.5)),
      colosseum and {0.98,0.34,0.18,1} or {0.10,0.10,0.09,1})
  end

  g.pop()
end

function GoldCompat.drawDialogueThemeFinal(box)
  if featureEnabled("revampedSaveUI") and GoldCompat.isGen1SavePromptBox(box) then
    return drawDialogueThemeLegacy(box)
  end

  local shared=GoldCompat.ColosseumUI and GoldCompat.ColosseumUI.drawDialogue
  if type(shared)~="function" then
    return drawDialogueThemeLegacy(box)
  end

  local shown=box and box.shown or {}
  local visible=math.min(2,#shown)
  local page=box and box.pages and box.pages[box.pageIndex]
  local complete=box and (box.waiting or box.done)
  local lines={}
  for i=1,visible do
    local revealed=GoldCompat.dialogueVisibleText(box,i)
    local sourceIndex=(tonumber(box.lineIndex) or #shown)-(#shown-i)
    local source=page and tostring(page[sourceIndex] or "") or revealed
    source=source:gsub("\v","")
    lines[i]=complete and source or revealed
  end
  if #lines==0 then lines[1]="" end

  local waiting=box and (box.waiting
    or (box.done and not box.choice and not box.auto and not box.stay))
  return shared(lines,waiting,box and box.blink or 0)
end

local function safeFooterText(text,lx,ly,size,color,ox,oy,sc,maxWidth)
  local drawSize=size
  local width=maxWidth or (160-lx-8)

  -- Footer legends are strictly single-line controls. Fit the font to the
  -- available logical width first, then draw WITHOUT a wrap width. Passing
  -- width into finalText caused long prompts such as A: CATCH LOCATIONS to
  -- wrap a second line into the 8px footer and overprint themselves.
  while drawSize>1.45 and finalTextWidth(text,drawSize,sc)>width do
    drawSize=drawSize-0.10
  end
  finalText(text,lx,ly,drawSize,color,ox,oy,sc)
end

-- -------------------------------------------------------------------------
-- Native SummaryMenu presentation.
-- SummaryMenu remains the owning state: its update/page/close behavior is
-- untouched. We only replace its draw surface while the Pokémon UI is enabled.
-- -------------------------------------------------------------------------

function DexUI.drawPartySummary(game, state)
  if not (game and state and state.mon) then return end

  if state.__colosseumMoveManager
      and GoldCompat.moveManagerPresentationEnabled() then
    return GoldCompat.drawGoldMoveManager(state)
  end

  if featureEnabled("colosseumPokemonMenu") then
    return GoldCompat.drawColosseumSummary(game,state)
  end

  local mon = state.mon
  local def = game.data and game.data.pokemon and game.data.pokemon[mon.species]
  if not def then return end

  local page = state.page or 1
  local ox,oy,sc = safeFullCanvas()
  local g = love.graphics

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.94,0.93,0.87,1)
  g.rectangle("fill",0,0,160,144)

  -- Header.
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,4,152,17)
  g.setColor(0.99,0.985,0.955,1)
  g.rectangle("fill",5,5,150,15)

  -- Main cards.
  g.setColor(0.12,0.12,0.11,1)
  roundedRect("fill",4,25,65,103,3)
  roundedRect("fill",72,25,84,103,3)
  g.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",6,27,61,99,2)
  roundedRect("fill",74,27,80,99,2)

  setCurrentBorderColor(1)
  roundedRect("line",7,28,59,97,2)
  roundedRect("line",75,28,78,97,2)

  -- Footer.
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,132,152,8)
  g.pop()

  finalText(page == 1 and "POKéMON STATS" or "POKéMON MOVES",
    9,8,4.8,{0.06,0.06,0.06,1},ox,oy,sc)

  local name = mon.nickname or def.name or "POKéMON"
  finalText(name,10,31,4.4,{0.07,0.07,0.07,1},ox,oy,sc,"left",52)
  finalText("Lv."..tostring(mon.level or "?"),10,39,3.2,
    {0.20,0.20,0.18,1},ox,oy,sc)

  -- Keep the same active sprite-source resolver used by Party/PC/Pokédex.
  g.push("all")
  g.origin()
  pcall(GoldCompat.drawCleanResolvedPortrait,game,mon,
    ox+13*sc,oy+48*sc,47*sc,39*sc,"summary")
  g.pop()

  finalText(("#%03d"):format(tonumber(def.dex) or 0),10,91,3.25,
    {0.36,0.36,0.33,1},ox,oy,sc)

  local TypeChart = require("src.battle.TypeChart")

  local function evolutionRows()
    local rows={}
    local methods=(game.data and game.data.evolution_methods) or Evolution.METHODS or {}
    for _,evo in ipairs(def.evolutions or {}) do
      local target=game.data and game.data.pokemon and game.data.pokemon[evo.species]
      local targetName=(target and target.name) or tostring(evo.species or "?")
      local method=methods[evo.method]
      local how

      if method and type(method.describe)=="function" then
        local ok,value=pcall(method.describe,evo,game.data)
        if ok and value and tostring(value)~="" then
          how=tostring(value)
        end
      end

      if not how then
        if evo.level then
          how="Level "..tostring(evo.level)
        elseif evo.item then
          local item=game.data and game.data.items and game.data.items[evo.item]
          how=(item and item.name) or tostring(evo.item)
        elseif tostring(evo.method or ""):upper()=="TRADE" then
          how="Trade"
        else
          how=tostring(evo.method or "Special")
        end
      end

      rows[#rows+1]={name=targetName,how=how}
    end
    return rows
  end

  local types={}
  for _,t in ipairs(def.types or {}) do
    types[#types+1]=TypeChart.displayName(t)
  end
  finalText(#types>0 and table.concat(types," / ") or "N/A",
    10,98,3.15,{0.12,0.12,0.11,1},ox,oy,sc,"left",52)

  local status = mon.status or "OK"
  finalText("STATUS",10,106,2.75,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(tostring(status),10,111,3.25,
    status=="OK" and {0.16,0.42,0.20,1} or {0.44,0.14,0.36,1},
    ox,oy,sc)

  if page == 1 then

    -- Compact identity block: information complementary to the main Party card.
    local entry=def.dexEntry or {}
    finalText("SPECIES",79,31,2.85,{0.40,0.40,0.37,1},ox,oy,sc)
    finalText(tostring(entry.kind or "N/A"):upper(),79,36,3.25,
      {0.08,0.08,0.08,1},ox,oy,sc,"left",35)

    -- Evolution summary sits opposite SPECIES in the upper-right corner.
    local evos=evolutionRows()
    finalText("EVOLUTION",116,31,2.85,{0.40,0.40,0.37,1},ox,oy,sc)
    if #evos==0 then
      finalText("NONE",116,36,3.0,{0.28,0.28,0.26,1},ox,oy,sc)
    else
      local row=evos[1]
      finalText(row.name,116,36,2.95,{0.08,0.08,0.08,1},ox,oy,sc,"left",34)
      finalText(row.how,116,41,2.55,{0.30,0.30,0.28,1},ox,oy,sc,"left",34)
      if #evos>1 then
        finalText((" +%d BRANCH"):format(#evos-1),116,46,2.0,
          {0.36,0.36,0.33,1},ox,oy,sc,"left",34)
      end
    end

    if DexUI.heightLabel and DexUI.weightLabel then
      finalText("HT",79,49,2.7,{0.40,0.40,0.37,1},ox,oy,sc)
      finalText(DexUI.heightLabel(def),91,49,3.05,
        {0.08,0.08,0.08,1},ox,oy,sc)
      finalText("WT",116,49,2.7,{0.40,0.40,0.37,1},ox,oy,sc)
      finalText(DexUI.weightLabel(def),128,49,3.05,
        {0.08,0.08,0.08,1},ox,oy,sc,"left",23)
    end

    -- Live stats: deliberately compact because the main Party screen already
    -- exposes the detailed stat block. Values are laid out explicitly instead
    -- with explicit placement so values remain readable.
    local stats=mon.stats or {}
    finalText("STATS",79,59,2.75,{0.40,0.40,0.37,1},ox,oy,sc)

    local statPairs={
      {"HP",stats.hp or 0, "ATK",stats.attack or 0},
      {"DEF",stats.defense or 0, "SPD",stats.speed or 0},
      {"SPC",stats.special or 0, nil,nil},
    }
    for i,row in ipairs(statPairs) do
      local yy=64+(i-1)*6
      finalText(row[1],79,yy,2.55,{0.30,0.30,0.28,1},ox,oy,sc)
      finalText(tostring(row[2]),93,yy,2.75,{0.08,0.08,0.08,1},ox,oy,sc)
      if row[3] then
        finalText(row[3],114,yy,2.55,{0.30,0.30,0.28,1},ox,oy,sc)
        finalText(tostring(row[4]),132,yy,2.75,{0.08,0.08,0.08,1},ox,oy,sc)
      end
    end

    -- Species level-up learnset. Gen1 species definitions expose level-1 moves
    -- separately from the ordered {level, move} learnset, so merge both while
    -- avoiding duplicate move IDs. Two columns use the available panel width
    -- without sacrificing readability.
    finalText("LEVEL-UP MOVES",79,83,2.8,{0.40,0.40,0.37,1},ox,oy,sc)

    local learned={}
    local seenMoves={}
    for _,moveId in ipairs(def.level1Moves or {}) do
      if moveId and not seenMoves[moveId] then
        learned[#learned+1]={level=1,move=moveId}
        seenMoves[moveId]=true
      end
    end
    for _,learn in ipairs(def.learnset or {}) do
      if learn and learn.move and not seenMoves[learn.move] then
        learned[#learned+1]={level=tonumber(learn.level) or 1,move=learn.move}
        seenMoves[learn.move]=true
      end
    end
    table.sort(learned,function(a,b)
      if a.level==b.level then return tostring(a.move)<tostring(b.move) end
      return a.level<b.level
    end)

    local rowsPerColumn=7
    local maxShown=rowsPerColumn*2
    for i=1,math.min(maxShown,#learned) do
      local item=learned[i]
      local col=(i-1)>=rowsPerColumn and 1 or 0
      local row=(i-1)%rowsPerColumn
      local xx=80+col*36
      local yy=89+row*5.35
      local md=game.data.moves and game.data.moves[item.move]
      local moveName=(md and md.name) or GoldCompat.humanizeIdentifier(item.move)
      finalText(("L%02d"):format(item.level),xx,yy,2.35,
        {0.36,0.36,0.33,1},ox,oy,sc)
      finalText(moveName,xx+11,yy,2.35,
        {0.08,0.08,0.08,1},ox,oy,sc,"left",26)
    end

    if #learned>maxShown then
      finalText((" +%d MORE"):format(#learned-maxShown),115,124,2.1,
        {0.36,0.36,0.33,1},ox,oy,sc,"left",31)
    end

    finalText("A / B: MOVES",9,134,2.6,{0.96,0.95,0.90,1},ox,oy,sc)
  else
    finalText("CURRENT MOVES",80,31,3.0,{0.40,0.40,0.37,1},ox,oy,sc)

    local moves=mon.moves or {}
    if #moves==0 then
      finalText("NO MOVES",79,43,3.4,{0.36,0.36,0.33,1},ox,oy,sc)
    else
      for i=1,math.min(4,#moves) do
        local mv=moves[i]
        local md=game.data.moves and game.data.moves[mv.id]
        local y=38+(i-1)*21.5

        g.push("all")
        g.translate(ox,oy)
        g.scale(sc,sc)
        g.setColor(0.12,0.12,0.11,1)
        roundedRect("fill",78,y,70,19,2)
        g.setColor(0.985,0.975,0.93,1)
        roundedRect("fill",79,y+1,68,17,2)
        g.pop()

        finalText(md and md.name or GoldCompat.humanizeIdentifier(mv.id or "MOVE"),
          82,y+3,3.35,{0.07,0.07,0.07,1},ox,oy,sc,"left",40)

        local pp=tonumber(mv.pp) or 0
        local maxpp=tonumber(md and md.pp) or pp
        -- Right edge is logical x=145. finalText's width extends to the
        -- right from its x coordinate, so start the field at 122 rather than
        -- 145 to keep PP completely inside the 148-wide move card.
        finalText(("PP %d/%d"):format(pp,maxpp),
          121,y+3,3.1,{0.20,0.20,0.18,1},ox,oy,sc,"right",23)

        local typeName=GoldCompat.moveTypeName(md)
        finalText(typeName,82,y+10,2.55,{0.34,0.34,0.31,1},ox,oy,sc,"left",22)

        local power=md and tonumber(md.power)
        local accuracy=md and tonumber(md.accuracy)
        local powerText=(power and power>0) and ("PWR "..tostring(power)) or "STATUS"
        local accText=(accuracy and accuracy>0) and ("ACC "..tostring(accuracy)) or ""
        finalText(powerText,104,y+10,2.35,{0.34,0.34,0.31,1},
          ox,oy,sc,"left",21)
        finalText(accText,126,y+10,2.35,{0.34,0.34,0.31,1},
          ox,oy,sc,"left",18)
      end
    end

    local nextExp=0
    if mon.level and mon.level<100 and mon.exp then
      nextExp=math.max(0,Growth.expForLevel(def.growthRate,mon.level+1)-mon.exp)
    end

    -- Large summary EXP treatment: keep the bar clearly above the values and
    -- away from the cyan card border.
    local expRatio=0
    if mon.level and mon.level<100 and mon.exp then
      local curFloor=Growth.expForLevel(def.growthRate,mon.level)
      local nextFloor=Growth.expForLevel(def.growthRate,mon.level+1)
      local span=math.max(1,nextFloor-curFloor)
      expRatio=math.max(0,math.min(1,(mon.exp-curFloor)/span))
    elseif mon.level and mon.level>=100 then
      expRatio=1
    end

    g.push("all")
    g.origin()
    local ex=ox+11*sc
    local ey=oy+116.0*sc
    local ew=50*sc
    local eh=2.8*sc
    g.setColor(0.10,0.16,0.18,1)
    roundedRect("fill",ex,ey,ew,eh,eh*0.48)
    local inset=0.65*sc
    g.setColor(0.12,0.50,0.86,1)
    roundedRect("fill",ex+inset,ey+inset,
      math.max(0,(ew-inset*2)*expRatio),math.max(0,eh-inset*2),
      math.max(0.5*sc,(eh-inset*2)*0.45))
    g.pop()

    finalText("EXP",11,120.5,2.65,{0.34,0.45,0.50,1},ox,oy,sc)
    finalText(tostring(mon.exp or 0),25,120.5,2.85,{0.08,0.08,0.08,1},ox,oy,sc)
    finalText("NEXT",43,120.5,2.65,{0.40,0.40,0.37,1},ox,oy,sc)
    finalText(tostring(nextExp),59,120.5,2.85,{0.08,0.08,0.08,1},ox,oy,sc)

    finalText("A / B: BACK",9,134,2.6,{0.96,0.95,0.90,1},ox,oy,sc)
  end
end


-- -------------------------------------------------------------------------
-- Pokédex presentation.
-- Namespaced deliberately: main.lua is close to Lua's 200-local chunk limit.
-- -------------------------------------------------------------------------

function DexUI.buildIndex(game)
  local out={}
  for species,def in pairs((game and game.data and game.data.pokemon) or {}) do
    local n=def and tonumber(def.dex)
    if n then
      out[n]={id=def.id or species,def=def}
    end
  end
  return out
end

function DexUI.locationName(game,mapId)
  local maps=game and game.data and game.data.maps
  local def=maps and maps[mapId]
  if type(def)=="table" then
    local name=def.name or def.label or def.displayName
    if name and tostring(name)~="" then return tostring(name) end
  end

  local field=game and game.data and game.data.field
  local townMap=field and field.townMap
  if type(townMap)=="table" then
    local locations=townMap.locations or townMap
    local e=type(locations)=="table" and locations[mapId]
    if type(e)=="table" then
      local name=e.name or e.label
      if name and tostring(name)~="" then return tostring(name) end
    end
  end

  return tostring(mapId or "N/A"):gsub("_"," ")
end


function DexUI.speciesLabel(def)
  local e=def and def.dexEntry
  local value=e and e.kind
  if value and tostring(value)~="" then
    return tostring(value):upper()
  end
  return "N/A"
end

function DexUI.heightLabel(def)
  local e=def and def.dexEntry
  if not e then return "N/A" end

  -- Match Gen1Recomp's native DexEntryMenu exactly.
  if e.heightM then
    return ("%.1f m"):format(e.heightM)
  end

  if e.heightFt then
    return ("%d' %02d\""):format(e.heightFt,e.heightIn or 0)
  end

  -- Gold stores the native four printed digits directly (e.g. 0108 = 1'08").
  if e.gen2Height~=nil then
    local raw=math.max(0,tonumber(e.gen2Height) or 0)
    local feet=math.floor(raw/100)
    local inches=raw%100
    return ("%d' %02d\""):format(feet,inches)
  end

  return "N/A"
end

function DexUI.weightLabel(def)
  local e=def and def.dexEntry
  if not e then return "N/A" end

  -- Match Gen1Recomp's native DexEntryMenu exactly.
  if e.heightM then
    return ("%.1f kg"):format(e.weightKg or 0)
  end

  if e.weight~=nil then
    return ("%.1f lb"):format((e.weight or 0)/10)
  end

  if e.gen2Weight~=nil then
    return ("%.1f lb"):format((tonumber(e.gen2Weight) or 0)/10)
  end

  return "N/A"
end

function DexUI.methodName(key,group)
  local raw=tostring(
    (type(group)=="table" and (group.method or group.type or group.name))
      or key or ""
  ):upper():gsub("_"," ")

  if raw:find("OLD",1,true) and raw:find("ROD",1,true) then return "OLD ROD" end
  if raw:find("GOOD",1,true) and raw:find("ROD",1,true) then return "GOOD ROD" end
  if raw:find("SUPER",1,true) and raw:find("ROD",1,true) then return "SUPER ROD" end
  if raw:find("SURF",1,true) or raw:find("WATER",1,true) then return "SURF" end
  if raw:find("GRASS",1,true) or raw:find("LAND",1,true)
      or raw:find("CAVE",1,true) or raw:find("WALK",1,true) then
    return "GRASS"
  end
  if raw:find("FISH",1,true) or raw:find("ROD",1,true) then return "FISHING" end
  return raw~="" and raw or "WILD"
end

function GoldCompat.dexEncounterRows(menu,speciesId)
  if not (menu and speciesId) then return {} end

  local data=menu.data or (menu.game and menu.game.data) or {}
  local save=menu.save or (menu.game and menu.game.save)
  local enc=data.gen2Encounters or data.encounters or {}
  local okNests,Nests=pcall(require,"src.core.gen2.Nests")

  local out={}
  local seen={}

  local function cleanName(name)
    name=tostring(name or ""):gsub("\n"," "):gsub("\\n"," "):gsub("%s+"," ")
    return name:gsub("^%s+",""):gsub("%s+$","")
  end

  local function mapLabel(mapId)
    local map=(data.maps and data.maps[mapId])
      or (data.gen2Maps and data.gen2Maps[mapId])
    if not map then return cleanName(mapId) end

    -- Prefer the same landmark registry Gold's AREA/Pokégear code uses.
    if okNests and Nests and type(Nests.landmark)=="function" and map.landmark then
      local ok,mark=pcall(Nests.landmark,data,map.landmark)
      if ok and mark and mark.name then return cleanName(mark.name) end
    end
    return cleanName(map.label or map.name or mapId)
  end

  local function add(mapId,method)
    if not mapId then return end
    local area=mapLabel(mapId)
    if area=="" then return end
    local token=tostring(mapId).."|"..tostring(method or "WILD")
    if seen[token] then return end
    seen[token]=true
    out[#out+1]={area=area,method=method or "WILD",map=mapId}
  end

  local function slotListHas(list)
    if type(list)~="table" then return false end
    for _,slot in ipairs(list) do
      if type(slot)=="table" and slot.species==speciesId then return true end
    end
    return false
  end

  local function encounterRowHas(row)
    if type(row)~="table" then return false end
    local slots=row.slots
    if type(slots)~="table" then return false end

    -- Water is a flat slot list; grass is a MORN/DAY/NITE map of lists.
    if slotListHas(slots) then return true end
    for _,list in pairs(slots) do
      if slotListHas(list) then return true end
    end
    return false
  end

  -- Gold's merged Gen 2 encounter registry lives at gen2Encounters.
  -- Read all map-keyed grass/water sources directly rather than depending on
  -- the native Nests helper's legacy data.encounters path.
  for _,kind in ipairs({
    {"grass","GRASS"},
    {"swarmGrass","SWARM"},
    {"water","SURF"},
    {"swarmWater","SWARM"},
  }) do
    for mapId,row in pairs(enc[kind[1]] or {}) do
      if encounterRowHas(row) then add(mapId,kind[2]) end
    end
  end

  -- Headbutt / Rock Smash are map -> set indirections.
  local treeSets=enc.treeSets or {}
  local function setHas(setId)
    local set=treeSets[setId]
    if type(set)~="table" then return false end
    return slotListHas(set.common) or slotListHas(set.rare)
  end
  for mapId,setId in pairs(enc.trees or {}) do
    if setHas(setId) then add(mapId,"HEADBUTT") end
  end
  for mapId,setId in pairs(enc.rocks or {}) do
    if setHas(setId) then add(mapId,"ROCK SMASH") end
  end

  -- Bug Contest has one canonical location.
  for _,slot in ipairs(enc.bugContest or {}) do
    if type(slot)=="table" and slot.species==speciesId then
      local contestMap=(data.maps and data.maps.NATIONAL_PARK
        and "NATIONAL_PARK") or "NATIONAL_PARK"
      add(contestMap,"BUG CONTEST")
      break
    end
  end

  -- Fishing groups are indirect. Gold datasets can expose the group on the map
  -- under different extractor-era keys, so accept the known presentation keys.
  local matchingFish={}
  for groupId,group in pairs(enc.fishGroups or {}) do
    if type(group)=="table" then
      for _,rod in ipairs({"old","good","super"}) do
        if slotListHas(group[rod]) then matchingFish[groupId]=rod:upper() end
      end
    end
  end
  if next(matchingFish) then
    local maps=data.maps or data.gen2Maps or {}
    for mapId,map in pairs(maps) do
      if type(map)=="table" then
        local gid=map.fishGroup or map.fishingGroup or map.fish
          or map.fishGroupId or map.fishing
        if gid and matchingFish[gid] then
          add(mapId,matchingFish[gid].." ROD")
        end
      end
    end
  end

  -- Roamers: preserve Gold's current-map behavior.
  if okNests and Nests and type(Nests.find)=="function" then
    local ok,found=pcall(Nests.find,data,speciesId,nil,save)
    if ok and type(found)=="table" then
      for _,landmark in ipairs(found) do
        local mark=type(Nests.landmark)=="function" and Nests.landmark(data,landmark)
        local area=mark and cleanName(mark.name)
        if area and area~="" then
          local token="LANDMARK|"..tostring(landmark)
          if not seen[token] then
            seen[token]=true
            out[#out+1]={area=area,method="WILD",landmark=landmark}
          end
        end
      end
    end
  end

  table.sort(out,function(a,b)
    if a.area==b.area then return tostring(a.method)<tostring(b.method) end
    return tostring(a.area)<tostring(b.area)
  end)

  return out
end

function DexUI.encounters(game,speciesId)
  if game and game.__gen2PokedexMenu then
    return GoldCompat.dexEncounterRows(game.__gen2PokedexMenu,speciesId)
  end

  local out={}
  local seen={}
  local all=(game and game.data and game.data.encounters) or {}

  for mapId,enc in pairs(all) do
    if type(enc)=="table" then
      for key,group in pairs(enc) do
        if type(group)=="table" then
          local slots=group.slots or group
          local found=false

          if type(slots)=="table" then
            for _,slot in pairs(slots) do
              if type(slot)=="table"
                  and (slot.species==speciesId or slot.id==speciesId) then
                found=true
                break
              end
            end
          end

          if found then
            local area=DexUI.locationName(game,mapId)
            local method=DexUI.methodName(key,group)
            local token=area.."|"..method
            if not seen[token] then
              seen[token]=true
              out[#out+1]={area=area,method=method}
            end
          end
        end
      end
    end
  end

  table.sort(out,function(a,b)
    if a.area==b.area then return a.method<b.method end
    return a.area<b.area
  end)
  return out
end

-- Normalize encounter labels once so both PokéDex presentations expose the
-- same route/method information without changing the generation adapters.
function DexUI.encounterDisplayRows(game,speciesId)
  local rows=DexUI.encounters(game,speciesId)
  local displayRows={}
  local displaySeen={}
  local safariAdded=false

  for _,sourceRow in ipairs(rows) do
    local area=tostring(sourceRow.area or "N/A")
    local method=tostring(sourceRow.method or "WILD")
    area=area:gsub("_"," ")
    area=area:gsub("(%a)(%d)","%1 %2")
    area=area:gsub("(%d)(%a)","%1 %2")
    area=area:gsub("(%l)(%u)","%1 %2")
    area=area:gsub("%s+"," ")
    area=area:gsub("^%s+",""):gsub("%s+$","")

    local safariKey=area:lower()
    if safariKey:find("safari",1,true) then
      if not safariAdded then
        safariAdded=true
        displayRows[#displayRows+1]={area="Safari Zone",method=method}
      end
    else
      local token=area.."|"..method
      if not displaySeen[token] then
        displaySeen[token]=true
        displayRows[#displayRows+1]={area=area,method=method}
      end
    end
  end
  return displayRows
end

function DexUI.ball(ox,oy,sc,lx,ly,caught)
  local g=love.graphics
  local cx=ox+lx*sc
  local cy=oy+ly*sc
  local r=2.3*sc

  g.push("all")
  g.origin()

  if caught then
    g.setColor(0.90,0.18,0.14,1)
    g.arc("fill","pie",cx,cy,r,math.pi,math.pi*2)
    g.setColor(0.98,0.98,0.94,1)
    g.arc("fill","pie",cx,cy,r,0,math.pi)
    g.setColor(0.08,0.08,0.07,1)
    g.setLineWidth(math.max(1,0.55*sc))
    g.circle("line",cx,cy,r)
    g.line(cx-r,cy,cx+r,cy)
    g.setColor(0.98,0.98,0.94,1)
    g.circle("fill",cx,cy,r*0.28)
  else
    g.setColor(0.38,0.39,0.37,0.42)
    g.setLineWidth(math.max(1,0.7*sc))
    g.circle("line",cx,cy,r)
    g.line(cx-r,cy,cx+r,cy)
  end

  g.pop()
end

function DexUI.draw(game,state)
  if not (game and state and state.items) then return end

  local ox,oy,sc=safeFullCanvas()
  local g=love.graphics
  local index=state.__gen3uiDexIndex
  if not index then
    index=DexUI.buildIndex(game)
    state.__gen3uiDexIndex=index
  end

  local total=#state.items
  local selected=math.max(1,math.min(state.index or 1,math.max(1,total)))
  local entry=index[selected]
  local speciesId=entry and entry.id
  local def=entry and entry.def
  local dex=(game.save and game.save.pokedex) or {seen={},owned={}}

  local seen=speciesId and (
    (dex.seen and dex.seen[speciesId]) or
    (dex.owned and dex.owned[speciesId])
  )
  local owned=speciesId and dex.owned and dex.owned[speciesId]

  local seenCount,ownedCount=0,0
  for _,e in pairs(index) do
    if dex.owned and dex.owned[e.id] then
      ownedCount=ownedCount+1
      seenCount=seenCount+1
    elseif dex.seen and dex.seen[e.id] then
      seenCount=seenCount+1
    end
  end

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.94,0.93,0.87,1)
  g.rectangle("fill",0,0,160,144)

  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,4,152,17)
  g.setColor(0.99,0.985,0.955,1)
  g.rectangle("fill",5,5,150,15)

  g.setColor(0.12,0.12,0.11,1)
  roundedRect("fill",4,25,88,104,3)
  roundedRect("fill",95,25,61,104,3)
  g.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",6,27,84,100,2)
  roundedRect("fill",97,27,57,100,2)

  setCurrentBorderColor(1)
  roundedRect("line",7,28,82,98,2)
  roundedRect("line",98,28,55,98,2)

  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,132,152,8)
  g.pop()

  finalText("POKéDEX",9,8,5.0,{0.06,0.06,0.06,1},ox,oy,sc)
  finalText(("SEEN %d  CAUGHT %d"):format(seenCount,ownedCount),
    79,8,3.15,{0.18,0.18,0.17,1},ox,oy,sc,"right",72)

  local shownName=(seen and def and def.name) or "-----"
  local selectedDex=(entry and tonumber(entry.dex))
      or (def and tonumber(def.dex)) or selected
  finalText(("#%03d  %s"):format(selectedDex,shownName),
    11,32,4.2,{0.07,0.07,0.07,1},ox,oy,sc,"left",74)

  finalText("STATUS",11,44,2.7,{0.38,0.38,0.35,1},ox,oy,sc)
  finalText(owned and "CAUGHT" or (seen and "SEEN" or "UNKNOWN"),
    11,49,3.4,
    owned and {0.16,0.42,0.20,1}
      or (seen and {0.46,0.35,0.10,1} or {0.42,0.42,0.40,1}),
    ox,oy,sc)

  if seen and def then
    finalText("SPECIES",11,58,2.5,{0.38,0.38,0.35,1},ox,oy,sc)
    finalText(DexUI.speciesLabel(def),11,63,3.0,{0.08,0.08,0.08,1},
      ox,oy,sc,"left",42)

    finalText("HT",11,70,2.5,{0.38,0.38,0.35,1},ox,oy,sc)
    finalText(DexUI.heightLabel(def),21,70,2.9,{0.08,0.08,0.08,1},
      ox,oy,sc,"left",24)

    finalText("WT",47,70,2.5,{0.38,0.38,0.35,1},ox,oy,sc)
    finalText(DexUI.weightLabel(def),57,70,2.9,{0.08,0.08,0.08,1},
      ox,oy,sc,"left",28)
  else
    finalText("SPECIES",11,58,2.5,{0.38,0.38,0.35,1},ox,oy,sc)
    finalText("N/A",11,63,3.0,{0.42,0.42,0.40,1},ox,oy,sc)
  end

  -- Match Party/PC compatibility: resolve the selected species through the
  -- live battle-sprite path so equipped sprite packs carry into the Pokédex.
  if seen and speciesId then
    g.push("all")
    g.origin()
    pcall(GoldCompat.drawCleanResolvedPortrait,game,{species=speciesId},
      ox+60*sc,oy+38*sc,24*sc,23*sc,"dex")
    g.pop()
  end

  finalText("WILD LOCATIONS",11,82,2.7,{0.38,0.38,0.35,1},ox,oy,sc)

  local displayRows=(seen and speciesId)
    and DexUI.encounterDisplayRows(game,speciesId) or {}

  if #displayRows==0 then
    finalText("N/A",11,90,3.7,{0.12,0.12,0.11,1},ox,oy,sc)
  else
    for i=1,math.min(3,#displayRows) do
      local row=displayRows[i]
      local y=89+(i-1)*10
      finalText(row.area,11,y,2.9,{0.08,0.08,0.08,1},
        ox,oy,sc,"left",51)
      finalText(row.method,63,y,2.6,{0.34,0.26,0.08,1},
        ox,oy,sc,"left",23)
    end
    if #displayRows>3 then
      finalText((" +%d MORE"):format(#displayRows-3),11,119,2.6,
        {0.38,0.38,0.35,1},ox,oy,sc)
    end
  end

  local visibleRows=8
  local first=math.max(1,selected-math.floor(visibleRows/2))
  if total>visibleRows then
    first=math.min(first,total-visibleRows+1)
  end

  for row=1,visibleRows do
    local n=first+row-1
    local item=state.items[n]
    if not item then break end

    local e=index[n]
    local id=e and e.id
    local isSeen=id and (
      (dex.seen and dex.seen[id]) or
      (dex.owned and dex.owned[id])
    )
    local caught=id and dex.owned and dex.owned[id]
    local name=(isSeen and e and e.def and e.def.name) or "-----"
    local y=31+(row-1)*11

    if n==selected then
      g.push("all")
      g.translate(ox,oy)
      g.scale(sc,sc)
      g.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",99,y-2,53,10,2)
      g.pop()
    end

    DexUI.ball(ox,oy,sc,103,y+2,caught)
    local rowDex=(e and tonumber(e.dex))
        or (e and e.def and tonumber(e.def.dex)) or n
    finalText(("%03d"):format(rowDex),107,y,2.6,
      n==selected and {0.98,0.97,0.92,1} or {0.34,0.34,0.32,1},
      ox,oy,sc)
    finalText(name,120,y,2.8,
      n==selected and {0.98,0.97,0.92,1} or {0.08,0.08,0.08,1},
      ox,oy,sc,"left",30)
  end

  safeFooterText("A: OPTIONS   B: BACK   ←/→: PAGE",9,134,2.5,
    {0.96,0.95,0.90,1},ox,oy,sc,142)
end


function DexUI.drawEntry(game,state)
  if not (game and state and state.def) then return end

  local ox,oy,sc=safeFullCanvas()
  local g=love.graphics
  local def=state.def
  local e=def.dexEntry or {}
  local dex=(game.save and game.save.pokedex) or {owned={}}
  local owned=state.forceOwned or (dex.owned and dex.owned[def.id])

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.94,0.93,0.87,1)
  g.rectangle("fill",0,0,160,144)

  -- Header
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,4,152,17)
  g.setColor(0.99,0.985,0.955,1)
  g.rectangle("fill",5,5,150,15)

  -- Main card
  g.setColor(0.12,0.12,0.11,1)
  roundedRect("fill",4,25,152,104,3)
  g.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",6,27,148,100,2)
  setCurrentBorderColor(1)
  roundedRect("line",7,28,146,98,2)

  -- Footer
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,132,152,8)
  g.pop()

  finalText("POKéDEX DATA",9,8,4.8,{0.06,0.06,0.06,1},ox,oy,sc)

  -- Sprite panel on left.
  if def.id then
    g.push("all")
    g.origin()
    pcall(GoldCompat.drawCleanResolvedPortrait,game,{species=def.id},
      ox+12*sc,oy+34*sc,43*sc,42*sc,"dex")
    g.pop()
  end

  finalText(tostring(def.name or "-----"),61,32,4.5,
    {0.07,0.07,0.07,1},ox,oy,sc,"left",86)

  finalText(tostring(e.kind or "N/A"):upper(),61,42,3.8,
    {0.34,0.34,0.31,1},ox,oy,sc,"left",86)

  finalText(("No. %03d"):format(tonumber(def.dex) or 0),61,51,3.8,
    {0.08,0.08,0.08,1},ox,oy,sc)

  if owned then
    finalText("HT",61,61,3.25,{0.38,0.38,0.35,1},ox,oy,sc)
    finalText(DexUI.heightLabel(def),73,61,3.55,
      {0.08,0.08,0.08,1},ox,oy,sc,"left",29)

    finalText("WT",104,61,3.25,{0.38,0.38,0.35,1},ox,oy,sc)
    finalText(DexUI.weightLabel(def),116,61,3.55,
      {0.08,0.08,0.08,1},ox,oy,sc,"left",32)
  else
    finalText("DATA UNKNOWN",61,61,3.0,
      {0.42,0.42,0.40,1},ox,oy,sc)
  end

  -- Native DexEntry description source, presented in our card.
  local description=nil
  if owned and e.text and game.data and game.data.text then
    description=game.data.text[e.text]
  end

  finalText("ENTRY",12,77,3.45,{0.38,0.38,0.35,1},ox,oy,sc)

  if description and tostring(description)~="" then
    local clean=GoldCompat.cleanWrappedText(description)

    -- Wrap in logical Pokédex pixels, not final screen pixels. Multiplying
    -- this width by sc made the renderer believe an entire paragraph fit on
    -- one line at high window scales.
    local entrySize=4.35
    local entryWidth=132
    local f=font(entrySize*UI_TEXT_SCALE*GoldCompat.userTextScale())
    local _,wrapped=f:getWrap(clean,entryWidth)
    local maxLines=4

    for i=1,math.min(maxLines,#wrapped) do
      finalText(wrapped[i],12,87+(i-1)*10,entrySize,
        {0.08,0.08,0.08,1},ox,oy,sc,"left",entryWidth)
    end
  else
    finalText("Data unknown.",12,88,3.2,
      {0.30,0.30,0.28,1},ox,oy,sc)
  end

  safeFooterText("A / B: BACK",9,134,2.6,
    {0.96,0.95,0.90,1},ox,oy,sc,142)
end


function DexUI.drawAction(game,state)
  if not state then return end

  -- Keep the full new Pokédex visible beneath the native option state.
  if DexUI.active then
    DexUI.draw(game,DexUI.active)
  end

  local ox,oy,sc=safeFullCanvas()
  local g=love.graphics
  local items=state.items or {}
  local count=math.max(1,#items)

  -- Compact action card hangs off the LEFT edge of the interface -- the
  -- same small "runoff" edge-bleed convention hanging panels use elsewhere
  -- in this mod (e.g. drawColosseumRunoffPanel caps its own overflow at a
  -- couple of canvas units past an edge, not a large one). The Pokédex
  -- interface's own left edge sits at x=4 with only ~4 canvas units of
  -- margin before the screen edge, so this hugs that margin instead of
  -- sitting well inside the species list column the way it used to.
  local w=43
  local rowH=9
  local h=6+count*rowH
  local x=2

  local y=31
  if DexUI.active and DexUI.active.items then
    local total=#DexUI.active.items
    local selected=math.max(1,math.min(DexUI.active.index or 1,math.max(1,total)))
    local visibleRows=8
    local first=math.max(1,selected-math.floor(visibleRows/2))
    if total>visibleRows then
      first=math.min(first,total-visibleRows+1)
    end

    local visibleRow=selected-first+1
    local selectedY=31+(visibleRow-1)*11
    local belowY=selectedY+10

    -- Prefer below. Flip only for genuinely bottom-most rows where even the
    -- compact card cannot fit inside the panel.
    if belowY+h<=127 then
      y=belowY
    else
      y=selectedY-h-2
    end
  end

  if y<29 then y=29 end
  if y+h>128 then y=128-h end

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0,0,0,0.40)
  roundedRect("fill",x+2,y+2,w,h,3)
  g.setColor(0.006,0.030,0.033,0.97)
  roundedRect("fill",x,y,w,h,3)
  g.setColor(0.34,0.58,0.56,1)
  roundedRect("line",x,y,w,h,3)

  for i,item in ipairs(items) do
    local yy=y+4+(i-1)*rowH
    local selected=i==(state.index or 1)

    if selected then
      g.setColor(0.07,0.31,0.28,0.98)
      roundedRect("fill",x+3,yy-1,w-6,8,2)
      g.setColor(1.00,0.33,0.16,1)
      -- Right-pointing marker, matching the selection arrow used everywhere
      -- else in this file (flat edge on the left, tip pointing right into
      -- the label text).
      g.polygon("fill",x+4,yy,x+4,yy+6,x+8,yy+3)
    end

    g.pop()
    local label=tostring(item.label or "")
    if label:upper()=="AREA" then label="LOCATION" end
    finalText(label,x+10,yy,2.55,
      selected and {0.98,1.00,0.98,1} or {0.64,0.79,0.75,1},
      ox,oy,sc,"left",w-13)
    g.push("all")
    g.translate(ox,oy)
    g.scale(sc,sc)
  end

  g.pop()
end

function DexUI.memoTypeLabel(def)
  local out={}
  for _,value in ipairs((def and def.types) or {}) do
    out[#out+1]=tostring(value):upper()
  end
  return #out>0 and table.concat(out," / ") or "--"
end

function GoldCompat.abilityLabel(game,mon,def)
  local raw=mon and (mon.abilityName or mon.ability or mon.abilityId)
    or def and (def.ability or def.ability1 or def.abilities)
  if type(raw)=="table" then
    raw=raw.name or raw.id or raw[1]
  end
  if type(raw)=="number" and def and type(def.abilities)=="table" then
    raw=def.abilities[raw] or raw
  end
  if type(raw)=="table" then raw=raw.name or raw.id or raw[1] end
  local abilityDefs=game and game.data and game.data.abilities
  if raw~=nil and abilityDefs then
    local record=abilityDefs[raw] or abilityDefs[tonumber(raw)]
    if type(record)=="table" then raw=record.name or record.id or raw end
  end
  if raw~=nil and tostring(raw)~="" then return tostring(raw):upper() end
  -- Abilities did not exist in the base Gen I/II battle rules. Say so instead
  -- of presenting a mysteriously blank field in those games.
  return GoldCompat.generation=="gen2" and "NOT USED IN GEN II"
    or "NOT USED IN GEN I"
end

function DexUI.memoAbilityLabel(game,def)
  return GoldCompat.abilityLabel(game,nil,def)
end

function DexUI.drawStrategyMemo(game,state)
  if not (game and state and state.items) then return end
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  local index=state.__gen3uiDexIndex or DexUI.buildIndex(game)
  state.__gen3uiDexIndex=index
  local total=#state.items
  local selected=clamp(state.index or 1,1,math.max(1,total))
  local entry=index[selected]
  local def=entry and entry.def
  local species=entry and entry.id
  local dex=(game.save and game.save.pokedex) or {}
  local ownedSet=dex.caught or dex.owned or {}
  local seenSet=dex.seen or {}
  local seen=species and (seenSet[species] or ownedSet[species])
  local caught=species and ownedSet[species]
  local seenCount,ownedCount=0,0
  for _,e in ipairs(index) do
    if ownedSet[e.id] then ownedCount=ownedCount+1; seenCount=seenCount+1
    elseif seenSet[e.id] then seenCount=seenCount+1 end
  end

  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.018,0.040,0.044,0.78); roundedRect("fill",3,3,154,128,5)
  G.setColor(0.34,0.53,0.52,0.96); roundedRect("line",3,3,154,128,5)
  G.setColor(0.015,0.075,0.054,0.88); roundedRect("fill",6,6,148,12,4)
  G.setColor(0.12,0.75,0.32,1); G.rectangle("fill",9,16,142,1)
  -- Encounter list and selected-species dossier are peers, like Colosseum's
  -- Strategy Memo, rather than handheld Pokédex mode + separate data page.
  G.setColor(0.012,0.030,0.033,0.84); roundedRect("fill",6,22,58,105,4)
  G.setColor(0.28,0.43,0.42,0.95); roundedRect("line",6,22,58,105,4)
  G.setColor(0.012,0.030,0.033,0.84); roundedRect("fill",67,22,87,105,4)
  G.setColor(0.28,0.43,0.42,0.95); roundedRect("line",67,22,87,105,4)
  G.setColor(0.08,0.11,0.11,0.78); roundedRect("fill",72,27,37,38,3)
  G.setColor(0.26,0.43,0.42,0.9); roundedRect("line",72,27,37,38,3)
  G.pop()

  finalText("PokéDex",10,9,3.35,{0.42,1.00,0.52,1},ox,oy,sc)
  finalText(("SEEN %d  CAUGHT %d"):format(seenCount,ownedCount),
    91,10,2.15,{0.76,0.90,0.80,1},ox,oy,sc,"right",59)

  local visible=9
  local first=math.max(1,selected-math.floor(visible/2))
  if total>visible then first=math.min(first,total-visible+1) end
  for row=1,visible do
    local n=first+row-1
    local e=index[n]
    if not e then break end
    local id=e.id
    local isSeen=seenSet[id] or ownedSet[id]
    local yy=27+(row-1)*10.5
    if n==selected then
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      G.setColor(0.58,0.12,0.075,0.96); roundedRect("fill",9,yy-2,52,9,3)
      G.setColor(1.0,0.31,0.15,1); G.rectangle("fill",9,yy-2,1.5,9)
      G.pop()
    end
    DexUI.ball(ox,oy,sc,13,yy+2,ownedSet[id])
    local name=isSeen and tostring((e.def and e.def.name) or id) or "-----"
    finalText(name,18,yy,2.55,n==selected and {1,1,1,1}
      or {0.72,0.84,0.78,1},ox,oy,sc,"left",40)
  end

  local shownName=seen and def and def.name or "UNKNOWN"
  finalText(shownName,112,29,3.25,{0.98,0.99,0.96,1},ox,oy,sc,"left",37)
  finalText(caught and "CAUGHT" or (seen and "ENCOUNTERED" or "NO DATA"),
    112,38,2.0,caught and {0.44,1.00,0.54,1} or {0.95,0.76,0.28,1},
    ox,oy,sc,"left",37)
  local encounterRows={}
  if seen and def and species then
    G.push("all"); G.origin()
    pcall(GoldCompat.drawCleanResolvedPortrait,game,{species=species},
      ox+74*sc,oy+29*sc,33*sc,34*sc,"dex")
    G.pop()

    -- Use the otherwise empty dossier column for immediately useful habitat
    -- data. The AREA action still exposes the complete location list.
    encounterRows=DexUI.encounterDisplayRows(game,species)
    finalText("FOUND AT",112,47,1.75,{0.45,0.86,0.58,1},ox,oy,sc)
    if #encounterRows>0 then
      local encounter=encounterRows[1]
      local areaSize=2.15
      while areaSize>1.45 and finalTextWidth(encounter.area,areaSize,sc)>37 do
        areaSize=areaSize-0.10
      end
      finalText(encounter.area,112,53,areaSize,{0.98,0.99,0.96,1},
        ox,oy,sc,"left",37)
      local method="VIA "..tostring(encounter.method or "WILD")
      local methodSize=1.75
      while methodSize>1.35 and finalTextWidth(method,methodSize,sc)>37 do
        methodSize=methodSize-0.10
      end
      finalText(method,112,60,methodSize,{0.95,0.76,0.28,1},
        ox,oy,sc,"left",37)
      if #encounterRows>1 then
        finalText(("+%d OTHER AREAS"):format(#encounterRows-1),72,116,1.7,
          {0.58,0.78,0.68,1},ox,oy,sc,"left",76)
      else
        finalText("A: VIEW AREA DETAILS",72,116,1.7,
          {0.58,0.78,0.68,1},ox,oy,sc,"left",76)
      end
    else
      finalText("NO WILD DATA",112,54,1.85,{0.68,0.78,0.74,1},
        ox,oy,sc,"left",37)
    end

    -- SELECT cycles this lower block through every known area/method for
    -- this species (page 1..N), then back to the normal dossier (page 0),
    -- mirroring Gen 2's native SELECT-to-browse-locations convention.
    local locationPage=math.min(state.__gen3uiDexLocationPage or 0,
      #encounterRows)
    local pageEntry=locationPage>0 and encounterRows[locationPage] or nil
    if pageEntry then
      finalText(("LOCATION %d OF %d"):format(locationPage,#encounterRows),
        72,70,1.75,{0.45,0.86,0.58,1},ox,oy,sc,"left",76)
      local areaSize=2.35
      while areaSize>1.55 and finalTextWidth(pageEntry.area,areaSize,sc)>76 do
        areaSize=areaSize-0.10
      end
      finalText(pageEntry.area,72,79,areaSize,{0.98,0.99,0.96,1},
        ox,oy,sc,"left",76)
      local pageMethod="VIA "..tostring(pageEntry.method or "WILD")
      local pageMethodSize=2.0
      while pageMethodSize>1.4
          and finalTextWidth(pageMethod,pageMethodSize,sc)>76 do
        pageMethodSize=pageMethodSize-0.10
      end
      finalText(pageMethod,72,92,pageMethodSize,{0.95,0.76,0.28,1},
        ox,oy,sc,"left",76)
      finalText("SELECT: NEXT AREA",72,107,1.7,{0.58,0.78,0.68,1},
        ox,oy,sc,"left",76)
    else
      finalText("TYPE",72,70,1.9,{0.45,0.86,0.58,1},ox,oy,sc)
      finalText(DexUI.memoTypeLabel(def),72,76,2.5,{0.98,0.99,0.96,1},
        ox,oy,sc,"left",76)
      finalText("ABILITY",72,85,1.9,{0.45,0.86,0.58,1},ox,oy,sc)
      finalText(DexUI.memoAbilityLabel(game,def),72,91,2.15,{0.98,0.99,0.96,1},
        ox,oy,sc,"left",76)
      finalText("HEIGHT",72,101,1.9,{0.45,0.86,0.58,1},ox,oy,sc)
      finalText(DexUI.heightLabel(def),72,107,2.35,{0.98,0.99,0.96,1},ox,oy,sc)
      finalText("WEIGHT",111,101,1.9,{0.45,0.86,0.58,1},ox,oy,sc)
      finalText(DexUI.weightLabel(def),111,107,2.35,{0.98,0.99,0.96,1},ox,oy,sc)
    end
  else
    finalText("Encounter this POKéMON",73,77,2.35,{0.68,0.78,0.74,1},
      ox,oy,sc,"left",74)
    finalText("to register its data.",73,86,2.35,{0.68,0.78,0.74,1},
      ox,oy,sc,"left",74)
  end
  if seen and def and species and #encounterRows>1 then
    finalText("A: DATA / LOCATION   B: BACK   SELECT: AREAS",10,134,1.85,
      {0.88,0.96,0.90,1},ox,oy,sc)
  else
    finalText("A: DATA / LOCATION   B: BACK",10,134,1.85,
      {0.88,0.96,0.90,1},ox,oy,sc)
  end
end

function DexUI.drawStrategyEntry(game,state)
  if not (game and state and state.def) then return end
  local def=state.def
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.018,0.040,0.044,0.80); roundedRect("fill",5,7,150,122,5)
  G.setColor(0.34,0.53,0.52,0.96); roundedRect("line",5,7,150,122,5)
  G.setColor(0.015,0.075,0.054,0.9); roundedRect("fill",8,10,144,12,4)
  G.setColor(0.08,0.11,0.11,0.80); roundedRect("fill",10,27,55,61,4)
  G.setColor(0.28,0.43,0.42,0.95); roundedRect("line",10,27,55,61,4)
  G.setColor(0.012,0.030,0.033,0.86); roundedRect("fill",69,27,81,61,4)
  G.setColor(0.28,0.43,0.42,0.95); roundedRect("line",69,27,81,61,4)
  G.setColor(0.012,0.030,0.033,0.86); roundedRect("fill",10,92,140,32,4)
  G.setColor(0.28,0.43,0.42,0.95); roundedRect("line",10,92,140,32,4)
  G.pop()
  finalText("PokéDex",12,13,3.15,{0.42,1.00,0.52,1},ox,oy,sc)
  finalText(tostring(def.name or "UNKNOWN"),73,31,3.7,{1,1,1,1},ox,oy,sc)
  finalText("TYPE  "..DexUI.memoTypeLabel(def),73,44,2.5,
    {0.95,0.82,0.32,1},ox,oy,sc,"left",72)
  finalText("ABILITY  "..DexUI.memoAbilityLabel(game,def),73,54,2.15,
    {0.92,0.97,0.93,1},ox,oy,sc,"left",72)
  finalText("HT  "..DexUI.heightLabel(def),73,66,2.4,{0.70,0.84,0.78,1},ox,oy,sc)
  finalText("WT  "..DexUI.weightLabel(def),111,66,2.4,{0.70,0.84,0.78,1},ox,oy,sc)
  if def.id then
    G.push("all"); G.origin()
    pcall(GoldCompat.drawCleanResolvedPortrait,game,{species=def.id},
      ox+14*sc,oy+31*sc,47*sc,52*sc,"dex")
    G.pop()
  end
  local description=nil
  local e=def.dexEntry or {}
  if e.text then
    local tableText=game.data and game.data.text and game.data.text[e.text]
    description=tableText or tostring(e.text)
  end
  if e.text2 then
    local tableText2=game.data and game.data.text and game.data.text[e.text2]
    local second=tableText2 or tostring(e.text2)
    description=((description and tostring(description).." ") or "")..second
  end
  finalText("MEMO",15,97,2.0,{0.45,0.86,0.58,1},ox,oy,sc)
  local clean=GoldCompat.cleanWrappedText(description or "Species data registered.")
  local f=font(2.65*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local _,wrapped=f:getWrap(clean,128)
  for i=1,math.min(3,#wrapped) do
    finalText(wrapped[i],15,104+(i-1)*6.5,2.65,{0.92,0.97,0.93,1},
      ox,oy,sc,"left",128)
  end
  finalText("B: BACK",118,134,2.1,{0.88,0.96,0.90,1},ox,oy,sc,"right",32)
end

-- Route every Gen 1 and adapted Gen 2 Pokédex call through the Strategy Memo.
DexUI.draw=DexUI.drawStrategyMemo
DexUI.drawEntry=DexUI.drawStrategyEntry


function DexUI.hudLayer(game,viewport)
  -- Dedicated wrapper keeps Pokédex references out of the already-large
  -- renderHudHook, avoiding LuaJIT's 60-upvalue function limit.
  -- A standalone DATA page (newly caught species, starter preview, scripted
  -- DexEntryMenu) does NOT have a parent Pokédex list state. Handle that page
  -- before consulting DexUI.active or it is suppressed by our wrapped draw and
  -- then silently skipped on screen.
  if not featureEnabled("revampedPokedex") then
    DexUI.active=nil
    DexUI.action=nil
    DexUI.entry=nil
    return
  end

  local top=topState(game)
  if DexUI.entry
      and stateExistsInStack(game,DexUI.entry)
      and top==DexUI.entry then
    local ok,err=pcall(DexUI.drawEntry,game,DexUI.entry)
    if not ok then
      DexUI.entry.__gen3uiDexEntryRenderFailed=true
      if modRef and modRef.log then
        modRef.log("error","Gen 3 UI Pokédex DATA renderer failed: "
          ..tostring(err))
      end
    end
    return
  elseif DexUI.entry and not stateExistsInStack(game,DexUI.entry) then
    DexUI.entry=nil
  end

  local state=DexUI.active
  if not state then
    DexUI.action=nil
    return
  end

  if not stateExistsInStack(game,state) then
    DexUI.active=nil
    DexUI.action=nil
    return
  end

  if DexUI.action
      and stateExistsInStack(game,DexUI.action)
      and top==DexUI.action then
    local ok,err=pcall(DexUI.drawAction,game,DexUI.action)
    if not ok then
      DexUI.action.__gen3uiPokedexActionRenderFailed=true
      if modRef and modRef.log then
        modRef.log("error","Gen 3 UI Pokédex action overlay failed: "
          ..tostring(err))
      end
    end
    return
  elseif DexUI.action and not stateExistsInStack(game,DexUI.action) then
    DexUI.action=nil
  end

  if top~=state then return end

  local ok,err=pcall(DexUI.draw,game,state)
  if not ok then
    state.__gen3uiPokedexRenderFailed=true
    DexUI.active=nil
    if modRef and modRef.log then
      modRef.log("error","Gen 3 UI Pokédex renderer failed; native fallback: "
        ..tostring(err))
    end
  end
end

function DexUI.hud(next,game,viewport)
  -- Keep the native scene outside the theme adapter; only the custom Pokédex
  -- layer receives the Colosseum material translation.
  next(game,viewport)
  return GoldCompat.withColosseumSkin(DexUI.hudLayer,game,viewport)
end



-- Starter confirmation is still owned by the native ChoiceBox/script flow.
-- This adapter only identifies the six canonical lab starters from the live
-- prompt and gives that exact YES/NO state the same hanging presentation and
-- sprite-source rules as Party/PC. No starter logic or save flags are replaced.
function GoldCompat.starterSpeciesFromTextBox(box)
  if not box then return nil end
  local chunks={}
  for _,page in ipairs(box.pages or {}) do
    for _,line in ipairs(page or {}) do chunks[#chunks+1]=tostring(line or "") end
  end
  local all=table.concat(chunks," "):upper()
  -- Keep the adapter narrowly on the lab's choose/take question. Nickname,
  -- release, move-learning, and other YES/NO prompts can also contain a
  -- starter species name and must remain ordinary dialogue.
  if all:find("NICK",1,true) or all:find("RELEASE",1,true)
      or all:find("FORGET",1,true) or all:find("LEARN",1,true)
      or all:find("DELETE",1,true) then
    return nil
  end
  local chooseIntent=all:find("WANT",1,true) or all:find("TAKE",1,true)
    or all:find("CHOOSE",1,true) or all:find("STARTER",1,true)
  if not chooseIntent then return nil end
  local starters={
    "BULBASAUR","CHARMANDER","SQUIRTLE",
    "CHIKORITA","CYNDAQUIL","TOTODILE",
    -- Included for compatible Yellow/variant scripts that expose a choice.
    "PIKACHU","EEVEE",
  }
  for _,species in ipairs(starters) do
    if all:find(species,1,true) then return species end
  end

  -- A few translated/legacy Gen I prompt tables describe the starter by type
  -- rather than repeating its species name. Keep this fallback generation-
  -- aware so "FIRE POKéMON" never guesses the wrong generation's starter.
  local gen2=GoldCompat.isGen2Game(box.game)
  if all:find("FIRE",1,true) then return gen2 and "CYNDAQUIL" or "CHARMANDER" end
  if all:find("WATER",1,true) then return gen2 and "TOTODILE" or "SQUIRTLE" end
  if all:find("GRASS",1,true) or all:find("PLANT",1,true)
      or all:find("LEAF",1,true) then
    return gen2 and "CHIKORITA" or "BULBASAUR"
  end
  return nil
end

function GoldCompat.isNicknamePromptBox(box)
  if not box then return false end
  local chunks={}
  for _,page in ipairs(box.pages or {}) do
    for _,line in ipairs(page or {}) do chunks[#chunks+1]=tostring(line or "") end
  end
  local all=table.concat(chunks," "):upper()
  -- Bind only the actual AskName-style question. This gives starter gifts,
  -- catches, eggs, and compatible scripted gifts the same input semantics
  -- without touching unrelated YES/NO prompts that happen to name a Pokémon.
  return all:find("NICK",1,true)~=nil
    and (all:find("GIVE",1,true)~=nil or all:find("NICKNAME",1,true)~=nil)
end

local function starterTypeLabel(value)
  if type(value)=="table" then value=value.name or value.id end
  local label=GoldCompat.humanizeIdentifier(value or "---"):upper()
  return label:gsub(" TYPE$","")
end

function GoldCompat.drawStarterChoiceFinal(box)
  local game=box and box.game
  local species=box and box.__colosseumStarterSpecies
  if not (game and species) then return false end
  local def=game.data and game.data.pokemon and game.data.pokemon[species]
  local name=tostring((def and def.name) or GoldCompat.humanizeIdentifier(species)):upper()
  local types=(def and def.types) or {}
  local type1=starterTypeLabel(types[1])
  local type2=starterTypeLabel(types[2])
  local typeText=(type2~="---" and type2~=type1) and (type1.." / "..type2) or type1
  local selected=math.max(1,math.min(2,tonumber(box.index) or 1))

  -- Presentation ownership is exclusive for the duration of the live starter
  -- choice. Gen II's pokepic and Gen I's StarterDex are native preview layers;
  -- if either survives or is reconstructed after ChoiceBox.new, keep it hidden
  -- every frame while this card owns the foreground.
  if DexUI then DexUI.entry=nil end
  local world=game and (game.world or game.overworld)
  if world then
    world.pokePic=nil
    world.pokePicName=nil
    world.pokePicColors=nil
  end

  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  -- Use a compact selection card rather than a nearly full menu.
  -- The overworld lab remains visible around it.
  local x,y,w,h=16,27,128,80
  -- The portrait viewport must end before the YES/NO rail begins. The older
  -- 43px-tall pod physically overlapped the rail by eight logical pixels, so
  -- even a correctly clipped sprite appeared to spill into the selection row.
  local portraitX,portraitY,portraitW,portraitH=x+8,y+22,43,32
  local infoX=x+57
  local railY=y+57
  local railGap=5
  local railW=(w-16-railGap)/2

  G.push("all")
  G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0,0,0,0.38); roundedRect("fill",x+2,y+3,w,h,6)
  G.setColor(0.010,0.045,0.046,0.97); roundedRect("fill",x,y,w,h,6)
  G.setColor(0.24,0.55,0.52,0.98); G.setLineWidth(1.1)
  roundedRect("line",x,y,w,h,6)

  G.setColor(0.020,0.105,0.082,0.96); roundedRect("fill",x+4,y+4,w-8,14,4)
  G.setColor(0.31,0.72,0.65,0.92); G.rectangle("fill",x+8,y+19,w-16,0.8)

  G.setColor(0.004,0.025,0.027,0.98); roundedRect("fill",portraitX,portraitY,portraitW,portraitH,5)
  G.setColor(0.19,0.43,0.42,0.98); roundedRect("line",portraitX,portraitY,portraitW,portraitH,5)

  G.setColor(0.006,0.030,0.032,0.94); roundedRect("fill",infoX,y+23,62,27,4)
  G.setColor(0.16,0.38,0.37,0.94); roundedRect("line",infoX,y+23,62,27,4)

  for i=1,2 do
    local rx=x+8+(i-1)*(railW+railGap)
    local on=selected==i
    G.setColor(on and {0.060,0.275,0.255,0.99} or {0.004,0.025,0.027,0.96})
    roundedRect("fill",rx,railY,railW,15,3)
    G.setColor(on and {0.31,0.96,0.59,1} or {0.17,0.42,0.39,0.94})
    G.setLineWidth(on and 1.15 or 0.8); roundedRect("line",rx,railY,railW,15,3)
    if on then
      G.setColor(1.00,0.34,0.16,1)
      G.polygon("fill",rx+6,railY+7.5,rx+2,railY+4.5,rx+2,railY+10.5)
    end
  end
  G.pop()

  finalText("CHOOSE YOUR STARTER",x+10,y+7,2.65,{0.72,1.00,0.82,1},ox,oy,sc)
  finalText(name,infoX+4,y+27,3.25,{0.98,0.99,0.96,1},ox,oy,sc,"left",56)
  finalText("TYPE  "..typeText,infoX+4,y+39,1.95,{0.95,0.78,0.30,1},ox,oy,sc,"left",56)
  finalText("Take this POKéMON?",infoX+4,y+46,1.55,{0.62,0.79,0.74,1},ox,oy,sc,"left",56)
  finalText("YES",x+25,railY+4,2.55,selected==1 and {1,1,1,1} or {0.68,0.82,0.78,1},ox,oy,sc)
  finalText("NO",x+88,railY+4,2.55,selected==2 and {1,1,1,1} or {0.68,0.82,0.78,1},ox,oy,sc)
  finalText("LEFT / RIGHT   •   A CONFIRM   •   B BACK",
    x+9,y+75,1.35,{0.60,0.79,0.74,1},ox,oy,sc,"center",w-18)

  pcall(GoldCompat.drawCleanResolvedPortrait,game,
    {species=species,level=5},
    ox+(portraitX+2)*sc,oy+(portraitY+2)*sc,(portraitW-4)*sc,(portraitH-4)*sc,"party")
  return true
end

function GoldCompat.safariContext(game)
  if not game then return false end
  if game.save and game.save.safari then return true end
  local ow=game.overworld or game.world
  local mapId=ow and ow.map and (ow.map.id or ow.map.name)
  return tostring(mapId or ""):upper():find("SAFARI_ZONE",1,true)~=nil
end

function GoldCompat.drawSafariChoiceFinal(box)
  local selected=math.max(1,math.min(2,tonumber(box and box.index) or 1))
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  local x,y,w,h=49,48,62,42
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0,0,0,0.34); roundedRect("fill",x+2,y+3,w,h,6)
  G.setColor(0.010,0.050,0.050,0.97); roundedRect("fill",x,y,w,h,6)
  G.setColor(0.24,0.55,0.52,0.98); G.setLineWidth(1.05)
  roundedRect("line",x,y,w,h,6)
  G.setColor(0.020,0.105,0.082,0.95); roundedRect("fill",x+4,y+4,w-8,10,3)
  for i=1,2 do
    local yy=y+17+(i-1)*10
    if selected==i then
      G.setColor(0.075,0.285,0.275,0.97)
      roundedRect("fill",x+7,yy,w-14,8,2)
      G.setColor(1.00,0.34,0.16,1)
      G.polygon("fill",x+10,yy+4,x+6,yy+1.5,x+6,yy+6.5)
    end
  end
  G.pop()
  finalText("SAFARI ZONE",x+9,y+7,2.0,{0.52,1.00,0.69,1},ox,oy,sc)
  finalText("YES",x+18,y+18.5,2.55,selected==1 and {1,1,1,1} or {0.68,0.82,0.78,1},ox,oy,sc)
  finalText("NO",x+18,y+28.5,2.55,selected==2 and {1,1,1,1} or {0.68,0.82,0.78,1},ox,oy,sc)
  return true
end

function GoldCompat.drawGen1ChoiceFinal(box)
  local selected=math.max(1,math.min(2,tonumber(box and box.index) or 1))
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  -- Ordinary Gen I YES/NO prompts now use the same proven hanging-state
  -- contract as Safari rather than a native-paper fallback. The native
  -- ChoiceBox remains the sole input/callback authority.
  local x,y,w,h=104,43,45,48
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0,0,0,0.34); roundedRect("fill",x+2,y+3,w,h,6)
  G.setColor(0.010,0.050,0.050,0.96); roundedRect("fill",x,y,w,h,6)
  G.setColor(0.24,0.55,0.52,0.98); G.setLineWidth(1.05)
  roundedRect("line",x,y,w,h,6)
  G.setColor(0.020,0.105,0.082,0.95); roundedRect("fill",x+4,y+4,w-8,10,3)
  for i=1,2 do
    local yy=y+17+(i-1)*11
    if selected==i then
      G.setColor(0.075,0.285,0.275,0.97)
      roundedRect("fill",x+7,yy,w-14,9,2)
      G.setColor(1.00,0.34,0.16,1)
      G.polygon("fill",x+10,yy+4.5,x+6,yy+1.5,x+6,yy+7.5)
    end
  end
  G.pop()
  finalText("CONFIRM",x+9,y+7,1.9,{0.52,1.00,0.69,1},ox,oy,sc)
  finalText("YES",x+17,y+18.5,2.5,selected==1 and {1,1,1,1} or {0.68,0.82,0.78,1},ox,oy,sc)
  finalText("NO",x+17,y+29.5,2.5,selected==2 and {1,1,1,1} or {0.68,0.82,0.78,1},ox,oy,sc)
  return true
end

function GoldCompat.drawChoiceThemeFinal(box)
  local saveBox=box and box.__colosseumSavePrompt
    or GoldCompat.__activeSavePromptBox
  if saveBox and featureEnabled("revampedSaveUI") then
    if box then box.__colosseumSavePrompt=saveBox end
    GoldCompat.__activeSavePromptBox=nil
    return GoldCompat.drawColosseumSavePanel(saveBox.game,
      saveBox.game and saveBox.game.save,box and box.index or 1,nil,
      "Would you like to save your progress?")
  end
  if box and box.__colosseumStarterSpecies
      and GoldCompat.pokemonPresentationEnabled() then
    return GoldCompat.drawStarterChoiceFinal(box)
  end
  if box and (box.__colosseumSafariChoice or GoldCompat.safariContext(box.game))
      and featureEnabled("revampedDialogueBoxes") then
    return GoldCompat.drawSafariChoiceFinal(box)
  end
  if box and GoldCompat.generation=="gen1"
      and featureEnabled("revampedDialogueBoxes") then
    return GoldCompat.drawGen1ChoiceFinal(box)
  end
  local g = love.graphics
  local sw,sh = g.getDimensions()
  local mobile=mobileBattleUIEnabled()

  -- Mobile YES/NO prompts are a compact hanging card ABOVE the dialogue lane.
  -- They no longer occupy the same right-bottom rectangle as the player's
  -- dialogue box. Desktop keeps the established geometry byte-for-byte.
  if mobile then
    local portrait=sh>sw
    local w=math.floor(clamp(sw*(portrait and 0.29 or 0.20),180,290)+0.5)
    local h=math.floor(clamp(sh*(portrait and 0.066 or 0.105),78,112)+0.5)
    local dialogueH=clamp(sh*(portrait and 0.082 or 0.088),68,108)
    local dialogueY=(sh-dialogueH)*0.5
    local gap=clamp(sh*0.012,8,18)
    local x=math.floor((sw-w)*0.5+0.5)
    local y=math.floor(clamp(dialogueY-h-gap,12,sh-h-12)+0.5)
    local selected=box.index or 1

    g.push("all"); g.origin()
    g.setColor(0.04,0.04,0.04,0.36); roundedRect("fill",x+3,y+4,w,h,12)
    g.setColor(0.055,0.105,0.115,0.90); roundedRect("fill",x,y,w,h,12)
    g.setColor(0.025,0.045,0.050,0.90); roundedRect("fill",x+4,y+4,w-8,h-8,9)
    g.setColor(0.44,0.68,0.68,1); g.setLineWidth(2)
    roundedRect("line",x+4,y+4,w-8,h-8,9)
    local pad=8
    local gapY=6
    local rowH=(h-pad*2-gapY)/2
    for i=1,2 do
      local ry=y+pad+(i-1)*(rowH+gapY)
      local on=selected==i
      if on then
        g.setColor(0.68,0.12,0.08,0.98)
        roundedRect("fill",x+pad,ry,w-pad*2,rowH,math.min(10,rowH*0.32))
      end
    end
    g.pop()
    local fontSize=clamp(math.floor(h*0.18+0.5),16,24)
    printText(Strings("YES"),x+math.floor(w*0.22),y+math.floor(pad+rowH*0.18),fontSize,
      selected==1 and {1,1,1,1} or {0.80,0.86,0.83,1})
    printText(Strings("NO"),x+math.floor(w*0.22),
      y+math.floor(pad+rowH+gapY+rowH*0.18),fontSize,
      selected==2 and {1,1,1,1} or {0.80,0.86,0.83,1})
    return true
  end

  local sc = math.max(1,sh/144)
  local margin = math.floor(4*sc+0.5)
  local dialogueH = math.floor(24*sc+0.5)
  local w = math.floor(48*sc+0.5)
  local h = math.floor(34*sc+0.5)
  local x = sw-w-margin
  local y = sh-dialogueH-margin-h-math.floor(3*sc+0.5)

  g.push("all")
  g.origin()
  local colosseum=GoldCompat.colosseumPartyFlowActive(box and box.game)
    or featureEnabled("colosseumBattleUI")
  g.setColor(colosseum and {0.055,0.105,0.115,0.78} or {0.08,0.08,0.07,1})
  roundedRect("fill",x,y,w,h,6*sc)
  g.setColor(colosseum and {0.025,0.045,0.050,0.72} or {0.99,0.985,0.95,1})
  roundedRect("fill",x+2*sc,y+2*sc,w-4*sc,h-4*sc,5*sc)
  if colosseum then
    g.setColor(0.44,0.68,0.68,1)
    g.setLineWidth(math.max(1,sc))
    roundedRect("line",x+2*sc,y+2*sc,w-4*sc,h-4*sc,5*sc)
  else
    drawUnifiedBorder(x,y,w,h,0)
  end

  local row1 = math.floor(y+5*sc+0.5)
  local row2 = math.floor(y+18*sc+0.5)
  local selected = box.index or 1
  g.setColor(colosseum and {0.68,0.12,0.08,0.98} or {0.10,0.10,0.09,1})
  roundedRect("fill",x+5*sc,(selected==1 and row1 or row2)-sc,
    w-10*sc,11*sc,5*sc)

  local pxSize = math.max(12,math.floor(5*sc+0.5))
  printText(Strings("YES"),math.floor(x+10*sc),row1,pxSize,
    selected==1 and {1,1,1,1}
      or (colosseum and {0.80,0.86,0.83,1} or {0.04,0.04,0.04,1}))
  printText(Strings("NO"),math.floor(x+10*sc),row2,pxSize,
    selected==2 and {1,1,1,1}
      or (colosseum and {0.80,0.86,0.83,1} or {0.04,0.04,0.04,1}))
  g.pop()
end
function GoldCompat.clonePaletteZones(zones)
  if type(zones)~="table" then return zones end
  local out={}
  for i,zone in ipairs(zones) do
    if type(zone)=="table" then
      local copy={}
      for key,value in pairs(zone) do
        if key=="colors" and type(value)=="table" then
          local colors={}
          for ci,color in ipairs(value) do
            if type(color)=="table" then
              colors[ci]={color[1],color[2],color[3],color[4]}
            else
              colors[ci]=color
            end
          end
          copy[key]=colors
        else
          copy[key]=value
        end
      end
      out[i]=copy
    else
      out[i]=zone
    end
  end
  return out
end

function GoldCompat.isDialogueTextState(state)
  if not state then return false end
  if state.isTextBox or getmetatable(state)==TextBox then return true end
  -- Structural fallback for API-v2 proxies/wrappers that intentionally hide
  -- the concrete metatable from another mod's sandbox.
  return type(state.pages)=="table" and type(state.shown)=="table"
    and state.boxTx~=nil and state.boxTy~=nil and state.game~=nil
end

function GoldCompat.isDialogueChoiceState(state,owner)
  if not state then return false end
  if getmetatable(state)==ChoiceBox then return true end
  return GoldCompat.isDialogueTextState(owner) and type(state.onChoose)=="function"
    and state.index~=nil and state.tx~=nil and state.ty~=nil and state.game~=nil
end

function GoldCompat.dialoguePaletteLockActive(game)
  local states=game and game.stack and game.stack.states
  local top=type(states)=="table" and states[#states] or nil
  local owner=type(states)=="table" and states[#states-1] or nil
  local latched=GoldCompat.__gen1DialoguePaletteOwner
  if latched and not stateExistsInStack(game,latched) then
    GoldCompat.__gen1DialoguePaletteOwner=nil
    latched=nil
  end
  local structuralOwner=GoldCompat.isDialogueTextState(top) and top
    or (GoldCompat.isDialogueChoiceState(top,owner) and top) or nil
  if structuralOwner then
    GoldCompat.__gen1DialoguePaletteOwner=structuralOwner
    latched=structuralOwner
  end
  return latched~=nil or State.activeDialogueBox~=nil
    or State.activeChoiceBox~=nil or GoldCompat.isDialogueTextState(top)
    or GoldCompat.isDialogueChoiceState(top,owner)
end

-- Photosensitivity safety guard for API-v2 Gen I.  Some script TextBoxes make
-- the palette compositor alternate between the map's normal zone set and the
-- saturated OG-Red boot palette.  The bad state lasts for the whole text page
-- and ends when ChoiceBox appears, so recomputing or pattern-matching the bad
-- palette cannot make the transition safe.  Freeze the last settled, pre-box
-- zones for the complete themed dialogue/choice flow instead.  A dedicated
-- owner latch survives render frames that occur between fixed updates; it is
-- released only after that state actually leaves the authoritative stack.
function GoldCompat.repairGen1TransientZones(game,zones)
  if GoldCompat.generation~="gen1" or type(zones)~="table" then return zones end
  if not featureEnabled("revampedDialogueBoxes") then
    GoldCompat.__lastStableGen1Zones=GoldCompat.clonePaletteZones(zones)
    return zones
  end

  if GoldCompat.dialoguePaletteLockActive(game) then
    local stable=GoldCompat.__lastStableGen1Zones
    if type(stable)=="table" and #stable>0 then
      return GoldCompat.clonePaletteZones(stable)
    end
    -- A dialogue opened before this mod observed a normal gameplay frame.
    -- Do not invent a palette; retain the engine result until a stable frame
    -- can be cached. This is restricted to unusual mid-load enable/reload.
    return zones
  end

  GoldCompat.__lastStableGen1Zones=GoldCompat.clonePaletteZones(zones)
  return zones
end

-- The current renderer has two independent palette inputs: `zones` for the
-- UI canvas and `worldZones` for the overworld canvas. render.zones can only
-- change the former. During Gen I TextBox ownership, Game:draw can
-- intermittently pass nil for worldZones; Renderer:endFrame then falls back
-- to the UI zones, producing the full-screen red flashes seen in captures.
--
-- RED++ deliberately uses an EMPTY worldZones table as a meaningful sentinel:
-- the overworld atlas is already true-color, so Renderer must plain-blit it
-- instead of running the UI shade-remap shader over it. Never use #zones > 0
-- as the validity test here. An empty table is the most important stable value
-- to retain; only nil/non-table means the world-specific input is absent.
function GoldCompat.installGen1WorldZoneSafety()
  if GoldCompat.__gen1WorldZoneSafetyInstalled then return end
  local ok,Renderer=pcall(require,"src.render.Renderer")
  if not (ok and Renderer and type(Renderer.endFrame)=="function") then return end
  GoldCompat.__gen1WorldZoneSafetyInstalled=true
  local originalEndFrame=Renderer.endFrame
  Renderer.endFrame=function(renderer,zones,worldZones,...)
    local game=GoldCompat.game
    if GoldCompat.generation=="gen1" and game
        and featureEnabled("revampedDialogueBoxes") then
      local locked=GoldCompat.dialoguePaletteLockActive(game)
      if locked then
        if type(GoldCompat.__lastStableGen1WorldZones)=="table" then
          if type(worldZones)~="table"
              and not GoldCompat.__loggedWorldZoneSafety then
            GoldCompat.__loggedWorldZoneSafety=true
            if modRef and modRef.log then
              modRef.log:info("Colosseum UI 1.1.0: blocked missing Gen I dialogue worldZones fallback")
            end
          end
          worldZones=GoldCompat.clonePaletteZones(
            GoldCompat.__lastStableGen1WorldZones)
        elseif type(worldZones)=="table" then
          -- First observed frame may already contain a newly-pushed TextBox.
          -- Its table (including RED++'s intentional empty sentinel) is a
          -- valid seed; only a later nil causes the dangerous UI-zone fallback.
          GoldCompat.__lastStableGen1WorldZones=
            GoldCompat.clonePaletteZones(worldZones)
        end
      elseif type(worldZones)=="table" then
        GoldCompat.__lastStableGen1WorldZones=
          GoldCompat.clonePaletteZones(worldZones)
      end
    end
    return originalEndFrame(renderer,zones,worldZones,...)
  end
end

function GoldCompat.installGen1TransientPaletteGuard()
  if GoldCompat.__gen1TransientPaletteGuard then return end
  GoldCompat.__gen1TransientPaletteGuard=true
  local ok,OverworldState=pcall(require,"src.world.OverworldController")
  if not (ok and OverworldState and type(OverworldState.stepHealAnim)=="function") then return end
  local nativeStepHealAnim=OverworldState.stepHealAnim
  OverworldState.stepHealAnim=function(ha,...)
    local result=nativeStepHealAnim(ha,...)
    -- API-v2 launcher currently reuses the heal-machine palette shader in a
    -- way that can tint the complete Gen I frame red during FlashSprite8Times.
    -- Keep the machine art on its normal palette rather than exposing that
    -- broken whole-frame flash. Gameplay timing/callbacks are untouched.
    if GoldCompat.generation=="gen1" and ha then ha.visible=true end
    return result
  end
end

local function installDialogueThemeDirect(mod)
  GoldCompat.installGen1TransientPaletteGuard()
  GoldCompat.installGen1WorldZoneSafety()
  -- API v2 asks opacity before draw(), so these two primitives must advertise
  -- overlay ownership at class level. Older launcher builds effectively treated
  -- the absence of isOpaque this way; making it explicit prevents one-frame
  -- red/black base-screen flashes during chained dialogue and menu handoffs.
  TextBox.isOpaque=false
  ChoiceBox.isOpaque=false
  local originalTextUpdate=TextBox.update
  TextBox.update=function(self,dt)
    -- Gen I can complete and replace script-owned dialogue states between the
    -- main-screen draw and the final HUD pass.  Under API v2 that made our
    -- presentation ownership arrive one frame late, exposing the palette/base
    -- canvas as a red flash.  Claim the live dialogue during UPDATE instead of
    -- waiting for TextBox.draw; input/typewriter behavior remains native.
    if GoldCompat.generation=="gen1" and featureEnabled("revampedDialogueBoxes") then
      self.isOpaque=false
      State.activeDialogueBox=self
      GoldCompat.__gen1DialoguePaletteOwner=self
    end
    if featureEnabled("revampedSaveUI")
        and GoldCompat.isGen1SavePromptBox(self) then
      GoldCompat.__activeSavePromptBox=self
      if not self.__colosseumSaveAuto then
        self.__colosseumSaveAuto=true
        -- Finish the informational summary and hand the completed TextBox
        -- directly to its native choice branch,
        -- which constructs the real save ChoiceBox without a redundant press.
        -- Never assign `auto`: TextBox processes auto before choice and would
        -- pop this owner without creating the YES/NO state.
        local page=self.pages and self.pages[#self.pages] or {""}
        self.pageIndex=math.max(1,#(self.pages or {}))
        self.lineIndex=math.max(1,#page)
        self.shown={}
        for i=math.max(1,#page-1),#page do
          self.shown[#self.shown+1]=EngineFont.encode(tostring(page[i] or ""))
        end
        self.codes=self.shown[#self.shown] or {}
        self.charIndex=#self.codes
        self.waiting=false
        self.done=true
        self.auto=nil
      end
    end
    -- Never synthesize a pop/onDone transition here. Gen I's native TextBox
    -- owns page acknowledgement and constructs the authoritative ChoiceBox;
    -- bypassing that lifecycle is what made SAVE appear but fail to commit.
    return originalTextUpdate(self,dt)
  end

  local originalChoiceNew=ChoiceBox.new
  ChoiceBox.new=function(game,onChoose,opts)
    local choice=originalChoiceNew(game,onChoose,opts)
    -- Instance-level opacity is intentional.  Other UI/mod wrappers may copy
    -- or shadow class fields, while StateStack.visibleBase reads the instance
    -- visible through __index.  Pinning it here removes the Gen I one-frame
    -- opaque handoff without changing ChoiceBox callbacks or hold timing.
    if choice and featureEnabled("revampedDialogueBoxes") then
      choice.isOpaque=false
    end
    if GoldCompat.__activeSavePromptBox then
      choice.__colosseumSavePrompt=GoldCompat.__activeSavePromptBox
    end
    local stackStates=game and game.stack and game.stack.states
    local owner=type(stackStates)=="table" and stackStates[#stackStates] or nil
    if owner and (owner.__colosseumNicknamePrompt
        or GoldCompat.isNicknamePromptBox(owner)) then
      owner.__colosseumNicknamePrompt=true
      choice.__colosseumNicknameChoice=true
    end

    -- A ChoiceBox belongs to the TextBox directly underneath it. Do not scan
    -- older boxes lower in the stack when deciding whether this is the lab's
    -- starter confirmation. During AddPartyMon/AskName the completed starter
    -- question can still be underneath the new nickname question for the same
    -- frame; scanning the whole stack then mislabels the nickname YES/NO as a
    -- starter choice and steals its presentation/input handoff. This is the
    -- shared Red/Blue starter and Yellow Pikachu-gift failure mode.
    local starterBox,starterSpecies=nil,nil
    if not choice.__colosseumNicknameChoice and owner
        and (owner.isTextBox or getmetatable(owner)==TextBox) then
      starterSpecies=GoldCompat.starterSpeciesFromTextBox(owner)
      if starterSpecies then starterBox=owner end
    end
    if starterSpecies and GoldCompat.starterPresentationEnabled() then
      choice.__colosseumStarterSpecies=starterSpecies
      choice.__colosseumStarterTextBox=starterBox
      starterBox.__colosseumStarterChoiceOpen=true

      -- The custom starter card owns the species portrait completely.  Both
      -- generations can leave a native preview surface alive underneath the
      -- YES/NO handoff (Gen I StarterDex, Gen II pokepic).  Clear only those
      -- starter-preview presentation remnants here so a previous starter can
      -- never bleed beside the currently selected portrait.  Script state,
      -- choice callbacks, gift flags, and the actual starter remain native.
      if DexUI then DexUI.entry=nil end
      local world=game and (game.world or game.overworld)
      if world and world.pokePic~=nil then
        world.pokePic=nil
        world.pokePicName=nil
        world.pokePicColors=nil
      end
      if type(stackStates)=="table" then
        for i=#stackStates,1,-1 do
          local state=stackStates[i]
          if state and state.__colosseumStarterDexPreview then
            state.__colosseumStarterDexDone=true
          end
        end
      end
    elseif GoldCompat.safariContext(game)
        and featureEnabled("revampedDialogueBoxes")
        and GoldCompat.safariPresentationEnabled() then
      choice.__colosseumSafariChoice=true
    end
    return choice
  end

  local originalChoiceUpdate=ChoiceBox.update
  ChoiceBox.update=function(self,dt)
    if GoldCompat.generation=="gen1" and featureEnabled("revampedDialogueBoxes") then
      self.isOpaque=false
      State.activeChoiceBox=self
      GoldCompat.__gen1DialoguePaletteOwner=self
    end
    if self.pending==nil then
      local input=self.game and self.game.input
      if self.__colosseumStarterSpecies
          and GoldCompat.starterPresentationEnabled() and input then
        -- The starter card is horizontal. Accept either axis so keyboard,
        -- controller, and touch-to-dpad mappings all produce an obvious move.
        if input:wasPressed("left") or input:wasPressed("up") then
          self.index=1
          return
        elseif input:wasPressed("right") or input:wasPressed("down") then
          self.index=2
          return
        end
      elseif self.__colosseumNicknameChoice
          and GoldCompat.flowPresentationEnabled("naming") and input then
        -- Nickname prompts have moved between vertical and horizontal visual
        -- treatments during the overhaul. Keep the native A/B callback and
        -- hold timing, but make both directional axes select deterministically.
        if input:wasPressed("left") or input:wasPressed("up") then
          self.index=1
          return
        elseif input:wasPressed("right") or input:wasPressed("down") then
          self.index=2
          return
        end
      end
    end
    return originalChoiceUpdate(self,dt)
  end

  local originalTextBoxDraw = TextBox.draw
  TextBox.draw = function(self)
    if self.__colosseumStarterChoiceOpen and GoldCompat.starterPresentationEnabled() then
      -- The starter card replaces the completed question while the native
      -- ChoiceBox owns input; do not leave a handheld dialogue strip behind it.
      State.activeDialogueBox=self
      return
    end
    if not featureEnabled("revampedDialogueBoxes") then
      State.activeDialogueBox = nil
      return originalTextBoxDraw(self)
    end

    -- Revamped mode is exclusive: suppress the vanilla box completely.
    -- Mark this TextBox for final-HUD rendering in the current frame.
    State.activeDialogueBox = self
    if GoldCompat.generation=="gen1" then
      GoldCompat.__gen1DialoguePaletteOwner=self
    end

    -- Preserve the only draw-time state mutation from vanilla TextBox.draw:
    -- the 8px scroll animation decays by 2px per rendered frame.
    if self.scrollPx and self.scrollPx > 0 then
      self.scrollPx = self.scrollPx - 2
      if self.scrollPx <= 0 then self.scrollPx = nil end
    end

    local r = self.game and self.game.renderer
    if r and r.setUIAnchor then
      r:setUIAnchor(self.boxTx * 8, self.boxTy * 8,
                    self.boxTw * 8, self.boxTh * 8, "bottom")
    end
  end

  local originalChoiceDraw = ChoiceBox.draw
  ChoiceBox.draw = function(self)
    if self.__colosseumStarterSpecies and GoldCompat.starterPresentationEnabled() then
      State.activeChoiceBox=self
      return
    end
    if self.__colosseumNicknameChoice
        and GoldCompat.flowPresentationEnabled("naming") then
      State.activeChoiceBox=self
      return
    end
    if not featureEnabled("revampedDialogueBoxes") then
      State.activeChoiceBox = nil
      return originalChoiceDraw(self)
    end

    -- Same exclusive behavior for YES / NO and other ChoiceBox prompts.
    State.activeChoiceBox = self
    if GoldCompat.generation=="gen1" then
      GoldCompat.__gen1DialoguePaletteOwner=self
    end
  end

  if mod.log then
    mod.log:info("Colosseum Inspired UI Overhaul: dialogue overlay installed")
  end
end


-- Entry
-- -------------------------------------------------------------------------


local function installPCIntegration()
  -- Bill's PC uses generic Menu/ListMenu classes internally. Mark only the
  -- exact PC-owned instances so our renderer stays compatible with unrelated
  -- menus and other mods.
  local originalBoxMenuNew=BoxMenu.new
  BoxMenu.new=function(game,...)
    local menu=originalBoxMenuNew(game,...)
    if menu then
      menu.__gen3uiPCMain=true
      if featureEnabled("revampedPokemonPC") then menu.isOpaque=false end

      -- BoxMenu installs a per-instance draw() that appends the native
      -- "What?" / "BOX No." chrome after Menu.draw. Replace only THIS
      -- BoxMenu instance's presentation hook; update/input remain native.
      local nativeBoxDraw=menu.draw
      menu.draw=function(self)
        if not featureEnabled("revampedPokemonPC") then
          return nativeBoxDraw(self)
        end
        State.activePCMenu=self
      end
    end
    return menu
  end

  local originalMenuNew=Menu.new
  Menu.new=function(game,items,opts,...)
    local menu=originalMenuNew(game,items,opts,...)
    if menu then
      local first=shopMenuLabel(items and items[1])
      local second=shopMenuLabel(items and items[2])

      -- Every out-of-battle Bag item goes through this shared USE/TOSS menu
      -- before TM/HM or evolution-stone targeting. Mark it immediately and
      -- prevent its native opaque screen from clearing the frame white.
      if type(items)=="table" and #items==2
          and first=="USE" and second=="TOSS" then
        menu.__gen3uiBagAction=true
        if GoldCompat.bagPresentationEnabled() then menu.isOpaque=false end
      elseif type(items)=="table" and DexUI.active then
        local dexHits=0
        for _,entry in ipairs(items) do
          local label=shopMenuLabel(entry)
          if label=="DATA" or label=="CRY" or label=="AREA"
              or label=="QUIT" or label=="CANCEL" then
            dexHits=dexHits+1
          end
        end
        if dexHits>=2 then
          menu.__gen3uiPokedexAction=true
          if featureEnabled("revampedPokedex") then menu.isOpaque=false end
          DexUI.action=menu
        elseif shopMainItems(items) then
          menu.__gen3uiShopMain=true
          if featureEnabled("revampedPokeMartUI") then menu.isOpaque=false end
        elseif pcAccessItems(items) then
          menu.__gen3uiPCAccess=true
          if featureEnabled("revampedPokemonPC") then menu.isOpaque=false end
        elseif pcMainItems(items) then
          menu.__gen3uiPCMain=true
          if featureEnabled("revampedPokemonPC") then menu.isOpaque=false end
        elseif pcActionItems(items) then
          menu.__gen3uiPCAction=true
          if featureEnabled("revampedPokemonPC") then menu.isOpaque=false end
        end
      elseif shopMainItems(items) then
        menu.__gen3uiShopMain=true
        if featureEnabled("revampedPokeMartUI") then menu.isOpaque=false end
      elseif pcItemRootItems(items) then
        menu.__gen3uiPCItemRoot=true
        if GoldCompat.itemPcPresentationEnabled() then menu.isOpaque=false end
        -- The redesigned Item Storage root is a horizontal action rail. Keep
        -- the native Menu as the action/callback authority, but map LEFT/RIGHT
        -- onto its index so the controls match what is on screen. UP/DOWN still
        -- fall through to native behavior for controller/accessibility parity.
        local nativePCItemRootUpdate=menu.update
        menu.update=function(self,dt)
          if GoldCompat.itemPcPresentationEnabled() then
            local input=self.game and self.game.input
            local left=input and input:wasPressed("left")
            local right=input and input:wasPressed("right")
            if left or right then
              local count=#(self.items or {})
              if count>0 then
                local previous=math.max(1,math.min(count,tonumber(self.index) or 1))
                if left then
                  self.index=(previous>1) and previous-1 or count
                else
                  self.index=(previous<count) and previous+1 or 1
                end
                if self.clampScroll then self:clampScroll() end
              end
              return
            end
          end
          return nativePCItemRootUpdate(self,dt)
        end
      elseif pcAccessItems(items) then
        menu.__gen3uiPCAccess=true
        if featureEnabled("revampedPokemonPC") then menu.isOpaque=false end
      elseif pcMainItems(items) then
        menu.__gen3uiPCMain=true
        if featureEnabled("revampedPokemonPC") then menu.isOpaque=false end
      elseif pcActionItems(items) then
        menu.__gen3uiPCAction=true
        if featureEnabled("revampedPokemonPC") then menu.isOpaque=false end
      end
    end
    return menu
  end

  local originalListMenuNew=ListMenu.new
  ListMenu.new=function(game,title,items,opts,...)
    local list=originalListMenuNew(game,title,items,opts,...)
    local upperTitle=tostring(title or ""):upper()

    -- Gen I PP UP / ETHER / MAX ETHER all enter the same native ListMenu
    -- titled exactly "Which move?" after the Party target is chosen. Keep that
    -- authoritative list/callback, but make it a child of our Party deck instead
    -- of allowing the cartridge-white move picker to take over the screen.
    if list and GoldCompat.generation=="gen1" and upperTitle=="WHICH MOVE?"
        and GoldCompat.pokemonPresentationEnabled() then
      list.__gen3uiPPMovePicker=true
      list.isOpaque=false
      local party=State.activeItemTargetParty or State.activeParty
      list.__gen3uiPPParty=party
      if party then
        party.__gen3uiPPMoveParty=true
        party.isOpaque=false
      end
      local nativePPUpdate=list.update
      list.update=function(self,dt)
        self.isOpaque=false
        local input=self.game and self.game.input
        local pressed=input and input.pressed
        if type(pressed)=="table" then
          local savedUp,savedDown=pressed.up,pressed.down
          if pressed.left and not pressed.up then pressed.up=pressed.left end
          if pressed.right and not pressed.down then pressed.down=pressed.right end
          local ok,result=pcall(nativePPUpdate,self,dt)
          pressed.up,pressed.down=savedUp,savedDown
          if not ok then error(result) end
          return result
        end
        return nativePPUpdate(self,dt)
      end
    elseif list and (upperTitle=="POKéDEX" or upperTitle=="POKEDEX") then
      list.__gen3uiPokedex=true
      if featureEnabled("revampedPokedex") then list.isOpaque=false end
      DexUI.active=list

      -- SELECT cycles the dossier's lower info block through every known
      -- area/method for the selected species, one at a time, then back to
      -- the normal TYPE/ABILITY/HEIGHT/WEIGHT view -- the same convention
      -- Gen 2's native Pokédex already uses SELECT for. Gen 1 ONLY: Gen 2's
      -- PokedexMenu already has its own complete, working select/location
      -- view state machine, so wrapping this generically here would double
      -- up on that native handling for any Gen 2 list sharing this title.
      if GoldCompat.generation=="gen1" then
      list.__gen3uiDexLocationPage=0
      list.__gen3uiDexLastIndex=list.index
      local nativeDexUpdate=list.update
      list.update=function(self,dt)
        if self.index~=self.__gen3uiDexLastIndex then
          self.__gen3uiDexLastIndex=self.index
          self.__gen3uiDexLocationPage=0
        end
        local input=self.game and self.game.input
        if input and featureEnabled("revampedPokedex")
            and input:wasPressed("select") then
          local dexIndex=self.__gen3uiDexIndex or DexUI.buildIndex(self.game)
          self.__gen3uiDexIndex=dexIndex
          local total=#self.items
          local selected=clamp(self.index or 1,1,math.max(1,total))
          local entry=dexIndex[selected]
          local speciesId=entry and entry.id
          local dex=(self.game.save and self.game.save.pokedex) or {}
          local seen=speciesId and ((dex.seen and dex.seen[speciesId])
            or (dex.caught and dex.caught[speciesId])
            or (dex.owned and dex.owned[speciesId]))
          local pageCount=seen and speciesId
            and #DexUI.encounterDisplayRows(self.game,speciesId) or 0
          if pageCount>0 then
            self.__gen3uiDexLocationPage=
              ((self.__gen3uiDexLocationPage or 0)+1)%(pageCount+1)
            pcall(function()
              require("src.core.Sound").play(self.game.data,"Press_AB")
            end)
          end
          return
        end
        return nativeDexUpdate(self,dt)
      end
      end
    elseif list and opts and opts.dialogue
        and (upperTitle=="BUY" or upperTitle=="SELL") then
      list.__gen3uiShopList=true
      list.__gen3uiShopSell=(upperTitle=="SELL")
      if featureEnabled("revampedPokeMartUI") then list.isOpaque=false end
    elseif list and GoldCompat.pcItemListTitle(title) then
      list.__gen3uiPCItemList=true
      list.__gen3uiPCItemMode=upperTitle:gsub(" ITEM$","")
      if GoldCompat.itemPcPresentationEnabled() then list.isOpaque=false end
    elseif list and GoldCompat.pcListTitle(title) then
      list.__gen3uiPCList=true
      if featureEnabled("revampedPokemonPC") then list.isOpaque=false end
      local nativePCUpdate=list.update
      list.update=function(self,dt)
        if not featureEnabled("revampedPokemonPC") then
          return nativePCUpdate(self,dt)
        end
        if upperTitle=="CHANGE BOX" then
          return nativePCUpdate(self,dt)
        end
        if upperTitle:find("DEPOSIT",1,true) then
          -- This presentation is a vertical six-member party list, so native
          -- up/down and cancel navigation is already the exact desired model.
          return nativePCUpdate(self,dt)
        end
        local input=self.game and self.game.input
        if not input then return nativePCUpdate(self,dt) end
        local left=input:wasPressed("left")
        local right=input:wasPressed("right")
        local up=input:wasPressed("up")
        local down=input:wasPressed("down")
        if left or right or up or down then
          local count=#(self.items or {})
          local cancelIndex=nil
          if count>0 then
            local last=self.items[count]
            local label=tostring(last and last.label or ""):upper()
            if label:find("CANCEL",1,true) or label:find("BACK",1,true) then
              cancelIndex=count
            end
          end
          local gridCount=cancelIndex and cancelIndex-1 or count
          local index=math.max(1,math.min(tonumber(self.index) or 1,math.max(1,count)))
          local nextIndex=index
          if cancelIndex and index==cancelIndex then
            if up then nextIndex=self.__colosseumPcLastBadge or math.max(1,gridCount-3) end
          else
            self.__colosseumPcLastBadge=index
            local col=(index-1)%4
            if left and col>0 then
              nextIndex=index-1
            elseif right and col<3 and index<gridCount then
              nextIndex=index+1
            elseif up and index>4 then
              nextIndex=index-4
            elseif down then
              if index+4<=gridCount then
                nextIndex=index+4
              elseif cancelIndex then
                self.__colosseumPcLastBadge=index
                nextIndex=cancelIndex
              end
            end
          end
          if nextIndex~=index then
            self.index=nextIndex
            self.scroll=0
            pcall(function()
              require("src.core.Sound").play(self.game.data,"Press_AB")
            end)
          end
          return
        end
        return nativePCUpdate(self,dt)
      end
    end
    return list
  end
end


local function handleModOptionChanged(mod,payload)
  if not payload or payload.mod ~= mod.id then return end

  if payload.key == "colosseumBattleUI" and payload.value == false then
    clearBattleUIState()
  elseif payload.key == "colosseumPokemonMenu" and payload.value == false then
    clearPokemonUIState()
    DexUI.summary=nil
  elseif payload.key == "revampedOverworldMenus" and payload.value == false then
    clearOverworldMenuState()
  elseif payload.key == "revampedPokeMartUI" and payload.value == false then
    clearShopUIState()
  elseif payload.key == "revampedPokemonPC" and payload.value == false then
    clearPCUIState()
  elseif payload.key == "revampedPokedex" and payload.value == false then
    DexUI.active=nil
    DexUI.action=nil
    DexUI.entry=nil
  elseif payload.key == "revampedDialogueBoxes" and payload.value == false then
    State.activeDialogueBox=nil
    State.activeChoiceBox=nil
  elseif payload.key == "revampedBagUI" and payload.value == false then
    State.activeBagMenu=nil
    State.activeBagActionMenu=nil
  elseif payload.key == "revampedItemPCUI" and payload.value == false then
    clearPCUIState()
  elseif payload.key == "revampedMoveManagerUI" and payload.value == false then
    if DexUI.summary then DexUI.summary.__colosseumMoveManager=nil end
  elseif payload.key == "revampedStarterUI" and payload.value == false then
    if State.activeChoiceBox then
      State.activeChoiceBox.__colosseumStarterSpecies=nil
      State.activeChoiceBox.__colosseumStarterTextBox=nil
    end
  elseif payload.key == "revampedSafariUI" and payload.value == false then
    if State.activeChoiceBox then State.activeChoiceBox.__colosseumSafariChoice=nil end
    if State.activeBattle and GoldCompat.resolvedSafariState(State.activeBattle) then
      State.activeBattle=nil
    end
  elseif payload.key == "revampedLocationBannerUI" and payload.value == false then
    State.locationBannerName=nil
    State.locationBannerPending=nil
    State.locationBannerStarted=nil
  end
end


local goldBattleScrubInstalled=false

function GoldCompat.cleanGearText(value)
  local text=tostring(value or "")
  text=text:gsub("<PK><MN>","POKEMON"):gsub("#MON","POKEMON")
  text=text:gsub("[%c]+"," "):gsub("%s+"," ")
  return (text:gsub("^%s+",""):gsub("%s+$",""))
end

function GoldCompat.drawGearWrapped(value,x,y,w,maxLines,size,color,lineGap)
  local text=GoldCompat.cleanGearText(value)
  local f=font(math.max(4,(tonumber(size) or 12)*UI_TEXT_SCALE*
    GoldCompat.userTextScale()))
  local _,lines=f:getWrap(text,math.max(1,w))
  local step=(tonumber(size) or 12)+(lineGap or 4)
  for i=1,math.min(maxLines or #lines,#lines) do
    printText(lines[i],x,y+(i-1)*step,size,color,"left",w)
  end
end

-- PokéGear is drawn in display pixels rather than the 160x144 logical canvas.
-- Fit every dense single-line label against the active profile's real glyph
-- metrics so wider/taller accessibility fonts reshape the typography instead
-- of wrapping into the next control.
function GoldCompat.drawGearFitted(value,x,y,w,h,size,minSize,color,align)
  local text=GoldCompat.cleanGearText(value)
  local candidate=tonumber(size) or 12
  local floorSize=math.min(candidate,tonumber(minSize) or 7)
  local function metrics(s)
    local f=font(math.max(4,s*UI_TEXT_SCALE*GoldCompat.userTextScale()))
    return f:getWidth(text),f:getHeight()
  end
  local tw,th=metrics(candidate)
  local widthScale=math.max(1,w-2)/math.max(1,tw)
  local heightScale=math.max(1,h)/math.max(1,th)
  local fitScale=math.min(1,widthScale,heightScale)
  if fitScale<1 then
    -- Font dimensions are effectively linear with point size. Jump directly
    -- to the fitted half-point instead of constructing every intermediate
    -- font on PokéGear's first frame.
    candidate=math.max(floorSize,math.floor(candidate*fitScale*2)/2)
    tw,th=metrics(candidate)
  end
  printText(text,x,y+math.max(0,(h-th)*0.5),candidate,color,align or "left",w)
end

function GoldCompat.drawGearClock(self,x,y,w,h)
  local G=love.graphics
  local hour,minute,weekday=self:clockParts()
  hour=tonumber(hour) or 0
  minute=tonumber(minute) or 0
  weekday=tonumber(weekday) or 1
  local days={"SUNDAY","MONDAY","TUESDAY","WEDNESDAY",
    "THURSDAY","FRIDAY","SATURDAY"}
  local display=hour%12
  if display==0 then display=12 end
  local period=hour<12 and "AM" or "PM"
  local daytime=(hour>=4 and hour<10) and "MORNING"
    or (hour>=10 and hour<18) and "DAY" or "NIGHT"
  local region="JOHTO"
  if type(self.region)=="function" then
    local ok,value=pcall(self.region,self)
    if ok and value then region=tostring(value):upper() end
  end

  local leftW=math.floor(w*0.64)
  G.setColor(0.008,0.055,0.050,0.94)
  G.rectangle("fill",x+12,y+14,leftW-18,h-28,14,14)
  G.setColor(0.22,0.52,0.47,0.94)
  G.setLineWidth(2)
  G.rectangle("line",x+12,y+14,leftW-18,h-28,14,14)
  G.setColor(0.015,0.11,0.075,0.94)
  G.rectangle("fill",x+28,y+36,leftW-50,math.max(84,h*0.35),10,10)
  G.setColor(0.13,0.78,0.34,0.85)
  G.rectangle("line",x+28,y+36,leftW-50,math.max(84,h*0.35),10,10)

  GoldCompat.drawGearFitted(days[((weekday-1)%7)+1],x+30,y+47,leftW-54,42,
    math.max(18,math.floor(h*0.055)),11,{0.45,1.00,0.58,1},"center")
  GoldCompat.drawGearFitted(("%02d:%02d"):format(display,minute),x+28,y+78,
    leftW-50,112,math.max(42,math.floor(h*0.16)),24,
    {0.97,1.00,0.97,1},"center")
  printText(period,x+leftW-86,y+104,math.max(15,math.floor(h*0.052)),
    {0.98,0.72,0.31,1},"center",56)
  printText("GAME CLOCK",x+28,y+h-70,13,{0.43,0.68,0.61,1},"left",leftW-50)
  printText("Updates from the active save RTC.",x+28,y+h-48,13,
    {0.72,0.85,0.79,1},"left",leftW-50)

  local rx=x+leftW+8
  local rw=w-leftW-20
  local cards={{"TIME OF DAY",daytime},{"REGION",region},
    {"STATUS","CLOCK ONLINE"}}
  local cardH=(h-52)/#cards
  for i,row in ipairs(cards) do
    local yy=y+14+(i-1)*(cardH+6)
    G.setColor(0.008,0.047,0.051,0.90)
    G.rectangle("fill",rx,yy,rw,cardH,10,10)
    G.setColor(0.22,0.48,0.46,0.90)
    G.rectangle("line",rx,yy,rw,cardH,10,10)
    GoldCompat.drawGearFitted(row[1],rx+16,yy+8,rw-32,24,12,8,
      {0.38,0.89,0.54,1},"left")
    GoldCompat.drawGearFitted(row[2],rx+16,yy+33,rw-32,30,17,10,
      {0.96,0.99,0.96,1},"left")
  end
end

function GoldCompat.drawGearPhone(self,x,y,w,h)
  local G=love.graphics
  local okPhone,Phone=pcall(require,"src.core.gen2.Phone")
  local signal=true
  if okPhone and Phone and type(Phone.mapHasService)=="function" then
    local ok,value=pcall(Phone.mapHasService,self:phoneContext())
    if ok then signal=value==true end
  end

  local leftW=math.floor(w*0.55)
  local gap=14
  local rightX=x+leftW+gap
  local rightW=w-leftW-gap
  G.setColor(0.007,0.043,0.046,0.94)
  G.rectangle("fill",x,y,leftW,h,12,12)
  G.setColor(0.23,0.50,0.48,0.94)
  G.setLineWidth(2)
  G.rectangle("line",x,y,leftW,h,12,12)
  G.setColor(0.007,0.043,0.046,0.94)
  G.rectangle("fill",rightX,y,rightW,h,12,12)
  G.setColor(0.23,0.50,0.48,0.94)
  G.rectangle("line",rightX,y,rightW,h,12,12)

  printText("CONTACTS",x+18,y+14,15,{0.39,0.97,0.57,1},"left",leftW-36)
  printText(signal and "SIGNAL  GOOD" or "NO SERVICE",x+leftW-165,y+15,12,
    signal and {0.47,1.00,0.58,1} or {1.00,0.46,0.28,1},"right",145)
  G.setColor(signal and {0.22,0.87,0.42,1} or {0.58,0.22,0.17,1})
  for i=1,4 do G.rectangle("fill",x+leftW-26+i*5,y+41-i*4,3,i*4) end

  local list=self:phoneList() or {}
  local rowH=math.max(62,math.floor((h-78)/4))
  for visible=1,4 do
    local absolute=(self.phoneScroll or 0)+visible
    local id=list[absolute] or 0
    local label,className=self:contactRow(id)
    label=GoldCompat.cleanGearText(label):gsub(":$","")
    local yy=y+54+(visible-1)*rowH
    local selected=(visible-1)==(self.phoneCursor or 0)
    G.setColor(selected and {0.035,0.29,0.23,0.98}
      or {0.010,0.075,0.069,0.82})
    G.rectangle("fill",x+12,yy,leftW-24,rowH-7,9,9)
    G.setColor(selected and {0.96,0.34,0.15,1}
      or {0.16,0.39,0.37,0.84})
    G.rectangle("fill",x+12,yy,selected and 5 or 2,rowH-7,5,5)
    if selected then
      local cy=yy+(rowH-7)*0.5
      G.polygon("fill",x+4,cy,x+14,cy-8,x+14,cy+8)
    end
    GoldCompat.drawGearFitted(label,x+28,yy+6,leftW-50,26,16,9,
      selected and {1,1,1,1} or {0.75,0.87,0.82,1},"left")
    if className then
      GoldCompat.drawGearFitted(className,x+28,yy+31,leftW-50,20,12,8,
        {0.42,0.76,0.63,1},"left")
    end
  end

  local selectedId=self:phoneSelection()
  local selectedName,selectedClass=self:contactRow(selectedId)
  selectedName=GoldCompat.cleanGearText(selectedName):gsub(":$","")
  selectedClass=GoldCompat.cleanGearText(selectedClass)
  printText(self.call and "CALL CONNECTED" or "PHONE CONSOLE",
    rightX+18,y+15,15,self.call and {0.48,1.00,0.58,1}
      or {0.39,0.97,0.57,1},"left",rightW-36)
  G.setColor(0.01,0.09,0.075,0.90)
  G.rectangle("fill",rightX+14,y+50,rightW-28,82,9,9)
  G.setColor(0.20,0.44,0.41,0.90)
  G.rectangle("line",rightX+14,y+50,rightW-28,82,9,9)
  GoldCompat.drawGearFitted(selectedName,rightX+28,y+59,rightW-56,34,22,11,
    {0.98,1.00,0.98,1},"left")
  GoldCompat.drawGearFitted(selectedClass~="" and selectedClass or "POKEGEAR CONTACT",
    rightX+28,y+94,rightW-56,24,13,8,{0.48,0.81,0.66,1},"left")

  local message
  if self.call then message=self.call.text or "Call in progress."
  elseif not signal then message="Calls are unavailable from this location."
  elseif selectedId and selectedId~=0 then
    message="Press A to open the contact actions."
  else message="No phone number is stored in this slot." end
  G.setColor(0.006,0.028,0.032,0.92)
  G.rectangle("fill",rightX+14,y+147,rightW-28,h-166,9,9)
  G.setColor(0.18,0.40,0.39,0.88)
  G.rectangle("line",rightX+14,y+147,rightW-28,h-166,9,9)
  GoldCompat.drawGearWrapped(message,rightX+28,y+166,rightW-56,7,15,
    {0.86,0.94,0.89,1},7)

  local Pokegear=require("src.ui.gen2.Pokegear")
  local menu=Pokegear.PHONE_SUBMENUS and
    Pokegear.PHONE_SUBMENUS[self.phoneSubmenu or ""]
  if menu then
    local mh=18+#menu.entries*39
    local mx,my=rightX+rightW-188,y+h-mh-18
    G.setColor(0.012,0.040,0.043,0.99)
    G.rectangle("fill",mx,my,170,mh,10,10)
    G.setColor(0.30,0.62,0.57,1)
    G.rectangle("line",mx,my,170,mh,10,10)
    for i,label in ipairs(menu.entries) do
      local yy=my+12+(i-1)*39
      local selected=(i-1)==(self.phoneSubmenuCursor or 0)
      if selected then
        G.setColor(0.05,0.31,0.25,1)
        G.rectangle("fill",mx+8,yy,154,31,7,7)
        G.setColor(0.98,0.34,0.15,1)
        G.polygon("fill",mx+2,yy+15,mx+11,yy+8,mx+11,yy+22)
      end
      GoldCompat.drawGearFitted(label,mx+24,yy+3,128,27,14,8,
        selected and {1,1,1,1} or {0.66,0.82,0.76,1},"left")
    end
  end
end

function GoldCompat.drawGearRadio(self,x,y,w,h)
  local G=love.graphics
  if type(self.ensureTuned)=="function" then pcall(self.ensureTuned,self) end
  local station=self.currentStation and self:currentStation() or nil
  local stations=self.stations and self:stations() or {}
  local tuned=math.max(1,math.min(tonumber(self.station) or 1,math.max(1,#stations)))
  local dialW=math.floor(w*0.42)
  G.setColor(0.007,0.043,0.046,0.94)
  G.rectangle("fill",x,y,dialW,h,12,12)
  G.setColor(0.23,0.50,0.48,0.94)
  G.rectangle("line",x,y,dialW,h,12,12)
  G.setColor(0.007,0.043,0.046,0.94)
  G.rectangle("fill",x+dialW+14,y,w-dialW-14,h,12,12)
  G.setColor(0.23,0.50,0.48,0.94)
  G.rectangle("line",x+dialW+14,y,w-dialW-14,h,12,12)
  printText("TUNER",x+18,y+15,15,{0.39,0.97,0.57,1},"left",dialW-36)
  local first=math.max(1,math.min(tuned-3,math.max(1,#stations-6)))
  for row=1,7 do
    local idx=first+row-1
    local s=stations[idx]
    if s then
      local yy=y+54+(row-1)*math.max(43,math.floor((h-76)/7))
      local selected=idx==tuned
      if selected then
        G.setColor(0.045,0.31,0.24,0.98)
        G.rectangle("fill",x+12,yy-6,dialW-24,35,8,8)
        G.setColor(0.98,0.34,0.15,1)
        G.polygon("fill",x+4,yy+11,x+14,yy+3,x+14,yy+19)
      end
      printText(("%02d"):format(idx),x+24,yy,13,
        selected and {1,1,1,1} or {0.52,0.70,0.64,1})
      printText(GoldCompat.cleanGearText(s.name or "STATIC"),x+63,yy,14,
        selected and {1,1,1,1} or {0.67,0.82,0.76,1},"left",dialW-82)
    end
  end
  local rx=x+dialW+14
  local rw=w-dialW-14
  printText(station and GoldCompat.cleanGearText(station.name) or "DEAD AIR",
    rx+20,y+18,24,{0.97,1.00,0.97,1},"left",rw-40)
  printText(station and "LIVE BROADCAST" or "NO STATION",
    rx+20,y+55,13,station and {0.45,1.00,0.58,1}
      or {0.95,0.48,0.28,1},"left",rw-40)
  G.setColor(0.008,0.075,0.064,0.90)
  G.rectangle("fill",rx+18,y+92,rw-36,h-118,10,10)
  G.setColor(0.18,0.43,0.40,0.92)
  G.rectangle("line",rx+18,y+92,rw-36,h-118,10,10)
  local radio=self.radio
  local broadcast=radio and table.concat({radio.top or "",radio.bottom or ""}," ")
    or "Tune with UP and DOWN to find a station."
  GoldCompat.drawGearWrapped(broadcast,rx+36,y+116,rw-72,8,17,
    {0.88,0.95,0.90,1},8)
end

-- -------------------------------------------------------------------------
-- Pokémon Gold: Colosseum Pokégear presentation
-- -------------------------------------------------------------------------

-- Compact Colosseum PokéGear renderer used when another Gen II state is
-- stacked above the gear (notably live phone scripts). In that situation the
-- engine asks the underlying state for drawPanel(), not drawWidescreen();
-- without this bridge Gold's native 160x144 PokéGear flashes back in beneath
-- the dialogue box.
function GoldCompat.drawPokegearPanel(self)
  local G=love.graphics
  local W,H=160,144
  local card=self.card and self:card() or (self.cards and self.cards[self.cardIndex or 1])
  local id=card and card.id or "clock"

  G.push("all")
  G.origin()
  G.setColor(0.008,0.020,0.021,1); G.rectangle("fill",0,0,W,H)
  G.setColor(0.035,0.10,0.09,1); G.rectangle("fill",2,2,156,18,3,3)
  G.setColor(0.16,0.46,0.38,1); G.rectangle("line",2,2,156,140,3,3)
  G.setColor(0.18,0.82,0.38,1); G.rectangle("fill",4,19,152,1)
  printText("PokéGear",6,6,8,{0.42,1.00,0.57,1})

  local cards=self.cards or {}
  local tx=50
  local tw=math.max(20,math.floor((104-math.max(0,#cards-1)*2)/math.max(1,#cards)))
  for i,c in ipairs(cards) do
    local x=tx+(i-1)*(tw+2)
    local sel=i==(self.cardIndex or 1)
    G.setColor(sel and {0.04,0.31,0.23,1} or {0.025,0.09,0.08,1})
    G.rectangle("fill",x,4,tw,14,2,2)
    if sel then G.setColor(0.98,0.35,0.14,1); G.rectangle("fill",x,4,2,14) end
    printText(tostring(c.label or c.id or ""):upper(),x,8,5.5,
      sel and {1,1,1,1} or {0.56,0.72,0.67,1},"center",tw)
  end

  local bx,by,bw,bh=5,25,150,105
  G.setColor(0.005,0.038,0.039,1); G.rectangle("fill",bx,by,bw,bh,3,3)
  G.setColor(0.18,0.44,0.41,1); G.rectangle("line",bx,by,bw,bh,3,3)

  if id=="phone" then
    printText("CONTACTS",10,31,7,{0.40,0.98,0.57,1})
    local list=self:phoneList() or {}
    for row=1,4 do
      local absolute=(self.phoneScroll or 0)+row
      local cid=list[absolute] or 0
      local label,className=self:contactRow(cid)
      label=GoldCompat.cleanGearText(label):gsub(":$","")
      local yy=43+(row-1)*18
      local sel=(row-1)==(self.phoneCursor or 0)
      if sel then
        G.setColor(0.035,0.27,0.21,1); G.rectangle("fill",9,yy-2,70,16,2,2)
        G.setColor(0.98,0.35,0.14,1); G.polygon("fill",6,yy+6,10,yy+2,10,yy+10)
      end
      printText(label,13,yy,6.5,sel and {1,1,1,1} or {0.72,0.84,0.79,1},"left",64)
      if className then printText(GoldCompat.cleanGearText(className),13,yy+8,4.7,{0.42,0.72,0.62,1},"left",64) end
    end
    G.setColor(0.008,0.075,0.064,1); G.rectangle("fill",84,39,66,76,3,3)
    local sid=self:phoneSelection()
    local name,className=self:contactRow(sid)
    name=GoldCompat.cleanGearText(name):gsub(":$","")
    printText(self.call and "CALL CONNECTED" or "PHONE",88,44,6.2,
      self.call and {0.48,1.00,0.58,1} or {0.40,0.98,0.57,1},"left",58)
    printText(name,88,58,8,{1,1,1,1},"left",58)
    if className then printText(GoldCompat.cleanGearText(className),88,69,5,{0.47,0.78,0.66,1},"left",58) end
    local msg=self.call and (self.call.text or "Call in progress.") or "A: CONTACT"
    GoldCompat.drawGearWrapped(msg,88,83,58,3,5.5,{0.82,0.91,0.86,1},2)
  elseif id=="clock" then
    local hour,minute,weekday=self:clockParts()
    hour=tonumber(hour) or 0; minute=tonumber(minute) or 0; weekday=tonumber(weekday) or 1
    local days={"SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"}
    local display=hour%12; if display==0 then display=12 end
    printText(days[((weekday-1)%7)+1],15,43,8,{0.46,1.00,0.58,1},"center",130)
    printText(("%02d:%02d"):format(display,minute),15,61,22,{0.97,1,0.97,1},"center",130)
    printText(hour<12 and "AM" or "PM",112,66,7,{1.00,0.73,0.30,1})
    printText("A/B: CARDS   LEFT/RIGHT: SWITCH",15,105,5.7,{0.66,0.82,0.76,1},"center",130)
  elseif id=="radio" then
    printText("RADIO",12,34,8,{0.40,0.98,0.57,1})
    local station=self.currentStation and self:currentStation() or nil
    printText(station and GoldCompat.cleanGearText(station.name) or "DEAD AIR",12,51,10,{1,1,1,1},"left",136)
    local radio=self.radio
    local text=radio and table.concat({radio.top or "",radio.bottom or ""}," ") or "UP / DOWN TO TUNE"
    GoldCompat.drawGearWrapped(text,12,70,136,4,6.3,{0.82,0.91,0.86,1},3)
  else
    -- The MAP card needs its live cursor/landmark state, so use Gold's original
    -- panel only for this one compact fallback path.
    local ok,Pokegear=pcall(require,"src.ui.gen2.Pokegear")
    if ok and Pokegear.__gen3uiOriginalDrawPanel then
      G.pop()
      return Pokegear.__gen3uiOriginalDrawPanel(self)
    end
  end

  G.setColor(0.008,0.045,0.035,1); G.rectangle("fill",5,133,150,7,2,2)
  printText(tostring(card and (card.label or card.id) or "POKéGEAR"):upper(),8,134,4.8,{0.40,0.96,0.57,1})
  G.pop()
end

function GoldCompat.drawPokegearWidescreen(self,winW,winH)
  local Pokegear=require("src.ui.gen2.Pokegear")
  local G=love.graphics

  -- Fly Map is a separate screen/state in Gen 2, not the Pokégear card UI.
  -- Preserve it verbatim until we theme the dedicated Gold map/fly surface.
  if self.fly and Pokegear.__gen3uiOriginalDrawWidescreen then
    return Pokegear.__gen3uiOriginalDrawWidescreen(self,winW,winH)
  end

  -- Every Pokégear card remains inside one Colosseum chassis. MAP keeps its
  -- complete native surface, including cursor and landmark plate; other apps
  -- crop only Gold's redundant cartridge tab strip.
  local activeCard=self.card and self:card()
    or (self.cards and self.cards[self.cardIndex or 1])

  winW=winW or G.getWidth()
  winH=winH or G.getHeight()

  -- Cache a native-resolution card surface per live Pokégear instance.
  local needsNativeMap=activeCard and activeCard.id=="map"
  if needsNativeMap and not self.__gen3uiGearCanvas then
    local ok,canvas=pcall(G.newCanvas,160,144)
    if ok then
      self.__gen3uiGearCanvas=canvas
      if canvas.setFilter then pcall(canvas.setFilter,canvas,"nearest","nearest") end
    end
  end

  local canvas=self.__gen3uiGearCanvas
  if needsNativeMap and not canvas then
    if Pokegear.__gen3uiOriginalDrawWidescreen then
      return Pokegear.__gen3uiOriginalDrawWidescreen(self,winW,winH)
    end
    return
  end

  -- Draw the engine-owned live card first. We crop away its native 16px card
  -- strip and replace only that chrome with our high-resolution navigation.
  if needsNativeMap then
    local oldCanvas=G.getCanvas()
    G.push("all")
    G.setCanvas(canvas)
    G.clear(0,0,0,0)
    G.origin()
    if Pokegear.__gen3uiOriginalDrawPanel then
    -- The native mode arrow belongs to Gold's original card strip. Our
    -- widescreen header is now the strip/selection UI, so suppress only that
    -- visual while capturing the live card. Input/card paging stays native.
      local oldModeArrow=self.drawModeArrow
      self.drawModeArrow=function() end
      Pokegear.__gen3uiOriginalDrawPanel(self)
      self.drawModeArrow=oldModeArrow
    end
    G.setCanvas(oldCanvas)
    G.pop()
  end

  G.push("all")
  G.origin()

  -- Live-world veil and graphite/green Colosseum chassis.
  G.setColor(0.005,0.015,0.018,0.56)
  G.rectangle("fill",0,0,winW,winH)

  local margin=math.max(24,math.floor(math.min(winW,winH)*0.045))
  local panelX=margin
  local panelY=margin
  local panelW=winW-margin*2
  local panelH=winH-margin*2

  G.setColor(0.01,0.02,0.02,0.48)
  G.rectangle("fill",panelX+7,panelY+9,panelW,panelH,18,18)
  G.setColor(0.10,0.13,0.12,0.97)
  G.rectangle("fill",panelX,panelY,panelW,panelH,18,18)
  G.setColor(0.37,0.47,0.43,1)
  G.setLineWidth(3)
  G.rectangle("line",panelX,panelY,panelW,panelH,18,18)

  -- Header.
  local headerH=math.max(58,math.floor(panelH*0.105))
  G.setColor(0.01,0.10,0.07,0.98)
  G.rectangle("fill",panelX+4,panelY+4,panelW-8,headerH,14,14)
  G.setColor(0.12,0.74,0.31,0.72)
  G.rectangle("fill",panelX+18,panelY+headerH-3,panelW-36,2)

  GoldCompat.drawGearFitted("PokéGear",panelX+24,panelY+10,
    math.max(130,math.floor(panelW*0.22)),headerH-15,
    math.max(16,math.floor(headerH*0.36)),11,{0.34,1.00,0.47,1},"left")

  -- Dynamic card tabs: visibleCards() already applies Gold's real engine flags.
  local cards=self.cards or {}
  local tabX=panelX+math.max(190,math.floor(panelW*0.27))
  local tabGap=8
  local available=panelX+panelW-18-tabX
  local tabW=(available-math.max(0,#cards-1)*tabGap)/math.max(1,#cards)
  local tabH=headerH-16

  for i,card in ipairs(cards) do
    local x=tabX+(i-1)*(tabW+tabGap)
    local selected=(i==(self.cardIndex or 1))
    G.setColor(selected and 0.04 or 0.035,
               selected and 0.30 or 0.11,
               selected and 0.22 or 0.10,1)
    G.rectangle("fill",x,panelY+10,tabW,tabH,8,8)
    if selected then
      G.setColor(0.96,0.37,0.16,1)
      G.rectangle("fill",x,panelY+10,4,tabH,4,4)
    end
    GoldCompat.drawGearFitted(tostring(card.label or card.id or ""):upper(),
      x+20,panelY+12,tabW-40,tabH-4,
      math.max(11,math.floor(headerH*0.23)),8,
      selected and {0.98,1.00,0.98,1} or {0.56,0.72,0.66,1},"center")

    if selected and #cards>1 then
      G.setColor(0.96,0.37,0.16,1)
      local cy=panelY+10+tabH/2
      G.polygon("fill",x+10,cy, x+18,cy-7, x+18,cy+7)
      G.polygon("fill",x+tabW-10,cy, x+tabW-18,cy-7, x+tabW-18,cy+7)
    end
  end

  -- Native live card viewport. Crop the original strip/indicator zone; the
  -- all map/phone/radio/clock content and their exact engine-driven state.
  local bodyX=panelX+22
  local bodyY=panelY+headerH+18
  local footerH=math.max(44,math.floor(panelH*0.075))
  local bodyW=panelW-44
  local bodyH=panelH-headerH-footerH-50

  G.setColor(0.004,0.025,0.027,0.95)
  G.rectangle("fill",bodyX-5,bodyY-5,bodyW+10,bodyH+10,10,10)
  G.setColor(0.27,0.55,0.51,1)
  G.rectangle("line",bodyX-5,bodyY-5,bodyW+10,bodyH+10,10,10)

  local cardId=activeCard and activeCard.id or "clock"
  if cardId=="map" and canvas then
    if not self.__gen3uiGearQuad then
      self.__gen3uiGearQuad=G.newQuad(0,0,160,144,160,144)
    end
    local scale=math.min(bodyW/160,bodyH/144)
    local dw,dh=160*scale,144*scale
    G.setColor(1,1,1,1)
    G.draw(canvas,self.__gen3uiGearQuad,bodyX+(bodyW-dw)/2,
      bodyY+(bodyH-dh)/2,0,scale,scale)
  elseif cardId=="phone" then
    GoldCompat.drawGearPhone(self,bodyX,bodyY,bodyW,bodyH)
  elseif cardId=="radio" then
    GoldCompat.drawGearRadio(self,bodyX,bodyY,bodyW,bodyH)
  else
    GoldCompat.drawGearClock(self,bodyX,bodyY,bodyW,bodyH)
  end

  -- Footer reflects native mode/input without taking ownership from update().
  local card=self.card and self:card() or cards[self.cardIndex or 1]
  local label=card and tostring(card.label or card.id or ""):upper() or "POKéGEAR"
  local hint
  if self.mode=="strip" then
    hint="LEFT / RIGHT: SELECT    A: OPEN    B: BACK"
  elseif card and card.id=="radio" then
    hint="UP / DOWN: TUNE    B: CARDS"
  elseif card and card.id=="phone" then
    hint="UP / DOWN: CONTACTS    A: SELECT    B: CARDS"
  elseif card and card.id=="map" then
    hint="D-PAD: MAP    B: CARDS"
  else
    hint="B: CARDS"
  end

  G.setColor(0.008,0.045,0.035,0.98)
  G.rectangle("fill",panelX+8,panelY+panelH-footerH,
    panelW-16,footerH-8,8,8)
  printText(label,panelX+24,panelY+panelH-footerH+10,
    math.max(11,math.floor(footerH*0.28)),{0.38,0.96,0.56,1})
  printText(hint,panelX+170,panelY+panelH-footerH+10,
    math.max(9,math.floor(footerH*0.24)),{0.67,0.82,0.76,1},
    "right",panelW-194)

  G.pop()
end


-- -------------------------------------------------------------------------
-- Pokémon Gold: core Colosseum menu presentation
-- -------------------------------------------------------------------------

GoldCompat.__cleanPortraitCache=GoldCompat.__cleanPortraitCache
  or setmetatable({}, {__mode="k"})

function GoldCompat.prepareCleanResolvedPortrait(image,sourceMeta)
  if not image then return nil,nil end
  local cached=GoldCompat.__cleanPortraitCache[image]
  if cached then return cached.image,cached.meta end

  local meta={}
  for k,v in pairs(type(sourceMeta)=="table" and sourceMeta or {}) do meta[k]=v end
  local result=image
  local ok,data=pcall(function() return image:newImageData() end)
  if ok and data then
    local iw,ih=data:getDimensions()
    local function borderColor(px,py)
      local r,g,b,a=data:getPixel(px,py)
      local hi=math.max(r or 0,g or 0,b or 0)
      local lo=math.min(r or 0,g or 0,b or 0)
      return r,g,b,a,(a or 0)>0.80 and lo>0.86 and hi-lo<0.13
    end
    local br,bg,bb,ba,light=borderColor(0,0)
    if not light then
      local hi=math.max(br or 0,bg or 0,bb or 0)
      local lo=math.min(br or 0,bg or 0,bb or 0)
      light=(ba or 0)>0.80 and hi>0.52 and hi-lo<0.20
    end
    local matchingCorners=0
    for _,corner in ipairs({{0,0},{iw-1,0},{0,ih-1},{iw-1,ih-1}}) do
      local r,g,b,a,isLight=borderColor(corner[1],corner[2])
      local hi=math.max(r or 0,g or 0,b or 0)
      local lo=math.min(r or 0,g or 0,b or 0)
      local matte=isLight or ((a or 0)>0.80 and hi>0.52 and hi-lo<0.20)
      if matte and math.abs(r-br)<=0.18 and math.abs(g-bg)<=0.18
          and math.abs(b-bb)<=0.18 and math.abs(a-ba)<=0.20 then
        matchingCorners=matchingCorners+1
      end
    end

    -- Remove a border-connected transparent/light neutral matte. Gen II's
    -- resolved front sprites can arrive with either a solid white ROM plate
    -- or a thin transparent gutter around that plate, so keying only from the
    -- corner color misses the exact failure seen in Summary/Pokedex. Walking
    -- through transparent pixels as well as neutral light pixels reaches both
    -- forms while still preserving white details enclosed by the silhouette.
    do
      local queueX,queueY,seen={},{},{}
      local head,tail=1,0
      local removed=false
      local function removable(r,g,b,a)
        a=a or 0
        if a<0.10 then return true end
        local hi=math.max(r or 0,g or 0,b or 0)
        local lo=math.min(r or 0,g or 0,b or 0)
        return a>0.68 and lo>0.70 and hi-lo<0.24
      end
      local function enqueue(px,py)
        if px<0 or py<0 or px>=iw or py>=ih then return end
        local key=py*iw+px+1
        if seen[key] then return end
        local r,g,b,a=data:getPixel(px,py)
        if removable(r,g,b,a) then
          seen[key]=true
          tail=tail+1; queueX[tail]=px; queueY[tail]=py
        end
      end
      for px=0,iw-1 do enqueue(px,0); enqueue(px,ih-1) end
      for py=1,ih-2 do enqueue(0,py); enqueue(iw-1,py) end
      while head<=tail do
        local px,py=queueX[head],queueY[head]; head=head+1
        local r,g,b,a=data:getPixel(px,py)
        if (a or 0)>0.03 then removed=true end
        data:setPixel(px,py,r,g,b,0)
        enqueue(px-1,py); enqueue(px+1,py)
        enqueue(px,py-1); enqueue(px,py+1)
      end
      if removed then
        local made,newImage=pcall(love.graphics.newImage,data)
        if made and newImage then
          result=newImage
          if result.setFilter then pcall(result.setFilter,result,"nearest","nearest") end
        end
      end
    end

    -- Some Gen II ROM sprites carry a white matte rectangle inset from a
    -- transparent gutter, so it never touches the image border. Remove any
    -- very large connected light-neutral component as a second pass. A real
    -- white marking on a Pokemon is much smaller and remains isolated by the
    -- silhouette, while the matte typically occupies most of the canvas.
    do
      local seen={}
      local function light(px,py)
        local r,g,b,a=data:getPixel(px,py)
        if (a or 0)<0.55 then return false end
        local hi=math.max(r or 0,g or 0,b or 0)
        local lo=math.min(r or 0,g or 0,b or 0)
        return lo>0.72 and hi-lo<0.22
      end
      local minComponent=math.max(64,math.floor(iw*ih*0.16))
      for sy=0,ih-1 do for sx=0,iw-1 do
        local sk=sy*iw+sx+1
        if not seen[sk] and light(sx,sy) then
          local qx,qy={sx},{sy}; seen[sk]=true
          local head=1
          while head<=#qx do
            local px,py=qx[head],qy[head]; head=head+1
            for _,d in ipairs({{-1,0},{1,0},{0,-1},{0,1}}) do
              local nx,ny=px+d[1],py+d[2]
              if nx>=0 and ny>=0 and nx<iw and ny<ih then
                local nk=ny*iw+nx+1
                if not seen[nk] and light(nx,ny) then
                  seen[nk]=true; qx[#qx+1]=nx; qy[#qy+1]=ny
                end
              end
            end
          end
          if #qx>=minComponent then
            for i=1,#qx do
              local px,py=qx[i],qy[i]
              local r,g,b=data:getPixel(px,py)
              data:setPixel(px,py,r,g,b,0)
            end
            local made,newImage=pcall(love.graphics.newImage,data)
            if made and newImage then
              result=newImage
              if result.setFilter then pcall(result.setFilter,result,"nearest","nearest") end
            end
          end
        end
      end end
    end

    local x0,y0,x1,y1=iw,ih,-1,-1
    local boundsData=data
    for py=0,ih-1 do
      for px=0,iw-1 do
        local _,_,_,a=boundsData:getPixel(px,py)
        if (a or 0)>0.03 then
          if px<x0 then x0=px end; if px>x1 then x1=px end
          if py<y0 then y0=py end; if py>y1 then y1=py end
        end
      end
    end
    if x1>=x0 and y1>=y0 then
      meta.x0,meta.x1,meta.y0,meta.y1=x0,x1,y0,y1
    end
  end

  local prepared={image=result,meta=meta}
  GoldCompat.__cleanPortraitCache[image]=prepared
  return prepared.image,prepared.meta
end

-- -------------------------------------------------------------------------
-- Optional Stadium 3D models for Pokemon information surfaces.
--
-- StadiumBattleFX owns extraction, source selection, actor lifetime internals,
-- skeletal animation and rendering. This UI consumes only its public v1 model
-- service. If Stadium is not the selected model provider, the service is not
-- ready, or a species is outside the exported model range, the existing
-- spritePortraitResolver path below remains authoritative.
-- -------------------------------------------------------------------------
GoldCompat.__stadiumUiActors=GoldCompat.__stadiumUiActors or {}

function GoldCompat.releaseStadiumUiActor(kind)
  local slots=GoldCompat.__stadiumUiActors
  local entry=slots and slots[kind]
  if not entry then return end
  if entry.actor and type(entry.actor.release)=="function" then
    pcall(entry.actor.release,entry.actor)
  end
  slots[kind]=nil
end

function GoldCompat.stadiumUiModelService(game)
  if not (modRef and type(modRef.find)=="function") then return nil end
  local ok,handle=pcall(modRef.find,"STADIUM_BATTLE_FX")
  if not ok or not handle then
    ok,handle=pcall(modRef.find,modRef,"STADIUM_BATTLE_FX")
  end
  if not (ok and handle and type(handle.exports)=="table") then return nil end

  local exports=handle.exports
  local models=exports.models
  if not (type(models)=="table" and tonumber(models.version or 0)>=1
      and type(models.available)=="function"
      and type(models.acquire)=="function"
      and type(models.draw)=="function") then
    return nil
  end

  -- Respect the user's selected battle-model provider. Merely installing
  -- StadiumBattleFX is not permission to replace another selected model source.
  local battles=exports.battles
  if type(battles)=="table" and exports.modelProvider
      and type(battles.resolve)=="function" then
    local resolvedOk,resolved=pcall(battles.resolve,battles,"models",{game=game})
    if resolvedOk and resolved and resolved~=exports.modelProvider then return nil end
  end
  return models,exports
end

function GoldCompat.stadiumUiDexNumber(game,mon)
  local species=mon and (mon.species or mon.id)
  local def=species and game and game.data and game.data.pokemon
    and game.data.pokemon[species]
  local dex=def and tonumber(def.dex)
  if not dex then return nil end
  return math.floor(dex)
end

function GoldCompat.stadiumUiVariant(mon)
  if mon and (mon.shiny==true or mon.isShiny==true) then return "shiny" end
  local dvs=mon and mon.dvs
  if type(dvs)=="table" then
    local okStats,Stats=pcall(require,"src.pokemon.Stats")
    if okStats and Stats and type(Stats.isShiny)=="function" then
      local ok,value=pcall(Stats.isShiny,dvs)
      if ok and value then return "shiny" end
    end
  end
  return "normal"
end

function GoldCompat.stadiumUiMatMul(a,b)
  local out={}
  for r=0,3 do
    local a0,a1=a[r*4+1],a[r*4+2]
    local a2,a3=a[r*4+3],a[r*4+4]
    for c=1,4 do
      out[r*4+c]=a0*b[c]+a1*b[4+c]+a2*b[8+c]+a3*b[12+c]
    end
  end
  return out
end

function GoldCompat.stadiumUiPerspective(fovY,aspect,near,far)
  local f=1/math.tan(fovY/2)
  local d=near-far
  return {f/aspect,0,0,0, 0,f,0,0,
    0,0,(far+near)/d,(2*far*near)/d, 0,0,-1,0}
end

function GoldCompat.stadiumUiLookAt(eye,target)
  local function sub(a,b) return {a[1]-b[1],a[2]-b[2],a[3]-b[3]} end
  local function norm(v)
    local len=math.sqrt(v[1]*v[1]+v[2]*v[2]+v[3]*v[3])
    if len<=1e-9 then return {0,0,0} end
    return {v[1]/len,v[2]/len,v[3]/len}
  end
  local function cross(a,b)
    return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],
      a[1]*b[2]-a[2]*b[1]}
  end
  local function dot(a,b) return a[1]*b[1]+a[2]*b[2]+a[3]*b[3] end
  local forward=norm(sub(target,eye))
  local right=norm(cross(forward,{0,1,0}))
  local up=cross(right,forward)
  return {right[1],right[2],right[3],-dot(right,eye),
    up[1],up[2],up[3],-dot(up,eye),
    -forward[1],-forward[2],-forward[3],dot(forward,eye),
    0,0,0,1}
end

function GoldCompat.stadiumUiViewProjection(actor,width,height)
  local modelH=math.max(1,tonumber(actor and actor.worldHeight
    and actor:worldHeight()) or 32)
  local radius=math.max(1,tonumber(actor and actor.worldRadius
    and actor:worldRadius()) or modelH*0.35)
  local aspect=math.max(0.2,width/math.max(1,height))
  local frameH=math.max(modelH*1.16,(radius*2.35)/aspect)
  local fov=math.rad(28)
  local distance=(frameH*0.5)/math.tan(fov*0.5)
  local focus={0,modelH*0.48,0}
  local eye={radius*0.30,modelH*0.53,distance}
  local projection=GoldCompat.stadiumUiPerspective(
    fov,aspect,math.max(0.1,distance*0.02),distance*5)
  -- Stadium's public renderer follows the battle host's screen-Y convention.
  projection=GoldCompat.stadiumUiMatMul(
    {1,0,0,0, 0,-1,0,0, 0,0,1,0, 0,0,0,1},projection)
  return GoldCompat.stadiumUiMatMul(
    projection,GoldCompat.stadiumUiLookAt(eye,focus))
end

function GoldCompat.drawStadiumUiModel(game,mon,x,y,w,h,kind)
  if kind~="summary" and kind~="dex" then return false end
  if not (game and mon and love and love.graphics) then return false end

  local models,exports=GoldCompat.stadiumUiModelService(game)
  if not models then
    GoldCompat.releaseStadiumUiActor(kind)
    return false
  end

  local dex=GoldCompat.stadiumUiDexNumber(game,mon)
  local maxSpecies=tonumber(models.speciesCount) or 0
  if not dex or dex<1 or (maxSpecies>0 and dex>maxSpecies) then
    GoldCompat.releaseStadiumUiActor(kind)
    return false
  end

  local source=models.SELECTED or "selected"
  local availableOk,available=pcall(models.available,source,dex)
  if not (availableOk and available) then
    GoldCompat.releaseStadiumUiActor(kind)
    return false
  end

  local sourceToken=source
  local sources=exports and exports.modelSources
  if type(sources)=="table" and type(sources.selectedId)=="function" then
    local tokenOk,value=pcall(sources.selectedId)
    if tokenOk and value then sourceToken=tostring(value) end
  end
  local variant=GoldCompat.stadiumUiVariant(mon)
  local slots=GoldCompat.__stadiumUiActors
  local entry=slots[kind]
  if entry and (entry.dex~=dex or entry.variant~=variant
      or entry.sourceToken~=sourceToken or entry.models~=models) then
    GoldCompat.releaseStadiumUiActor(kind)
    entry=nil
  end

  if not entry then
    local acquireOk,actor=pcall(models.acquire,source,dex,variant,{side="external"})
    if not (acquireOk and actor) then return false end
    entry={actor=actor,dex=dex,variant=variant,sourceToken=sourceToken,
      models=models,lastTime=nil,canvas=nil,canvasW=0,canvasH=0}
    slots[kind]=entry
    if type(actor.play)=="function" then pcall(actor.play,actor,"idle") end
  end

  local actor=entry.actor
  if not actor then return false end
  local now=(love.timer and love.timer.getTime and love.timer.getTime()) or 0
  local dt=entry.lastTime and math.max(0,math.min(0.05,now-entry.lastTime)) or 0
  entry.lastTime=now
  if type(actor.update)=="function" then pcall(actor.update,actor,dt) end

  local G=love.graphics
  local px1,py1=x,y
  local px2,py2=x+w,y+h
  if type(G.transformPoint)=="function" then
    local ok1,a,b=pcall(G.transformPoint,x,y)
    local ok2,c,d=pcall(G.transformPoint,x+w,y+h)
    if ok1 and ok2 then px1,py1,px2,py2=a,b,c,d end
  end
  local canvasW=math.max(64,math.min(512,math.floor(math.abs(px2-px1)+0.5)))
  local canvasH=math.max(64,math.min(512,math.floor(math.abs(py2-py1)+0.5)))
  if not entry.canvas or entry.canvasW~=canvasW or entry.canvasH~=canvasH then
    local canvasOk,canvas=pcall(G.newCanvas,canvasW,canvasH,{dpiscale=1})
    if not (canvasOk and canvas) then return false end
    entry.canvas,entry.canvasW,entry.canvasH=canvas,canvasW,canvasH
  end

  local priorCanvas=G.getCanvas and G.getCanvas() or nil
  G.push("all")
  local renderOk=pcall(function()
    G.setCanvas({entry.canvas,depth=true})
    G.origin()
    G.clear(0,0,0,0,true,true)
    local vp=GoldCompat.stadiumUiViewProjection(actor,canvasW,canvasH)
    local matrix=actor.matrix and actor:matrix(0,0,0,0,1) or nil
    if not matrix then error("Stadium UI model matrix unavailable") end
    local okDraw,drew=models.draw(actor,vp,matrix,0)
    if not okDraw or drew==false then
      error("Stadium UI model draw failed: "..tostring(drew))
    end
  end)
  if priorCanvas then G.setCanvas(priorCanvas) else G.setCanvas() end
  G.pop()
  if not renderOk then return false end

  G.push("all")
  G.setColor(1,1,1,1)
  G.draw(entry.canvas,x,y,0,w/canvasW,h/canvasH)
  G.pop()
  return true
end

function GoldCompat.drawCleanResolvedPortrait(game,mon,x,y,w,h,kind)
  -- Information surfaces prefer the active Stadium 3D model when the
  -- Stadium provider is selected. Every failure falls through to the existing
  -- resolved-sprite path, preserving Battle Arts, Crystal and custom packs.
  local stadiumOk,stadiumDrew=pcall(
    GoldCompat.drawStadiumUiModel,game,mon,x,y,w,h,kind)
  if stadiumOk and stadiumDrew then return true end

  local ok,image,meta=pcall(spritePortraitResolver.resolve,game,mon,kind)
  if not (ok and image) then return false end
  image,meta=GoldCompat.prepareCleanResolvedPortrait(image,meta)
  if not image then return false end

  local iw,ih=image:getDimensions()
  if not iw or not ih or iw<=0 or ih<=0 then return false end
  local x0,y0,x1,y1=0,0,iw-1,ih-1
  if type(meta)=="table" and meta.x0 and meta.x1 and meta.y0 and meta.y1 then
    x0,y0,x1,y1=meta.x0,meta.y0,meta.x1,meta.y1
  end
  local vw,vh=math.max(1,x1-x0+1),math.max(1,y1-y0+1)
  local scale=math.min((w*0.88)/vw,(h*0.88)/vh)
  local visibleCX=(x0+x1+1)*0.5
  local visibleCY=(y0+y1+1)*0.5
  local dx=x+w*0.5-visibleCX*scale
  local dy=y+h*0.5-visibleCY*scale

  local G=love.graphics
  G.push("all"); G.origin(); G.setColor(1,1,1,1)
  -- Hard portrait viewport. Some external sprite packages expose authored
  -- bounds that do not cover every opaque pixel in the prepared frame; clip
  -- at the UI cell so those pixels can never spill into adjacent controls.
  local sx,sy,sw,sh=G.getScissor()
  local clipX,clipY,clipW,clipH=x,y,w,h
  if sx then
    local rx=math.max(clipX,sx)
    local ry=math.max(clipY,sy)
    local rr=math.min(clipX+clipW,sx+sw)
    local rb=math.min(clipY+clipH,sy+sh)
    clipX,clipY,clipW,clipH=rx,ry,math.max(0,rr-rx),math.max(0,rb-ry)
  end
  G.setScissor(clipX,clipY,clipW,clipH)
  G.draw(image,dx,dy,0,scale,scale)
  if type(meta)=="table" and meta.trueColor then
    local okPalette,PaletteFX=pcall(require,"src.render.PaletteFX")
    if okPalette and PaletteFX and type(PaletteFX.markTrueColor)=="function" then
      local mx=math.max(x,dx)
      local my=math.max(y,dy)
      local mr=math.min(x+w,dx+iw*scale)
      local mb=math.min(y+h,dy+ih*scale)
      if mr>mx and mb>my then
        pcall(PaletteFX.markTrueColor,mx,my,mr-mx,mb-my)
      end
    end
  end
  G.pop()
  return true
end

function GoldCompat.genderSymbol(mon)
  local gender=mon and mon.gender
  if gender=="male" or gender=="female" then return gender end
  return nil
end

function GoldCompat.drawGenderIcon(x,y,size,gender)
  if gender~="male" and gender~="female" then return false end
  local G=love.graphics

  -- Compact modern Venus/Mars glyphs based on the user's reference:
  -- bold circular body, short stem/cross for female, diagonal arrow for male.
  size=math.max(8,math.min(22,size or 11))
  local line=math.max(1.4,size*0.16)
  local r=size*0.25
  local cx=x+r+1
  local cy=y+r+1

  G.push("all")
  G.origin()
  if G.setLineStyle then G.setLineStyle("smooth") end
  G.setLineWidth(line)

  if gender=="female" then
    G.setColor(0.95,0.20,0.52,1)
    G.circle("line",cx,cy,r)
    local stemTop=cy+r
    local stemBottom=cy+r+size*0.34
    G.line(cx,stemTop,cx,stemBottom)
    local crossY=cy+r+size*0.22
    G.line(cx-size*0.17,crossY,cx+size*0.17,crossY)
  else
    G.setColor(0.02,0.63,0.84,1)
    G.circle("line",cx,cy,r)

    local x1=cx+r*0.68
    local y1=cy-r*0.68
    local x2=cx+r+size*0.30
    local y2=cy-r-size*0.30
    G.line(x1,y1,x2,y2)

    local arm=size*0.19
    G.line(x2-arm,y2,x2,y2)
    G.line(x2,y2,x2,y2+arm)
  end

  G.setColor(1,1,1,1)
  G.pop()
  return true
end

function GoldCompat.prepareGoldStartMenu(self)
  -- Preserve Gold's actual menu entries/actions but normalize presentation-only
  -- labels that contain Gen 2 text-control tokens.
  if not self.__gen3uiDisplayItems then
    self.__gen3uiDisplayItems={}
  end
  for i,item in ipairs(self.items or {}) do
    local copy={}
    for k,v in pairs(item) do copy[k]=v end
    local label=tostring(copy.label or copy.value or "")
    if label:find("GEAR") or label:find("<PO>") or label:find("<KE>") then
      copy.label="PokéGear"
    end
    self.__gen3uiDisplayItems[i]=copy
  end

  self.__gen3uiOriginalItems=self.items
  self.items=self.__gen3uiDisplayItems

  local count=#(self.items or {})
  self.index=(self.list and self.list.index) or self.index or 1
  self.maxVisible=math.min(8,count)
  self.scroll=0
  if count>self.maxVisible then
    self.scroll=math.max(0,math.min(
      self.index-math.ceil(self.maxVisible/2),
      count-self.maxVisible))
  end
  State.activeStartMenu=self
end

function GoldCompat.drawGoldStartConfirm(self)
  if self.phase~="confirm" then return end
  local ox,oy,sc=finalCanvas()
  local G=love.graphics
  local x,y,w,h=26,48,108,50

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(0.05,0.05,0.05,0.35)
  G.rectangle("fill",x+2,y+2,w,h)
  G.setColor(0.08,0.08,0.07,1)
  G.rectangle("fill",x,y,w,h)
  G.setColor(0.99,0.985,0.95,1)
  G.rectangle("fill",x+2,y+2,w-4,h-4)
  drawUnifiedBorder(x,y,w,h,0)

  for i=1,2 do
    local yy=y+24+(i-1)*11
    if self.confirmChoice==i then
      G.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",x+65,yy-1,32,9,2)
    end
  end
  G.pop()

  finalText("Return to title screen?",x+8,y+8,3.8,
    {0.06,0.06,0.06,1},ox,oy,sc)

  finalText("YES",x+71,y+24,3.2,
    self.confirmChoice==1 and {1,1,1,1} or {0.06,0.06,0.06,1},
    ox,oy,sc)
  finalText("NO",x+71,y+35,3.2,
    self.confirmChoice==2 and {1,1,1,1} or {0.06,0.06,0.06,1},
    ox,oy,sc)
end

function GoldCompat.drawGoldPartyMenu(self,winW,winH)
  if featureEnabled("colosseumPokemonMenu") then
    self.isOpaque=false
    self.__gen3uiColosseumParty=true
    return GoldCompat.drawColosseumParty(self.game,self)
  end

  self.__gen3uiColosseumParty=nil
  local party=self.party or {}
  local G=love.graphics
  local ox,oy,sc=partyLogicalCanvas()

  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)

  -- Exact Gen 1 Party screen foundation.
  G.setColor(0.94,0.93,0.87,1)
  G.rectangle("fill",0,0,160,144)

  G.setColor(0.08,0.08,0.08,1)
  G.rectangle("fill",4,4,152,16)
  G.setColor(0.99,0.985,0.955,1)
  G.rectangle("fill",5,5,150,14)
  G.pop()

  partyText("POKéMON",10,6,6,{0.06,0.06,0.06,1})

  if #party==0 then
    partyText("No POKéMON!",12,62,6,{0.06,0.06,0.06,1})
    return
  end

  local selected=math.max(1,math.min(self.index or 1,#party))
  local mon=party[selected]
  local def=mon and self.pokemon and self.pokemon[mon.species]

  -- ---------------------------------------------------------- selected detail
  local lx,ly,lw,lh=4,23,74,101
  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  partySlotPanel(lx,ly,lw,lh,true)

  -- Large selected portrait follows the exact same resolved battle-art path as
  -- Gen 1 Party/Pokédex. This is what keeps Battle Arts / configured sprite
  -- packages consistent outside battle. Native Gold icon is only a fallback.
  if mon then
    G.pop()
    local drewResolved=false
    G.push("all")
    G.origin()
    drewResolved=GoldCompat.drawCleanResolvedPortrait(
      self.game,mon,
      ox+(lx+7)*sc,oy+(ly+14)*sc,31*sc,28*sc,"summary")
    G.pop()
    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)
    if not drewResolved then
      G.push("all")
      G.translate(lx+9,ly+15)
      G.scale(1.8,1.8)
      self:drawIcon(mon,0,0)
      G.pop()
    end
  end
  G.pop()

  if mon then
    local name=mon.isEgg and "EGG"
      or tostring(mon.nickname or (def and def.name) or mon.species or "POKéMON")
    partyText(name,lx+7,ly+5,5.2,{0.06,0.06,0.06,1})
    local gender=GoldCompat.genderSymbol(mon)

    if not mon.isEgg then
      local lv="Lv."..tostring(mon.level or "?")
      partyText(lv,lx+lw-7-partyTextWidth(lv,4),ly+6,4,
        {0.06,0.06,0.06,1})

      -- HP
      local hpMax=math.max(1,mon.maxHp or (mon.stats and mon.stats.hp) or 1)
      local hpNow=mon.hp or 0
      local hpText=tostring(hpNow).."/"..tostring(hpMax)
      local hpY=ly+44
      local hpValueX=lx+lw-7-partyTextWidth(hpText,3)
      local hpBarX=lx+21
      local hpBarW=math.max(17,hpValueX-hpBarX-3)

      partyText("HP",lx+9,hpY,3,{0.08,0.08,0.08,1})

      G.push("all")
      G.translate(ox,oy)
      G.scale(sc,sc)
      local ratio=math.max(0,math.min(1,hpNow/hpMax))
      G.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",hpBarX,hpY+1,hpBarW,4,1.5)
      G.setColor(0.78,0.76,0.63,1)
      roundedRect("fill",hpBarX+1,hpY+2,hpBarW-2,2,1)
      if hpNow>0 then
        local r,gg,b,a=hpColor(ratio)
        G.setColor(r,gg,b,a)
        roundedRect("fill",hpBarX+1,hpY+2,
          math.max(1,(hpBarW-2)*ratio),2,1)
      end
      G.pop()

      partyText(hpText,hpValueX,hpY,3,{0.08,0.08,0.08,1})

      -- Selected-card gender gets its own readable slot between HP and EXP.
      -- This keeps it away from the Pokémon name and makes the symbol much
      -- easier to discern on handheld/mobile displays.
      if gender then
        pcall(GoldCompat.drawGenderIcon,
          ox+(lx+14)*sc,oy+(ly+52)*sc,12,gender)
      end

      local rowData=self.rowFor and self.rowFor(mon) or nil
      if rowData and rowData.status then
        partyText(rowData.status,lx+9,ly+49,2.8,{0.44,0.14,0.14,1})
      end

      -- EXP sits beneath the HP/status area, leaving more room below for moves
      -- and a properly padded stat footer.
      partyText("EXP",lx+9,ly+56,2.5,{0.34,0.45,0.50,1})
      G.push("all")
      G.translate(ox,oy)
      G.scale(sc,sc)
      local expRatio=partyExpRatio(self.game,mon)
      G.setColor(0.10,0.18,0.24,1)
      roundedRect("fill",lx+21,ly+57,lw-29,4,1.5)
      G.setColor(0.14,0.28,0.38,1)
      roundedRect("fill",lx+22,ly+58,lw-31,2,1)
      if expRatio>0 then
        G.setColor(0.08,0.48,0.96,1)
        roundedRect("fill",lx+22,ly+58,(lw-31)*expRatio,2,1)
      end
      G.pop()

      -- Four-move horizontal strip, matching the mature Gen 1 Party workflow.
      -- This creates one stable move region for normal viewing, TM replacement,
      -- and mid-battle MoveLearn selection instead of changing geometry by flow.
      local moves=mon.moves or {}
      local stripX=lx+6
      local stripY=ly+62
      local stripW=lw-12
      local moveGap=1
      local moveW=(stripW-moveGap*3)/4
      local moveH=20

      G.push("all")
      G.translate(ox,oy)
      G.scale(sc,sc)
      G.setColor(0.70,0.68,0.59,1)
      G.rectangle("fill",lx+7,ly+61,lw-14,1)

      for i=1,4 do
        local cx=stripX+(i-1)*(moveW+moveGap)
        G.setColor(0.965,0.95,0.88,1)
        roundedRect("fill",cx,stripY,moveW,moveH,1.2)
        G.setColor(0.74,0.71,0.61,1)
        roundedRect("line",cx,stripY,moveW,moveH,1.2)
      end
      G.pop()

      for i=1,4 do
        local entry=moves[i]
        local cx=stripX+(i-1)*(moveW+moveGap)
        local moveName=partyMoveName(self.game,entry)
        local pp=partyMovePP(self.game,entry)

        -- Fit the complete move name to the cell rather than truncating it.
        local nameSize=2.35
        while nameSize>1.45 and partyTextWidth(moveName,nameSize)>moveW-3 do
          nameSize=nameSize-0.12
        end

        partyText(moveName,cx+1.5,stripY+4,nameSize,
          {0.06,0.06,0.06,1},"center",moveW-3)
        if pp~="" then
          partyText(pp,cx+1.5,stripY+13,1.8,
            {0.24,0.24,0.21,1},"center",moveW-3)
        end
      end

      -- Gen 2 stat footer. Gold has split Special, so preserve both values.
      local stats={
        {"ATK",partyStat(mon,"attack","atk")},
        {"DEF",partyStat(mon,"defense","def")},
        {"SPD",partyStat(mon,"speed","spd")},
        {"SPA",partyStat(mon,"specialAttack","spAtk","special")},
        {"SPD",partyStat(mon,"specialDefense","spDef","special")},
      }
      local statY=ly+lh-15
      local innerX=lx+6
      local innerW=lw-12
      local colW=innerW/5

      G.push("all")
      G.translate(ox,oy)
      G.scale(sc,sc)
      G.setColor(0.74,0.72,0.64,1)
      G.rectangle("fill",lx+7,statY-1,lw-14,1)
      G.pop()

      for i,s in ipairs(stats) do
        local cx=innerX+(i-1)*colW
        local label=s[1]
        local value=tostring(s[2])
        partyText(label,cx+(colW-partyTextWidth(label,1.7))/2,statY,1.7,
          {0.25,0.25,0.22,1})
        partyText(value,cx+(colW-partyTextWidth(value,2.4))/2,statY+4,2.4,
          {0.06,0.06,0.06,1})
      end

      if mon.item and mon.item~=0 and mon.item~="" then
        local itemName=tostring(mon.item)
        local idef=self.items and self.items[mon.item]
        if idef and idef.name then itemName=idef.name end
        if #itemName>13 then itemName=itemName:sub(1,12).."." end
        partyText("HELD "..itemName,lx+31,ly+50,1.9,{0.34,0.34,0.30,1})
      end
    else
      partyText("EGG",lx+9,ly+49,4,{0.18,0.18,0.16,1})
    end
  end

  -- --------------------------------------------------------------- party list
  local rx,rw=80,76
  local slotH,gap=16,1

  for i,m in ipairs(party) do
    if i>6 then break end
    local yy=23+(i-1)*(slotH+gap)
    local isSelected=i==selected
    local d=self.pokemon and self.pokemon[m.species]

    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)

    if isSelected then
      G.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",rx,yy,rw,slotH,3)
      G.setColor(0.985,0.975,0.92,1)
      roundedRect("fill",rx+2,yy+2,rw-4,slotH-4,2)
      G.setColor(0.62,0.48,0.20,1)
      roundedRect("line",rx+3,yy+3,rw-6,slotH-6,2)
    else
      partySlotPanel(rx,yy,rw,slotH,false)
    end

    G.push("all")
    G.translate(rx+2,yy)
    self:drawIcon(m,0,0)
    G.pop()
    G.pop()

    local n=m.isEgg and "EGG"
      or tostring(m.nickname or (d and d.name) or m.species or "POKéMON")
    if #n>10 then n=n:sub(1,9).."." end
    partyText(n,rx+19,yy+1,3.3,{0.06,0.06,0.06,1})
    local rowGender=GoldCompat.genderSymbol(m)
    if rowGender and not m.isEgg then
      local gx=math.min(rx+20+partyTextWidth(n,3.3),rx+rw-27)
      pcall(GoldCompat.drawGenderIcon,
        ox+gx*sc,oy+(yy+2.7)*sc,8,rowGender)
    end

    if not m.isEgg then
      local lv="Lv."..tostring(m.level or "?")
      partyText(lv,rx+rw-4-partyTextWidth(lv,3),yy+1,3,
        {0.06,0.06,0.06,1})

      local mhp=math.max(1,m.maxHp or (m.stats and m.stats.hp) or 1)
      local ratio=math.max(0,math.min(1,(m.hp or 0)/mhp))

      G.push("all")
      G.translate(ox,oy)
      G.scale(sc,sc)
      G.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",rx+19,yy+9,39,4,1.5)
      G.setColor(0.78,0.76,0.63,1)
      roundedRect("fill",rx+20,yy+10,37,2,1)
      if (m.hp or 0)>0 then
        local r,gg,b,a=hpColor(ratio)
        G.setColor(r,gg,b,a)
        roundedRect("fill",rx+20,yy+10,math.max(1,37*ratio),2,1)
      end
      G.pop()

      local hp=tostring(m.hp or 0).."/"..tostring(mhp)
      partyText(hp,rx+rw-4-partyTextWidth(hp,2.4),yy+9,2.4,
        {0.18,0.18,0.16,1})
    end
  end

  -- -------------------------------------------------------------- footer/prompt
  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  local fy=127
  G.setColor(0.08,0.08,0.07,1)
  G.rectangle("fill",4,fy,152,13)
  G.pop()

  local prompt=self.switchFrom and "Move to where?"
    or tostring(self.prompt or "Choose a POKéMON.")
  prompt=prompt:gsub("<PK><MN>","POKéMON")
  if #prompt>34 then prompt=prompt:sub(1,33).."." end
  partyText(prompt,8,130,3.6,{1,1,1,1})

  -- Gold's native submenu state, themed to match the Gen 1 party screen.
  if self.submenu and self.submenu.items then
    local count=#self.submenu.items
    local w=48
    local h=count*10+6
    local x=108
    local y=math.max(24,124-h)

    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)
    G.setColor(0.08,0.08,0.07,1)
    G.rectangle("fill",x,y,w,h)
    G.setColor(0.99,0.985,0.95,1)
    G.rectangle("fill",x+2,y+2,w-4,h-4)
    drawUnifiedBorder(x,y,w,h,0)

    for i=1,count do
      local yy=y+3+(i-1)*10
      if i==self.submenu.index then
        G.setColor(0.10,0.10,0.09,1)
        G.rectangle("fill",x+4,yy,w-8,9)
      end
    end
    G.pop()

    for i,item in ipairs(self.submenu.items) do
      local yy=y+3+(i-1)*10
      partyText(item.label,x+8,yy+1,3,
        i==self.submenu.index and {1,1,1,1} or {0.06,0.06,0.06,1})
    end
  end
end

function GoldCompat.dexMapLabel(data,mapId)
  local map=data and data.gen2Maps and data.gen2Maps[mapId]
  if map then
    if map.name and tostring(map.name)~="" then return tostring(map.name) end
    local landmarkIndex=map.landmark
    if landmarkIndex then
      local ok,Nests=pcall(require,"src.core.gen2.Nests")
      if ok and Nests then
        local landmark=Nests.landmark(data,landmarkIndex)
        if landmark then
          local name=landmark.name or landmark.label or landmark.title
          if not name and type(landmark.lines)=="table" then
            name=table.concat(landmark.lines," ")
          end
          if name and tostring(name)~="" then return tostring(name) end
        end
      end
    end
  end
  return tostring(mapId or "UNKNOWN")
    :gsub("^MAP_",""):gsub("_"," "):gsub("%s+"," ")
end


-- -------------------------------------------------------------------------
-- Cross-generation location banner
-- -------------------------------------------------------------------------
-- Presentation-only area indicator. Gen I does not natively expose this as a
-- screen, so the mod observes the already-loaded overworld map. Gen II uses the
-- same read-only path through Game2.world. No warp, connection, save, encounter,
-- script, or map lifecycle is replaced.
function GoldCompat.locationBannerMapId(game)
  local world=game and (game.overworld or game.world)
  local map=world and world.map
  local mapId=map and (map.id or map.name)
  if mapId==nil or tostring(mapId)=="" then return nil end
  return tostring(mapId)
end

-- Vocabulary used only when the engine's human-facing map/landmark name
-- falls back to a compact generated identifier (FUCHSIACITY, SAFARIZONEGATE,
-- OLIVINELIGHTHOUSE5F, etc.). This is intentionally cross-generation and
-- generic: the formatter segments every identifier with the same rules rather
-- than maintaining a growing list of one-off map fixes.
GoldCompat.LOCATION_BANNER_WORDS=GoldCompat.LOCATION_BANNER_WORDS or {
  -- Regions / settlements.
  KANTO=true,JOHTO=true,PALLET=true,VIRIDIAN=true,PEWTER=true,CERULEAN=true,
  LAVENDER=true,VERMILION=true,CELADON=true,FUCHSIA=true,FUSCHIA=true,
  CINNABAR=true,SAFFRON=true,INDIGO=true,PLATEAU=true,
  NEW=true,BARK=true,CHERRYGROVE=true,VIOLET=true,AZALEA=true,GOLDENROD=true,
  ECRUTEAK=true,OLIVINE=true,CIANWOOD=true,MAHOGANY=true,BLACKTHORN=true,
  SILVER=true,

  -- Outdoor / landmark vocabulary shared by map ids in Red/Yellow and Gold.
  ROUTE=true,TOWN=true,CITY=true,ISLAND=true,ISLANDS=true,ROAD=true,PATH=true,
  FOREST=true,CAVE=true,CAVES=true,TUNNEL=true,MOUNTAIN=true,MT=true,MOON=true,
  SEAFOAM=true,VICTORY=true,DIGLETT=true,DIGLETTS=true,ROCK=true,POWER=true,
  PLANT=true,SAFARI=true,ZONE=true,SECRET=true,HOUSE=true,ENTRANCE=true,EXIT=true,
  GATE=true,PORT=true,DOCK=true,HARBOR=true,BRIDGE=true,LAKE=true,RAGE=true,
  NATIONAL=true,PARK=true,RUINS=true,ALPH=true,UNION=true,SLOWPOKE=true,WELL=true,
  ILEX=true,BURNED=true,SPROUT=true,TIN=true,BELL=true,WHIRL=true,ICE=true,
  DRAGON=true,DRAGONS=true,DEN=true,MORTAR=true,TOHJO=true,FALLS=true,
  DARK=true,ROCK=true,RECEIVING=true,

  -- Buildings / facilities / rooms.
  CENTER=true,CENTRE=true,POKE=true,POKEMON=true,MART=true,GYM=true,LAB=true,
  TOWER=true,LIGHTHOUSE=true,MANSION=true,DEPT=true,STORE=true,SHOP=true,
  UNDERGROUND=true,BASEMENT=true,FLOOR=true,ROOF=true,ROOM=true,HALL=true,
  OFFICE=true,CLUB=true,HOTEL=true,MUSEUM=true,SCHOOL=true,ACADEMY=true,
  DAY=true,CARE=true,BIKE=true,TRAIN=true,STATION=true,RADIO=true,
  GAME=true,CORNER=true,PRIZE=true,THEATER=true,THEATRE=true,DANCE=true,
  RESTAURANT=true,CAFE=true,WARDEN=true,HEADQUARTERS=true,HQ=true,
  ELEVATOR=true,LIFT=true,LOBBY=true,RECEPTION=true,

  -- Common map-specific nouns / proper-name components.
  OAK=true,OAKS=true,ELM=true,ELMS=true,BILL=true,BILLS=true,FUJI=true,FUJIS=true,
  MR=true,PSYCHIC=true,NAME=true,RATER=true,MOVE=true,DELETER=true,RELEARNER=true,
  FAN=true,ROCKET=true,HIDEOUT=true,SILPH=true,CO=true,ANNE=true,SS=true,
  COPYCAT=true,FIGHTING=true,DOJO=true,TRADE=true,BADGE=true,FISHING=true,
  GOOD=true,ROD=true,OLD=true,MAN=true,REDS=true,BLUES=true,PLAYERS=true,
  MOMS=true,KURTS=true,EARLS=true,KENYAS=true,KIMONO=true,CHARCOAL=true,KILN=true,
  BATTLE=true,FRONTIER=true,TRAINER=true,HOUSE=true,

  -- Gold-specific facilities / landmarks that otherwise arrive concatenated.
  POKEGEAR=true,BUG=true,CONTEST=true,HAIRCUT=true,BROTHERS=true,COM=true,SEER=true,SEERS=true,
  GOLDENROD=true,DEPARTMENT=true,STORE=true,UNDERGROUND=true,
  RADIO=true,LIGHTHOUSE=true,AQUA=true,FAST=true,SHIP=true,OUTSIDE=true,INSIDE=true,
  DRAGON=true,SHRINE=true,WHIRLPOOL=true,MAZE=true,FOREST=true,
  COTTAGE=true,KITCHEN=true,PHARMACY=true,OBSERVATORY=true,
  LOCKER=true,WAREHOUSE=true,TERMINAL=true,LOUNGE=true,
}

GoldCompat.LOCATION_BANNER_ALIASES=GoldCompat.LOCATION_BANNER_ALIASES or {
  OAKSLAB="OAK'S LAB", ELMSLAB="ELM'S LAB", BILLSHOUSE="BILL'S HOUSE",
  MRFUJISHOUSE="MR. FUJI'S HOUSE", SAFARIZONE="SAFARI ZONE",
  SAFARIZONEGATE="SAFARI ZONE GATE",
}

function GoldCompat.locationBannerSplitWord(word)
  word=tostring(word or "")
  if word=="" or word:find("%d") or GoldCompat.LOCATION_BANNER_WORDS[word] then
    return word
  end

  -- Segment every compact identifier, not only identifiers made entirely from
  -- words we already know. Unknown proper-name runs are preserved as one piece
  -- while recognised location nouns around them are separated. That means a
  -- new/obscure map like SOMEONESHOUSE or SOMETOWNCITY still becomes
  -- "SOMEONES HOUSE" / "SOMETOWN CITY" without needing a per-map override.
  local n=#word
  local best={[1]={text="",unknownChars=0,unknownRuns=0,parts=0,score=0}}

  local function better(a,b)
    if not b then return true end
    if a.unknownChars~=b.unknownChars then return a.unknownChars<b.unknownChars end
    if a.unknownRuns~=b.unknownRuns then return a.unknownRuns<b.unknownRuns end
    if a.parts~=b.parts then return a.parts<b.parts end
    return a.score>b.score
  end

  local function append(state,token,isUnknown)
    local row={
      text=state.text=="" and token or (state.text.." "..token),
      unknownChars=state.unknownChars+(isUnknown and #token or 0),
      unknownRuns=state.unknownRuns+(isUnknown and 1 or 0),
      parts=state.parts+1,
      score=state.score+(isUnknown and 0 or (#token*#token)),
    }
    return row
  end

  local function knownStartsAt(pos)
    for finish=pos,n do
      if GoldCompat.LOCATION_BANNER_WORDS[word:sub(pos,finish)] then return true end
    end
    return false
  end

  for i=1,n do
    local state=best[i]
    if state then
      for j=i,n do
        local token=word:sub(i,j)
        if GoldCompat.LOCATION_BANNER_WORDS[token] then
          local row=append(state,token,false)
          if better(row,best[j+1]) then best[j+1]=row end
        end
      end

      -- Unknown text is allowed only as one contiguous run ending at the next
      -- recognised boundary (or end of the word). This prevents letter-by-
      -- letter garbage while still spacing every actual facility/area suffix.
      for j=i,n do
        if j==n or knownStartsAt(j+1) then
          local token=word:sub(i,j)
          local row=append(state,token,true)
          if better(row,best[j+1]) then best[j+1]=row end
        end
      end
    end
  end
  return best[n+1] and best[n+1].text or word
end

function GoldCompat.locationBannerFormatRaw(label)
  label=tostring(label or ""):upper()
    :gsub("^MAP_",""):gsub("_+"," "):gsub("%-+"," ")
    :gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","")
  if label=="" then return label end

  local aliasKey=label:gsub("[^A-Z0-9]","")
  local alias=GoldCompat.LOCATION_BANNER_ALIASES[aliasKey]
  if alias then return alias end

  -- Expose route numbers and floor markers before the word-break pass. The
  -- floor markers are reassembled afterwards, so B1F/2F remain conventional.
  label=label:gsub("(%a)(%d)","%1 %2"):gsub("(%d)(%a)","%1 %2")
  label=label:gsub("([A-Z])B%s+(%d+)%s+F","%1 B%2F")
  label=label:gsub("(%d+)%s+F","%1F")

  local parts={}
  for chunk in label:gmatch("%S+") do
    parts[#parts+1]=GoldCompat.locationBannerSplitWord(chunk)
  end
  label=table.concat(parts," ")
    :gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","")

  -- A gate's first floor is just the gate. Keep upper/basement floors because
  -- they distinguish genuinely separate areas.
  if label:find("GATE",1,true) then label=label:gsub("%s+1F$","") end
  return label
end

-- Gen I's Town Map deliberately maps ordinary interiors back onto their
-- containing city/town square. Gen II exposes the same concept directly as a
-- landmark id on every map record. The banner follows that semantic location
-- rather than the raw room/map id, so walking through a house, shop, Center,
-- gate floor, etc. does not manufacture a new "area" just because a new map
-- object was loaded.
function GoldCompat.locationBannerArea(game,mapId)
  if not (game and game.data and mapId) then return nil,nil end

  if GoldCompat.isGen2Game(game) then
    local map=game.data.gen2Maps and game.data.gen2Maps[mapId]
    if not map then return nil,nil end
    local key=map.landmark~=nil and ("g2-landmark:"..tostring(map.landmark))
      or ("g2-map:"..tostring(mapId))
    local label=GoldCompat.locationBannerFormatRaw(
      GoldCompat.dexMapLabel(game.data,mapId))
    if label=="" or label=="UNKNOWN" or label=="N/A" then label=nil end
    return key,label
  end

  local field=game.data.field or {}
  local townMap=field.townMap
  if type(townMap)=="table" and type(townMap.locations)=="table" then
    townMap=townMap.locations
  end
  local entry=type(townMap)=="table" and townMap[mapId] or nil
  if type(entry)=="table" then
    local coords=entry.coords or entry
    local x=tonumber(coords.x or coords.col)
    local y=tonumber(coords.y or coords.row)
    local raw=entry.name or entry.label
    local label=GoldCompat.locationBannerFormatRaw(raw or DexUI.locationName(game,mapId))
    local key
    if x~=nil and y~=nil then
      key=("g1-townmap:%s:%s:%s"):format(tostring(raw or label or ""),tostring(x),tostring(y))
    else
      key="g1-townmap:"..tostring(raw or label or mapId)
    end
    if label=="" or label=="UNKNOWN" or label=="N/A" then label=nil end
    return key,label
  end

  local label=GoldCompat.locationBannerFormatRaw(DexUI.locationName(game,mapId))
  if label=="" or label=="UNKNOWN" or label=="N/A" then label=nil end
  return "g1-map:"..tostring(mapId),label
end

-- The semantic area above decides WHAT changed. This decides whether the
-- CURRENT map is an appropriate place to announce it. Ordinary interiors are
-- intentionally silent; crucially, they also do not advance the last announced
-- area, so a ROUTE -> GATE -> CITY transition announces the CITY after the
-- player emerges rather than announcing it inside the gate.
GoldCompat.LOCATION_BANNER_GEN1_SURFACES=GoldCompat.LOCATION_BANNER_GEN1_SURFACES or {
  -- Geographic / traversal areas only. Building-class tilesets intentionally
  -- stay out even when the building is large: the banner is for world-area
  -- orientation, not a toast for every door warp.
  OVERWORLD=true, PLATEAU=true, FOREST=true, CAVERN=true, UNDERGROUND=true,
}

function GoldCompat.locationBannerMapVisible(game,mapId)
  if not (game and game.data and mapId) then return false end
  if GoldCompat.isGen2Game(game) then
    local map=game.data.gen2Maps and game.data.gen2Maps[mapId]
    if not map then return false end
    local env=tostring(map.environment or ""):upper()
    -- Gold's map metadata explicitly distinguishes ordinary interiors/gates
    -- from towns, routes and caves. Keep those transition rooms silent.
    if env:find("INDOOR",1,true) or env:find("GATE",1,true) then return false end
    if env~="" then return true end
    -- Stale/modified caches without an environment still get a conservative
    -- fallback: obvious room/building maps stay quiet, geographic maps pass.
    local id=tostring(mapId):upper()
    for _,word in ipairs({"_HOUSE","HOUSE_","_MART","MART_","CENTER","_GYM","GYM_",
      "_LAB","LAB_","_ROOM","ROOM_","_GATE","GATE_","ELEVATOR","OFFICE","SHOP"}) do
      if id:find(word,1,true) then return false end
    end
    return true
  end

  local def=game.data.maps and game.data.maps[mapId]
  if not def then return false end
  if def.outdoor==true then return true end
  local tileset=tostring(def.tileset or ""):upper()
  return GoldCompat.LOCATION_BANNER_GEN1_SURFACES[tileset] and true or false
end

function GoldCompat.locationBannerForeground(game)
  -- Never compete with battle presentation. Safari included: its battle state
  -- is intentionally engine-owned and this decoration stays completely out.
  if battleStateInStack(game) then return false end
  local top=topState(game)
  if not top then
    -- Gold's world is owned by Game2 rather than living in StateStack; an empty
    -- stack is its ordinary field-play state.
    return GoldCompat.isGen2Game(game) and game.world~=nil
  end
  if top.isOverworld then return true end
  if top.isTextBox or getmetatable(top)==TextBox or getmetatable(top)==ChoiceBox then
    return true
  end
  return false
end

function GoldCompat.drawLocationBanner(name,alpha)
  if not name or (alpha or 0)<=0 then return end
  local G=love.graphics
  local sw,sh=G.getDimensions()
  local uiScale=clamp(math.min(sw/1280,sh/720),0.72,1.75)
  local textSize=clamp(math.floor(22*uiScale+0.5),15,34)
  local textFont=font(textSize*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local textW=textFont and textFont:getWidth(tostring(name)) or (#tostring(name)*textSize*0.55)
  local padX=math.floor(34*uiScale+0.5)
  local w=clamp(math.floor(textW+padX*2+0.5),math.floor(260*uiScale),math.floor(720*uiScale))
  w=math.min(w,sw-math.floor(24*uiScale))
  local h=clamp(math.floor(56*uiScale+0.5),44,88)
  local x=math.floor((sw-w)*0.5+0.5)
  local y=math.max(10,math.floor(18*uiScale+0.5))
  local a=clamp(alpha,0,1)

  G.push("all")
  G.origin()

  -- Same charcoal/teal glass stack as the shared dialogue and battle panels,
  -- compressed into a quiet top-center navigation banner.
  G.setColor(0.01,0.015,0.02,0.42*a)
  roundedRect("fill",x+math.max(2,math.floor(3*uiScale)),
    y+math.max(2,math.floor(4*uiScale)),w,h,math.max(7,math.floor(12*uiScale)))
  G.setColor(0.055,0.105,0.115,0.84*a)
  roundedRect("fill",x,y,w,h,math.max(7,math.floor(12*uiScale)))
  G.setColor(0.025,0.045,0.050,0.72*a)
  local inset=math.max(2,math.floor(4*uiScale))
  roundedRect("fill",x+inset,y+inset,w-inset*2,h-inset*2,
    math.max(5,math.floor(9*uiScale)))

  G.setColor(0.44,0.68,0.68,0.94*a)
  G.setLineWidth(math.max(1.5,2*uiScale))
  roundedRect("line",x+inset,y+inset,w-inset*2,h-inset*2,
    math.max(5,math.floor(9*uiScale)))

  -- A restrained teal hardware rail keeps the banner recognisably part of the
  -- Colosseum shell without turning an informational toast into a menu card.
  G.setColor(0.20,0.62,0.57,0.78*a)
  G.rectangle("fill",x+math.floor(20*uiScale),y+inset,
    math.max(1,w-math.floor(40*uiScale)),math.max(1,math.floor(2*uiScale)))
  G.pop()

  -- Center against the equipped font's actual glyph box rather than the
  -- requested point size. This keeps every font profile visually centered
  -- inside the glass panel, including the heavier/wider replacement fonts.
  local glyphH=textFont and textFont:getHeight() or textSize
  local weight=GoldCompat.userTextWeight()
  local textX=x+(w-textW)*0.5-weight*0.5
  local textY=y+(h-glyphH)*0.5-0.5
  printText(name,textX,textY,textSize,{0.88,1.00,0.96,a})
end

function GoldCompat.locationBannerHud(next,game,viewport)
  next(game,viewport)

  local mapId=GoldCompat.locationBannerMapId(game)
  if not mapId then
    State.locationBannerLastMap=nil
    State.locationBannerName=nil
    State.locationBannerPending=nil
    State.locationBannerStarted=nil
    return
  end

  local areaKey,areaName=GoldCompat.locationBannerArea(game,mapId)
  local visibleMap=GoldCompat.locationBannerMapVisible(game,mapId)

  if not GoldCompat.locationBannerPresentationEnabled() then
    -- Track meaningful areas silently while disabled so turning the option
    -- back on does not manufacture a fake transition. Interior/transit maps do
    -- not advance the semantic area for the same reason they do not announce.
    if visibleMap and areaKey then State.locationBannerLastMap=areaKey end
    State.locationBannerName=nil
    State.locationBannerPending=nil
    State.locationBannerStarted=nil
    return
  end

  if not visibleMap then
    -- Never leave an already-running toast hanging over a house/gate/etc.
    -- Keep locationBannerLastMap untouched so emerging into a genuinely new
    -- route/town/city/cave can still announce that area.
    State.locationBannerName=nil
    State.locationBannerPending=nil
    State.locationBannerStarted=nil
    return
  end

  if areaKey and areaKey~=State.locationBannerLastMap then
    State.locationBannerLastMap=areaKey
    State.locationBannerName=areaName
    State.locationBannerPending=State.locationBannerName~=nil
    State.locationBannerStarted=nil
  end
  if not State.locationBannerName or not GoldCompat.locationBannerForeground(game) then
    return
  end

  local now=(love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
  if State.locationBannerPending then
    State.locationBannerPending=nil
    State.locationBannerStarted=now
  end
  local elapsed=now-(State.locationBannerStarted or now)
  local duration=2.65
  if elapsed>=duration then
    State.locationBannerName=nil
    State.locationBannerStarted=nil
    return
  end

  local alpha=1
  if elapsed<0.18 then
    alpha=elapsed/0.18
  elseif elapsed>2.05 then
    alpha=(duration-elapsed)/(duration-2.05)
  end
  GoldCompat.drawLocationBanner(State.locationBannerName,alpha)
end

function GoldCompat.dexSlotHasSpecies(slots,species)
  if type(slots)~="table" then return false end
  -- direct list: water/fish/tree
  for _,slot in ipairs(slots) do
    if type(slot)=="table" and slot.species==species then return true end
  end
  -- time-of-day map: grass
  for _,list in pairs(slots) do
    if type(list)=="table" then
      for _,slot in ipairs(list) do
        if type(slot)=="table" and slot.species==species then return true end
      end
    end
  end
  return false
end

function GoldCompat.dexCatchLocations(self,species)
  local data=self and self.data or {}
  local enc=data.gen2Encounters or {}
  local byMap={}

  local function add(mapId,method)
    if not mapId or not method then return end
    local row=byMap[mapId]
    if not row then
      row={map=mapId,name=GoldCompat.dexMapLabel(data,mapId),methods={},seen={}}
      byMap[mapId]=row
    end
    if not row.seen[method] then
      row.seen[method]=true
      row.methods[#row.methods+1]=method
    end
  end

  local function grassTable(tbl,label)
    for mapId,entry in pairs(tbl or {}) do
      local times={}
      for _,tod in ipairs({"MORN","DAY","NITE"}) do
        if GoldCompat.dexSlotHasSpecies(entry and entry.slots
            and entry.slots[tod],species) then
          times[#times+1]=tod
        end
      end
      if #times>0 then
        add(mapId,label.." "..table.concat(times,"/"))
      end
    end
  end
  grassTable(enc.grass,"GRASS")
  grassTable(enc.swarmGrass,"SWARM GRASS")

  for mapId,entry in pairs(enc.water or {}) do
    if GoldCompat.dexSlotHasSpecies(entry and entry.slots,species) then
      add(mapId,"SURF")
    end
  end
  for mapId,entry in pairs(enc.swarmWater or {}) do
    if GoldCompat.dexSlotHasSpecies(entry and entry.slots,species) then
      add(mapId,"SWARM SURF")
    end
  end

  -- Fishing groups are selected by each map header's fishGroup.
  for mapId,map in pairs(data.gen2Maps or {}) do
    local group=map and map.fishGroup
    local fish=group and enc.fishGroups and enc.fishGroups[group]
    if fish then
      if GoldCompat.dexSlotHasSpecies(fish.old,species) then
        add(mapId,"OLD ROD")
      end
      if GoldCompat.dexSlotHasSpecies(fish.good,species) then
        add(mapId,"GOOD ROD")
      end
      if GoldCompat.dexSlotHasSpecies(fish.super,species) then
        add(mapId,"SUPER ROD")
      end
    end
  end

  for mapId,setId in pairs(enc.trees or {}) do
    local set=enc.treeSets and enc.treeSets[setId]
    if set then
      if GoldCompat.dexSlotHasSpecies(set.common,species) then
        add(mapId,"HEADBUTT")
      end
      if GoldCompat.dexSlotHasSpecies(set.rare,species) then
        add(mapId,"HEADBUTT RARE")
      end
    end
  end

  for mapId,setId in pairs(enc.rocks or {}) do
    local set=enc.treeSets and enc.treeSets[setId]
    if set and (GoldCompat.dexSlotHasSpecies(set.common,species)
        or GoldCompat.dexSlotHasSpecies(set.rare,species)) then
      add(mapId,"ROCK SMASH")
    end
  end

  for _,slot in ipairs(enc.bugContest or {}) do
    if slot and slot.species==species then
      add("NATIONAL_PARK","BUG CONTEST")
      break
    end
  end

  -- Roaming Pokémon show their CURRENT catchable map.
  for _,slot in ipairs((self.save and self.save.roamers) or {}) do
    if slot and slot.species==species and slot.map then
      add(slot.map,"ROAMING")
    end
  end

  local rows={}
  for _,row in pairs(byMap) do
    table.sort(row.methods)
    row.method=table.concat(row.methods," / ")
    rows[#rows+1]=row
  end
  table.sort(rows,function(a,b)
    if a.name==b.name then return a.method<b.method end
    return a.name<b.name
  end)
  return rows
end

function GoldCompat.drawGoldDexLocations(self,row)
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  local source=self.pokemon and self.pokemon[row.species]
  local dexEntry=self.dex and self.dex.entries and self.dex.entries[row.species]
  local name=tostring((source and source.name) or row.species or "POKéMON")
  local locations=GoldCompat.dexCatchLocations(self,row.species)

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  -- Keep this native PokéDex subpage inside the same translucent monitor
  -- language as the main dossier; never fall back to the donor cartridge page.
  -- This page owns the full logical screen. An alpha surface here exposes the
  -- native caught/new-entry text or the prior dossier underneath as faint
  -- artifacts, so only hanging overlays remain translucent.
  G.setColor(0.018,0.040,0.044,1.00)
  roundedRect("fill",3,3,154,128,5)
  G.setColor(0.34,0.53,0.52,0.96)
  roundedRect("line",3,3,154,128,5)
  G.setColor(0.015,0.075,0.054,0.90)
  roundedRect("fill",6,6,148,12,4)
  G.setColor(0.12,0.75,0.32,1)
  G.rectangle("fill",9,16,142,1)
  G.setColor(0.025,0.085,0.085,0.90)
  roundedRect("fill",7,22,146,20,4)
  G.setColor(0.27,0.45,0.43,0.95)
  roundedRect("line",7,22,146,20,4)
  G.setColor(0.012,0.030,0.033,0.86)
  roundedRect("fill",7,46,146,80,4)
  G.setColor(0.28,0.43,0.42,0.95)
  roundedRect("line",7,46,146,80,4)
  G.setColor(0.030,0.130,0.115,0.80)
  G.rectangle("fill",10,49,140,9)
  G.pop()

  finalText("PokéDex  /  HABITAT DATA",10,9,3.1,
    {0.42,1.00,0.52,1},ox,oy,sc)
  finalText(name,12,27,3.65,{0.98,0.99,0.96,1},ox,oy,sc,"left",83)
  if dexEntry and dexEntry.dex then
    finalText(("No. %03d"):format(tonumber(dexEntry.dex) or 0),
      122,28,2.45,{0.68,0.84,0.77,1},ox,oy,sc,"right",24)
  end
  finalText(("%d KNOWN AREA%s"):format(#locations,#locations==1 and "" or "S"),
    103,35,1.75,{0.45,0.86,0.58,1},ox,oy,sc,"right",43)
  finalText("LOCATION",12,51,1.85,{0.45,0.86,0.58,1},ox,oy,sc)
  finalText("ENCOUNTER METHOD",82,51,1.85,{0.45,0.86,0.58,1},ox,oy,sc)

  self.__gen3uiDexLocationRows=locations
  local visible=7
  local maxScroll=math.max(0,#locations-visible)
  self.__gen3uiDexLocationScroll=math.max(0,
    math.min(self.__gen3uiDexLocationScroll or 0,maxScroll))
  local first=(self.__gen3uiDexLocationScroll or 0)+1

  if #locations==0 then
    finalText("NO WILD LOCATION DATA",12,70,3.0,
      {0.68,0.78,0.74,1},ox,oy,sc)
  else
    for i=0,visible-1 do
      local loc=locations[first+i]
      if not loc then break end
      local yy=62+i*8.4
      if i%2==1 then
        G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
        G.setColor(0.035,0.080,0.078,0.55)
        G.rectangle("fill",10,yy-1.2,140,7.6)
        G.pop()
      end
      -- Keep the location column compact and visually stable. Long names
      -- are slightly smaller and get a wider dedicated column so they never
      -- stack or collide with neighboring rows.
      local locName=tostring(loc.name or "")
      local locSize=(#locName>=13) and 2.35 or 2.65
      finalTextFitted(locName,12,yy,locSize,1.35,{0.92,0.97,0.93,1},
        ox,oy,sc,"left",66,6.6)
      local method=tostring(loc.method or "WILD")
      local methodSize=2.20
      while methodSize>1.45 and finalTextWidth(method,methodSize,sc)>66 do
        methodSize=methodSize-0.10
      end
      finalTextFitted(method,82,yy,methodSize,1.35,{0.95,0.76,0.28,1},
        ox,oy,sc,"left",64,6.6)
    end
    if first>1 then
      finalText("▲",145,59,2.5,{0.42,1.00,0.52,1},ox,oy,sc)
    end
    if first+visible-1<#locations then
      finalText("▼",145,117,2.5,{0.42,1.00,0.52,1},ox,oy,sc)
    end
  end

  finalText("↑/↓ SCROLL",9,134,1.95,
    {0.70,0.86,0.78,1},ox,oy,sc)
  local dexBackLabel="A/B: BACK TO DATA"
  local dexBackSize=2.05
  local dexBackX=151-finalTextWidth(dexBackLabel,dexBackSize,sc)
  finalText(dexBackLabel,dexBackX,134,dexBackSize,
    {0.88,0.96,0.90,1},ox,oy,sc)
  return true
end

function GoldCompat.drawGoldDexAction(self)
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  -- Match the Pokémon action rail: a compact vertical hanging card with one
  -- runoff selector, clear UP/DOWN affordances and measured single-line rows.
  -- It stays entirely inside the Dex's left column and never crosses into the
  -- species data panel or bottom footer.
  -- Five logical pixels of clear air separate the card (including its shadow)
  -- from the Pokédex's outer frame.
  local x,y,w,h=-52,48,47,32
  local labels={"DATA","LOCATION"}
  local selected=clamp(self.__colosseumDexActionIndex or 1,1,#labels)
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(x,y,w,h,0)
  for i,label in ipairs(labels) do
    local yy=y+5+(i-1)*12
    if i==selected then
      drawColosseumRunoffSelection(x+3,yy-2,w-6,9)
    end
  end
  G.pop()
  for i,label in ipairs(labels) do
    local yy=y+5+(i-1)*12
    finalTextFitted(label,x+12,yy,2.55,1.55,
      i==selected and {0.98,1.00,0.98,1} or {0.64,0.79,0.75,1},
      ox,oy,sc,"left",w-15,8)
  end
end

function GoldCompat.drawGoldPokedex(self,winW,winH)
  local row=self.current and self:current() or nil

  if self.view=="list" then
    -- Adapt Gold's real sorted rows/cursor/caught flags to the mature Gen 1
    -- Pokédex presentation. Input, mode switching and entry opening stay Gold.
    local items={}
    local index={}
    for i,r in ipairs(self.rows or {}) do
      items[i]={label=r.species}

      local source=self.pokemon and self.pokemon[r.species]
      local dexEntry=self.dex and self.dex.entries and self.dex.entries[r.species]
      local def={}
      if type(source)=="table" then
        for k,v in pairs(source) do def[k]=v end
      end

      def.id=r.species
      def.name=(source and source.name) or r.species
      def.dex=(dexEntry and dexEntry.dex) or r.dex or i
      def.dexEntry={
        kind=dexEntry and dexEntry.kind,
        gen2Height=dexEntry and dexEntry.height,
        gen2Weight=dexEntry and dexEntry.weight,
      }

      index[i]={id=r.species,def=def,dex=def.dex}
    end

    local facade={
      items=items,
      index=self.index or 1,
      __gen3uiDexIndex=index,
      __gen2Dex=true,
    }

    -- DexUI expects save.pokedex.owned; Gold calls the same set `caught`.
    local game=self.game
    local proxy=setmetatable({
      data=game.data,
      __gen2PokedexMenu=self,
      save=setmetatable({
        pokedex={
          seen=(self.save and self.save.pokedex and self.save.pokedex.seen) or {},
          owned=(self.save and self.save.pokedex and
            (self.save.pokedex.caught or self.save.pokedex.owned)) or {},
        }
      },{__index=game.save})
    },{__index=game})

    GoldCompat.dexActionRailActive=self.__colosseumDexAction==true
    DexUI.draw(proxy,facade)
    if self.__colosseumDexAction then GoldCompat.drawGoldDexAction(self) end
    GoldCompat.dexActionRailActive=nil
    return
  end

  if self.view=="locations" and row then
    return GoldCompat.drawGoldDexLocations(self,row)
  end

  if self.view=="entry" and row then
    local source=self.pokemon and self.pokemon[row.species]
    local dexEntry=self.dex and self.dex.entries and self.dex.entries[row.species]

    if source and dexEntry then
      -- Shallow display definition only; never mutate Gold's data tables.
      local def={}
      for k,v in pairs(source) do def[k]=v end
      def.id=row.species
      def.dex=dexEntry.dex
      def.dexEntry={
        kind=dexEntry.kind,
        gen2Height=dexEntry.height,
        gen2Weight=dexEntry.weight,
        text=dexEntry.text,
        text2=dexEntry.text2,
      }

      local proxy=setmetatable({
        data=self.game.data,
        __gen2PokedexMenu=self,
        save=setmetatable({
          pokedex={owned={[row.species]=row.caught==true}}
        },{__index=self.game.save})
      },{__index=self.game})

      -- Draw the established Gen 1 entry card, then replace its description
      -- region with Gold's real two-page dex text.
      DexUI.drawEntry(proxy,{def=def,forceOwned=row.caught==true})
      -- Strategy Memo owns the complete dossier surface. Gold's old adapter
      -- used to repaint a cartridge-style description/footer over this point.
      do return end

      local ox,oy,sc=safeFullCanvas()
      -- Our UI has one complete DATA page. Gold's two cartridge-sized text
      -- chunks are joined and rewrapped for the larger modern card.
      local raw=table.concat({
        tostring(dexEntry.text or ""),
        tostring(dexEntry.text2 or "")
      }," ")
      local clean=GoldCompat.cleanWrappedText(raw)

      local G=love.graphics
      G.push("all")
      G.translate(ox,oy)
      G.scale(sc,sc)
      G.setColor(0.99,0.985,0.95,1)

      -- The shared entry card already printed a bare ENTRY label. Clear the
      -- complete description/label region before drawing Gold's page counter
      -- so ENTRY never appears double-layered.
      G.rectangle("fill",10,75,138,48)
      G.pop()

      finalText("ENTRY",12,78,3.2,{0.38,0.38,0.35,1},ox,oy,sc)

      local entrySize=3.55
      local f=font(entrySize*UI_TEXT_SCALE*GoldCompat.userTextScale())
      local _,wrapped=f:getWrap(clean,132)
      for i=1,math.min(5,#wrapped) do
        finalText(wrapped[i],12,87+(i-1)*7.4,entrySize,
          {0.08,0.08,0.08,1},ox,oy,sc,"left",132)
      end

      -- DexUI's shared detail renderer already drew its own footer controls.
      -- Erase that footer here before painting the Gold DATA controls; without
      -- this the two legends occupy the exact same pixels and look "bold" or
      -- scrambled regardless of text scaling.
      G.push("all")
      G.translate(ox,oy)
      G.scale(sc,sc)
      G.setColor(0.08,0.08,0.08,1)
      G.rectangle("fill",4,132,152,8)
      G.pop()

      local backLabel="B: BACK"
      local backSize=2.05
      local backX=151-finalTextWidth(backLabel,backSize,sc)
      safeFooterText("A: CATCH LOCATIONS",9,134,2.05,
        {0.96,0.95,0.90,1},ox,oy,sc,104)
      finalText(backLabel,backX,134,backSize,
        {0.96,0.95,0.90,1},ox,oy,sc)
      return
    end
  end

  -- Gen 2-only views still use Gold's real renderer inside our widescreen shell
  -- until dedicated visual translations are added.
  local PokedexMenu=require("src.ui.gen2.PokedexMenu")
  local G=love.graphics
  winW=winW or G.getWidth()
  winH=winH or G.getHeight()

  if not self.__gen3uiDexCanvas then
    local ok,canvas=pcall(G.newCanvas,160,144)
    if ok then
      self.__gen3uiDexCanvas=canvas
      if canvas.setFilter then pcall(canvas.setFilter,canvas,"nearest","nearest") end
    end
  end

  local canvas=self.__gen3uiDexCanvas
  if not canvas or not PokedexMenu.__gen3uiOriginalDrawPanel then
    return PokedexMenu.__gen3uiOriginalDrawWidescreen(self,winW,winH)
  end

  local oldCanvas=G.getCanvas()
  G.push("all")
  G.setCanvas(canvas)
  G.clear(0,0,0,1)
  G.origin()
  PokedexMenu.__gen3uiOriginalDrawPanel(self)
  G.setCanvas(oldCanvas)
  G.pop()

  G.push("all")
  G.origin()
  G.setColor(0.94,0.93,0.87,1)
  G.rectangle("fill",0,0,winW,winH)

  local margin=24
  local x,y=margin,margin
  local w,h=winW-margin*2,winH-margin*2
  G.setColor(0.08,0.08,0.07,1)
  G.rectangle("fill",x,y,w,h)
  G.setColor(0.99,0.985,0.95,1)
  G.rectangle("fill",x+4,y+4,w-8,h-8)
  G.setColor(0.18,0.17,0.15,1)
  G.setLineWidth(2)
  G.rectangle("line",x+4,y+4,w-8,h-8)

  local bodyX=x+18
  local bodyY=y+54
  local bodyW=w-36
  local bodyH=h-84
  local scale=math.min(bodyW/160,bodyH/144)
  local dw,dh=160*scale,144*scale
  G.setColor(1,1,1,1)
  G.draw(canvas,bodyX+(bodyW-dw)/2,bodyY+(bodyH-dh)/2,0,scale,scale)
  G.pop()

  printText("POKéDEX  "..tostring(self.view or ""):upper(),
    x+18,y+14,16,{0.06,0.06,0.06,1})
end


function GoldCompat.cleanWrappedText(text)
  local clean=tostring(text or "")
    :gsub("<NEXT>"," ")
    :gsub("\\v"," ")
    :gsub("\\f"," ")
    :gsub("%s+"," ")
    :gsub("^%s+","")
    :gsub("%s+$","")

  -- Gen 2's source strings sometimes encode line-break hyphenation such as
  -- "pro- tects" / "Be- cause". Once presented in a widescreen UI those
  -- cartridge-era breaks look like accidental word splitting, so rejoin only
  -- alphabetic hyphen+whitespace+alphabetic sequences.
  local previous
  repeat
    previous=clean
    clean=clean:gsub("(%a)%-%s+(%a)","%1%2")
  until clean==previous

  return clean
end

function GoldCompat.summaryDexEntry(summary)
  local mon=summary and summary.mon
  local dex=summary and summary.game and summary.game.data
      and summary.game.data.gen2Pokedex
  return mon and dex and dex.entries and dex.entries[mon.species] or nil
end

function GoldCompat.summaryTypeNames(summary)
  if summary and type(summary.typeNames)=="function" then
    local ok,a,b=pcall(summary.typeNames,summary)
    if ok then return a,b end
  end
  local mon=summary and summary.mon
  local def=summary and summary.pokemon and mon
      and summary.pokemon[mon.species]
  local types=(mon and mon.types) or (def and def.types) or {}
  local function clean(value)
    if value==nil then return nil end
    local label=GoldCompat.humanizeIdentifier(value):upper()
    label=label:gsub(" TYPE$","")
    return label
  end
  return clean(types[1] or "N/A"),clean(types[2])
end

function GoldCompat.summaryMoveDef(summary,entry)
  if not entry then return nil end
  local id=type(entry)=="table" and (entry.id or entry.move) or entry
  return summary and summary.moves and summary.moves[id] or nil
end

function GoldCompat.summaryMoveName(summary,entry)
  local def=GoldCompat.summaryMoveDef(summary,entry)
  local id=type(entry)=="table" and (entry.id or entry.move) or entry
  local fallback=GoldCompat.humanizeIdentifier(id)
  return tostring((def and def.name) or (fallback~="" and fallback) or "---")
end

function GoldCompat.summaryExpRatio(summary)
  local mon=summary and summary.mon
  local def=summary and summary.pokemon and mon
      and summary.pokemon[mon.species]
  if not (mon and def and mon.level and mon.experience) then return 0 end
  if mon.level>=100 then return 1 end

  local ok,Mon=pcall(require,"src.battle.gen2.Mon")
  if not ok or not Mon then return 0 end
  local growth=summary.growth and summary:growth()
  if not growth then return 0 end

  local floor=Mon.experienceForLevel(growth,mon.level)
  local nextFloor=Mon.experienceForLevel(growth,mon.level+1)
  return math.max(0,math.min(1,
    (mon.experience-floor)/math.max(1,nextFloor-floor)))
end

function GoldCompat.drawGoldSummaryBase(summary,title)
  local G=love.graphics
  local ox,oy,sc=safeFullCanvas()

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)

  G.setColor(0.94,0.93,0.87,1)
  G.rectangle("fill",0,0,160,144)

  -- Header.
  G.setColor(0.08,0.08,0.08,1)
  G.rectangle("fill",4,4,152,17)
  G.setColor(0.99,0.985,0.955,1)
  G.rectangle("fill",5,5,150,15)

  -- Main cards - same geometry family as the Gen 1 summary.
  G.setColor(0.12,0.12,0.11,1)
  roundedRect("fill",4,33,65,95,3)
  roundedRect("fill",72,33,84,95,3)
  G.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",6,35,61,91,2)
  roundedRect("fill",74,35,80,91,2)

  setCurrentBorderColor(1)
  roundedRect("line",7,36,59,89,2)
  roundedRect("line",75,36,78,89,2)

  -- Footer.
  G.setColor(0.08,0.08,0.08,1)
  G.rectangle("fill",4,132,152,8)

  -- Three native Gold pages as explicit tabs.
  local tabs={"INFO","MOVES","STATS"}
  local page=math.max(1,math.min(3,summary.page or 1))
  local tx=75
  local tw=25
  for i,label in ipairs(tabs) do
    local x=tx+(i-1)*26
    if i==page then
      G.setColor(0.11,0.28,0.38,1)
      roundedRect("fill",x,23,tw,8,1.5)
    else
      G.setColor(0.84,0.82,0.74,1)
      roundedRect("fill",x,23,tw,8,1.5)
    end
  end
  G.pop()

  finalText(title or "POKéMON SUMMARY",
    9,8,4.8,{0.06,0.06,0.06,1},ox,oy,sc)

  for i,label in ipairs({"INFO","MOVES","STATS"}) do
    finalText(label,75+(i-1)*26,24.7,2.45,
      i==(summary.page or 1) and {0.98,0.97,0.92,1}
        or {0.24,0.24,0.22,1},
      ox,oy,sc,"center",25)
  end

  return ox,oy,sc
end

function GoldCompat.summaryEvolutionRows(summary)
  local mon=summary and summary.mon
  local def=summary and summary.pokemon and mon
      and summary.pokemon[mon.species]
  local rows={}
  if not def then return rows end

  for _,evo in ipairs(def.evolutions or {}) do
    local into=evo.into or evo.species
    local target=summary.pokemon and summary.pokemon[into]
    local targetName=tostring((target and target.name) or into or "?")
    local method=tostring(evo.method or ""):upper()
    local how

    if method=="EVOLVE_LEVEL" or method=="LEVEL" then
      how="Lv. "..tostring(evo.level or "?")
    elseif method=="EVOLVE_ITEM" or method=="ITEM" then
      local item=summary.items and summary.items[evo.item]
      how=tostring((item and item.name) or evo.item or "ITEM")
    elseif method=="EVOLVE_TRADE" or method=="TRADE" then
      if evo.item then
        local item=summary.items and summary.items[evo.item]
        how="Trade + "..tostring((item and item.name) or evo.item)
      else
        how="Trade"
      end
    elseif evo.level then
      how="Lv. "..tostring(evo.level)
    elseif evo.item then
      local item=summary.items and summary.items[evo.item]
      how=tostring((item and item.name) or evo.item)
    else
      how=(method~="" and method:gsub("^EVOLVE_","")) or "Special"
    end

    rows[#rows+1]={name=targetName,how=how}
  end
  return rows
end

function GoldCompat.drawGoldSummaryIdentity(summary,ox,oy,sc)
  local mon=summary.mon
  local def=summary.pokemon and summary.pokemon[mon.species]
  if not (mon and def) then return end

  local name=mon.nickname or mon.name or def.name or mon.species or "POKéMON"
  finalText(name,10,39,4.2,{0.07,0.07,0.07,1},ox,oy,sc,"left",47)
  finalText("Lv."..tostring(mon.level or "?"),10,46,3.0,
    {0.20,0.20,0.18,1},ox,oy,sc)

  -- Same resolved sprite-package path as Party/Pokédex.
  local G=love.graphics
  G.push("all")
  G.origin()
  pcall(GoldCompat.drawCleanResolvedPortrait,summary.game,mon,
    ox+13*sc,oy+54*sc,47*sc,39*sc,"summary")
  G.pop()

  local gender=GoldCompat.genderSymbol(mon)
  if gender then
    pcall(GoldCompat.drawGenderIcon,
      ox+53*sc,oy+42*sc,10,gender)
  end

  finalText(("#%03d"):format(tonumber(def.dex) or 0),10,96,3.0,
    {0.36,0.36,0.33,1},ox,oy,sc)

  local type1,type2=GoldCompat.summaryTypeNames(summary)
  local types=type1 or "N/A"
  if type2 and type2~=type1 then types=types.." / "..type2 end
  finalText(types,10,102,2.9,{0.12,0.12,0.11,1},
    ox,oy,sc,"left",53)

  -- Bottom metadata is intentionally a two-column row: status left,
  -- evolution right. Both headers share the same baseline.
  local status=owStatus(mon) or "OK"
  finalText("STATUS",10,110,2.25,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(status,10,116,2.85,
    status=="OK" and {0.16,0.42,0.20,1} or {0.44,0.14,0.36,1},
    ox,oy,sc)

  local evos=GoldCompat.summaryEvolutionRows(summary)
  finalText("EVOLUTION",36,110,2.15,{0.40,0.40,0.37,1},ox,oy,sc,"left",26)
  if #evos==0 then
    finalText("NONE",36,116,2.35,{0.28,0.28,0.26,1},ox,oy,sc,"left",26)
  else
    local first=evos[1]
    finalText(first.name,36,116,2.30,{0.08,0.08,0.08,1},
      ox,oy,sc,"left",26)
    finalText(first.how,36,121,2.00,{0.30,0.30,0.28,1},
      ox,oy,sc,"left",26)
    if #evos>1 then
      finalText((" +%d"):format(#evos-1),56,121,1.65,
        {0.36,0.36,0.33,1},ox,oy,sc,"right",7)
    end
  end
end

function GoldCompat.drawGoldSummaryFooter(ox,oy,sc)
  finalText("SELECT: MOVE MANAGER",9,134,2.00,
    {0.96,0.95,0.90,1},ox,oy,sc,"left",58)
  finalText("←/→ PAGE  ↑/↓ POKéMON",63,134,1.62,
    {0.74,0.74,0.70,1},ox,oy,sc,"center",60)
  local backLabel="B: BACK"
  local backSize=2.00
  local backX=151-finalTextWidth(backLabel,backSize,sc)
  finalText(backLabel,backX,134,backSize,
    {0.96,0.95,0.90,1},ox,oy,sc)
end

function GoldCompat.drawGoldSummaryInfo(summary,ox,oy,sc)
  local mon=summary.mon
  local def=summary.pokemon and summary.pokemon[mon.species]
  local dex=GoldCompat.summaryDexEntry(summary)
  local stats=mon.stats or {}

  finalText("SPECIES",79,39,2.5,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(tostring((dex and dex.kind) or "N/A"):upper(),
    79,44,3.0,{0.08,0.08,0.08,1},ox,oy,sc,"left",34)

  local pseudo={dexEntry={
    gen2Height=dex and dex.height,
    gen2Weight=dex and dex.weight,
  }}
  finalText("HT",116,39,2.5,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(DexUI.heightLabel(pseudo),126,39,2.8,
    {0.08,0.08,0.08,1},ox,oy,sc,"left",24)
  finalText("WT",116,46,2.5,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(DexUI.weightLabel(pseudo),126,46,2.8,
    {0.08,0.08,0.08,1},ox,oy,sc,"left",24)

  -- HP.
  local hpMax=math.max(1,mon.maxHp or stats.hp or 1)
  finalText("HP",79,57,2.6,{0.40,0.40,0.37,1},ox,oy,sc)
  local G=love.graphics
  G.push("all")
  G.origin()
  local hx=ox+91*sc
  local hy=oy+58*sc
  local hw=52*sc
  local hh=3.0*sc
  local ratio=math.max(0,math.min(1,(mon.hp or 0)/hpMax))
  G.setColor(0.10,0.10,0.09,1)
  roundedRect("fill",hx,hy,hw,hh,hh*0.45)
  local r,gg,b,a=hpColor(ratio)
  G.setColor(r,gg,b,a)
  roundedRect("fill",hx+0.7*sc,hy+0.7*sc,
    math.max(0,(hw-1.4*sc)*ratio),math.max(1,hh-1.4*sc),hh*0.35)
  G.pop()
  finalText(("%d/%d"):format(mon.hp or 0,hpMax),
    116,64,2.65,{0.08,0.08,0.08,1},ox,oy,sc,"right",28)

  -- EXP.
  finalText("EXP POINTS",79,74,2.45,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(tostring(mon.experience or 0),119,74,2.8,
    {0.08,0.08,0.08,1},ox,oy,sc,"right",28)
  local nextExp=summary.expToNext and summary:expToNext() or 0
  finalText("NEXT LEVEL",79,81,2.45,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(tostring(nextExp),119,81,2.8,
    {0.08,0.08,0.08,1},ox,oy,sc,"right",28)

  G.push("all")
  G.origin()
  local ex=ox+80*sc
  local ey=oy+90*sc
  local ew=67*sc
  local eh=3.0*sc
  G.setColor(0.10,0.16,0.18,1)
  roundedRect("fill",ex,ey,ew,eh,eh*0.45)
  G.setColor(0.12,0.50,0.86,1)
  roundedRect("fill",ex+0.7*sc,ey+0.7*sc,
    math.max(0,(ew-1.4*sc)*GoldCompat.summaryExpRatio(summary)),
    math.max(1,eh-1.4*sc),eh*0.35)
  G.pop()

  local held=summary.itemName and summary:itemName() or nil
  finalText("HELD ITEM",79,100,2.45,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText(held or "NONE",79,106,3.0,{0.08,0.08,0.08,1},
    ox,oy,sc,"left",31)

  -- Mod-owned lifetime KO counter for this individual Pokémon.
  finalText("POKéMON FAINTED",116,100,1.80,{0.40,0.40,0.37,1},
    ox,oy,sc,"left",33)
  finalText(tostring(tonumber(mon.gen3uiFainted) or 0),126,106,3.0,
    {0.08,0.08,0.08,1},ox,oy,sc,"right",20)

  GoldCompat.drawGoldSummaryFooter(ox,oy,sc)
end

function GoldCompat.summaryCompatibleMachines(summary)
  local mon=summary and summary.mon
  local def=summary and summary.pokemon and mon
      and summary.pokemon[mon.species]
  local compatible={}
  if not def then return compatible end

  -- Gold's species definition is authoritative for TM/HM compatibility.
  -- Do not infer compatibility from move type or mutate any engine tables.
  for _,moveId in ipairs(def.tmhm or {}) do
    local md=summary.moves and summary.moves[moveId]
    compatible[#compatible+1]={
      id=moveId,
      name=tostring((md and md.name)
        or GoldCompat.humanizeIdentifier(moveId) or "---"),
      typeName=GoldCompat.moveTypeName(md),
      power=md and tonumber(md.power) or nil,
      accuracy=md and tonumber(md.accuracy) or nil,
    }
  end
  table.sort(compatible,function(a,b)
    return a.name<b.name
  end)
  return compatible
end

function GoldCompat.summaryLevelUpLearnset(summary)
  local mon=summary and summary.mon
  local def=summary and summary.pokemon and mon
      and summary.pokemon[mon.species]
  local learned={}
  if not def then return learned end

  -- Gen 2's authoritative EvosAttacks data is exposed as `levelMoves`.
  -- This is the same table src/battle/gen2/Mon.lua uses for:
  --   * movesAtLevel()
  --   * pokemon.level_up learnable payloads
  --   * actual post-level move offers
  for _,entry in ipairs(def.levelMoves or {}) do
    local level=tonumber(entry and entry.level)
    local moveId=entry and entry.move
    if level and moveId then
      local md=summary.moves and summary.moves[moveId]
      learned[#learned+1]={
        level=level,
        id=moveId,
        name=tostring((md and md.name)
          or GoldCompat.humanizeIdentifier(moveId) or "---")
      }
    end
  end

  table.sort(learned,function(a,b)
    if a.level==b.level then return a.name<b.name end
    return a.level<b.level
  end)
  return learned
end

function GoldCompat.drawGoldSummaryMoves(summary,ox,oy,sc)
  -- The party screen already exposes currently learned moves, so this page
  -- is dedicated to acquisition data: compatible machines + level-up moves.
  finalText("TM / HM COMPATIBILITY",79,38,2.65,{0.40,0.40,0.37,1},ox,oy,sc)

  local machines=GoldCompat.summaryCompatibleMachines(summary)
  if #machines==0 then
    finalText("NONE",80,46,2.4,{0.34,0.34,0.31,1},ox,oy,sc)
  else
    local rows=7
    local shown=math.min(#machines,rows*2)
    for i=1,shown do
      local item=machines[i]
      local col=(i-1)>=rows and 1 or 0
      local row=(i-1)%rows
      local x=80+col*34
      local y=46+row*5.2
      finalText(item.name,x,y,2.15,{0.08,0.08,0.08,1},
        ox,oy,sc,"left",31)
    end
    if #machines>shown then
      finalText((" +%d MORE"):format(#machines-shown),115,82,1.95,
        {0.36,0.36,0.33,1},ox,oy,sc,"left",31)
    end
  end

  finalText("LEVEL-UP LEARNSET",79,87,2.65,{0.40,0.40,0.37,1},ox,oy,sc)
  local learnset=GoldCompat.summaryLevelUpLearnset(summary)
  if #learnset==0 then
    finalText("NO LEVEL-UP DATA",80,95,2.25,{0.34,0.34,0.31,1},ox,oy,sc)
  else
    -- Two columns, sorted by level, with explicit level labels.
    local rows=5
    local shown=math.min(#learnset,rows*2)
    for i=1,shown do
      local item=learnset[i]
      local col=(i-1)>=rows and 1 or 0
      local row=(i-1)%rows
      local x=80+col*34
      local y=95+row*5.5
      finalText(("Lv.%d  %s"):format(item.level,item.name),
        x,y,2.1,{0.08,0.08,0.08,1},ox,oy,sc,"left",32)
    end
    if #learnset>shown then
      finalText((" +%d MORE"):format(#learnset-shown),115,123,1.9,
        {0.36,0.36,0.33,1},ox,oy,sc,"left",31)
    end
  end

  finalText("TM/HM: BAG TO TEACH",79,128,1.95,
    {0.30,0.30,0.28,1},ox,oy,sc)
  GoldCompat.drawGoldSummaryFooter(ox,oy,sc)
end

function GoldCompat.drawGoldSummaryStats(summary,ox,oy,sc)
  local mon=summary.mon
  local stats=mon.stats or {}

  finalText("TRAINER",79,39,2.5,{0.40,0.40,0.37,1},ox,oy,sc)
  finalText("OT",79,46,2.4,{0.34,0.34,0.31,1},ox,oy,sc)
  finalText(summary.otName and summary:otName() or "—",
    94,46,2.8,{0.08,0.08,0.08,1},ox,oy,sc,"left",52)
  finalText("ID",79,52,2.4,{0.34,0.34,0.31,1},ox,oy,sc)
  finalText(("%05d"):format(summary.otId and summary:otId() or 0),
    94,52,2.8,{0.08,0.08,0.08,1},ox,oy,sc)

  finalText("BATTLE STATS",79,62,2.6,{0.40,0.40,0.37,1},ox,oy,sc)

  local rows={
    {"HP",stats.hp or mon.maxHp or 0},
    {"ATTACK",stats.attack or 0},
    {"DEFENSE",stats.defense or 0},
    {"SP. ATK",stats.specialAttack or stats.special or 0},
    {"SP. DEF",stats.specialDefense or stats.special or 0},
    {"SPEED",stats.speed or 0},
  }

  for i,row in ipairs(rows) do
    local y=69+(i-1)*8.1
    finalText(row[1],81,y,2.6,{0.30,0.30,0.28,1},ox,oy,sc)
    finalText(tostring(row[2]),126,y,3.0,{0.08,0.08,0.08,1},
      ox,oy,sc,"right",20)
  end

  GoldCompat.drawGoldSummaryFooter(ox,oy,sc)
end

function GoldCompat.moveManagerMoveId(entry)
  if type(entry)=="table" then
    return entry.id or entry.move or entry.moveId
  end
  return entry
end

function GoldCompat.moveManagerMoveDef(summary,entry)
  local id=GoldCompat.moveManagerMoveId(entry)
  if not id then return nil end
  local game=summary and summary.game
  local moves=(summary and summary.moves)
    or (game and game.data and game.data.moves)
  return moves and moves[id] or nil
end

function GoldCompat.moveManagerMoveName(summary,entry)
  local id=GoldCompat.moveManagerMoveId(entry)
  local def=GoldCompat.moveManagerMoveDef(summary,entry)
  local fallback=GoldCompat.humanizeIdentifier(id)
  return tostring((def and def.name) or (fallback~="" and fallback) or "---")
end

function GoldCompat.moveManagerRememberId(mon,id)
  if not (type(mon)=="table" and id) then return end
  mon.__colosseumMoveHistory=mon.__colosseumMoveHistory or {}
  for _,known in ipairs(mon.__colosseumMoveHistory) do
    if known==id then return end
  end
  mon.__colosseumMoveHistory[#mon.__colosseumMoveHistory+1]=id
end

function GoldCompat.moveManagerRemembered(summary)
  local mon=summary and summary.mon
  if not mon then return {} end
  local game=summary.game
  local defs=(summary.pokemon)
    or (game and game.data and game.data.pokemon) or {}
  local level=math.max(1,tonumber(mon.level) or 1)
  local current={}
  for _,mv in ipairs(mon.moves or {}) do
    local id=GoldCompat.moveManagerMoveId(mv)
    if id then current[id]=true end
  end

  local rows,byId={},{}
  local function add(id,learnLevel,source,recorded)
    if not id or current[id] or byId[id] then return end
    local row={id=id,level=tonumber(learnLevel),source=source,recorded=recorded==true}
    row.name=GoldCompat.moveManagerMoveName(summary,id)
    rows[#rows+1]=row
    byId[id]=row
  end

  -- Walk the current species and every direct/recursive pre-evolution.  This
  -- gives an evolved Pokémon access to level-up moves it could genuinely have
  -- carried forward from an earlier stage rather than limiting the reminder to
  -- only the current species' table.
  local visited={}
  local function collect(species)
    if not species or visited[species] then return end
    visited[species]=true
    for candidateId,candidate in pairs(defs) do
      if type(candidate)=="table" then
        for _,evo in ipairs(candidate.evolutions or {}) do
          local into=evo and (evo.into or evo.species or evo.target)
          if into==species then collect(candidateId) end
        end
      end
    end
    local def=defs[species]
    if type(def)~="table" then return end
    for _,id in ipairs(def.level1Moves or {}) do add(id,1,species,false) end
    for _,entry in ipairs(def.learnset or {}) do
      local at=tonumber(entry and entry.level) or 1
      if at<=level then add(entry and entry.move,at,species,false) end
    end
    for _,entry in ipairs(def.levelMoves or {}) do
      local at=tonumber(entry and entry.level) or 1
      if at<=level then add(entry and entry.move,at,species,false) end
    end
  end
  collect(mon.species)

  -- The level-up tables cannot reconstruct old TM/HM or service-move choices
  -- from saves created before this feature existed.  From this point forward,
  -- preserve every move the manager sees/forgets so those moves remain truly
  -- rememberable for this individual Pokémon.
  for _,id in ipairs(mon.__colosseumMoveHistory or {}) do
    add(id,nil,"HISTORY",true)
  end

  table.sort(rows,function(a,b)
    if a.recorded~=b.recorded then return a.recorded end
    local al,bl=a.level or 999,b.level or 999
    if al~=bl then return al<bl end
    return a.name<b.name
  end)
  return rows
end

function GoldCompat.openMoveManager(summary)
  local mon=summary and summary.mon
  if not mon or mon.isEgg then return false end
  mon.moves=mon.moves or {}
  for _,mv in ipairs(mon.moves) do
    GoldCompat.moveManagerRememberId(mon,GoldCompat.moveManagerMoveId(mv))
  end
  local count=#mon.moves
  local index=math.max(1,math.min(count>0 and count or 1,
    tonumber(summary.moveIndex) or 1))
  summary.__colosseumMoveManager={
    phase="current",
    currentIndex=index,
    targetSlot=nil,
    historyIndex=1,
    historyScroll=0,
    message=nil,
  }
  summary.moveIndex=index
  return true
end

local function moveManagerMaxPp(summary,mv)
  if not mv then return 0 end
  local def=GoldCompat.moveManagerMoveDef(summary,mv)
  local stored=type(mv)=="table" and (mv.maxPp or mv.maxPP or mv.pp) or nil
  local base=tonumber(def and def.pp) or tonumber(stored) or 0
  if type(mv)=="table" and mv.maxPp then return mv.maxPp end
  if type(mv)=="table" and mv.maxPP then return mv.maxPP end
  local ups=type(mv)=="table" and tonumber(mv.ppUps) or 0
  return base+(ups or 0)*math.floor(base/5)
end

local function moveManagerNewMove(summary,id)
  local def=GoldCompat.moveManagerMoveDef(summary,id)
  local pp=math.max(0,tonumber(def and def.pp) or 0)
  local entry={id=id,pp=pp,ppUps=0}
  if GoldCompat.generation=="gen2" or (summary and summary.pokemon) then
    entry.maxPp=pp
  end
  return entry
end

local function moveManagerHistoryVisible(manager,total,visible)
  manager.historyIndex=math.max(1,math.min(total,manager.historyIndex or 1))
  local scroll=math.max(0,tonumber(manager.historyScroll) or 0)
  if manager.historyIndex<=scroll then
    scroll=manager.historyIndex-1
  elseif manager.historyIndex>scroll+visible then
    scroll=manager.historyIndex-visible
  end
  manager.historyScroll=math.max(0,math.min(scroll,math.max(0,total-visible)))
end

function GoldCompat.updateMoveManager(summary,input)
  local manager=summary and summary.__colosseumMoveManager
  local mon=summary and summary.mon
  if not (manager and mon and input) then return end
  local moves=mon.moves or {}

  if manager.phase=="current" then
    local count=#moves
    if input:wasPressed("b") then
      summary.__colosseumMoveManager=nil
      return
    end
    if count<1 then
      manager.message="NO CURRENT MOVE TO MANAGE"
      return
    end
    if input:wasPressed("up") then
      manager.currentIndex=manager.currentIndex>1 and manager.currentIndex-1 or count
    elseif input:wasPressed("down") then
      manager.currentIndex=manager.currentIndex<count and manager.currentIndex+1 or 1
    elseif input:wasPressed("a") then
      manager.targetSlot=manager.currentIndex
      manager.phase="history"
      manager.historyIndex=1
      manager.historyScroll=0
      manager.message=nil
    end
    summary.moveIndex=manager.currentIndex
    return
  end

  local remembered=GoldCompat.moveManagerRemembered(summary)
  local total=#remembered+1 -- first row is DELETE MOVE
  moveManagerHistoryVisible(manager,total,5)

  if input:wasPressed("b") or input:wasPressed("left") then
    manager.phase="current"
    manager.targetSlot=nil
    manager.message=nil
    return
  elseif input:wasPressed("up") then
    manager.historyIndex=manager.historyIndex>1 and manager.historyIndex-1 or total
    moveManagerHistoryVisible(manager,total,5)
    return
  elseif input:wasPressed("down") then
    manager.historyIndex=manager.historyIndex<total and manager.historyIndex+1 or 1
    moveManagerHistoryVisible(manager,total,5)
    return
  elseif not input:wasPressed("a") then
    return
  end

  local slot=math.max(1,math.min(#moves,tonumber(manager.targetSlot) or 1))
  local old=moves[slot]
  if not old then
    manager.phase="current"
    manager.message="MOVE SLOT IS EMPTY"
    return
  end

  if manager.historyIndex==1 then
    -- Keep at least one usable move.  Battle code can resolve disabled/zero-PP
    -- moves through STRUGGLE, but an actually empty move table is not a normal
    -- cartridge state and breaks several menu assumptions.
    if #moves<=1 then
      manager.message="THE LAST MOVE CAN'T BE DELETED"
      return
    end
    local oldId=GoldCompat.moveManagerMoveId(old)
    local oldName=GoldCompat.moveManagerMoveName(summary,old)
    GoldCompat.moveManagerRememberId(mon,oldId)
    table.remove(moves,slot)
    manager.currentIndex=math.max(1,math.min(slot,#moves))
    summary.moveIndex=manager.currentIndex
    manager.phase="current"
    manager.targetSlot=nil
    manager.message="DELETED "..oldName
    return
  end

  local choice=remembered[manager.historyIndex-1]
  if not choice then return end
  local oldId=GoldCompat.moveManagerMoveId(old)
  GoldCompat.moveManagerRememberId(mon,oldId)
  GoldCompat.moveManagerRememberId(mon,choice.id)
  moves[slot]=moveManagerNewMove(summary,choice.id)
  manager.currentIndex=slot
  summary.moveIndex=slot
  manager.phase="current"
  manager.targetSlot=nil
  manager.message="RELEARNED "..choice.name

  -- Keep the engine/mod event contract informed that this individual learned a
  -- move.  The mutation above remains authoritative; listeners are advisory.
  pcall(function()
    require("src.mods.Runtime").emit("pokemon.move_learned",{
      mon=mon,pokemon=mon,moveId=choice.id,move=choice.id,
      source="colosseum_move_manager",
    })
  end)
end

function GoldCompat.drawGoldMoveManager(summary)
  if not GoldCompat.moveManagerPresentationEnabled() then return false end
  local mon=summary and summary.mon
  local manager=summary and summary.__colosseumMoveManager
  if not (mon and manager) then return end

  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  local white={0.96,1.00,0.97,1}
  local muted={0.58,0.73,0.70,1}
  local dim={0.34,0.48,0.46,1}
  local steel={0.29,0.55,0.54,0.96}
  local gold={1.00,0.79,0.27,1}
  local cyan={0.22,0.95,0.68,1}
  local danger={1.00,0.39,0.25,1}
  local card={0.010,0.030,0.034,0.97}

  local game=summary.game
  local defs=(summary.pokemon) or (game and game.data and game.data.pokemon) or {}
  local def=defs[mon.species] or {}
  local monName=tostring(mon.nickname or mon.name or def.name or mon.species or "POKéMON")
  local moves=mon.moves or {}
  local remembered=GoldCompat.moveManagerRemembered(summary)
  local total=#remembered+1
  moveManagerHistoryVisible(manager,total,5)

  local x,y,w,h=5,5,150,134
  local leftX,leftY,leftW,leftH=8,27,61,88
  local rightX,rightY,rightW,rightH=72,27,80,88

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(0.005,0.015,0.020,0.36)
  G.rectangle("fill",0,0,160,144)
  drawColosseumRunoffPanel(x,y,w,h,17)
  G.setColor(0.007,0.024,0.027,0.985)
  roundedRect("fill",x+4,y+18,w-8,h-24,4)

  G.setColor(0.008,0.028,0.031,0.995)
  roundedRect("fill",x+5,y+4,w-10,12,3)
  G.setColor(card)
  roundedRect("fill",leftX,leftY,leftW,leftH,4)
  roundedRect("fill",rightX,rightY,rightW,rightH,4)
  G.setColor(steel)
  roundedRect("line",leftX,leftY,leftW,leftH,4)
  roundedRect("line",rightX,rightY,rightW,rightH,4)

  G.setColor(0.024,0.105,0.100,0.97)
  roundedRect("fill",leftX+2,leftY+2,leftW-4,9,2)
  roundedRect("fill",rightX+2,rightY+2,rightW-4,9,2)

  -- One dedicated data rail. No metadata is allowed to spill between columns.
  G.setColor(0.008,0.026,0.030,0.98)
  roundedRect("fill",8,118,144,11,2.5)
  G.setColor(steel)
  roundedRect("line",8,118,144,11,2.5)
  G.pop()

  finalText("MOVE MANAGER",11,10,3.05,white,ox,oy,sc)
  finalText(monName,117,9,2.15,white,ox,oy,sc,"right",46)
  finalText("Lv"..tostring(mon.level or "?"),148,9,1.85,gold,ox,oy,sc,"right",24)
  finalText("CURRENT MOVES",13,31,1.95,cyan,ox,oy,sc)
  finalText(manager.phase=="history" and "REPLACEMENT MOVES" or "MOVE OPTIONS",
    78,31,1.95,cyan,ox,oy,sc,"left",66)

  -- Current moves: name on line one; type and PP on one contained metadata row.
  for i=1,4 do
    local mv=moves[i]
    local rowY=40+(i-1)*17.2
    local selected=(manager.currentIndex or 1)==i
    local target=manager.phase=="history" and manager.targetSlot==i

    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    if selected and manager.phase=="current" then
      drawColosseumRunoffSelection(leftX+4,rowY-3,leftW-8,14)
    elseif target then
      G.setColor(0.28,0.19,0.050,0.96)
      roundedRect("fill",leftX+5,rowY-3,leftW-10,14,2)
      G.setColor(gold)
      roundedRect("line",leftX+5,rowY-3,leftW-10,14,2)
    else
      G.setColor(0.013,0.038,0.042,0.94)
      roundedRect("fill",leftX+5,rowY-3,leftW-10,14,2)
    end
    G.pop()

    local name=GoldCompat.moveManagerMoveName(summary,mv)
    finalText(name,leftX+12,rowY,2.10,mv and white or dim,ox,oy,sc,"left",43)
    if mv then
      local md=GoldCompat.moveManagerMoveDef(summary,mv)
      local pp=type(mv)=="table" and tonumber(mv.pp) or nil
      local maxpp=moveManagerMaxPp(summary,mv)
      finalText(GoldCompat.moveTypeName(md),leftX+12,rowY+6.4,1.34,gold,
        ox,oy,sc,"left",23)
      finalText(("PP %s/%s"):format(tostring(pp or "?"),tostring(maxpp)),
        leftX+35,rowY+6.4,1.30,muted,ox,oy,sc,"right",20)
    else
      finalText("EMPTY SLOT",leftX+12,rowY+6.4,1.30,dim,ox,oy,sc)
    end
  end

  if manager.phase=="current" then
    finalText("SELECT A CURRENT MOVE",rightX+7,41,1.82,white,ox,oy,sc,"left",64)
    finalText("A: MANAGE / RELEARN",rightX+7,49,1.48,muted,ox,oy,sc,"left",64)
    finalText("B: RETURN TO SUMMARY",rightX+7,55,1.48,muted,ox,oy,sc,"left",64)

    finalText("AVAILABLE PAST MOVES",rightX+7,67,1.55,gold,ox,oy,sc,"left",64)
    if #remembered==0 then
      finalText("NONE RECORDED YET",rightX+9,77,1.58,dim,ox,oy,sc,"left",60)
    else
      for i=1,math.min(3,#remembered) do
        local entry=remembered[i]
        local md=GoldCompat.moveManagerMoveDef(summary,entry)
        local badge=entry.recorded and "PAST" or ("Lv."..tostring(entry.level or "--"))
        local rowY=76+(i-1)*10
        finalText(entry.name,rightX+9,rowY,1.70,{0.72,0.86,0.82,1},
          ox,oy,sc,"left",43)
        finalText(badge.."  "..GoldCompat.moveTypeName(md),rightX+9,rowY+5,1.24,muted,
          ox,oy,sc,"left",58)
      end
      if #remembered>3 then
        finalText(("+%d MORE"):format(#remembered-3),rightX+58,107,1.25,dim,
          ox,oy,sc,"right",15)
      end
    end
  else
    local first=(manager.historyScroll or 0)+1
    for row=1,5 do
      local index=first+row-1
      if index>total then break end
      local rowY=39+(row-1)*14.5
      local selected=index==manager.historyIndex
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      if selected then
        drawColosseumRunoffSelection(rightX+4,rowY-2.5,rightW-8,13.5)
      else
        G.setColor(0.013,0.038,0.042,0.72)
        roundedRect("fill",rightX+5,rowY-2.5,rightW-10,13.5,1.5)
      end
      G.pop()

      if index==1 then
        finalText("DELETE CURRENT MOVE",rightX+13,rowY,1.78,
          selected and white or danger,ox,oy,sc,"left",57)
        finalText("REMOVE WITHOUT REPLACEMENT",rightX+13,rowY+5.2,1.18,
          selected and {0.90,0.63,0.58,1} or dim,ox,oy,sc,"left",57)
      else
        local entry=remembered[index-1]
        local md=GoldCompat.moveManagerMoveDef(summary,entry)
        local badge=entry.recorded and "PAST" or ("Lv."..tostring(entry.level or "--"))
        local maxpp=moveManagerMaxPp(summary,entry)
        finalText(entry.name,rightX+13,rowY,1.76,
          selected and white or {0.73,0.85,0.81,1},ox,oy,sc,"left",49)
        finalText(badge.."  "..GoldCompat.moveTypeName(md).."  PP "..tostring(maxpp),
          rightX+13,rowY+5.2,1.18,selected and gold or muted,
          ox,oy,sc,"left",57)
      end
    end
  end

  -- Detail rail always describes exactly what A would act on.
  local detailEntry
  local detailMode="CURRENT"
  if manager.phase=="history" then
    if manager.historyIndex==1 then
      detailEntry=moves[manager.targetSlot or manager.currentIndex or 1]
      detailMode="DELETE"
    else
      detailEntry=remembered[manager.historyIndex-1]
      detailMode="RELEARN"
    end
  else
    detailEntry=moves[manager.currentIndex or 1]
  end
  local md=GoldCompat.moveManagerMoveDef(summary,detailEntry)
  local detailName=GoldCompat.moveManagerMoveName(summary,detailEntry)
  if md then
    local power=tonumber(md.power) or 0
    local acc=tonumber(md.accuracy) or 0
    local pp=type(detailEntry)=="table" and tonumber(detailEntry.pp) or nil
    local maxpp=moveManagerMaxPp(summary,detailEntry)
    finalText(detailName,12,121,1.67,white,ox,oy,sc,"left",34)
    finalText(detailMode,47,121,1.22,detailMode=="DELETE" and danger or cyan,
      ox,oy,sc,"left",16)
    finalText(GoldCompat.moveTypeName(md),64,121,1.30,gold,ox,oy,sc,"left",20)
    finalText("PP "..tostring(pp or maxpp).."/"..tostring(maxpp),84,121,1.22,muted,ox,oy,sc)
    finalText("PWR "..(power>1 and tostring(power) or "—"),111,121,1.22,muted,ox,oy,sc)
    finalText("ACC "..(acc>0 and tostring(acc) or "—"),135,121,1.22,muted,ox,oy,sc)
  else
    finalText("SELECT A MOVE",12,121,1.60,muted,ox,oy,sc)
  end

  if manager.message then
    finalText(manager.message,11,132,1.70,{0.48,0.98,0.62,1},ox,oy,sc,
      "left",84)
  end
  local help=manager.phase=="history"
    and "↑/↓ OPTION   A APPLY   B BACK"
    or "↑/↓ MOVE   A MANAGE   B BACK"
  finalText(help,149,132,1.58,white,ox,oy,sc,"right",79)
end

function GoldCompat.summaryAbilityName(game,mon,def)
  return GoldCompat.abilityLabel(game,mon,def)
end

function GoldCompat.drawColosseumSummaryTabs(page,ox,oy,sc)
  local G=love.graphics
  local labels={"STATUS","MOVES","PROFILE"}
  for i,label in ipairs(labels) do
    local x=82+(i-1)*24
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    if i==page then
      G.setColor(0.055,0.31,0.28,0.98)
      G.polygon("fill",x,7,x+21,7,x+23,10.5,x+21,15,x,15,x-2,11)
      G.setColor(0.26,1.00,0.48,1)
      G.rectangle("fill",x+2,14,17,1)
    else
      G.setColor(0.055,0.13,0.14,0.92)
      G.polygon("fill",x,8,x+21,8,x+22,11.5,x+20,14,x,14,x-1,11)
    end
    G.pop()
    finalText(label,x,10,1.62,
      i==page and {0.92,1.00,0.94,1} or {0.54,0.70,0.68,1},
      ox,oy,sc,"center",21)
  end
end

function GoldCompat.drawColosseumStatusPage(game,summary,mon,def,gen2)
  local G=love.graphics
  local ox,oy,sc=safeFullCanvas()
  local white={0.98,0.99,0.96,1}
  local lime={0.58,0.94,0.20,1}
  local gold={1.00,0.80,0.25,1}
  local muted={0.66,0.78,0.75,1}
  local glass={0.018,0.040,0.044,0.80}
  local rim={0.35,0.55,0.54,0.96}
  local stats=mon.stats or {}
  local hpMax=tonumber(stats.hp or mon.maxHp) or 0
  local rows={
    {"HP",tonumber(mon.hp) or 0,hpMax},
    {"ATTACK",tonumber(stats.attack) or 0},
    {"DEFENSE",tonumber(stats.defense) or 0},
    {"SP. ATK",tonumber(stats.specialAttack or stats.special) or 0},
    {"SP. DEF",tonumber(stats.specialDefense or stats.special) or 0},
    {"SPEED",tonumber(stats.speed) or 0},
  }
  local maxStat=1
  for i=2,#rows do maxStat=math.max(maxStat,rows[i][2]) end

  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  -- Rounded status bubble: portrait left, readable meter stack right.
  G.setColor(glass); roundedRect("fill",3,3,154,128,5)
  G.setColor(rim); roundedRect("line",3,3,154,128,5)
  G.setColor(0.015,0.030,0.033,0.86); roundedRect("fill",6,6,148,12,4)
  G.setColor(0.10,0.12,0.12,0.86); roundedRect("fill",7,22,55,70,4)
  G.setColor(rim); roundedRect("line",7,22,55,70,4)
  G.setColor(0.12,0.14,0.14,0.78); roundedRect("fill",10,25,49,48,3)
  G.setColor(0.015,0.030,0.033,0.84); roundedRect("fill",65,22,89,70,4)
  G.setColor(rim); roundedRect("line",65,22,89,70,4)
  G.setColor(0.015,0.030,0.033,0.84); roundedRect("fill",7,95,147,32,4)
  G.setColor(rim); roundedRect("line",7,95,147,32,4)

  for i,row in ipairs(rows) do
    local yy=27+(i-1)*10
    local ratio=i==1 and ((hpMax>0) and clamp(row[2]/hpMax,0,1) or 0)
      or clamp(row[2]/maxStat,0,1)
    G.setColor(0.10,0.13,0.13,1); roundedRect("fill",94,yy+4,46,3,1.5)
    local rr,gg,bb
    if i==1 then rr,gg,bb=hpColor(ratio)
    else rr,gg,bb=0.64,0.82,0.18 end
    G.setColor(rr,gg,bb,1); roundedRect("fill",95,yy+5,44*ratio,1.5,0.8)
  end
  G.pop()

  finalText("POKéMON INFO",9,9,3.15,white,ox,oy,sc)
  GoldCompat.drawColosseumSummaryTabs(1,ox,oy,sc)

  G.push("all"); G.origin()
  pcall(GoldCompat.drawCleanResolvedPortrait,game,mon,
    ox+12*sc,oy+27*sc,45*sc,43*sc,"summary")
  G.pop()
  local name=tostring(mon.nickname or mon.name or def.name or mon.species or "POKéMON")
  finalText(name,11,76,3.0,white,ox,oy,sc,"left",35)
  finalText("Lv"..tostring(mon.level or "?"),45,76,2.4,gold,ox,oy,sc,"right",13)
  local status=owStatus(mon) or tostring(mon.status or "OK")
  finalText(status,11,84,2.1,status=="OK" and lime or {1,0.42,0.30,1},ox,oy,sc)

  for i,row in ipairs(rows) do
    local yy=27+(i-1)*10
    finalText(row[1],69,yy,2.35,i==1 and {1,0.28,0.19,1} or gold,
      ox,oy,sc,"left",23)
    local value=i==1 and (tostring(row[2]).." / "..tostring(row[3]))
      or tostring(row[2])
    finalText(value,140,yy,2.5,white,ox,oy,sc,"right",11)
  end

  local typeNames={}
  for _,id in ipairs(def.types or {}) do typeNames[#typeNames+1]=tostring(id):upper() end
  local typeLabel=#typeNames>0 and table.concat(typeNames," / ") or "--"
  local itemId=mon.item
  local items=summary.items or (game and game.data and game.data.items) or {}
  local item=items[itemId]
  local exp=tonumber(mon.experience or mon.exp) or 0
  local nextExp=0
  if gen2 then nextExp=summary.expToNext and summary:expToNext() or 0
  elseif mon.level and mon.level<100 then
    local ok,value=pcall(Growth.expForLevel,def.growthRate,mon.level+1,
      game.data and game.data.growth_rates)
    if ok then nextExp=math.max(0,(tonumber(value) or exp)-exp) end
  end
  finalText("EXP. POINTS",11,99,1.9,muted,ox,oy,sc)
  finalText(tostring(exp),11,105,2.45,white,ox,oy,sc,"left",33)
  finalText("NEXT LV.",47,99,1.9,muted,ox,oy,sc)
  finalText(tostring(nextExp),47,105,2.45,white,ox,oy,sc,"left",28)
  finalText("TYPE",79,99,1.9,muted,ox,oy,sc)
  finalText(typeLabel,79,105,2.2,white,ox,oy,sc,"left",30)
  finalText("ABILITY",112,99,1.9,muted,ox,oy,sc)
  finalText(GoldCompat.summaryAbilityName(game,mon,def),112,105,2.05,white,
    ox,oy,sc,"left",38)
  finalText("HELD  "..tostring((item and item.name) or itemId or "NONE"),
    11,116,2.05,muted,ox,oy,sc,"left",65)
  local ot=gen2 and summary.otName and summary:otName()
    or mon.otName or mon.originalTrainer or "--"
  local id=gen2 and summary.otId and summary:otId()
    or mon.otId or mon.trainerId or 0
  finalText("OT  "..tostring(ot).."   ID "..("%05d"):format(tonumber(id) or 0),
    79,116,1.95,muted,ox,oy,sc,"left",70)
  finalText("←/→ PAGE   ↑/↓ POKéMON",9,134,1.9,white,ox,oy,sc)
  finalText("B: BACK",133,134,1.9,muted,ox,oy,sc,"right",18)
end

function GoldCompat.drawColosseumSummary(game,summary)
  if not (summary and summary.mon) then return end
  game=game or summary.game
  local mon=summary.mon
  local defs=summary.pokemon or (game and game.data and game.data.pokemon) or {}
  local def=defs[mon.species]
  if not def then return end

  -- Preserve Gold's protected egg presentation instead of exposing hidden data.
  if mon.isEgg and GoldCompat.generation=="gen2" then
    local Summary=require("src.ui.gen2.SummaryMenu")
    if Summary.__gen3uiOriginalDrawWidescreen then
      return Summary.__gen3uiOriginalDrawWidescreen(summary,
        love.graphics.getWidth(),love.graphics.getHeight())
    end
  end

  local G=love.graphics
  local ox,oy,sc=safeFullCanvas()
  local page=math.max(1,tonumber(summary.page) or 1)
  local gen2=GoldCompat.generation=="gen2" or summary.pokemon~=nil
  if summary.__colosseumMoveManager
      and GoldCompat.moveManagerPresentationEnabled() then
    return GoldCompat.drawGoldMoveManager(summary)
  end
  local moveManager=gen2 and (summary.moveDetail or summary.moveScreen)
  if page==1 and not moveManager then
    return GoldCompat.drawColosseumStatusPage(game,summary,mon,def,gen2)
  end
  local dark={0.025,0.045,0.050,0.93}
  local body={0.055,0.105,0.115,0.91}
  local steel={0.42,0.63,0.63,1}
  local cyan={0.08,0.64,0.95,1}
  local white={0.98,0.98,0.94,1}
  local gold={1.00,0.82,0.32,1}
  local muted={0.70,0.79,0.77,1}

  local function panel(x,y,w,h)
    G.setColor(0.01,0.02,0.025,0.55)
    roundedRect("fill",x+1.5,y+1.5,w,h,2.5)
    G.setColor(body)
    roundedRect("fill",x,y,w,h,2.5)
    G.setColor(steel)
    roundedRect("line",x,y,w,h,2.5)
  end
  local function section(x,y,w,label)
    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)
    G.setColor(0.01,0.025,0.035,0.94)
    roundedRect("fill",x,y,w,5.5,1.2)
    G.setColor(cyan)
    roundedRect("fill",x,y,w*0.48,5.5,1.2)
    G.pop()
    finalText(label,x+2,y+0.5,2.5,white,ox,oy,sc)
  end
  local function moveDef(entry)
    if gen2 then return GoldCompat.summaryMoveDef(summary,entry) end
    local id=type(entry)=="table" and (entry.id or entry.move) or entry
    return game and game.data and game.data.moves and game.data.moves[id]
  end
  local function moveName(entry)
    if gen2 then return GoldCompat.summaryMoveName(summary,entry) end
    local md=moveDef(entry)
    local id=type(entry)=="table" and (entry.id or entry.move) or entry
    local fallback=GoldCompat.humanizeIdentifier(id)
    return tostring((md and md.name) or (fallback~="" and fallback) or "---")
  end

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(0.01,0.02,0.025,0.28)
  G.rectangle("fill",0,0,160,144)
  panel(3,3,154,16)
  panel(3,22,53,109)
  panel(59,22,98,109)
  G.setColor(0.01,0.025,0.035,0.94)
  roundedRect("fill",5,5,150,12,2)
  G.setColor(0.02,0.04,0.05,0.92)
  roundedRect("fill",7,25,45,48,2)
  G.setColor(0.18,0.38,0.44,0.85)
  for gx=10,49,8 do G.line(gx,27,gx,70) end
  for gy=29,69,8 do G.line(9,gy,50,gy) end
  G.pop()

  finalText(moveManager and "MOVE MANAGER" or "POKéMON INFO",
    8,7,3.25,white,ox,oy,sc)
  GoldCompat.drawColosseumSummaryTabs(page,ox,oy,sc)

  G.push("all")
  G.origin()
  pcall(GoldCompat.drawCleanResolvedPortrait,game,mon,
    ox+10*sc,oy+28*sc,39*sc,42*sc,"summary")
  G.pop()

  local name=tostring(mon.nickname or mon.name or def.name or mon.species or "POKéMON")
  finalText(name,7,76,3.4,white,ox,oy,sc,"left",45)
  finalText("Lv"..tostring(mon.level or "?"),39,83,2.5,gold,ox,oy,sc,"right",13)
  local itemId=mon.item
  local items=summary.items or (game and game.data and game.data.items) or {}
  local item=items[itemId]
  finalText("ITEM",7,90,2.0,muted,ox,oy,sc)
  finalText(tostring((item and item.name) or itemId or "NONE"),7,95,2.45,white,
    ox,oy,sc,"left",45)
  local status=owStatus(mon) or tostring(mon.status or "OK")
  finalText("STATUS  "..status,7,104,2.15,
    status=="OK" and {0.40,0.94,0.55,1} or {1.00,0.46,0.34,1},ox,oy,sc)
  local dexNo=tonumber(def.dex or def.number or def.id)
  finalText(dexNo and ("#%03d"):format(dexNo) or tostring(mon.species or ""),
    7,113,2.3,muted,ox,oy,sc,"left",45)
  if not gen2 then
    local evo=def.evolutions and def.evolutions[1]
    local into=evo and defs[evo.species]
    finalText("EVOLUTION",7,119,1.75,muted,ox,oy,sc)
    finalText(evo and tostring((into and into.name) or evo.species or "SPECIAL")
      or "NONE",7,124,1.95,white,ox,oy,sc,"left",45)
  end

  if moveManager then
    section(62,25,92,"CURRENT MOVES")
    local moves=mon.moves or {}
    for i=1,4 do
      local mv=moves[i]
      local md=moveDef(mv)
      local y=34+(i-1)*18
      G.push("all") G.translate(ox,oy) G.scale(sc,sc)
      G.setColor(i==(summary.moveIndex or 1) and {0.68,0.12,0.08,0.96}
        or {0.015,0.035,0.040,0.88})
      roundedRect("fill",63,y,90,15,2)
      G.setColor(i==(summary.moveIndex or 1) and {1.0,0.32,0.17,1} or steel)
      roundedRect("line",63,y,90,15,2)
      G.pop()
      finalText(moveName(mv),66,y+2,2.8,white,ox,oy,sc,"left",49)
      if mv then
        local pp=type(mv)=="table" and (mv.pp or "?") or "?"
        local maxpp=type(mv)=="table" and (mv.maxPp or mv.maxPP) or nil
        maxpp=maxpp or (md and md.pp) or pp
        finalText("PP "..tostring(pp).."/"..tostring(maxpp),116,y+2,2.1,muted,
          ox,oy,sc,"right",34)
        finalText(GoldCompat.moveTypeName(md),116,y+8,1.9,gold,
          ox,oy,sc,"right",34)
      end
    end
    local current=moves[summary.moveIndex or 1]
    local currentDef=moveDef(current)
    finalText(currentDef and tostring(currentDef.description or "") or "NO MOVE",
      64,108,2.0,muted,ox,oy,sc,"left",87)
    finalText(summary.swapFrom and "A: PLACE   B: CANCEL" or "A: PICK UP   B: BACK",
      7,134,2.15,white,ox,oy,sc)
    return
  end

  local type1,type2
  if gen2 then
    type1,type2=GoldCompat.summaryTypeNames(summary)
  else
    local ok,TypeChart=pcall(require,"src.battle.TypeChart")
    local names={}
    for _,id in ipairs(def.types or {}) do
      names[#names+1]=(ok and TypeChart.displayName and TypeChart.displayName(id)) or tostring(id)
    end
    type1,type2=names[1],names[2]
  end
  local types=type1 or "N/A"
  if type2 and type2~=type1 then types=types.." / "..type2 end

  if page==3 then
    section(62,25,92,"TRAINER")
    local ot=gen2 and summary.otName and summary:otName()
      or mon.otName or mon.originalTrainer or "—"
    local id=gen2 and summary.otId and summary:otId()
      or mon.otId or mon.trainerId or 0
    finalText("OT/ "..tostring(ot),65,34,2.65,gold,ox,oy,sc,"left",48)
    finalText(("ID No.%05d"):format(tonumber(id) or 0),114,34,2.35,gold,
      ox,oy,sc,"right",37)
    finalText("TYPE/  "..types,65,42,2.55,white,ox,oy,sc,"left",83)

    section(62,52,92,"DETAILS")
    local dex=gen2 and (GoldCompat.summaryDexEntry(summary) or {}) or {}
    finalText("SPECIES  "..tostring(dex.kind or def.name or mon.species),65,61,2.2,
      white,ox,oy,sc,"left",83)
    local heightLabel,weightLabel
    if gen2 then
      local pseudo={dexEntry={gen2Height=dex.height,gen2Weight=dex.weight}}
      heightLabel=DexUI.heightLabel(pseudo); weightLabel=DexUI.weightLabel(pseudo)
    else
      heightLabel=DexUI.heightLabel(def); weightLabel=DexUI.weightLabel(def)
    end
    finalText("HT  "..heightLabel,65,68,2.15,muted,ox,oy,sc)
    finalText("WT  "..weightLabel,111,68,2.15,muted,ox,oy,sc)
    local evoLabel="NONE"
    if gen2 then
      local evos=GoldCompat.summaryEvolutionRows(summary)
      local evo=evos[1]
      if evo then evoLabel=evo.name.." / "..evo.how end
    else
      local evo=def.evolutions and def.evolutions[1]
      local into=evo and defs[evo.species]
      if evo then evoLabel=tostring((into and into.name) or evo.species or "SPECIAL") end
    end
    finalText("EVOLUTION  "..evoLabel,
      65,75,2.05,muted,ox,oy,sc,"left",83)

    local machines={}
    for _,moveId in ipairs(def.tmhm or {}) do
      machines[#machines+1]=moveName(moveId)
    end
    table.sort(machines)
    local perPage=10
    local pages=math.max(1,math.ceil(#machines/perPage))
    local tmPage=math.max(1,math.min(tonumber(summary.__colosseumTmPage) or 1,pages))
    summary.__colosseumTmPage=tmPage
    summary.__colosseumTmPages=pages
    section(62,85,92,("TM/HM COMPATIBILITY  %d/%d"):format(tmPage,pages))
    local first=(tmPage-1)*perPage+1
    for slot=1,perPage do
      local machine=machines[first+slot-1]
      if not machine then break end
      local col=(slot-1)>=5 and 1 or 0
      local row=(slot-1)%5
      finalText(machine,64+col*44,94+row*6,1.85,white,
        ox,oy,sc,"left",42)
    end
    if #machines==0 then finalText("NONE",64,95,2.2,muted,ox,oy,sc) end
    if pages>1 then
      finalText("SELECT: NEXT LIST",111,125,1.55,{0.42,0.94,0.58,1},
        ox,oy,sc,"right",38)
    end
  elseif page==2 then
    section(62,25,92,"CURRENT MOVES")
    local moves=mon.moves or {}
    for i=1,4 do
      local mv=moves[i]
      local md=moveDef(mv)
      local y=33+(i-1)*13
      finalText(moveName(mv),64,y,2.65,white,ox,oy,sc,"left",48)
      local pp=mv and type(mv)=="table" and (mv.pp or "?") or "—"
      local maxpp=mv and type(mv)=="table" and (mv.maxPp or mv.maxPP) or nil
      maxpp=maxpp or (md and md.pp) or pp
      finalText("PP "..tostring(pp).."/"..tostring(maxpp),115,y,2.0,muted,
        ox,oy,sc,"right",36)
      finalText(GoldCompat.moveTypeName(md),115,y+5,1.8,gold,
        ox,oy,sc,"right",36)
    end
    section(62,86,92,"LEVEL-UP LEARNSET")
    local learned={}
    if gen2 then
      learned=GoldCompat.summaryLevelUpLearnset(summary)
    else
      for _,id in ipairs(def.level1Moves or {}) do
        learned[#learned+1]={level=1,name=moveName(id)}
      end
      for _,entry in ipairs(def.learnset or {}) do
        if entry and entry.move then
          learned[#learned+1]={level=tonumber(entry.level) or 1,name=moveName(entry.move)}
        end
      end
      table.sort(learned,function(a,b) return a.level<b.level end)
    end
    for i=1,math.min(10,#learned) do
      local entry=learned[i]
      local col=(i-1)>=5 and 1 or 0
      local row=(i-1)%5
      finalText(("L%02d %s"):format(entry.level,entry.name),64+col*44,94+row*6,
        1.85,white,ox,oy,sc,"left",42)
    end
    if #learned==0 then finalText("NO LEVEL MOVES",64,95,1.8,muted,ox,oy,sc) end
  else
    section(62,25,92,"PROFILE")
    local ot=gen2 and summary.otName and summary:otName()
      or mon.otName or mon.originalTrainer or "—"
    local id=gen2 and summary.otId and summary:otId()
      or mon.otId or mon.trainerId or 0
    finalText("OT/ "..tostring(ot),65,33,2.5,gold,ox,oy,sc,"left",48)
    finalText(("ID No.%05d"):format(tonumber(id) or 0),114,33,2.25,gold,
      ox,oy,sc,"right",37)
    finalText("TYPE/  "..types,65,40,2.6,white,ox,oy,sc,"left",83)
    finalText("SPECIES/  "..tostring(def.name or mon.species),65,47,2.2,muted,
      ox,oy,sc,"left",83)
    local heightLabel="—"
    local weightLabel="—"
    if gen2 then
      local dex=GoldCompat.summaryDexEntry(summary) or {}
      local pseudo={dexEntry={gen2Height=dex.height,gen2Weight=dex.weight}}
      heightLabel=DexUI.heightLabel(pseudo)
      weightLabel=DexUI.weightLabel(pseudo)
    else
      heightLabel=DexUI.heightLabel(def)
      weightLabel=DexUI.weightLabel(def)
    end
    finalText("HT "..heightLabel.."   WT "..weightLabel,65,52,1.85,muted,
      ox,oy,sc,"left",83)

    section(62,57,92,"STATS")
    local stats=mon.stats or {}
    local rows={{"HP",stats.hp or mon.maxHp or 0},{"ATTACK",stats.attack or 0},
      {"DEFENSE",stats.defense or 0},{"SP. ATK",stats.specialAttack or stats.special or 0},
      {"SP. DEF",stats.specialDefense or stats.special or 0},{"SPEED",stats.speed or 0}}
    for i,row in ipairs(rows) do
      local col=(i-1)>=3 and 1 or 0
      local ry=(i-1)%3
      finalText(row[1],65+col*45,66+ry*7,2.25,gold,ox,oy,sc)
      finalText(tostring(row[2]),94+col*45,66+ry*7,2.55,white,
        ox,oy,sc,"right",12)
    end

    section(62,89,92,"EXP.")
    local exp=tonumber(mon.experience or mon.exp) or 0
    local nextExp=0
    local ratio=0
    if gen2 then
      nextExp=summary.expToNext and summary:expToNext() or 0
      ratio=GoldCompat.summaryExpRatio(summary)
    else
      ratio=partyExpRatio(game,mon)
      if mon.level and mon.level<100 then
        local ok,value=pcall(Growth.expForLevel,def.growthRate,mon.level+1,
          game.data and game.data.growth_rates)
        if ok then nextExp=math.max(0,(tonumber(value) or exp)-exp) end
      end
    end
    finalText("EXP. POINTS",65,98,2.2,gold,ox,oy,sc)
    finalText(tostring(exp),113,98,2.55,white,ox,oy,sc,"right",36)
    finalText("NEXT LV.",65,105,2.2,gold,ox,oy,sc)
    finalText(tostring(nextExp),113,105,2.55,white,ox,oy,sc,"right",36)
    G.push("all") G.translate(ox,oy) G.scale(sc,sc)
    G.setColor(0.01,0.025,0.03,1) roundedRect("fill",65,114,84,4,1.5)
    G.setColor(0.08,0.46,0.96,1) roundedRect("fill",66,115,82*clamp(ratio,0,1),2,1)
    G.pop()
  end

  finalText("←/→ SELECT TIER",7,134,1.75,white,ox,oy,sc)
  finalText(page==2 and "↑/↓ MON   SELECT: MANAGE" or "↑/↓ POKéMON",
    66,134,page==2 and 1.32 or 1.50,muted,
    ox,oy,sc,"center",73)
  finalText("B: BACK",133,134,1.95,white,ox,oy,sc,"right",18)
end

function GoldCompat.drawGoldSummary(summary,winW,winH)
  if not (summary and summary.mon) then return end

  -- Eggs keep their purpose-built native Gold summary screen; revealing the
  -- hidden species/stats would violate Gold's own egg flow.
  if summary.mon.isEgg then
    local Summary=require("src.ui.gen2.SummaryMenu")
    if Summary.__gen3uiOriginalDrawWidescreen then
      return Summary.__gen3uiOriginalDrawWidescreen(summary,winW,winH)
    end
  end

  if featureEnabled("colosseumPokemonMenu") then
    return GoldCompat.drawColosseumSummary(summary.game,summary)
  end

  if summary.__colosseumMoveManager
      and GoldCompat.moveManagerPresentationEnabled() then
    return GoldCompat.drawGoldMoveManager(summary)
  end

  if summary.moveDetail or summary.moveScreen then
    return GoldCompat.drawGoldMoveManager(summary)
  end

  local title=(summary.page==1 and "POKéMON INFO")
      or (summary.page==2 and "POKéMON MOVES")
      or "POKéMON STATS"

  local ox,oy,sc=GoldCompat.drawGoldSummaryBase(summary,title)
  GoldCompat.drawGoldSummaryIdentity(summary,ox,oy,sc)

  if summary.page==2 then
    GoldCompat.drawGoldSummaryMoves(summary,ox,oy,sc)
  elseif summary.page==3 then
    GoldCompat.drawGoldSummaryStats(summary,ox,oy,sc)
  else
    GoldCompat.drawGoldSummaryInfo(summary,ox,oy,sc)
  end
end


function GoldCompat.panelText(text,x,y,size,color,align,width)
  local ox,oy,sc=finalCanvas()
  return finalText(tostring(text or ""),x,y,size,color,ox,oy,sc,align,width)
end

function GoldCompat.drawGoldPack(pack,winW,winH,embedded)
  local G=love.graphics
  winW=winW or G.getWidth()
  winH=winH or G.getHeight()
  local ox,oy,sc=finalCanvas()

  -- GIVE is a nested Pack state above HeldItemMenu/PartyMenu. Preserve that
  -- context instead of replacing it with a detached opaque bag screen.
  if pack.give and not embedded then
    local party=GoldCompat.flowStateBelow(pack.game,pack,"party")
    if party then
      pcall(GoldCompat.drawGoldPartyMenu,party,winW,winH)
    end
  end

  if embedded then
  -- Legacy compact PACK surface. Reused unchanged for the Mart sell list and
  -- the PC item PC; only the standalone field Bag below has been rebuilt as
  -- a purpose-built Colosseum surface. These embedded call sites remain
  -- pending their own native-rewrite pass.
  local x=5
  local y=24
  local w=150
  local h=112

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)

  drawColosseumRunoffPanel(x,y,w,h,13)
  G.setColor(0.006,0.026,0.030,0.91)
  G.polygon("fill",x+4,y+17,x+w+3,y+17,x+w+3,y+h-7,
    x+8,y+h-7,x+4,y+h-11)
  G.setColor(0.25,0.55,0.53,0.74)
  G.line(x+7,y+18,x+w-2,y+18)

  local pocket=pack.pocket and pack:pocket() or {id="ITEM",label="ITEMS"}
  local tabs={"ITEMS","BALLS","KEY","TM/HM"}
  local ids={"ITEM","BALL","KEY_ITEM","TM_HM"}
  local tabW=(w-8)/4
  for i,label in ipairs(tabs) do
    local tx=x+4+(i-1)*tabW
    local selected=pocket.id==ids[i]
    G.setColor(selected and 0.06 or 0.025,
               selected and 0.31 or 0.085,
               selected and 0.28 or 0.09,selected and 0.96 or 0.72)
    G.polygon("fill",tx,y+5,tx+tabW-4,y+5,tx+tabW-1,y+8,
      tx+tabW-4,y+14,tx,y+14)
  end

  -- List body.
  G.setColor(0.22,0.52,0.49,0.76)
  G.rectangle("fill",x+5,y+18,w-10,1)

  local rows=pack.rows or {}
  local first=(pack.scroll or 0)+1
  local visible=tonumber(pack.visibleRows) or 6
  for r=1,visible do
    local idx=first+r-1
    local yy=y+23+(r-1)*10
    local row=rows[idx]
    local isCancel=(idx>#rows and idx==(pack.index or 1))
    local selected=idx==(pack.index or 1)

    if selected then
      drawColosseumRunoffSelection(x+6,yy-1,w-12,9)
    end

    if row then
      local label=tostring(row.name or row.id or "")
      G.setColor(selected and 1 or 0.06,selected and 1 or 0.06,
                 selected and 1 or 0.06,1)
      -- native final text is drawn outside transform below
    elseif idx==#rows+1 then
      -- CANCEL row
    end
  end

  -- Description / message strip.
  G.setColor(0.008,0.033,0.036,0.96)
  roundedRect("fill",x+5,y+h-29,w-10,22,2)
  G.setColor(0.26,0.58,0.56,0.86)
  roundedRect("line",x+5,y+h-29,w-10,22,2)

  G.pop()

  for i,label in ipairs(tabs) do
    local tx=x+4+(i-1)*tabW
    GoldCompat.panelText(label,tx,y+7,2.15,
      pocket.id==ids[i] and {0.94,1.00,0.97,1} or {0.48,0.67,0.63,1},
      "center",tabW-1)
  end

  -- Scroll indicators reflect the same authoritative viewport as the list.
  if (pack.scroll or 0)>0 then
    GoldCompat.panelText("▲",x+w-11,y+20,2.1,{0.40,0.83,0.72,1})
  end
  if ((pack.scroll or 0)+visible)<#rows then
    GoldCompat.panelText("▼",x+w-11,y+h-34,2.1,{0.40,0.83,0.72,1})
  end

  for r=1,visible do
    local idx=first+r-1
    local yy=y+23+(r-1)*10
    local row=rows[idx]
    local selected=idx==(pack.index or 1)
    if row then
      local label=tostring(row.name or row.id or "")
      GoldCompat.panelText(label,x+9,yy+1,3.0,
        selected and {1,1,1,1} or {0.68,0.83,0.79,1},"left",w-27)
      if row.showCount then
        GoldCompat.panelText("×"..tostring(row.count or 1),x+w-20,yy+1,2.55,
          selected and {1,1,1,1} or {0.48,0.68,0.64,1},"right",12)
      elseif row.teaches then
        GoldCompat.panelText(row.teaches,x+w-31,yy+1,2.15,
          selected and {0.90,1.00,0.91,1} or {0.43,0.66,0.61,1},"right",24)
      end
    elseif idx==#rows+1 then
      GoldCompat.panelText("CANCEL",x+9,yy+1,3.0,
        selected and {1,1,1,1} or {0.68,0.83,0.79,1})
    end
  end

  local desc
  if pack.message then
    desc=table.concat(pack.message," ")
  elseif pack.description then
    local ok,v=pcall(pack.description,pack)
    if ok then desc=v end
  end
  desc=GoldCompat.cleanItemDescription(desc or "Choose an item.")
  local f=font(2.55*UI_TEXT_SCALE*GoldCompat.userTextScale())
  local _,wrapped=f:getWrap(desc,w-18)
  for i=1,math.min(2,#wrapped) do
    GoldCompat.panelText(wrapped[i],x+10,y+h-24+(i-1)*7,2.55,
      {0.84,0.94,0.90,1},"left",w-20)
  end

  -- Native Pack subflows visualized without touching their input.
  if pack.submenu then
    local m=pack.submenu
    local count=#(m.rows or {})
    local mw=34
    local mh=count*9+8
    local mx=x+5
    local my=math.max(y+20,y+h-mh-32)
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.005,0.025,0.029,0.97); roundedRect("fill",mx,my,mw,mh,2)
    G.setColor(0.28,0.61,0.58,0.96); roundedRect("line",mx,my,mw,mh,2)
    for i=1,count do
      if i==m.index then
        drawColosseumRunoffSelection(mx+3,my+4+(i-1)*9,mw-6,8)
      end
    end
    G.pop()
    for i,id in ipairs(m.rows or {}) do
      local labels={use="USE",give="GIVE",toss="TOSS",sel="SEL",quit="QUIT"}
      GoldCompat.panelText(labels[id] or tostring(id),mx+8,my+5+(i-1)*9,2.7,
        i==m.index and {1,1,1,1} or {0.66,0.82,0.77,1})
    end
  end

  if pack.qtyState then
    local q=pack.qtyState
    GoldCompat.panelText(("HOW MANY?  ×%02d"):format(q.qty or 1),
      x+10,y+h-41,2.9,{0.84,0.96,0.90,1})
  end
  if pack.confirm then
    GoldCompat.panelText(pack.confirm.choice==1 and "YES  /  no" or "yes  /  NO",
      x+w-40,y+h-41,2.6,{0.84,0.96,0.90,1})
  end

  return
  end

  -- -------------------------------------------------------------------------
  -- Standalone field Bag: purpose-built Colosseum surface.
  --
  -- Reference-led composition: a chrome ribbon header carrying the pocket
  -- name, pocket-color tab dots hanging off a stalk beneath it, a dark glass
  -- item list with a rounded pill selection, and a separate floating
  -- message/description panel down at the bottom-left over the live scene --
  -- the same two-panel layout Pokémon Colosseum's own bag uses, rebuilt here
  -- in this mod's steel/teal glass + red-orange focus material language.
  -- This same renderer draws the Bag during battle item selection and the
  -- Pokémon-menu item-target flow, since both push the identical Pack state
  -- above their owning screen; only this rendering changes; the underlying
  -- pocket/scroll/submenu/qty/confirm state and callbacks are untouched.
  -- -------------------------------------------------------------------------

  local pocket=pack.pocket and pack:pocket() or {id="ITEM",label="ITEMS"}
  local ids={"ITEM","BALL","KEY_ITEM","TM_HM"}
  local pocketTitles={ITEM="ITEMS",BALL="BALLS",KEY_ITEM="KEY ITEMS",TM_HM="TM/HM"}
  local dotColors={
    ITEM={0.34,0.64,0.66},
    BALL={0.30,0.52,0.78},
    KEY_ITEM={0.38,0.68,0.44},
    TM_HM={0.54,0.44,0.76},
  }
  local headerTitle=pocketTitles[pocket.id] or pocket.label or "ITEMS"

  local listX,listY,listW,listH = 76,8,84,90
  local headerH,tabRowH,topChevH,footerChevH = 11,12,5,5
  local listBodyTop=listY+headerH+tabRowH+topChevH
  local listBodyBottom=listY+listH-footerChevH
  -- Respect the pack's own visibleRows when it supplies one. The Gen 1
  -- categorized-Bag adapter always sets 6; the native Gen 2 Pack state may
  -- or may not set its own, so the fallback here matches the original
  -- shared renderer's field-mode default (7) exactly, to avoid silently
  -- desyncing Gen 2's own scroll math against a different row count.
  local visible=tonumber(pack.visibleRows) or 7
  local rowH=(listBodyBottom-listBodyTop)/visible

  local descX,descY,descW,descH = 4,listY+listH+4,68,32

  local rows=pack.rows or {}
  local first=(pack.scroll or 0)+1
  local rx=listX+4
  local rw=listW-8

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)

  -- Chrome ribbon header.
  local hx1,hx2=listX+3,listX+listW-3
  G.setColor(0.03,0.07,0.08,0.55)
  G.polygon("fill",hx1+1,listY+1,hx2+1,listY+1,listX+listW+1,listY+headerH*0.5+1,
    hx2+1,listY+headerH+1,hx1+1,listY+headerH+1,listX+1,listY+headerH*0.5+1)
  G.setColor(0.18,0.36,0.36,0.96)
  G.polygon("fill",hx1,listY,hx2,listY,listX+listW,listY+headerH*0.5,
    hx2,listY+headerH,hx1,listY+headerH,listX,listY+headerH*0.5)
  G.setColor(0.40,0.66,0.63,0.55)
  G.line(hx1+2,listY+1.4,hx2-2,listY+1.4)
  G.setColor(0.05,0.15,0.16,0.95)
  G.setLineWidth(0.6)
  G.polygon("line",hx1,listY,hx2,listY,listX+listW,listY+headerH*0.5,
    hx2,listY+headerH,hx1,listY+headerH,listX,listY+headerH*0.5)

  -- Stalk connecting the header to the pocket-color tab dots.
  local cx=listX+listW/2
  local usable=listW-20
  local step=usable/3
  local dotY=listY+headerH+tabRowH*0.5
  for i=1,4 do
    local dx=listX+10+(i-1)*step
    G.setColor(0.10,0.24,0.24,0.75)
    G.setLineWidth(0.7)
    G.line(cx,listY+headerH+0.5,dx,dotY-3.5)
  end
  for i=1,4 do
    local dx=listX+10+(i-1)*step
    local selected=pocket.id==ids[i]
    local c=dotColors[ids[i]] or {0.4,0.6,0.6}
    if selected then
      G.setColor(1.00,0.36,0.16,0.9)
      G.circle("line",dx,dotY,4.4)
      G.setColor(0.92,0.98,0.95,1)
      G.circle("fill",dx,dotY,3.4)
    else
      G.setColor(c[1]*0.55,c[2]*0.55,c[3]*0.55,0.85)
      G.circle("fill",dx,dotY,2.9)
      G.setColor(0.05,0.10,0.11,0.9)
      G.setLineWidth(0.5)
      G.circle("line",dx,dotY,2.9)
    end
  end

  -- Scroll bars (top lid / bottom footer), chevrons brighten when scrollable.
  local canScrollUp=(pack.scroll or 0)>0
  local canScrollDown=((pack.scroll or 0)+visible)<#rows
  G.setColor(0.03,0.09,0.10,0.85)
  roundedRect("fill",rx,listBodyTop-topChevH,rw,topChevH,1.4)
  roundedRect("fill",rx,listBodyBottom,rw,footerChevH,1.4)
  G.setColor(canScrollUp and 0.44 or 0.16,canScrollUp and 0.86 or 0.24,
    canScrollUp and 0.78 or 0.25,canScrollUp and 1 or 0.6)
  G.polygon("fill",cx-3.5,listBodyTop-1.6,cx+3.5,listBodyTop-1.6,cx,listBodyTop-4.4)
  G.setColor(canScrollDown and 0.44 or 0.16,canScrollDown and 0.86 or 0.24,
    canScrollDown and 0.78 or 0.25,canScrollDown and 1 or 0.6)
  G.polygon("fill",cx-3.5,listBodyBottom+1.6,cx+3.5,listBodyBottom+1.6,cx,listBodyBottom+4.4)

  -- Item list glass.
  G.setColor(0.006,0.028,0.031,0.90)
  G.rectangle("fill",rx,listBodyTop,rw,listBodyBottom-listBodyTop)
  G.setColor(0.20,0.44,0.42,0.55)
  G.rectangle("line",rx,listBodyTop,rw,listBodyBottom-listBodyTop)

  for r=1,visible do
    local idx=first+r-1
    local ry=listBodyTop+(r-1)*rowH
    local selected=idx==(pack.index or 1)
    if selected then
      G.setColor(0.05,0.26,0.23,0.95)
      roundedRect("fill",rx+1.5,ry+0.7,rw-3,rowH-1.4,(rowH-1.4)*0.5)
      G.setColor(0.30,0.92,0.62,0.95)
      G.setLineWidth(0.7)
      roundedRect("line",rx+1.5,ry+0.7,rw-3,rowH-1.4,(rowH-1.4)*0.5)
      G.setColor(1.00,0.36,0.16,1)
      G.circle("fill",rx+1.5+(rowH-1.4)*0.5,ry+0.7+(rowH-1.4)*0.5,(rowH-1.4)*0.30)
    end
  end

  G.pop()

  -- Header + pocket title text.
  GoldCompat.panelText(headerTitle,listX,listY+2.2,3.6,
    {0.95,1.00,0.97,1},"center",listW)

  for r=1,visible do
    local idx=first+r-1
    local ry=listBodyTop+(r-1)*rowH
    local row=rows[idx]
    local selected=idx==(pack.index or 1)
    local textX=rx+(selected and 10 or 6)
    if row then
      local label=tostring(row.name or row.id or "")
      GoldCompat.panelText(label,textX,ry+rowH*0.16,2.9,
        selected and {1,1,1,1} or {0.66,0.82,0.78,1},"left",rw-30)
      if row.showCount then
        GoldCompat.panelText("×"..tostring(row.count or 1),rx+rw-20,ry+rowH*0.16,2.5,
          selected and {1,1,1,1} or {0.48,0.68,0.64,1},"right",16)
      elseif row.teaches then
        GoldCompat.panelText(row.teaches,rx+rw-30,ry+rowH*0.16,2.1,
          selected and {0.90,1.00,0.91,1} or {0.43,0.66,0.61,1},"right",26)
      end
    elseif idx==#rows+1 then
      GoldCompat.panelText("CANCEL",textX,ry+rowH*0.16,2.9,
        selected and {1,1,1,1} or {0.66,0.82,0.78,1})
    end
  end

  -- Floating message / description panel, separate from the list -- the
  -- same bottom-corner flavor-text box Colosseum's own bag screen uses.
  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(0.02,0.04,0.05,0.45)
  roundedRect("fill",descX+1,descY+1.4,descW,descH,4)
  G.setColor(0.008,0.032,0.035,0.93)
  roundedRect("fill",descX,descY,descW,descH,3.5)
  G.setColor(0.30,0.60,0.58,0.85)
  G.setLineWidth(0.8)
  roundedRect("line",descX,descY,descW,descH,3.5)
  G.setColor(0.45,0.78,0.72,0.30)
  G.line(descX+4,descY+1.6,descX+descW-4,descY+1.6)
  G.pop()

  if pack.qtyState then
    local q=pack.qtyState
    GoldCompat.panelText("HOW MANY?",descX+6,descY+5,3.0,{0.90,0.98,0.94,1})
    GoldCompat.panelText(("×%02d"):format(q.qty or 1),descX+6,descY+15,4.2,
      {1.00,0.78,0.55,1})
  elseif pack.confirm then
    GoldCompat.panelText("USE THIS ITEM?",descX+6,descY+5,2.8,{0.90,0.98,0.94,1})
    GoldCompat.panelText(pack.confirm.choice==1 and "YES  /  no" or "yes  /  NO",
      descX+6,descY+16,3.1,{1.00,0.78,0.55,1})
  else
    local desc
    if pack.message then
      desc=table.concat(pack.message," ")
    elseif pack.description then
      local ok,v=pcall(pack.description,pack)
      if ok then desc=v end
    end
    desc=GoldCompat.cleanItemDescription(desc or "Choose an item.")
    local f=font(2.5*UI_TEXT_SCALE*GoldCompat.userTextScale())
    local _,wrapped=f:getWrap(desc,descW-10)
    for i=1,math.min(3,#wrapped) do
      GoldCompat.panelText(wrapped[i],descX+5,descY+5+(i-1)*8,2.5,
        {0.84,0.94,0.90,1},"left",descW-10)
    end
  end

  -- Native Pack subflows (USE / GIVE / TOSS / CANCEL) visualized without
  -- touching their input; anchored beside the selected row.
  if pack.submenu then
    local m=pack.submenu
    local count=#(m.rows or {})
    local mw=36
    local mh=count*9+7
    local mx=listX-mw-3
    local my=math.max(listBodyTop,math.min(listY+listH-mh,
      listBodyTop+((pack.index or 1)-first)*rowH-2))

    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)
    G.setColor(0.02,0.04,0.05,0.5)
    roundedRect("fill",mx+1,my+1.4,mw,mh,3)
    G.setColor(0.006,0.030,0.033,0.96)
    roundedRect("fill",mx,my,mw,mh,2.6)
    G.setColor(0.30,0.60,0.58,0.9)
    roundedRect("line",mx,my,mw,mh,2.6)
    for i=1,count do
      if i==m.index then
        local ry=my+4+(i-1)*9
        G.setColor(0.05,0.26,0.23,0.95)
        roundedRect("fill",mx+2,ry-0.5,mw-4,8,3.5)
        G.setColor(1.00,0.36,0.16,1)
        G.circle("fill",mx+6.5,ry+3.5,1.6)
      end
    end
    G.pop()

    local labels={use="USE",give="GIVE",toss="TOSS",sel="SEL",quit="CANCEL"}
    for i,id in ipairs(m.rows or {}) do
      GoldCompat.panelText(labels[id] or tostring(id):upper(),mx+11,my+5+(i-1)*9,2.6,
        i==m.index and {1,1,1,1} or {0.66,0.82,0.77,1})
    end
  end
end

local FLOW_TITLES={
  ["held-item"]="HELD ITEM", ["mail"]="MAIL", ["mailbox"]="MAILBOX",
  ["mail-read"]="READ MAIL", ["mail-compose"]="WRITE MAIL",
  ["bank"]="MOM'S BANK", ["daycare"]="DAY-CARE", ["elevator"]="ELEVATOR",
  ["decoration"]="DECORATION", ["prize"]="PRIZE EXCHANGE",
  ["contest"]="BUG-CATCHING CONTEST", ["move-deleter"]="MOVE DELETER",
  ["script-menu"]="SELECTION", ["trade"]="TRADE CENTER",
  ["trade-animation"]="POKéMON TRADE", ["photo"]="PHOTO STUDIO",
  ["unown"]="UNOWN REPORT", ["naming"]="NAME ENTRY",
  ["evolution"]="EVOLUTION", ["egg-hatch"]="EGG HATCH",
  ["hall-of-fame"]="HALL OF FAME", ["diploma"]="DIPLOMA",
  ["clock"]="SET THE CLOCK", ["name-pick"]="CHOOSE A NAME",
  ["map-radio"]="POKéGEAR RADIO",
}

function GoldCompat.flowLines(value)
  if type(value)=="string" then return {GoldCompat.cleanWrappedText(value)} end
  if type(value)~="table" then return nil end
  if value.pages then
    return GoldCompat.flowLines(value.pages[value.page or 1])
  end
  local out={}
  for i=1,#value do
    local line=value[i]
    if type(line)=="string" then out[#out+1]=GoldCompat.cleanWrappedText(line) end
  end
  return #out>0 and out or nil
end

function GoldCompat.flowCurrentLines(flow)
  if not flow then return nil end
  return GoldCompat.flowLines(flow.message)
      or GoldCompat.flowLines(flow.confirm)
      or GoldCompat.flowLines(flow.lines)
      or GoldCompat.flowLines(flow.prompt)
      or GoldCompat.flowLines(flow.entry and
        (flow.entry.message or flow.entry.text or flow.entry.lines))
end

function GoldCompat.flowRows(flow)
  if not flow then return {} end
  -- Do not build an array from optional fields: ipairs stops at the first nil,
  -- which made list-backed states such as Gold's Move Deleter intermittently
  -- appear empty. Inspect each named field explicitly instead.
  for _,key in ipairs({"rows","entries","items","categories","prizes",
      "team","party"}) do
    local rows=flow[key]
    if type(rows)=="table" and #rows>0 then return rows end
  end
  if type(flow.list)=="table" then
    if type(flow.list.items)=="table" and #flow.list.items>0 then
      return flow.list.items
    end
    if #flow.list>0 then return flow.list end
  end
  if type(flow.moves)=="table" and #flow.moves>0 then return flow.moves end
  return {}
end

function GoldCompat.flowRowLabel(row)
  if type(row)=="string" or type(row)=="number" then return tostring(row) end
  if type(row)~="table" then return "" end
  local label=row.label or row.name or row.text or row.id or row.item or row.species
  if type(label)=="function" then
    local ok,value=pcall(label,row)
    if ok then label=value end
  end
  local rawId=row.label==nil and row.name==nil and row.text==nil and row.id
  label=rawId and GoldCompat.humanizeIdentifier(label) or tostring(label or "")
  if row.count then label=label.."  ×"..tostring(row.count) end
  if row.price then label=label.."  ¥"..tostring(row.price) end
  return label
end

function GoldCompat.flowSelectedIndex(flow)
  return math.max(1,tonumber(flow and (flow.index or flow.listIndex or
    flow.cursor or flow.row or flow.cursorY or flow.optionIndex or
    flow.modeIndex)) or 1)
end

function GoldCompat.drawFlowShell(title,x,y,w,h,ox,oy,sc)
  local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(x,y,w,h,14)
  G.setColor(0.015,0.045,0.048,0.76)
  G.polygon("fill",x+5,y+18,x+w+4,y+18,x+w+4,y+h-8,
    x+9,y+h-8,x+5,y+h-12)
  G.setColor(0.20,0.45,0.43,0.78)
  G.line(x+8,y+h-8,x+w+3,y+h-8)
  G.pop()
  finalTextFitted(title or "MENU",x+9,y+5.5,3.35,2.15,
    {0.88,1.00,0.94,1},ox,oy,sc,"left",w-18,7.5)
end

function GoldCompat.drawFlowMessage(lines,confirm,x,y,w,ox,oy,sc)
  if not lines then return end
  local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.006,0.025,0.028,0.94)
  G.polygon("fill",x+3,y,x+w,y,x+w+3,y+4,x+w,y+25,x+3,y+25,x,y+21,x,y+4)
  G.setColor(0.32,0.62,0.60,0.94)
  G.line(x+4,y,x+w-1,y)
  G.line(x+4,y+25,x+w-1,y+25)
  G.pop()
  local textWidth=confirm and (w-61) or (w-14)
  for i=1,math.min(2,#lines) do
    finalTextFitted(lines[i],x+7,y+6+(i-1)*7,2.55,1.70,
      {0.94,0.99,0.96,1},ox,oy,sc,"left",textWidth,6.5)
  end
  if confirm and confirm.page>=(#(confirm.pages or {})) then
    local choice=confirm.choice or 1
    for i,label in ipairs({"YES","NO"}) do
      local bx=x+w-47+(i-1)*22
      local G=love.graphics
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      if i==choice then drawColosseumRunoffSelection(bx,y+14,20,8) end
      G.pop()
      finalText(label,bx+2,y+16,2.1,
        i==choice and {0.95,1.00,0.96,1} or {0.55,0.70,0.68,1},
        ox,oy,sc,"center",15)
    end
  end
end

function GoldCompat.flowStateBelow(game,flow,kind)
  local states=game and game.stack and game.stack.states or {}
  for i=#states,1,-1 do
    local state=states[i]
    if state~=flow and (not kind or state.__gen3uiGoldOverlayKind==kind
        or state.__colosseumFlowKind==kind) then return state end
  end
  return nil
end

function GoldCompat.drawHeldItemFlow(flow)
  local game=flow and flow.game
  local party=GoldCompat.flowStateBelow(game,flow,"party")
  if party then pcall(GoldCompat.drawGoldPartyMenu,party,
    love.graphics.getWidth(),love.graphics.getHeight()) end

  local ox,oy,sc=finalCanvas()
  local x,y,w,h=4,39,46,45
  GoldCompat.drawFlowShell("HELD ITEM",x,y,w,h,ox,oy,sc)
  if not flow.message and not flow.confirm then
    for i,label in ipairs({"GIVE","TAKE"}) do
      local yy=y+22+(i-1)*11
      local G=love.graphics
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      if i==(flow.index or 1) then drawColosseumRunoffSelection(x+3,yy-3,w-7,9) end
      G.pop()
      finalText(label,x+11,yy,2.8,
        i==(flow.index or 1) and {0.96,1.00,0.97,1} or {0.64,0.78,0.75,1},
        ox,oy,sc)
    end
  end
  local lines=GoldCompat.flowCurrentLines(flow)
  GoldCompat.drawFlowMessage(lines,flow.confirm,8,105,144,ox,oy,sc)
end

function GoldCompat.spriteProxy(mon,species)
  local proxy={species=species}
  for k,v in pairs(mon or {}) do proxy[k]=v end
  proxy.species=species
  return proxy
end

function GoldCompat.drawEvolutionFlow(flow,egg)
  local game=flow and flow.game
  local ox,oy,sc=safeFullCanvas()
  local x,y,w,h=18,7,124,128
  GoldCompat.drawFlowShell(egg and "EGG HATCH" or "EVOLUTION",x,y,w,h,ox,oy,sc)
  local oldSpecies=flow.__colosseumOldSpecies or flow.oldSpecies
    or (flow.mon and flow.mon.species)
  local newSpecies=flow.newSpecies or flow.species
    or (flow.evolved and flow.evolved.species)
  local showNew=flow.showNew
  if showNew==nil and flow.t then
    local period=math.max(4,28-math.floor((flow.t or 0)/40)*6)
    showNew=math.floor((flow.t or 0)/period)%2==1
  end
  if flow.done and not flow.canceled then showNew=true end
  if egg then showNew=flow.showMon==true end

  local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  -- One suspended presentation stage, echoing Colosseum's evolution scene
  -- without replacing the game's native evolution state machine.
  G.setColor(0.004,0.025,0.029,0.82)
  roundedRect("fill",x+8,y+21,w-16,67,5)
  G.setColor(0.23,0.48,0.47,0.92)
  roundedRect("line",x+8,y+21,w-16,67,5)
  G.setColor(0.02,0.15,0.16,0.60)
  G.ellipse("fill",x+w*0.5,y+76,42,10)
  G.setColor(0.16,0.82,0.63,0.38)
  G.ellipse("line",x+w*0.5,y+76,42,10)
  G.setColor(0.22,0.95,0.67,0.16)
  G.ellipse("fill",x+w*0.5,y+75,31,6)
  G.setColor(0.24,0.95,0.53,0.55)
  G.line(x+19,y+27,x+w-19,y+27)
  G.pop()

  if egg and not showNew then
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.95,0.96,0.84,1); G.ellipse("fill",x+w*0.5,y+52,13,18)
    G.setColor(0.35,0.58,0.52,1)
    for _,dot in ipairs({{-6,-5},{5,-2},{-2,7}}) do
      G.circle("fill",x+w*0.5+dot[1],y+52+dot[2],2.5)
    end
    G.pop()
  else
    local activeSpecies=(showNew and newSpecies) or oldSpecies or newSpecies
    local activeMon=showNew and (flow.evolved or flow.mon) or flow.mon
    G.push("all"); G.origin()
    pcall(GoldCompat.drawCleanResolvedPortrait,game,
      GoldCompat.spriteProxy(activeMon,activeSpecies),
      ox+(x+34)*sc,oy+(y+29)*sc,56*sc,48*sc,"evolution")
    G.pop()
  end

  local function speciesName(id)
    local def=game and game.data and game.data.pokemon and game.data.pokemon[id]
    return tostring((def and def.name) or id or "POKÃ©MON")
  end
  local stageLabel
  if egg then
    stageLabel=showNew and speciesName(newSpecies) or "THE EGG IS HATCHING"
  elseif showNew then
    stageLabel=speciesName(newSpecies)
  else
    stageLabel=speciesName(oldSpecies)
  end
  finalTextFitted(stageLabel,x+14,y+15,2.45,1.65,
    {0.78,0.98,0.87,1},ox,oy,sc,"center",w-28,7.0)
  local phase=tostring(flow.phase or (flow.done and "complete") or "transforming")
  finalTextFitted(phase:upper(),x+12,y+91,2.0,1.35,
    {0.29,0.94,0.52,1},ox,oy,sc,"left",w-43,6.0)
  local lines=GoldCompat.flowCurrentLines(flow)
  if not lines then
    local name=flow.nick or flow.oldName or
      (flow.mon and (flow.mon.nickname or flow.mon.name)) or "POKéMON"
    lines=egg and {tostring(name).." is hatching!"}
      or {"What? "..tostring(name),"is evolving!"}
  end
  GoldCompat.drawFlowMessage(lines,nil,x+6,y+97,w-12,ox,oy,sc)
  if not egg and not flow.force and flow.cancelable~=false and not flow.done then
    finalText("B: CANCEL",x+w-31,y+90,1.75,{0.65,0.77,0.74,1},ox,oy,sc)
  end
end

function GoldCompat.drawNamingFlow(flow,kind)
  -- Native naming input remains authoritative. This renderer only replaces the
  -- cartridge/full-screen presentation with a compact hanging Colosseum deck.
  -- Its keyboard borrows the grouped, low-screen selection structure of
  -- Colosseum's name entry without copying the character/trainer backdrop.
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  -- One shared geometry contract serves intro names, caught-Pokemon nicknames,
  -- starter nicknames, Gen II naming, and the input-only battle handoff.
  local x,y,w,h=18,20,124,104

  -- Naming uses the same translucent charcoal/teal glass as battle dialogue.
  -- Keep the live world or battlefield clearly visible through the deck while
  -- giving text a stable local surface.
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  local right=x+w
  G.setColor(0,0,0,0.25)
  G.polygon("fill",x+5,y+4,right+4,y+4,right+4,y+h+4,
    x+7,y+h+4,x,y+h-3,x,y+8)
  G.setColor(0.025,0.095,0.098,0.67)
  G.polygon("fill",x+5,y,right,y,right,y+h,x+7,y+h,x,y+h-6,x,y+6)
  G.setColor(0.035,0.19,0.18,0.48)
  G.polygon("fill",x+4,y+3,right,y+3,right,y+15,x+7,y+15,x+3,y+11)
  G.setColor(0.36,0.68,0.65,0.92)
  G.setLineWidth(1.1)
  G.line(x+6,y,right,y)
  G.line(x,y+7,x,y+h-6)
  G.line(x+7,y+h,right,y+h)
  G.setColor(0.19,0.55,0.51,0.78)
  G.line(x+8,y+35,x+w-6,y+35)
  G.pop()

  local isGen1=type(flow.glyphs)=="table"
  local maxLen=tonumber(flow.maxLen or flow.maxLength) or 7
  local value=""
  local glyphCount=0
  if isGen1 then
    value=table.concat(flow.glyphs or {})
    glyphCount=#(flow.glyphs or {})
  else
    value=tostring(flow.text or flow.pendingName or "")
    -- Gen II names are usually ASCII here; use the screen's own text as the
    -- display source and keep byte-counting out of input/state logic entirely.
    glyphCount=math.min(maxLen,#value)
  end

  local title=flow.title or flow.prompt
  if not title or tostring(title)=="" then
    title=(flow.monName and "NICKNAME?") or "NAME ENTRY"
  end
  finalText(tostring(title),x+10,y+6,3.05,{0.88,1.00,0.94,1},ox,oy,sc,
    "left",w-20)
  if flow.monName and tostring(flow.monName)~="" then
    finalText(tostring(flow.monName),x+w-60,y+7,2.0,{0.56,0.76,0.72,1},
      ox,oy,sc,"right",50)
  end

  -- Name strip. Empty positions remain visible as a subtle underline rail so
  -- the player can judge the native character limit without a full-screen box.
  local fieldX,fieldY,fieldW,fieldH=x+7,y+18,w-14,14
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.004,0.020,0.023,0.52)
  roundedRect("fill",fieldX,fieldY,fieldW,fieldH,3)
  G.setColor(0.25,0.58,0.56,1)
  roundedRect("line",fieldX,fieldY,fieldW,fieldH,3)
  local railLeft=fieldX+8
  local railRight=fieldX+fieldW-38
  G.setColor(0.36,0.66,0.62,0.62)
  G.line(railLeft,fieldY+fieldH-4,railRight,fieldY+fieldH-4)
  G.pop()
  finalText(value~="" and value or "_",fieldX+8,fieldY+4,3.05,
    {0.96,1.00,0.98,1},ox,oy,sc,"left",fieldW-42)
  finalText(("%d/%d"):format(glyphCount,maxLen),fieldX+fieldW-34,fieldY+5,1.8,
    {0.52,0.72,0.68,1},ox,oy,sc,"right",27)

  local rows={}
  local rowIndex,colIndex=1,1
  local bottomSelected=nil
  if isGen1 then
    local ok,grid=pcall(function() return flow:grid() end)
    if ok and type(grid)=="table" then rows=grid end
    rowIndex=math.max(1,tonumber(flow.row) or 1)
    colIndex=math.max(1,tonumber(flow.col) or 1)
  else
    local ok,grid=pcall(function() return flow:rows() end)
    if ok and type(grid)=="table" then rows=grid end
    -- Gen II now uses the same modern hanging name-entry presentation and
    -- selector geometry as Gen I, but its authoritative keyboard remains
    -- Gold's own four-row board plus the native case/DEL/END rail.  Keeping the
    -- native rows here preserves the already-correct nickname flow while the
    -- presentation itself stays visually in sync across both generations.
    -- Gen II's native cursor is zero-based and its case/delete/end row is not
    -- part of rows(). Preserve that geometry exactly in this presentation.
    rowIndex=(tonumber(flow.row) or 0)+1
    colIndex=(tonumber(flow.col) or 0)+1
    if (tonumber(flow.row) or 0)==#rows then
      local nativeCol=tonumber(flow.col) or 0
      bottomSelected=nativeCol<3 and 1 or (nativeCol<6 and 2 or 3)
    end
  end

  local caseRow=nil
  if isGen1 then
    for r,row in ipairs(rows) do
      if #row==1 then
        local label=tostring(row[1] or ""):lower()
        if label:find("lower",1,true) or label:find("upper",1,true) then
          caseRow=r
          break
        end
      end
    end
  end

  local keyboardRows={}
  for r,row in ipairs(rows) do
    if r~=caseRow then keyboardRows[#keyboardRows+1]={nativeRow=r,cells=row} end
  end
  local maxRows=math.min(5,#keyboardRows)
  local kbX,kbY,kbW,kbH=x+6,y+39,w-12,45
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.004,0.024,0.026,0.43)
  roundedRect("fill",kbX,kbY,kbW,kbH,4)
  G.setColor(0.18,0.43,0.42,1)
  roundedRect("line",kbX,kbY,kbW,kbH,4)
  -- Keep the keyboard as one uninterrupted selection field. The Colosseum
  -- grouping is carried by spacing alone; no center divider is needed.
  G.pop()

  local rowGap=maxRows>=5 and 7.3 or 8.7
  local startY=kbY+4
  -- Divide the keyboard's real inner width into nine bounded navigation slots.
  -- The previous hand-authored offsets placed column nine outside the frame.
  local gridInset=5
  local gridW=kbW-gridInset*2
  local slotW=gridW/9
  local function displayCell(cell,nativeRow,col)
    local raw=tostring(cell or "")
    -- Gold's standard upper-case name board leaves the last three cells of
    -- its punctuation row as spaces. Keep one real SP cell, then use the final
    -- two positions for the same male/female glyphs Gen I already exposes.
    if not isGen1 and not flow.isBox and not flow.lower and nativeRow==4 then
      if col==8 then return "♂" end
      if col==9 then return "♀" end
    end
    if raw==" " then return "SP" end
    if raw=="ED" then return "END" end
    if raw=="<PK>" then return "PK" end
    if raw=="<MN>" then return "MN" end
    local ok,res=pcall(Strings,raw)
    if ok and res then return tostring(res) end
    return raw
  end

  for displayRow=1,maxRows do
    local entry=keyboardRows[displayRow]
    local nativeRow=entry.nativeRow
    local cells=entry.cells or {}
    local cy=startY+(displayRow-1)*rowGap
    for c=1,math.min(9,#cells) do
      local selected=(not bottomSelected and nativeRow==rowIndex and c==colIndex)
      -- The slot is a strict layout boundary; the label and its measured focus
      -- plate share this same rectangle.
      local cellX=kbX+gridInset+(c-1)*slotW
      local label=displayCell(cells[c],nativeRow,c)
      local metricSize=(label=="♂" or label=="♀") and 2.55
        or ((#label>=3) and 1.55 or ((#label==2) and 1.95 or 2.55))
      while metricSize>1.20
          and finalTextWidth(label,metricSize,sc)>slotW-1.2 do
        metricSize=metricSize-0.10
      end
      local measuredW=math.min(slotW-1.2,
        math.max(1,finalTextWidth(label,metricSize,sc)))
      local metricPx=math.max(4,math.floor(metricSize*sc+0.5))
      local measuredH=font(metricPx*UI_TEXT_SCALE*GoldCompat.userTextScale())
        :getHeight()/math.max(sc,0.001)
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      if selected then
        -- Fit the plate to the active font's rendered glyph bounds, with a
        -- small readable pad, then clamp it to the navigation slot.
        local selectW=clamp(measuredW+3.0,6.5,slotW-0.7)
        local selectH=clamp(measuredH+1.8,5.8,rowGap-0.6)
        local sx=cellX+slotW*0.5-selectW*0.5
        local sy=cy+(measuredH-selectH)*0.5
        G.setColor(0.075,0.285,0.275,0.96)
        roundedRect("fill",sx,sy,selectW,selectH,1.7)
        G.setColor(0.31,0.96,0.59,0.88)
        roundedRect("line",sx,sy,selectW,selectH,1.7)
        G.setColor(1.00,0.34,0.16,1)
        -- Arrow sits to the left and points right, into the selected glyph.
        G.polygon("fill",sx+0.9,sy+selectH*0.50,
          sx-1.8,sy+selectH*0.24,sx-1.8,sy+selectH*0.76)
      end
      G.pop()
      finalText(label,cellX,cy,metricSize,
        selected and {0.98,1.00,0.98,1} or {0.68,0.84,0.79,1},
        ox,oy,sc,"center",slotW)
    end
  end

  -- Native meta controls stay native: Gen I has a one-cell case row plus ED
  -- inside its fifth row; Gen II has three fat bottom targets. Render those
  -- targets as a compact control rail instead of inventing new input behavior.
  local actionY=y+87
  if isGen1 then
    local label=flow.lower and "UPPER" or "LOWER"
    local selected=(caseRow and rowIndex==caseRow)
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    if selected then drawColosseumRunoffSelection(x+9,actionY-3,38,8) end
    G.pop()
    finalText(label,x+14,actionY,1.9,
      selected and {0.98,1.00,0.98,1} or {0.59,0.78,0.73,1},ox,oy,sc)
    finalText("A INPUT   B DELETE",x+54,actionY,1.7,{0.58,0.76,0.72,1},ox,oy,sc)
  else
    local labels={flow.lower and "UPPER" or "LOWER","DEL","END"}
    local targetX={x+10,x+58,x+96}
    local targetW={40,31,35}
    for i,label in ipairs(labels) do
      local selected=bottomSelected==i
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      if selected then drawColosseumRunoffSelection(targetX[i]-2,actionY-3,targetW[i],8) end
      G.pop()
      finalText(label,targetX[i]+2,actionY,1.9,
        selected and {0.98,1.00,0.98,1} or {0.59,0.78,0.73,1},
        ox,oy,sc,"center",targetW[i]-5)
    end
  end

  local footer=isGen1
    and "SELECT: CASE     START: DONE"
    or "SELECT: CASE     START: END"
  finalText(footer,x+10,y+h-6,1.55,{0.50,0.70,0.66,1},ox,oy,sc,
    "center",w-20)
end

function GoldCompat.flowMoveLabel(flow,row)
  local id
  if type(row)=="table" then
    id=row.id or row.move or row.moveId or row.name or row.label
  else
    id=row
  end
  local def=flow and flow.game and flow.game.data and flow.game.data.moves
    and flow.game.data.moves[id]
  local label=(def and def.name) or id or "---"
  return GoldCompat.humanizeIdentifier(label):upper()
end

function GoldCompat.drawMoveDeleterFlow(flow)
  -- Field TM/HM learning in Gold pushes Gen2MoveDeleter after the target
  -- Party screen has closed. Present that authoritative row/input state inside
  -- the same Party detail deck as Gen I instead of opening a second full-page
  -- "MOVE DELETER" interface.
  if GoldCompat.pokemonPresentationEnabled() and flow and flow.mon then
    local game=flow.game
    local party=(game and game.save and game.save.party) or {}
    local selected=1
    for i,mon in ipairs(party) do
      if mon==flow.mon then selected=i break end
    end
    local pending=State.pendingGen2FieldLearn
    local adapter={
      game=game,mon=flow.mon,
      newMoveId=(pending and pending.mon==flow.mon and pending.moveId) or "MOVE",
      index=math.max(1,tonumber(flow.row) or 1),selecting=true,
      __gen2FieldMoveLearn=true,
    }
    local partyState={
      game=game,party=party,index=selected,selected=selected,blink=0,
      keepOpen=true,__gen3uiFieldMoveParty=true,
    }
    function partyState:bottomMessage() return "Choose a move to replace." end
    State.activeMoveLearn=adapter
    return GoldCompat.drawColosseumParty(game,partyState)
  end

  local ox,oy,sc=safeFullCanvas()
  local x,y,w,h=25,7,110,129
  GoldCompat.drawFlowShell("MOVE DELETER",x,y,w,h,ox,oy,sc)
  local G=love.graphics

  -- Portrait stage and move selector are deliberately separate. Selection can
  -- never paint across the installed sprite, regardless of window scale.
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.006,0.032,0.035,0.91)
  roundedRect("fill",x+37,y+20,36,35,4)
  G.setColor(0.28,0.57,0.55,0.96)
  roundedRect("line",x+37,y+20,36,35,4)
  G.setColor(0.008,0.030,0.033,0.94)
  roundedRect("fill",x+8,y+63,w-16,37,4)
  G.setColor(0.22,0.45,0.43,0.94)
  roundedRect("line",x+8,y+63,w-16,37,4)
  G.pop()

  local mon=flow.mon or flow.pokemon
  if type(mon)=="table" and mon.species then
    pcall(GoldCompat.drawCleanResolvedPortrait,flow.game,mon,
      ox+(x+40)*sc,oy+(y+23)*sc,30*sc,29*sc,"flow")
    local def=flow.game and flow.game.data and flow.game.data.pokemon
      and flow.game.data.pokemon[mon.species]
    local name=mon.nickname or mon.name or (def and def.name) or mon.species
    finalText(tostring(name or "POKÃ©MON"),x+12,y+56,2.25,
      {0.74,0.91,0.84,1},ox,oy,sc,"center",w-24)
  end

  local rows=GoldCompat.flowRows(flow)
  local selected=GoldCompat.flowSelectedIndex(flow)
  local visible=math.min(4,#rows)
  local first=math.max(1,math.min(selected-1,math.max(1,#rows-visible+1)))
  for slot=1,visible do
    local idx=first+slot-1
    local row=rows[idx]
    local yy=y+67+(slot-1)*8
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    if idx==selected then drawColosseumRunoffSelection(x+12,yy-2,w-24,7.5) end
    G.pop()
    finalText(GoldCompat.flowMoveLabel(flow,row),x+19,yy,2.35,
      idx==selected and {0.98,1.00,0.98,1} or {0.67,0.82,0.78,1},
      ox,oy,sc,"left",w-34)
  end
  if #rows==0 then
    finalText("NO MOVES",x+19,y+75,2.5,{0.62,0.76,0.72,1},ox,oy,sc)
  end

  local lines=GoldCompat.flowCurrentLines(flow)
    or {"Which move should be forgotten?"}
  GoldCompat.drawFlowMessage(lines,flow.confirm,x+5,y+102,w-10,ox,oy,sc)
end

function GoldCompat.clockDisplay12(hour,minute)
  local h=math.floor(tonumber(hour) or 0)%24
  local m=math.floor(tonumber(minute) or 0)%60
  local suffix=h>=12 and "PM" or "AM"
  local shown=h%12
  if shown==0 then shown=12 end
  return ("%d:%02d %s"):format(shown,m,suffix)
end

function GoldCompat.cleanClockQuestion(flow,question)
  local phase=tostring(flow and flow.phase or "")
  local hour=flow and flow.hour or 0
  local minute=flow and flow.minute or 0
  local human=GoldCompat.clockDisplay12(hour,minute)
  if phase=="confirm-hour" then
    return "Is "..GoldCompat.clockDisplay12(hour,0).." correct?"
  elseif phase=="confirm-minute" then
    return "Is "..human.." correct?"
  elseif phase=="response" then
    local suffix=""
    local raw=tostring(question or "")
    if raw:find("dark",1,true) or raw:find("DARK",1,true) then
      suffix="  It's so dark!"
    elseif raw:find("overslept",1,true) or raw:find("OVERSLEPT",1,true) then
      suffix="  I overslept!"
    elseif raw:find("Yikes",1,true) or raw:find("YIKES",1,true) then
      suffix="  Yikes!"
    end
    return human..suffix
  end
  return question
end

function GoldCompat.drawClockFlow(flow)
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  local x,y,w,h=22,15,116,112
  local isDay=flow.mode=="day"
  local phase=tostring(flow.phase or "")
  local title=isDay and "SET THE DAY" or "SET THE CLOCK"
  GoldCompat.drawFlowShell(title,x,y,w,h,ox,oy,sc)

  local question=""
  if type(flow.question)=="function" then
    local ok,value=pcall(flow.question,flow)
    if ok and value then question=tostring(value) end
  end
  question=GoldCompat.cleanWrappedText(question)
  question=GoldCompat.cleanClockQuestion(flow,question)

  local display=nil
  if type(flow.display)=="function" then
    local ok,value=pcall(flow.display,flow)
    if ok then display=value end
  end
  -- The native Gold clock writes cartridge-era labels such as
  -- "NITE 10 O'CLOCK".  Keep its 24-hour value/state machine untouched but
  -- present it as ordinary 12-hour time in the overhaul.
  if phase=="hour" then
    display=GoldCompat.clockDisplay12(flow.hour,0)
  elseif phase=="minute" then
    display=GoldCompat.clockDisplay12(flow.hour,flow.minute)
  end

  local confirming=false
  if type(flow.confirming)=="function" then
    local ok,value=pcall(flow.confirming,flow)
    confirming=ok and value==true
  end

  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.004,0.024,0.027,0.98)
  roundedRect("fill",x+7,y+25,w-14,49,5)
  G.setColor(0.20,0.46,0.44,0.98)
  roundedRect("line",x+7,y+25,w-14,49,5)
  G.setColor(0.020,0.105,0.082,0.93)
  roundedRect("fill",x+11,y+29,w-22,11,3)
  G.pop()

  if question~="" then
    finalTextFitted(question,x+14,y+32,2.05,1.35,
      {0.69,0.88,0.82,1},ox,oy,sc,"center",w-28,6.0)
  end

  if display then
    local label=tostring(display):upper()
    finalText("UP",x+53,y+46,1.8,{0.48,0.96,0.72,1},ox,oy,sc,"center",10)
    finalTextFitted(label,x+18,y+54,4.25,2.30,
      {0.98,1.00,0.97,1},ox,oy,sc,"center",w-36,11.0)
    finalText("DOWN",x+48,y+67,1.65,{0.48,0.96,0.72,1},ox,oy,sc,"center",20)
    finalTextFitted("UP / DOWN OR LEFT / RIGHT: CHANGE",x+13,y+80,1.45,1.05,
      {0.53,0.73,0.69,1},ox,oy,sc,"center",w-26,5.0)
  elseif confirming then
    local selected=math.max(1,math.min(2,tonumber(flow.yesNo) or 1))
    local ry=y+51
    local gap=5
    local rw=(w-26-gap)/2
    for i=1,2 do
      local rx=x+13+(i-1)*(rw+gap)
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      G.setColor(i==selected and {0.060,0.275,0.255,0.99} or {0.004,0.025,0.027,0.96})
      roundedRect("fill",rx,ry,rw,16,3)
      G.setColor(i==selected and {0.31,0.96,0.59,1} or {0.17,0.42,0.39,0.94})
      roundedRect("line",rx,ry,rw,16,3)
      if i==selected then
        G.setColor(1.00,0.34,0.16,1)
        G.polygon("fill",rx+6,ry+8,rx+2,ry+5,rx+2,ry+11)
      end
      G.pop()
      finalText(i==1 and "YES" or "NO",rx+10,ry+5,2.55,
        i==selected and {1,1,1,1} or {0.68,0.82,0.78,1},ox,oy,sc,"center",rw-16)
    end
    finalTextFitted("LEFT / RIGHT: CHOOSE",x+13,y+80,1.55,1.05,
      {0.53,0.73,0.69,1},ox,oy,sc,"center",w-26,5.0)
  else
    -- Intro/readback pages are still native state-machine pages; display their
    -- text clearly and let A advance exactly as the engine expects.
    finalText("A: CONTINUE",x+31,y+61,2.35,{0.65,0.88,0.80,1},ox,oy,sc,"center",54)
  end

  local footer=confirming and "A: CONFIRM   B: BACK" or "A: SELECT"
  if phase=="intro" or phase=="response" then footer="A: CONTINUE" end
  finalTextFitted(footer,x+10,y+h-7,1.65,1.05,
    {0.50,0.70,0.66,1},ox,oy,sc,"center",w-20,5.5)
end

function GoldCompat.drawGenericFlow(flow,kind)
  if kind=="clock" then return GoldCompat.drawClockFlow(flow) end
  if kind=="held-item" then return GoldCompat.drawHeldItemFlow(flow) end
  if kind=="evolution" then return GoldCompat.drawEvolutionFlow(flow,false) end
  if kind=="egg-hatch" then return GoldCompat.drawEvolutionFlow(flow,true) end
  if kind=="move-deleter" then return GoldCompat.drawMoveDeleterFlow(flow) end
  if kind=="naming" or kind=="mail-compose" then
    return GoldCompat.drawNamingFlow(flow,kind)
  end

  local ox,oy,sc=finalCanvas()
  local x,y,w,h=31,13,126,121
  local title=FLOW_TITLES[kind] or tostring(kind or "MENU"):upper()
  GoldCompat.drawFlowShell(title,x,y,w,h,ox,oy,sc)
  local preview=flow.mon or flow.pokemon
  if type(preview)=="table" and preview.species then
    local G=love.graphics
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.01,0.04,0.045,0.90)
    roundedRect("fill",x+w-43,y+23,35,35,3)
    G.setColor(0.27,0.59,0.57,0.92)
    roundedRect("line",x+w-43,y+23,35,35,3)
    G.pop()
    G.push("all"); G.origin()
    pcall(GoldCompat.drawCleanResolvedPortrait,flow.game,preview,
      ox+(x+w-40)*sc,oy+(y+26)*sc,29*sc,28*sc,"flow")
    G.pop()
  end
  local rows=GoldCompat.flowRows(flow)
  local selected=GoldCompat.flowSelectedIndex(flow)
  local visible=math.min(8,math.max(1,#rows))
  local first=math.max(1,math.min(selected-3,math.max(1,#rows-visible+1)))
  for slot=1,visible do
    local idx=first+slot-1
    local row=rows[idx]
    if not row then break end
    local yy=y+24+(slot-1)*10
    local G=love.graphics
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    if idx==selected then drawColosseumRunoffSelection(x+5,yy-3,w-10,9) end
    G.pop()
    finalTextFitted(GoldCompat.flowRowLabel(row),x+13,yy,2.65,1.65,
      idx==selected and {0.96,1.00,0.97,1} or {0.65,0.79,0.76,1},
      ox,oy,sc,"left",w-27,6.5)
  end
  if #rows==0 then
    local value=flow.text or flow.stationName or flow.pendingDeco or flow.mode
      or flow.phase or "READY"
    finalTextFitted(tostring(value):upper(),x+12,y+29,3.0,1.65,
      {0.72,0.92,0.84,1},ox,oy,sc,"left",w-24,8.0)
  end
  local lines=GoldCompat.flowCurrentLines(flow)
  GoldCompat.drawFlowMessage(lines,flow.confirm,x+5,y+h-35,w-10,ox,oy,sc)
  finalTextFitted("A: SELECT",x+8,y+h-6,1.75,1.10,
    {0.51,0.72,0.68,1},ox,oy,sc,"left",42,5.5)
  if kind~="name-pick" then
    finalTextFitted("B: BACK",x+w-35,y+h-6,1.75,1.10,
      {0.51,0.72,0.68,1},ox,oy,sc,"right",27,5.5)
  end
end

function GoldCompat.flowPresentationEnabled(kind)
  if kind=="evolution" or kind=="egg-hatch" then
    return GoldCompat.evolutionPresentationEnabled()
  end
  if kind=="held-item" then
    return GoldCompat.heldItemPresentationEnabled()
  end
  if kind=="naming" or kind=="name-pick" then
    return GoldCompat.namingPresentationEnabled()
  end
  if kind=="clock" then
    return GoldCompat.clockPresentationEnabled()
  end

  -- Gold's smaller native screens share one presentation adapter, but each
  -- user-facing flow still gets its own UI-menu switch. SERVICE / EVENT MENUS
  -- remains the master switch for this family; the rows below are the granular
  -- controls beneath it.
  if not GoldCompat.serviceFlowPresentationEnabled() then return false end
  if kind=="mail-compose" or kind=="mail" or kind=="mail-read"
      or kind=="mailbox" then
    return featureEnabled("revampedMailUI")
  end
  if kind=="bank" then return featureEnabled("revampedBankUI") end
  if kind=="daycare" then return featureEnabled("revampedDayCareUI") end
  if kind=="elevator" then return featureEnabled("revampedElevatorUI") end
  if kind=="decoration" then return featureEnabled("revampedDecorationUI") end
  if kind=="prize" then return featureEnabled("revampedPrizeUI") end
  if kind=="contest" then return featureEnabled("revampedContestUI") end
  if kind=="move-deleter" then return featureEnabled("revampedMoveDeleterUI") end
  if kind=="script-menu" then return featureEnabled("revampedScriptMenuUI") end
  if kind=="trade" or kind=="trade-animation" then
    return featureEnabled("revampedTradeUI")
  end
  if kind=="photo" then return featureEnabled("revampedPhotoStudioUI") end
  if kind=="unown" then return featureEnabled("revampedUnownPrinterUI") end
  if kind=="hall-of-fame" then return featureEnabled("revampedHallOfFameUI") end
  if kind=="diploma" then return featureEnabled("revampedDiplomaUI") end
  if kind=="map-radio" then return featureEnabled("revampedMapRadioUI") end
  return true
end

-- Horizontal two-choice rows share one directional contract everywhere they
-- appear: LEFT/UP selects the first choice and RIGHT/DOWN selects the second.
-- The native state still owns A/B confirmation and all callbacks.
function GoldCompat.remapHorizontalConfirmInput(owner)
  local confirm=owner and owner.confirm
  local input=owner and owner.game and owner.game.input
  if not (confirm and input) then return false end
  local pages=confirm.pages or {}
  if confirm.page and #pages>0 and confirm.page<#pages then return false end

  local left=input:wasPressed("left")
  local right=input:wasPressed("right")
  local up=input:wasPressed("up")
  local down=input:wasPressed("down")
  if not (left or right or up or down) then return false end

  local previous=math.max(1,math.min(2,tonumber(confirm.choice) or 1))
  local nextChoice=previous
  if left or up then
    nextChoice=1
  elseif right or down then
    nextChoice=2
  end
  confirm.choice=nextChoice
  if nextChoice~=previous then
    pcall(function()
      require("src.core.Sound").play(owner.game.data,"Press_AB")
    end)
  end
  return true
end

function GoldCompat.remapVerticalListInput(owner,items,indexKey)
  local input=owner and owner.game and owner.game.input
  local count=type(items)=="number" and items or #(items or {})
  if not input or count<1 then return false end
  local up=input:wasPressed("up")
  local down=input:wasPressed("down")
  local left=input:wasPressed("left")
  local right=input:wasPressed("right")
  if not (up or down or left or right) then return false end

  indexKey=indexKey or "index"
  local previous=math.max(1,math.min(count,tonumber(owner[indexKey]) or 1))
  local nextIndex=previous
  if up or left then
    nextIndex=(previous>1) and (previous-1) or count
  elseif down or right then
    nextIndex=(previous<count) and (previous+1) or 1
  end
  owner[indexKey]=nextIndex
  if nextIndex~=previous then
    pcall(function()
      require("src.core.Sound").play(owner.game.data,"Press_AB")
    end)
  end
  return true
end

-- -------------------------------------------------------------------------
-- Intro-safe Gen I name entry.
--
-- Oak's player/rival naming happens before a new save has completed the usual
-- overworld/session setup. The general NamingScreen is perfect once the game
-- exists, but mods which inspect normal menu/HUD context can make that early
-- state fragile. This tiny state deliberately owns ONLY glyph input and the
-- completion callback; the Colosseum renderer above supplies the presentation.
-- -------------------------------------------------------------------------
local SAFE_INTRO_GRID_UPPER={
  {"A","B","C","D","E","F","G","H","I"},
  {"J","K","L","M","N","O","P","Q","R"},
  {"S","T","U","V","W","X","Y","Z"," "},
  {"×","(",")",":",";","[","]","<PK>","<MN>"},
  {"-","?","!","♂","♀","/",".",",","ED"},
  {"lower case"},
}
local SAFE_INTRO_GRID_LOWER={
  {"a","b","c","d","e","f","g","h","i"},
  {"j","k","l","m","n","o","p","q","r"},
  {"s","t","u","v","w","x","y","z"," "},
  {"×","(",")",":",";","[","]","<PK>","<MN>"},
  {"-","?","!","♂","♀","/",".",",","ED"},
  {"UPPER CASE"},
}

local SafeIntroNaming={}
SafeIntroNaming.__index=SafeIntroNaming
SafeIntroNaming.isOpaque=false

function SafeIntroNaming.new(game,opts)
  opts=opts or {}
  local self=setmetatable({},SafeIntroNaming)
  self.game=game
  self.title=opts.title or Strings("YOUR NAME?")
  self.presets=opts.presets
  self.maxLen=math.max(1,tonumber(opts.maxLen) or 7)
  self.default=opts.default
  self.onDone=opts.onDone
  self.glyphs={}
  self.row,self.col=1,1
  self.lower=false
  self.__colosseumFlowKind="naming"
  self.__colosseumIntroSafe=true
  self.screenId="NamingScreen"
  return self
end

function SafeIntroNaming:grid()
  return self.lower and SAFE_INTRO_GRID_LOWER or SAFE_INTRO_GRID_UPPER
end

function SafeIntroNaming:enter()
  if not (type(self.presets)=="table" and #self.presets>0) then return end
  local items={{label=Strings("NEW NAME")}}
  for _,preset in ipairs(self.presets) do
    local value=tostring(preset)
    items[#items+1]={
      label=value,
      onSelect=function()
        -- Menu has already popped itself when this callback runs.
        if self.game and self.game.stack then self.game.stack:pop() end
        if self.onDone then self.onDone(value) end
      end,
    }
  end
  if self.game and self.game.stack then
    self.game.stack:push(Menu.new(self.game,items,{
      tx=4,ty=0,tw=12,th=#items*2+2,cancelable=false,
    }))
  end
end

function SafeIntroNaming:confirm()
  local name=table.concat(self.glyphs or {})
  if name=="" then
    name=(type(self.presets)=="table" and self.presets[1]) or self.default or ""
  end
  pcall(function()
    local data=self.game and self.game.data
    if data then require("src.core.Sound").play(data,"Press_AB") end
  end)
  if self.game and self.game.stack then self.game.stack:pop() end
  if self.onDone then self.onDone(name) end
end

function SafeIntroNaming:jumpToEnd()
  self.row,self.col=5,9
end

function SafeIntroNaming:update(_dt)
  local input=self.game and self.game.input
  if not input then return end
  local grid=self:grid()
  local caseRow=#grid

  if input:wasPressed("start") then
    self:confirm(); return
  elseif input:wasPressed("select") then
    self.lower=not self.lower; return
  elseif input:wasPressed("up") then
    self.row=self.row>1 and self.row-1 or caseRow
    self.col=math.min(self.col,#grid[self.row]); return
  elseif input:wasPressed("down") then
    self.row=self.row<#grid and self.row+1 or 1
    self.col=math.min(self.col,#grid[self.row]); return
  elseif input:wasPressed("left") then
    if self.row~=caseRow then
      self.col=self.col>1 and self.col-1 or #grid[self.row]
    end
    return
  elseif input:wasPressed("right") then
    if self.row~=caseRow then
      self.col=self.col<#grid[self.row] and self.col+1 or 1
    end
    return
  end

  local a=input:wasPressed("a")
  local b=input:wasPressed("b")
  if a and b then b=false end
  if b then
    table.remove(self.glyphs)
    return
  end
  if not a then return end
  if self.row==5 and self.col==9 then
    self:confirm(); return
  end
  if self.row==caseRow then
    self.lower=not self.lower; return
  end
  if #self.glyphs>=self.maxLen then return end

  local cell=grid[self.row] and grid[self.row][self.col]
  if cell==nil then return end
  pcall(function()
    local data=self.game and self.game.data
    if data then require("src.core.Sound").play(data,"Press_AB") end
  end)
  self.glyphs[#self.glyphs+1]=cell
  if #self.glyphs>=self.maxLen then self:jumpToEnd() end
end

-- Native screen draw is intentionally empty: renderCrossgenFlowOverlay paints
-- the hanging board after Oak's intro scene. Keeping this state non-opaque also
-- guarantees the player/rival backdrop survives underneath it.
function SafeIntroNaming:draw() end
function SafeIntroNaming:drawWidescreen() end
function SafeIntroNaming:drawsWidescreen() return false end
function SafeIntroNaming:wantsFillScale() return false end

function GoldCompat.installSafeGen1IntroNaming()
  if GoldCompat.generation~="gen1" or GoldCompat.safeIntroNamingInstalled then return end
  local ok,OakSpeech=pcall(require,"src.ui.OakSpeech")
  if not (ok and type(OakSpeech)=="table" and type(OakSpeech.runStep)=="function") then
    return
  end
  GoldCompat.safeIntroNamingInstalled=true
  OakSpeech.__colosseumOriginalRunStep=OakSpeech.__colosseumOriginalRunStep or OakSpeech.runStep
  local original=OakSpeech.__colosseumOriginalRunStep

  OakSpeech.runStep=function(self,step)
    local kind=step and (step.kind or "say")
    if kind~="name" or not GoldCompat.flowPresentationEnabled("naming") then
      return original(self,step)
    end

    local game=self.game
    if not (game and game.stack) then return original(self,step) end
    -- Establish only the tiny save shape Oak's callback actually writes. No
    -- overworld, map, party, options, or renderer state is fabricated here.
    if type(game.save)~="table" then game.save={} end
    if type(game.save.player)~="table" then game.save.player={} end

    local who=step.who or "player"
    local presetKey=step.presetsWho or who
    local boot=game.data and game.data.field and game.data.field.boot
    local bootPresets=boot and boot.namePresets and boot.namePresets[presetKey]
    local presets=step.presets
    if type(presets)~="table" or #presets==0 then
      if type(bootPresets)=="table" and #bootPresets>0 then
        presets=bootPresets
      else
        presets=step.presetsFallback or (who=="rival"
          and {"BLUE","GARY","JOHN"} or {"RED","ASH","JACK"})
      end
    end

    local state=SafeIntroNaming.new(game,{
      title=step.title or (who=="rival" and Strings("HIS NAME?") or Strings("YOUR NAME?")),
      presets=presets,
      maxLen=step.maxLen or self.nameLen or 7,
      onDone=function(name)
        -- The intro must never hand an empty name into later text substitution.
        if not name or name=="" then name=tostring(presets[1] or (who=="rival" and "BLUE" or "RED")) end
        if type(game.save)~="table" then game.save={} end
        if type(game.save.player)~="table" then game.save.player={} end
        if who=="rival" then game.save.player.rival=name
        else game.save.player.name=name end
        if type(self.recordAnswer)=="function" then
          self:recordAnswer(step,1,name,name)
        end
        self:advance()
      end,
    })
    game.stack:push(state)
  end
end

-- The cartridge generations expose different concrete screen classes, but
-- they share one presentation contract here: native update/selection/commit
-- logic remains authoritative while only draw ownership is replaced.
function GoldCompat.patchFlowClass(moduleName,kind,captureOldSpecies)
  local ok,class=pcall(require,moduleName)
  if not ok or type(class)~="table" or class.__colosseumFlowPatched then
    return false
  end
  class.__colosseumFlowPatched=true
  class.__colosseumOriginalOpaque=class.isOpaque
  class.__colosseumOriginalNew=class.new
  class.__colosseumOriginalUpdate=class.update
  class.__colosseumOriginalDraw=class.draw
  class.__colosseumOriginalDrawWidescreen=class.drawWidescreen
  class.__colosseumOriginalDrawsWidescreen=class.drawsWidescreen
  class.__colosseumOriginalWantsFillScale=class.wantsFillScale

  -- Naming is a hanging overlay in both generations. Some stack/compositor
  -- paths inspect the class/metatable opacity flag before the instance field,
  -- so clear both seams while our renderer owns the naming presentation. The
  -- constructor below still restores instance opacity when the feature is off.
  if kind=="naming" then class.isOpaque=false end

  if type(class.__colosseumOriginalNew)=="function" then
    class.new=function(...)
      local args={...}
      local self=class.__colosseumOriginalNew(...)
      if type(self)=="table" then
        self.__colosseumFlowKind=kind
        if captureOldSpecies then
          local mon
          if type(args[2])=="table" and args[2].species then
            mon=args[2]
          elseif type(args[2])=="table" and type(args[2].mon)=="table" then
            mon=args[2].mon
          end
          self.__colosseumOldSpecies=self.__colosseumOldSpecies
            or self.oldSpecies or (mon and mon.species)
        end
        self.isOpaque=not GoldCompat.flowPresentationEnabled(kind)
          and class.__colosseumOriginalOpaque or false
      end
      return self
    end
  end

  if type(class.__colosseumOriginalUpdate)=="function" then
    class.update=function(self,dt,...)
      if kind=="clock" and GoldCompat.flowPresentationEnabled(kind) then
        local input=self.game and self.game.input
        if input then
          local confirming=false
          if type(self.confirming)=="function" then
            local ok,value=pcall(self.confirming,self)
            confirming=ok and value==true
          end
          local more=false
          if type(self.morePages)=="function" then
            local ok,value=pcall(self.morePages,self)
            more=ok and value==true
          end
          if confirming and not more then
            if input:wasPressed("left") then
              self.yesNo=1
              return
            elseif input:wasPressed("right") then
              self.yesNo=2
              return
            end
          elseif self.phase=="hour" or self.phase=="minute" or self.phase=="day" then
            if input:wasPressed("left") and type(self.step)=="function" then
              self:step(-1)
              return
            elseif input:wasPressed("right") and type(self.step)=="function" then
              self:step(1)
              return
            end
          end
        end
      end
      if kind=="move-deleter" and GoldCompat.flowPresentationEnabled(kind) then
        local input=self.game and self.game.input
        local direction=input and (input:wasPressed("left") and "left"
          or input:wasPressed("right") and "right"
          or input:wasPressed("up") and "up"
          or input:wasPressed("down") and "down")
        if direction then
          local pressed=input.pressed or {}
          local saved={left=pressed.left,right=pressed.right,
            up=pressed.up,down=pressed.down}
          pressed.left=nil; pressed.right=nil
          pressed.up=nil; pressed.down=nil
          local result=callOriginal(class.__colosseumOriginalUpdate,self,dt,...)
          pressed.left=saved.left; pressed.right=saved.right
          pressed.up=saved.up; pressed.down=saved.down
          local count=math.max(1,#(self.list or {}))
          local index=math.max(1,math.min(count,tonumber(self.row) or 1))
          if direction=="left" or direction=="up" then
            self.row=index>1 and index-1 or count
          else
            self.row=index<count and index+1 or 1
          end
          return result
        end
      end
      if GoldCompat.flowPresentationEnabled(kind)
          and GoldCompat.remapHorizontalConfirmInput(self) then
        return
      end
      return callOriginal(class.__colosseumOriginalUpdate,self,dt,...)
    end
  end

  class.drawsWidescreen=function(self,...)
    if GoldCompat.flowPresentationEnabled(kind) then return false end
    return callOriginal(class.__colosseumOriginalDrawsWidescreen,self,...)
  end
  class.wantsFillScale=function(self,...)
    if GoldCompat.flowPresentationEnabled(kind) then return false end
    return callOriginal(class.__colosseumOriginalWantsFillScale,self,...)
  end
  class.draw=function(self,...)
    if self.__colosseumRenderFailed then
      self.isOpaque=class.__colosseumOriginalOpaque
      return callOriginal(class.__colosseumOriginalDraw,self,...)
    end
    if GoldCompat.flowPresentationEnabled(kind) then
      self.__colosseumFlowKind=kind
      self.isOpaque=false
      return
    end
    self.isOpaque=class.__colosseumOriginalOpaque
    return callOriginal(class.__colosseumOriginalDraw,self,...)
  end
  class.drawWidescreen=function(self,...)
    if self.__colosseumRenderFailed then
      self.isOpaque=class.__colosseumOriginalOpaque
      return callOriginal(class.__colosseumOriginalDrawWidescreen,self,...)
    end
    if GoldCompat.flowPresentationEnabled(kind) then
      self.__colosseumFlowKind=kind
      self.isOpaque=false
      return
    end
    self.isOpaque=class.__colosseumOriginalOpaque
    return callOriginal(class.__colosseumOriginalDrawWidescreen,self,...)
  end
  return true
end

function GoldCompat.installCrossgenFlowUI()
  if GoldCompat.crossgenFlowUiInstalled then return end
  GoldCompat.crossgenFlowUiInstalled=true

  if GoldCompat.generation=="gen1" then
    GoldCompat.installSafeGen1IntroNaming()

    -- Scripted Gen I gifts (including all three Red/Blue starters and
    -- Yellow's forced Pikachu) enter AskName through Commands.give_pokemon,
    -- which pushes the ordinary NamingScreen after the YES callback. Keep the
    -- script coroutine, gift result, nickname callback and stack ownership
    -- exactly native, but construct the same hardened input-only naming state
    -- already used by the stable intro/catch handoffs. This avoids the old
    -- full-screen NamingScreen re-entering while its gift TextBox/script stack
    -- is still unwinding.
    if NamingScreen and type(NamingScreen.new)=="function"
        and not NamingScreen.__colosseumGiftNamingPatched then
      NamingScreen.__colosseumGiftNamingPatched=true
      NamingScreen.__colosseumOriginalNew=NamingScreen.new
      NamingScreen.new=function(game,opts)
        opts=opts or {}
        local title=tostring(opts.title or ""):upper()
        local scriptedNickname=(tonumber(opts.maxLen)==10)
          and (title:find("NICK",1,true)~=nil)
        if scriptedNickname and GoldCompat.namingPresentationEnabled() then
          local state=SafeIntroNaming.new(game,opts)
          state.__colosseumGiftNaming=true
          return state
        end
        return NamingScreen.__colosseumOriginalNew(game,opts)
      end
    end

    -- BattleState's native AskName path is safe by itself, but a caught-mon
    -- NamingScreen remains stacked over a still-live battle. The overhaul's
    -- cross-screen probes made that specific combination fragile and could
    -- crash on the first typed glyph. Keep the native question/YES-NO and
    -- battle queue ownership, but use the same tiny input-only naming state
    -- that already hardens Oak's intro. This changes no catch/storage logic:
    -- the callback still writes only mon.nickname and the battle resumes when
    -- the naming state pops.
    if BattleState and type(BattleState.askNicknameUI)=="function"
        and not BattleState.__colosseumCaughtNamingPatched then
      BattleState.__colosseumCaughtNamingPatched=true
      BattleState.__colosseumOriginalAskNicknameUI=BattleState.askNicknameUI
      BattleState.askNicknameUI=function(self,mon,displayName)
        if not GoldCompat.flowPresentationEnabled("naming") then
          return BattleState.__colosseumOriginalAskNicknameUI(self,mon,displayName)
        end
        local game=self.game
        if not (game and game.stack and mon) then
          return BattleState.__colosseumOriginalAskNicknameUI(self,mon,displayName)
        end

        self.lockedBall=nil
        -- The overhaul owns presentation here, so do NOT run AskName's
        -- cartridge ClearScreenArea path.  Keeping the battle visible behind
        -- the question/choice removes the white flash before name entry.
        self.blankForAskName=false
        local text=self:romText("_DoYouWantToNicknameText",
          "Do you want to\ngive a nickname\nto %s?",displayName)
        local label=game.data and game.data.text
          and game.data.text._DoYouWantToNicknameText
        if type(label)=="string" and label~="" then
          text=label:gsub("\t","\n"):gsub("{RAM:?[%w_]*}",tostring(displayName or ""))
        end

        local prompt=TextBox.new(game,text,nil,{
          -- AskName's YES/NO belongs on the completed question immediately.
          -- Starting on the already-typed final page avoids an invisible
          -- acknowledgement frame before ChoiceBox is pushed.
          instant=true,
          choice=function(yes)
            self.blankForAskName=false
            if not yes then return end
            local state=SafeIntroNaming.new(game,{
              title=Strings("NICKNAME?"),
              maxLen=10,
              onDone=function(name)
                if name and #name>0 then mon.nickname=name end
              end,
            })
            state.monName=tostring(displayName or "")
            state.__colosseumCaughtNaming=true
            game.stack:push(state)
          end,
        })
        -- Lets the ChoiceBox adapter identify this exact prompt without
        -- guessing from translated text. Input/callback ownership stays native.
        prompt.__colosseumNicknamePrompt=true
        return prompt
      end
    end

    GoldCompat.patchFlowClass("src.ui.EvolutionState","evolution",true)
    GoldCompat.patchFlowClass("src.ui.NamingScreen","naming",false)
    return
  end

  -- Remember the incoming field move across Gold's asynchronous ask/list
  -- screens. Gen2MoveDeleter itself only receives the Pokémon and old moves,
  -- so this is the missing presentation context needed by the Party deck.
  local okGame2,Game2=pcall(require,"src.core.Game2")
  if okGame2 and Game2 and type(Game2.learnMoveOn)=="function"
      and not Game2.__gen3uiLearnMoveWrapped then
    Game2.__gen3uiLearnMoveWrapped=true
    Game2.__gen3uiOriginalLearnMoveOn=Game2.learnMoveOn
    Game2.learnMoveOn=function(self,mon,moveId,onDone)
      local pending={mon=mon,moveId=moveId}
      State.pendingGen2FieldLearn=pending
      local function finished(...)
        if State.pendingGen2FieldLearn==pending then
          State.pendingGen2FieldLearn=nil
        end
        if State.activeMoveLearn
            and State.activeMoveLearn.__gen2FieldMoveLearn then
          State.activeMoveLearn=nil
        end
        if onDone then return onDone(...) end
      end
      return Game2.__gen3uiOriginalLearnMoveOn(self,mon,moveId,finished)
    end
  end

  -- Gen II nickname lifecycle is engine-owned. Current Gen2Recomp's
  -- givepoke path calls Specials.askNickname(), which keeps the script VM
  -- suspended until its native YES/NO and NamingScreen callbacks complete.
  -- This mod deliberately does not wrap givePokeFn or World:step here: doing
  -- so duplicates the nickname flow and can resume the overworld out of order.
  -- The presentation adapter below still skins that native NamingScreen.

  -- Match the Gen II naming input to the presented board: on the standard
  -- upper-case page, the final two spare cells type gender symbols. Box naming
  -- already owns its richer native symbol rows and is left untouched.
  local okNaming2,Naming2=pcall(require,"src.ui.gen2.NamingScreen")
  if okNaming2 and Naming2 and type(Naming2.characterAt)=="function"
      and not Naming2.__colosseumGenderCellsPatched then
    Naming2.__colosseumGenderCellsPatched=true
    Naming2.__colosseumOriginalCharacterAt=Naming2.characterAt
    Naming2.characterAt=function(self,col,row)
      if GoldCompat.flowPresentationEnabled("naming")
          and not self.isBox and not self.lower and row==3 then
        if col==7 then return "♂" end
        if col==8 then return "♀" end
      end
      return Naming2.__colosseumOriginalCharacterAt(self,col,row)
    end
  end

  local flows={
    {"src.ui.gen2.HeldItemMenu","held-item"},
    {"src.ui.gen2.MailMenu","mail"},
    {"src.ui.gen2.MailboxMenu","mailbox"},
    {"src.ui.gen2.MailRead","mail-read"},
    {"src.ui.gen2.MailCompose","mail-compose"},
    {"src.ui.gen2.BankOfMom","bank"},
    {"src.ui.gen2.DayCareMenu","daycare"},
    {"src.ui.gen2.ElevatorMenu","elevator"},
    {"src.ui.gen2.DecorationMenu","decoration"},
    {"src.ui.gen2.PrizeMenu","prize"},
    {"src.ui.gen2.ContestMenu","contest"},
    {"src.ui.gen2.MoveDeleter","move-deleter"},
    {"src.ui.gen2.ScriptMenu","script-menu"},
    {"src.ui.gen2.TradeMenu","trade"},
    {"src.ui.gen2.TradeAnim","trade-animation"},
    {"src.ui.gen2.PhotoStudio","photo"},
    {"src.ui.gen2.UnownPrinter","unown"},
    {"src.ui.gen2.HallOfFame","hall-of-fame"},
    {"src.ui.gen2.Diploma","diploma"},
    {"src.ui.gen2.InitClock","clock"},
    {"src.ui.gen2.NamePick","name-pick"},
    {"src.ui.gen2.MapRadio","map-radio"},
    {"src.ui.gen2.NamingScreen","naming"},
    {"src.ui.gen2.EvolutionAnim","evolution",true},
    {"src.ui.gen2.EggHatchAnim","egg-hatch",true},
  }
  for _,entry in ipairs(flows) do
    GoldCompat.patchFlowClass(entry[1],entry[2],entry[3])
  end
end

function GoldCompat.drawGoldMart(mart,winW,winH)
  local ox,oy,sc=finalCanvas()
  local G=love.graphics
  local phase=mart.phase

  local function panel(x,y,w,h)
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.01,0.02,0.02,0.34)
    roundedRect("fill",x+2,y+2,w,h,6)
    G.setColor(0.025,0.065,0.068,0.94)
    roundedRect("fill",x,y,w,h,6)
    G.setColor(0.38,0.58,0.56,0.96)
    roundedRect("line",x,y,w,h,6)
    G.setColor(0.015,0.035,0.036,0.96)
    roundedRect("fill",x+5,y+5,w-10,h-10,4)
    G.pop()
  end

  local function selection(x,y,w,h)
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.64,0.13,0.075,0.94)
    roundedRect("fill",x,y,w,h,4)
    G.pop()
  end

  -- STANDARD root: compact hanging choice menu over the live shop.
  if phase=="top" or phase=="outro" then
    local labels={"BUY","SELL","EXIT"}
    local x,y,w,h=94,25,58,49
    panel(x,y,w,h)
    if phase=="top" then
      local yy=y+8+((mart.topIndex or 1)-1)*13
      selection(x+5,yy-1,w-10,10)
    end
    for i,label in ipairs(labels) do
      GoldCompat.panelText(label,x+12,y+9+(i-1)*13,4.0,
        i==(mart.topIndex or 1) and phase=="top"
          and {1,1,1,1} or {0.73,0.86,0.81,1})
    end

  -- SELL and every SELL child phase keep the custom Bag visible underneath.
  elseif (phase=="sell" or phase=="sellQuantity") and mart.pack then
    GoldCompat.drawGoldPack(mart.pack,winW,winH,false)

  -- BUY and BUY quantity/confirmation use one continuous hanging list.
  else
    local px,py,pw,ph=63,20,92,91
    panel(px,py,pw,ph)
    GoldCompat.panelText("POKé MART — BUY",px+9,py+7,3.3,{0.72,0.92,0.85,1})
    local money=("¥%d"):format(mart.money and mart:money() or 0)
    GoldCompat.panelText(money,px+pw-33,py+7,3.05,{0.72,0.92,0.85,1},"right",25)

    local entries=mart.entries or {}
    local first=(mart.scroll or 0)+1
    local total=#entries+1
    for r=1,5 do
      local idx=first+r-1
      if idx>total then break end
      local yy=py+22+(r-1)*12
      local selected=idx==(mart.index or 1)
      if selected then selection(px+5,yy-1,pw-10,10) end
      if idx<=#entries then
        local entry=entries[idx]
        GoldCompat.panelText(entry.name or entry.id,px+10,yy,2.8,
          selected and {1,1,1,1} or {0.73,0.86,0.81,1},"left",53)
        GoldCompat.panelText(("¥%d"):format(entry.price or 0),px+pw-30,yy,2.55,
          selected and {1,1,1,1} or {0.58,0.76,0.70,1},"right",22)
      else
        GoldCompat.panelText("CANCEL",px+10,yy,2.8,
          selected and {1,1,1,1} or {0.73,0.86,0.81,1})
      end
    end

    -- Selected item description owns a separate hanging glass card directly
    -- beneath BUY. Keep the item list itself free of footer/help text.
    if not (mart.message or mart.confirm) and phase~="buyQuantity" and mart.description then
      local ok,d=pcall(mart.description,mart)
      if ok and d and d~="" then
        d=GoldCompat.cleanItemDescription(d)
        local dx,dy,dw,dh=px,py+ph+3,pw,25
        panel(dx,dy,dw,dh)
        local pages=TextBox.paginate(d,28)
        local page=(pages and pages[1]) or {d}
        for i=1,math.min(2,#page) do
          GoldCompat.panelText(tostring(page[i]),dx+9,dy+6+(i-1)*8,2.55,
            {0.84,0.94,0.90,1},"left",dw-18)
        end
      end
    end
  end

  -- Only show the root clerk line while the root menu is actually active.
  -- Message/confirm pages belong to their current child flow. Never allow
  -- stale topLines to leak under the Bag or BUY list.
  local lines=nil
  if mart.message and mart.message.pages then
    lines=mart.message.pages[mart.message.page or 1]
  elseif mart.confirm and mart.confirm.pages then
    lines=mart.confirm.pages[mart.confirm.page or 1]
  elseif (phase=="top" or phase=="outro") and mart.topLines then
    lines=mart.topLines
  end

  if lines then
    if type(lines)=="string" then lines={lines} end
    local bx,by,bw,bh=8,108,144,29
    panel(bx,by,bw,bh)
    for i,line in ipairs(lines) do
      if i<=2 then
        GoldCompat.panelText(tostring(line),bx+8,by+7+(i-1)*8,3.15,
          {0.88,0.96,0.93,1},"left",bw-16)
      end
    end
  end

  -- Quantity panels always sit over the surface that spawned them: BUY list
  -- for purchases, custom Bag for sales.
  if phase=="buyQuantity" or phase=="sellQuantity" then
    local qx,qy,qw,qh=92,73,59,27
    panel(qx,qy,qw,qh)
    GoldCompat.panelText("HOW MANY?",qx+7,qy+5,2.35,{0.55,0.78,0.69,1})
    GoldCompat.panelText(("×%02d"):format(mart.qty or 1),qx+7,qy+13,3.8,
      {0.94,0.99,0.97,1})
    if mart.qtyItem and mart.qtyItem.price then
      local totalPrice
      if phase=="sellQuantity" then
        totalPrice=math.floor((mart.qtyItem.price or 0)*(mart.qty or 1)/2)
      else
        totalPrice=(mart.qtyItem.price or 0)*(mart.qty or 1)
      end
      GoldCompat.panelText(("¥%d"):format(totalPrice),qx+qw-30,qy+13,2.65,
        {0.72,0.92,0.85,1},"right",23)
    end
  end

  if mart.confirm and mart.confirm.page>=#(mart.confirm.pages or {}) then
    local cx,cy,cw,ch=109,84,42,24
    panel(cx,cy,cw,ch)
    local c=mart.confirm.choice or 1
    selection(cx+5,cy+4+(c-1)*8,cw-10,8)
    GoldCompat.panelText("YES",cx+11,cy+5,2.55,
      c==1 and {1,1,1,1} or {0.73,0.86,0.81,1})
    GoldCompat.panelText("NO",cx+11,cy+13,2.55,
      c==2 and {1,1,1,1} or {0.73,0.86,0.81,1})
  end
end


function GoldCompat.cleanPcText(value,playerName)
  local text=tostring(value or "")
  text=text:gsub("{PLAYER}",playerName or "GOLD")
  text=text:gsub("#MON","POKéMON")
  text=text:gsub("#DEX","POKéDEX")
  text=text:gsub("<PK><MN>","POKéMON")
  return text
end

function GoldCompat.drawGoldCenterPc(pc,winW,winH)
  do
    local player=(pc.playerName and pc:playerName()) or "GOLD"
    if pc.message then
      local page=pc.message.pages and pc.message.pages[pc.message.page or 1] or {}
      local lines={}
      for i,line in ipairs(page or {}) do
        lines[i]=GoldCompat.cleanPcText(line,player)
      end
      local ox,oy,sc=finalCanvas()
      GoldCompat.drawFlowMessage(lines,nil,8,108,144,ox,oy,sc)
      if lines[3] then
        finalText(lines[3],15,128,2.45,{0.94,0.99,0.96,1},ox,oy,sc,
          "left",130)
      end
      return
    end

    drawPCAccessFinal(pc.game,{
      items=pc.entries or {},
      index=pc.index or 1,
      prompt="Access whose PC?",
    },pc.confirm~=nil)
    if pc.confirm then
      local lines={}
      for i,line in ipairs(pc.confirm.prompt or {}) do
        lines[i]=GoldCompat.cleanPcText(line,player)
      end
      local confirm={choice=pc.confirm.choice or 1,page=1,pages={{}}}
      local ox,oy,sc=finalCanvas()
      GoldCompat.drawFlowMessage(lines,confirm,8,108,144,ox,oy,sc)
    end
    return
  end
  local ox,oy,sc=finalCanvas()
  local G=love.graphics
  local player=(pc.playerName and pc:playerName()) or "GOLD"

  -- MESSAGE / BOOT / ACCESS pages: only a hanging dialogue panel. The world
  -- remains fully visible behind it.
  if pc.message then
    local page=pc.message.pages and pc.message.pages[pc.message.page or 1] or {}
    local x,y,w,h=8,108,144,29

    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)
    G.setColor(0.04,0.04,0.04,0.34)
    roundedRect("fill",x+2,y+2,w,h,3)
    G.setColor(0.08,0.08,0.07,1)
    roundedRect("fill",x,y,w,h,3)
    G.setColor(0.99,0.985,0.95,1)
    roundedRect("fill",x+2,y+2,w-4,h-4,2)
    drawUnifiedBorder(x,y,w,h,0)
    G.pop()

    for i,line in ipairs(page or {}) do
      if i<=3 then
        GoldCompat.panelText(
          GoldCompat.cleanPcText(line,player),
          x+8,y+6+(i-1)*7,3.25,{0.06,0.06,0.06,1},"left",w-16)
      end
    end
    if pc.message.page and pc.message.pages
        and pc.message.page<#pc.message.pages then
      GoldCompat.panelText("▼",x+w-13,y+h-10,2.8,{0.12,0.12,0.11,1})
    end
    return
  end

  -- Whose-PC selector: same compact hanging-panel concept as Gen 1.
  local entries=pc.entries or {}
  local w=67
  local h=10+#entries*13
  local x=88
  local y=13

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(0.04,0.04,0.04,0.34)
  roundedRect("fill",x+2,y+2,w,h,3)
  G.setColor(0.08,0.08,0.07,1)
  roundedRect("fill",x,y,w,h,3)
  G.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",x+2,y+2,w-4,h-4,2)
  drawUnifiedBorder(x,y,w,h,0)

  for i,_ in ipairs(entries) do
    local yy=y+5+(i-1)*13
    if i==(pc.index or 1) then
      G.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",x+5,yy-1,w-10,10,1.5)
    end
  end
  G.pop()

  for i,entry in ipairs(entries) do
    local yy=y+5+(i-1)*13
    local selected=i==(pc.index or 1)
    GoldCompat.panelText(
      GoldCompat.cleanPcText(entry.label,player),
      x+9,yy+1,3.25,
      selected and {1,1,1,1} or {0.06,0.06,0.06,1},
      "left",w-18)
  end

  -- Native PC question / Oak-rating yes-no uses our dialogue strip.
  local prompt=pc.confirm and pc.confirm.prompt or {"Access whose PC?"}
  local dx,dy,dw,dh=8,108,144,29
  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(0.04,0.04,0.04,0.34)
  roundedRect("fill",dx+2,dy+2,dw,dh,3)
  G.setColor(0.08,0.08,0.07,1)
  roundedRect("fill",dx,dy,dw,dh,3)
  G.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",dx+2,dy+2,dw-4,dh-4,2)
  drawUnifiedBorder(dx,dy,dw,dh,0)
  G.pop()

  for i,line in ipairs(prompt or {}) do
    GoldCompat.panelText(GoldCompat.cleanPcText(line,player),
      dx+8,dy+6+(i-1)*7,3.2,{0.06,0.06,0.06,1},"left",95)
  end

  if pc.confirm then
    local c=pc.confirm.choice or 1
    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)
    local qx,qy,qw,qh=117,79,35,27
    G.setColor(0.08,0.08,0.07,1)
    roundedRect("fill",qx,qy,qw,qh,2)
    G.setColor(0.99,0.985,0.95,1)
    roundedRect("fill",qx+2,qy+2,qw-4,qh-4,1.5)
    if c==1 then
      G.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",qx+5,qy+5,qw-10,8,1)
    else
      G.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",qx+5,qy+15,qw-10,8,1)
    end
    G.pop()
    GoldCompat.panelText("YES",qx+10,qy+6,2.8,
      c==1 and {1,1,1,1} or {0.06,0.06,0.06,1})
    GoldCompat.panelText("NO",qx+10,qy+16,2.8,
      c==2 and {1,1,1,1} or {0.06,0.06,0.06,1})
  end
end

function GoldCompat.drawGoldPcRoot(pc,suppressFooter)
  do
    local ox,oy,sc=finalCanvas()
    local G=love.graphics
    local save=pc.save or (pc.game and pc.game.save) or {}
    if pc.message then
      local lines=type(pc.message)=="table" and pc.message or {pc.message}
      local clean={}
      for i,line in ipairs(lines) do clean[i]=GoldCompat.cleanPcText(line) end
      GoldCompat.drawFlowMessage(clean,nil,8,108,144,ox,oy,sc)
      if clean[3] then
        finalText(clean[3],15,128,2.45,{0.94,0.99,0.96,1},ox,oy,sc,
          "left",130)
      end
      return
    end

    partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    drawPCBackground(pc.game,"POKéMON PC",
      ("BOX %d"):format(save.currentBox or 1))
    drawPCGlassPanel(6,26,54,96,false)
    drawPCGlassPanel(64,26,90,96,false)
    if not (suppressFooter or pc.__colosseumSuppressFooter) then
      G.setColor(0.004,0.025,0.028,0.94)
      roundedRect("fill",6,128,148,8,2)
      G.setColor(0.22,0.51,0.48,0.90)
      roundedRect("line",6,128,148,8,2)
    end
    G.pop()

    local seenCount,ownedCount=0,0
    if GoldCompat.generation=="gen2" then
      local okSpecials,Specials=pcall(require,"src.script.gen2.Specials")
      if okSpecials and Specials and type(Specials.dexCounts)=="function" then
        local okCounts,a,b=pcall(Specials.dexCounts,save)
        if okCounts then seenCount=tonumber(a) or 0; ownedCount=tonumber(b) or 0 end
      end
    else
      seenCount=pokedexSeenCount(save); ownedCount=pokedexOwnedCount(save)
    end

    GoldCompat.panelText("STORAGE STATUS",11,32,2.5,{0.40,0.96,0.60,1})
    GoldCompat.panelText(("CURRENT BOX  %d"):format(save.currentBox or 1),
      11,42,2.8,{0.91,0.98,0.94,1})
    GoldCompat.panelText(("PARTY  %d / 6"):format(#(save.party or {})),
      11,51,2.8,{0.74,0.87,0.82,1})
    GoldCompat.panelText("POKéDEX",11,65,2.3,{0.40,0.96,0.60,1})
    GoldCompat.panelText(("%d SEEN"):format(seenCount),11,74,2.7,
      {0.91,0.98,0.94,1})
    GoldCompat.panelText(("%d CAUGHT"):format(ownedCount),11,83,2.7,
      {0.91,0.98,0.94,1})
    GoldCompat.panelText("TOTAL STORED",11,97,2.3,{0.40,0.96,0.60,1})
    GoldCompat.panelText(tostring(GoldCompat.totalStoredPokemon(save)),11,106,3.2,
      {0.96,1.00,0.97,1})

    if pc.picking then
      GoldCompat.panelText("CHANGE BOX",71,32,2.6,{0.40,0.96,0.60,1})
      local first=math.max(1,math.min((pc.pickIndex or 1)-5,9))
      for r=1,6 do
        local n=first+r-1
        local yy=43+(r-1)*12
        local selected=n==(pc.pickIndex or 1)
        if selected then
          G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
          drawColosseumRunoffSelection(68,yy-2,81,9)
          G.pop()
        end
        GoldCompat.panelText("BOX "..tostring(n),75,yy,2.8,
          selected and {0.98,1.00,0.96,1} or {0.64,0.81,0.76,1})
      end
    else
      GoldCompat.panelText("PC FUNCTIONS",71,32,2.6,{0.40,0.96,0.60,1})
      for i,e in ipairs(pc.entries or {}) do
        local yy=43+(i-1)*12
        local selected=i==(pc.index or 1)
        if selected then
          G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
          drawColosseumRunoffSelection(68,yy-2,81,9)
          G.pop()
        end
        local label=GoldCompat.cleanPcText(e.label or e.id or "")
        GoldCompat.panelText(label,75,yy,2.7,
          selected and {0.98,1.00,0.96,1} or {0.64,0.81,0.76,1},"left",72)
      end
    end
    if not (suppressFooter or pc.__colosseumSuppressFooter) then
      GoldCompat.panelText(pc.picking and "Choose a BOX." or "Choose a PC action.",
        10,130,2.7,{0.92,0.98,0.94,1},"left",112)
      GoldCompat.panelText("B: BACK",131,130,2.0,{0.68,0.84,0.78,1})
    end
    return
  end
  local ox,oy,sc=finalCanvas()
  local G=love.graphics

  if pc.message then
    local x,y,w,h=8,108,144,29
    G.push("all")
    G.translate(ox,oy)
    G.scale(sc,sc)
    G.setColor(0.04,0.04,0.04,0.34)
    roundedRect("fill",x+2,y+2,w,h,3)
    G.setColor(0.08,0.08,0.07,1)
    roundedRect("fill",x,y,w,h,3)
    G.setColor(0.99,0.985,0.95,1)
    roundedRect("fill",x+2,y+2,w-4,h-4,2)
    drawUnifiedBorder(x,y,w,h,0)
    G.pop()

    local lines=type(pc.message)=="table" and pc.message or {pc.message}
    for i,line in ipairs(lines) do
      if i<=3 then
        GoldCompat.panelText(GoldCompat.cleanPcText(line),
          x+8,y+6+(i-1)*7,3.2,{0.06,0.06,0.06,1},"left",w-16)
      end
    end
    return
  end
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.94,0.93,0.87,1); G.rectangle("fill",0,0,160,144)
  G.setColor(0.08,0.08,0.08,1); G.rectangle("fill",4,4,152,16)
  G.setColor(0.99,0.985,0.955,1); G.rectangle("fill",5,5,150,14)

  partySlotPanel(5,24,69,96,true)
  partySlotPanel(79,24,76,96,false)
  G.setColor(0.08,0.08,0.07,1); G.rectangle("fill",4,127,152,13)
  G.pop()

  GoldCompat.panelText("POKéMON PC",10,7,5.0,{0.06,0.06,0.06,1})
  local save=pc.save or (pc.game and pc.game.save) or {}
  GoldCompat.panelText("STORAGE",12,31,3.0,{0.34,0.34,0.31,1})
  GoldCompat.panelText(("CURRENT BOX  %d"):format(save.currentBox or 1),
    12,40,4.0,{0.08,0.08,0.08,1})
  GoldCompat.panelText(("PARTY  %d / 6"):format(#(save.party or {})),
    12,50,3.6,{0.12,0.12,0.11,1})

  local seenCount,ownedCount=0,0
  if GoldCompat.generation=="gen2" then
    local okSpecials,Specials=pcall(require,"src.script.gen2.Specials")
    if okSpecials and Specials and type(Specials.dexCounts)=="function" then
      local okCounts,a,b=pcall(Specials.dexCounts,save)
      if okCounts then
        seenCount=tonumber(a) or 0
        ownedCount=tonumber(b) or 0
      end
    end
  else
    seenCount=pokedexSeenCount(save)
    ownedCount=pokedexOwnedCount(save)
  end
  GoldCompat.panelText("POKéDEX",12,61,2.7,{0.34,0.34,0.31,1})
  GoldCompat.panelText(("%d SEEN"):format(seenCount),12,68,3.1,
    {0.08,0.08,0.08,1})
  GoldCompat.panelText(("%d OWNED"):format(ownedCount),42,68,3.1,
    {0.08,0.08,0.08,1})

  local entries=pc.entries or {}
  local index=pc.index or 1
  if pc.picking then
    GoldCompat.panelText("CHANGE BOX",85,31,3.1,{0.34,0.34,0.31,1})
    local first=math.max(1,math.min((pc.pickIndex or 1)-5,9))
    for r=1,6 do
      local n=first+r-1
      local yy=41+(r-1)*12
      local selected=n==(pc.pickIndex or 1)
      if selected then
        G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
        G.setColor(0.10,0.10,0.09,1); roundedRect("fill",83,yy-1,68,10,1.5)
        G.pop()
      end
      GoldCompat.panelText("BOX "..tostring(n),88,yy,3.2,
        selected and {1,1,1,1} or {0.06,0.06,0.06,1})
    end
  else
    for i,e in ipairs(entries) do
      local yy=31+(i-1)*12
      local selected=i==index
      if selected then
        G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
        G.setColor(0.10,0.10,0.09,1); roundedRect("fill",83,yy-1,68,10,1.5)
        G.pop()
      end
      local label=tostring(e.label or e.id or ""):gsub("<PK><MN>","POKéMON")
      GoldCompat.panelText(label,88,yy,2.8,
        selected and {1,1,1,1} or {0.06,0.06,0.06,1},"left",60)
    end
  end

  local footer=pc.message and tostring(pc.message):gsub("\n"," ") or "Choose a PC action."
  GoldCompat.panelText(footer,9,130,3.2,{0.98,0.98,0.96,1},"left",142)
end

function GoldCompat.drawGoldBoxMenu(box)
  local ox,oy,sc=finalCanvas()
  local G=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0.94,0.93,0.87,1); G.rectangle("fill",0,0,160,144)
  G.setColor(0.08,0.08,0.08,1); G.rectangle("fill",4,4,152,16)
  G.setColor(0.99,0.985,0.955,1); G.rectangle("fill",5,5,150,14)
  G.setColor(0.08,0.08,0.07,1); G.rectangle("fill",4,127,152,13)
  G.pop()

  local title=box.title and box:title() or "POKéMON PC"
  partyText(tostring(title):gsub("<PK><MN>","POKéMON"),10,6,6,{0.06,0.06,0.06,1})

  local mon=box.panelMon and box:panelMon() or (box.selected and box:selected())
  local pokemon=box.pokemon or (box.game and box.game.data and box.game.data.pokemon) or {}

  -- Exact Party-card footprint. The PC no longer maintains a second, slightly
  -- different left-column layout.
  local lx,ly,lw,lh=4,23,74,101
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  partySlotPanel(lx,ly,lw,lh,true)
  G.pop()

  if mon and not mon.isEgg then
    local def=pokemon[mon.species]
    local name=tostring(mon.nickname or mon.name or (def and def.name) or mon.species or "POKéMON")
    local stats=mon.stats or {}

    partyText(name,lx+7,ly+5,5.2,{0.06,0.06,0.06,1})
    local lv="Lv."..tostring(mon.level or "?")
    partyText(lv,lx+lw-7-partyTextWidth(lv,4),ly+6,4,{0.06,0.06,0.06,1})

    local gender=GoldCompat.genderSymbol(mon)

    pcall(GoldCompat.drawCleanResolvedPortrait,box.game,mon,
      ox+(lx+14)*sc,oy+(ly+19)*sc,31*sc,24*sc,"pc")

    local hpMax=math.max(1,mon.maxHp or stats.hp or stats.maxHp or 1)
    local hpNow=tonumber(mon.hp) or 0
    local hpText=tostring(hpNow).."/"..tostring(hpMax)
    local hpY=ly+43
    local hpValueX=lx+lw-7-partyTextWidth(hpText,3)
    local hpBarX=lx+21
    local hpBarW=math.max(17,hpValueX-hpBarX-3)
    partyText("HP",lx+9,hpY,3,{0.08,0.08,0.08,1})
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    local ratio=math.max(0,math.min(1,hpNow/hpMax))
    G.setColor(0.10,0.10,0.09,1); roundedRect("fill",hpBarX,hpY+1,hpBarW,4,1.5)
    G.setColor(0.78,0.76,0.63,1); roundedRect("fill",hpBarX+1,hpY+2,hpBarW-2,2,1)
    if hpNow>0 then
      local r,gg,b,a=hpColor(ratio); G.setColor(r,gg,b,a)
      roundedRect("fill",hpBarX+1,hpY+2,math.max(1,(hpBarW-2)*ratio),2,1)
    end
    G.pop()
    partyText(hpText,hpValueX,hpY,3,{0.08,0.08,0.08,1})

    if gender then
      pcall(GoldCompat.drawGenderIcon,
        ox+(lx+14)*sc,oy+(ly+51.5)*sc,12,gender)
    end

    partyText("EXP",lx+9,ly+55,2.5,{0.34,0.45,0.50,1})
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    local expRatio=partyExpRatio(box.game,mon)
    G.setColor(0.10,0.18,0.24,1); roundedRect("fill",lx+21,ly+56,lw-29,4,1.5)
    G.setColor(0.14,0.28,0.38,1); roundedRect("fill",lx+22,ly+57,lw-31,2,1)
    if expRatio>0 then
      G.setColor(0.08,0.48,0.96,1)
      roundedRect("fill",lx+22,ly+57,(lw-31)*expRatio,2,1)
    end
    G.pop()

    local moves=mon.moves or {}
    local stripX,stripY=lx+6,ly+63
    local stripW=lw-12
    local gap=1
    local moveW=(stripW-gap*3)/4
    local moveH=20
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.70,0.68,0.59,1); G.rectangle("fill",lx+7,ly+60,lw-14,1)
    for i=1,4 do
      local cx=stripX+(i-1)*(moveW+gap)
      G.setColor(0.965,0.95,0.88,1); roundedRect("fill",cx,stripY,moveW,moveH,1.2)
      G.setColor(0.74,0.71,0.61,1); roundedRect("line",cx,stripY,moveW,moveH,1.2)
    end
    G.pop()
    for i=1,4 do
      local entry=moves[i]
      local cx=stripX+(i-1)*(moveW+gap)
      local moveName=partyMoveName(box.game,entry)
      local pp=partyMovePP(box.game,entry)
      local nameSize=2.35
      while nameSize>1.45 and partyTextWidth(moveName,nameSize)>moveW-3 do nameSize=nameSize-0.12 end
      partyText(moveName,cx+1.5,stripY+4,nameSize,{0.06,0.06,0.06,1},"center",moveW-3)
      if pp~="" then partyText(pp,cx+1.5,stripY+13,1.8,{0.24,0.24,0.21,1},"center",moveW-3) end
    end

    local statDefs={
      {"ATK",partyStat(mon,"attack","atk")},
      {"DEF",partyStat(mon,"defense","def")},
      {"SPD",partyStat(mon,"speed","spd")},
      {"SPA",partyStat(mon,"specialAttack","spAtk","special")},
      {"SPD",partyStat(mon,"specialDefense","spDef","special")},
    }
    local statY=ly+lh-15
    local innerX,innerW=lx+6,lw-12
    local colW=innerW/5
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.74,0.72,0.64,1); G.rectangle("fill",lx+7,statY-1,lw-14,1)
    G.pop()
    for i,st in ipairs(statDefs) do
      local cx=innerX+(i-1)*colW
      partyText(st[1],cx+(colW-partyTextWidth(st[1],1.7))/2,statY,1.7,{0.25,0.25,0.22,1})
      local value=tostring(st[2])
      partyText(value,cx+(colW-partyTextWidth(value,2.4))/2,statY+4,2.4,{0.06,0.06,0.06,1})
    end
  else
    partyText(mon and "EGG" or "NO POKéMON",lx+20,ly+45,4,{0.28,0.28,0.25,1})
  end

  -- Right list: keep compact Party-style rows.
  local list=box.list and box:list() or {}
  local first=(box.scroll or 0)+1
  for r=1,5 do
    local idx=first+r-1
    local yy=27+(r-1)*18
    local m=list[idx]
    local selected=idx==(box.index or 1)

    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    partySlotPanel(82,yy,71,16,selected)
    G.pop()

    if m then
      local def=pokemon[m.species]
      local name=m.nickname or m.name or (def and def.name) or m.species or "POKéMON"
      GoldCompat.panelText(name,88,yy+3,2.8,{0.06,0.06,0.06,1},"left",41)
      GoldCompat.panelText("Lv."..tostring(m.level or "?"),131,yy+3,2.35,
        {0.22,0.22,0.20,1},"right",16)
      local g=GoldCompat.genderSymbol(m)
      if g then pcall(GoldCompat.drawGenderIcon,ox+146*sc,oy+(yy+3)*sc,6,g) end
    elseif idx==#list+1 and not (box.phase=="insert") then
      GoldCompat.panelText("CANCEL",88,yy+3,2.8,{0.06,0.06,0.06,1})
    end
  end

  GoldCompat.panelText(box.prompt and box:prompt() or "Choose a POKéMON.",
    9,130,3.3,{0.98,0.98,0.96,1},"left",142)

  if box.phase=="submenu" then
    local labels={"MOVE","STATS","CANCEL"}
    local ix=box.submenuIndex or 1
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    partySlotPanel(109,87,44,36,true)
    for i=1,3 do
      if i==ix then
        G.setColor(0.10,0.10,0.09,1)
        roundedRect("fill",113,90+(i-1)*10,36,9,1)
      end
    end
    G.pop()
    for i,label in ipairs(labels) do
      GoldCompat.panelText(label,117,91+(i-1)*10,2.7,
        i==ix and {1,1,1,1} or {0.06,0.06,0.06,1})
    end
  end
end

local drawGoldBoxMenuLegacy=GoldCompat.drawGoldBoxMenu

function GoldCompat.drawGoldBoxBadges(box)
  local game=box.game
  if not game then return drawGoldBoxMenuLegacy(box) end
  local list=box.list and box:list() or {}
  local items={}
  for i,mon in ipairs(list) do
    local def=game.data and game.data.pokemon and game.data.pokemon[mon.species]
    items[i]={label=mon.nickname or mon.name or (def and def.name) or "POKéMON"}
  end
  items[#items+1]={label="CANCEL"}
  local selected=box.panelMon and box:panelMon() or (box.selected and box:selected())
  local title=box.title and box:title() or "POKéMON PC"
  local prompt=box.prompt and box:prompt() or "Choose a POKéMON."
  drawPCBadgeListFinal(game,{
    title=title,
    items=items,
    index=box.index or 1,
    blink=box.blink or 0,
    __colosseumPcSource=list,
    __colosseumPcSelected=selected,
    __colosseumPcFooter=prompt,
    __colosseumPcMode=box.mode,
  })

  if box.phase=="submenu" then
    local ox,oy,sc=finalCanvas()
    local G=love.graphics
    local labels={"MOVE","STATS","CANCEL"}
    local ix=box.submenuIndex or 1
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    drawPCGlassPanel(111,89,43,35,false)
    for i=1,3 do
      if i==ix then
        drawColosseumRunoffSelection(113,92+(i-1)*10,38,9)
      end
    end
    G.pop()
    for i,label in ipairs(labels) do
      finalText(label,118,94+(i-1)*10,2.4,
        i==ix and {1,1,1,1} or {0.73,0.90,0.91,1},ox,oy,sc)
    end
  end
end

GoldCompat.drawGoldBoxMenu=GoldCompat.drawGoldBoxBadges

function GoldCompat.drawGoldItemPc(pc,winW,winH)
  -- Gold's ItemPcMenu keeps all transfer logic, quantity state, confirmation,
  -- mailbox/decor callbacks, and Pack chooser ownership. Only the display is
  -- unified with the Pokémon PC: BAG inventory on the left, PC item badges on
  -- the right, and the native phase/state highlighted in place.
  drawPCItemStorageFinal(pc.game,pc,false)
  if pc.qtyState then
    drawPCItemQuantityOverlay(pc.qtyState)
  elseif pc.confirm then
    drawPCItemChoiceOverlay(pc.confirm)
  end
end

function GoldCompat.installGoldServiceUI()
  if GoldCompat.generation~="gen2" or GoldCompat.serviceUiInstalled then return end

  local okPack,PackMenu=pcall(require,"src.ui.gen2.PackMenu")
  if okPack and type(PackMenu)=="table" and not PackMenu.__gen3uiVisualPatched then
    PackMenu.__gen3uiVisualPatched=true
    PackMenu.__gen3uiOriginalOpaque=PackMenu.isOpaque
    PackMenu.__gen3uiOriginalNew=PackMenu.new
    PackMenu.__gen3uiOriginalUpdate=PackMenu.update
    PackMenu.__gen3uiOriginalDraw=PackMenu.draw
    PackMenu.__gen3uiOriginalDrawWidescreen=PackMenu.drawWidescreen
    PackMenu.__gen3uiOriginalDrawsWidescreen=PackMenu.drawsWidescreen
    PackMenu.__gen3uiOriginalWantsFillScale=PackMenu.wantsFillScale
    PackMenu.isOpaque=false
    PackMenu.wantsFillScale=function(self,...)
      if GoldCompat.bagPresentationEnabled() then return false end
      return callOriginal(PackMenu.__gen3uiOriginalWantsFillScale,self,...)
    end
    PackMenu.drawsWidescreen=function(self,...)
      if GoldCompat.bagPresentationEnabled() then return false end
      return callOriginal(PackMenu.__gen3uiOriginalDrawsWidescreen,self,...)
    end
    PackMenu.new=function(...)
      local self=PackMenu.__gen3uiOriginalNew(...)
      if GoldCompat.bagPresentationEnabled() then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pack"
      else
        self.isOpaque=PackMenu.__gen3uiOriginalOpaque
        self.__gen3uiGoldOverlayKind=nil
      end
      return self
    end
    if type(PackMenu.__gen3uiOriginalUpdate)=="function" then
      PackMenu.update=function(self,dt,...)
        if GoldCompat.bagPresentationEnabled()
            and GoldCompat.remapHorizontalConfirmInput(self) then
          return
        end
        return callOriginal(PackMenu.__gen3uiOriginalUpdate,self,dt,...)
      end
    end
    PackMenu.draw=function(self,...)
      if GoldCompat.bagPresentationEnabled() then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pack"
        return
      end
      self.isOpaque=PackMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PackMenu.__gen3uiOriginalDraw,self,...)
    end
    PackMenu.drawWidescreen=function(self,winW,winH,...)
      if GoldCompat.bagPresentationEnabled() then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pack"
        return
      end
      self.isOpaque=PackMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PackMenu.__gen3uiOriginalDrawWidescreen,
        self,winW,winH,...)
    end
  end

  local okMart,MartMenu=pcall(require,"src.ui.gen2.MartMenu")
  if okMart and type(MartMenu)=="table" and not MartMenu.__gen3uiVisualPatched then
    MartMenu.__gen3uiVisualPatched=true
    MartMenu.__gen3uiOriginalOpaque=MartMenu.isOpaque
    MartMenu.__gen3uiOriginalNew=MartMenu.new
    MartMenu.__gen3uiOriginalUpdate=MartMenu.update
    MartMenu.__gen3uiOriginalDraw=MartMenu.draw
    MartMenu.__gen3uiOriginalDrawWidescreen=MartMenu.drawWidescreen
    MartMenu.__gen3uiOriginalDrawsWidescreen=MartMenu.drawsWidescreen
    MartMenu.__gen3uiOriginalWantsFillScale=MartMenu.wantsFillScale
    MartMenu.isOpaque=false
    MartMenu.wantsFillScale=function(self,...)
      if goldScreenEnabled("revampedPokeMartUI") then return false end
      return callOriginal(MartMenu.__gen3uiOriginalWantsFillScale,self,...)
    end
    MartMenu.drawsWidescreen=function(self,...)
      if goldScreenEnabled("revampedPokeMartUI") then return false end
      return callOriginal(MartMenu.__gen3uiOriginalDrawsWidescreen,self,...)
    end
    MartMenu.new=function(...)
      local self=MartMenu.__gen3uiOriginalNew(...)
      if goldScreenEnabled("revampedPokeMartUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="mart"
      else
        self.isOpaque=MartMenu.__gen3uiOriginalOpaque
        self.__gen3uiGoldOverlayKind=nil
      end
      return self
    end
    if type(MartMenu.__gen3uiOriginalUpdate)=="function" then
      MartMenu.update=function(self,dt,...)
        if goldScreenEnabled("revampedPokeMartUI")
            and GoldCompat.remapHorizontalConfirmInput(self) then
          return
        end
        return callOriginal(MartMenu.__gen3uiOriginalUpdate,self,dt,...)
      end
    end
    MartMenu.draw=function(self,...)
      if goldScreenEnabled("revampedPokeMartUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="mart"
        return
      end
      self.isOpaque=MartMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(MartMenu.__gen3uiOriginalDraw,self,...)
    end
    MartMenu.drawWidescreen=function(self,winW,winH,...)
      if goldScreenEnabled("revampedPokeMartUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="mart"
        return
      end
      self.isOpaque=MartMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(MartMenu.__gen3uiOriginalDrawWidescreen,
        self,winW,winH,...)
    end
  end

  local okCenter,CenterPcMenu=pcall(require,"src.ui.gen2.CenterPcMenu")
  if okCenter and type(CenterPcMenu)=="table"
      and not CenterPcMenu.__gen3uiVisualPatched then
    CenterPcMenu.__gen3uiVisualPatched=true
    CenterPcMenu.__gen3uiOriginalOpaque=CenterPcMenu.isOpaque
    CenterPcMenu.__gen3uiOriginalNew=CenterPcMenu.new
    CenterPcMenu.__gen3uiOriginalUpdate=CenterPcMenu.update
    CenterPcMenu.__gen3uiOriginalDraw=CenterPcMenu.draw
    CenterPcMenu.__gen3uiOriginalDrawWidescreen=CenterPcMenu.drawWidescreen
    CenterPcMenu.__gen3uiOriginalDrawsWidescreen=CenterPcMenu.drawsWidescreen
    CenterPcMenu.__gen3uiOriginalWantsFillScale=CenterPcMenu.wantsFillScale
    CenterPcMenu.isOpaque=false
    CenterPcMenu.wantsFillScale=function(self,...)
      if goldScreenEnabled("revampedPokemonPC") then return false end
      return callOriginal(CenterPcMenu.__gen3uiOriginalWantsFillScale,self,...)
    end
    CenterPcMenu.drawsWidescreen=function(self,...)
      if goldScreenEnabled("revampedPokemonPC") then return false end
      return callOriginal(CenterPcMenu.__gen3uiOriginalDrawsWidescreen,self,...)
    end
    CenterPcMenu.new=function(...)
      local self=CenterPcMenu.__gen3uiOriginalNew(...)
      if goldScreenEnabled("revampedPokemonPC") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="centerpc"
      else
        self.isOpaque=CenterPcMenu.__gen3uiOriginalOpaque
        self.__gen3uiGoldOverlayKind=nil
      end
      return self
    end
    if type(CenterPcMenu.__gen3uiOriginalUpdate)=="function" then
      CenterPcMenu.update=function(self,dt,...)
        if goldScreenEnabled("revampedPokemonPC") then
          self.isOpaque=false
          self.__gen3uiGoldOverlayKind="centerpc"
        end
        if goldScreenEnabled("revampedPokemonPC") and self.confirm then
          local input=self.game and self.game.input
          local previous=math.max(1,math.min(2,
            tonumber(self.confirm.choice) or 1))
          local nextChoice=previous
          if input and (input:wasPressed("left") or input:wasPressed("up")) then
            nextChoice=math.max(1,previous-1)
          elseif input and (input:wasPressed("right") or input:wasPressed("down")) then
            nextChoice=math.min(2,previous+1)
          end
          if nextChoice~=previous then
            self.confirm.choice=nextChoice
            pcall(function()
              require("src.core.Sound").play(self.game.data,"Press_AB")
            end)
            return
          end
        elseif goldScreenEnabled("revampedPokemonPC") and not self.message
            and GoldCompat.remapVerticalListInput(self,self.entries,"index") then
          return
        end
        return callOriginal(CenterPcMenu.__gen3uiOriginalUpdate,self,dt,...)
      end
    end
    CenterPcMenu.draw=function(self,...)
      if goldScreenEnabled("revampedPokemonPC") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="centerpc"
        return
      end
      self.isOpaque=CenterPcMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(CenterPcMenu.__gen3uiOriginalDraw,self,...)
    end
    CenterPcMenu.drawWidescreen=function(self,winW,winH,...)
      if goldScreenEnabled("revampedPokemonPC") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="centerpc"
        return
      end
      self.isOpaque=CenterPcMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(CenterPcMenu.__gen3uiOriginalDrawWidescreen,
        self,winW,winH,...)
    end
  end

  local okPc,PcMenu=pcall(require,"src.ui.gen2.PcMenu")
  if okPc and type(PcMenu)=="table" and not PcMenu.__gen3uiVisualPatched then
    PcMenu.__gen3uiVisualPatched=true
    PcMenu.__gen3uiOriginalOpaque=PcMenu.isOpaque
    PcMenu.__gen3uiOriginalNew=PcMenu.new
    PcMenu.isOpaque=false
    PcMenu.__gen3uiOriginalUpdate=PcMenu.update
    PcMenu.__gen3uiOriginalDraw=PcMenu.draw
    PcMenu.__gen3uiOriginalDrawWidescreen=PcMenu.drawWidescreen
    PcMenu.__gen3uiOriginalDrawsWidescreen=PcMenu.drawsWidescreen
    PcMenu.__gen3uiOriginalWantsFillScale=PcMenu.wantsFillScale
    PcMenu.drawsWidescreen=function(self)
      if goldScreenEnabled("revampedPokemonPC") then return false end
      return callOriginal(PcMenu.__gen3uiOriginalDrawsWidescreen,self)
    end
    PcMenu.wantsFillScale=function(self)
      if goldScreenEnabled("revampedPokemonPC") then return false end
      return callOriginal(PcMenu.__gen3uiOriginalWantsFillScale,self)
    end
    if type(PcMenu.__gen3uiOriginalNew)=="function" then
      PcMenu.new=function(...)
        local self=PcMenu.__gen3uiOriginalNew(...)
        if type(self)=="table" then
          local enabled=goldScreenEnabled("revampedPokemonPC")
          self.isOpaque=enabled and false or PcMenu.__gen3uiOriginalOpaque
          self.__gen3uiGoldOverlayKind=enabled and "pc-root" or nil
        end
        return self
      end
    end
    if type(PcMenu.__gen3uiOriginalUpdate)=="function" then
      PcMenu.update=function(self,dt,...)
        if goldScreenEnabled("revampedPokemonPC") then
          self.isOpaque=false
          self.__gen3uiGoldOverlayKind="pc-root"
        end
        if goldScreenEnabled("revampedPokemonPC") and not self.message then
          local count=self.picking and 14 or (self.entries or {})
          local key=self.picking and "pickIndex" or "index"
          if GoldCompat.remapVerticalListInput(self,count,key) then return end
        end
        return callOriginal(PcMenu.__gen3uiOriginalUpdate,self,dt,...)
      end
    end
    PcMenu.draw=function(self,...)
      if goldScreenEnabled("revampedPokemonPC") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pc-root"
        return
      end
      self.isOpaque=PcMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PcMenu.__gen3uiOriginalDraw,self,...)
    end
    PcMenu.drawWidescreen=function(self,winW,winH)
      if goldScreenEnabled("revampedPokemonPC") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pc-root"
        return
      end
      self.isOpaque=PcMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PcMenu.__gen3uiOriginalDrawWidescreen,self,winW,winH)
    end
  end

  local okBox,BoxMenu=pcall(require,"src.ui.gen2.BoxMenu")
  if okBox and type(BoxMenu)=="table" and not BoxMenu.__gen3uiVisualPatched then
    BoxMenu.__gen3uiVisualPatched=true
    BoxMenu.__gen3uiOriginalOpaque=BoxMenu.isOpaque
    BoxMenu.__gen3uiOriginalNew=BoxMenu.new
    BoxMenu.isOpaque=false
    BoxMenu.__gen3uiOriginalUpdate=BoxMenu.update
    BoxMenu.__gen3uiOriginalDraw=BoxMenu.draw
    BoxMenu.__gen3uiOriginalDrawWidescreen=BoxMenu.drawWidescreen
    BoxMenu.__gen3uiOriginalDrawsWidescreen=BoxMenu.drawsWidescreen
    BoxMenu.__gen3uiOriginalWantsFillScale=BoxMenu.wantsFillScale
    BoxMenu.drawsWidescreen=function(self)
      if goldScreenEnabled("revampedPokemonPC") then return false end
      return callOriginal(BoxMenu.__gen3uiOriginalDrawsWidescreen,self)
    end
    BoxMenu.wantsFillScale=function(self)
      if goldScreenEnabled("revampedPokemonPC") then return false end
      return callOriginal(BoxMenu.__gen3uiOriginalWantsFillScale,self)
    end
    if type(BoxMenu.__gen3uiOriginalNew)=="function" then
      BoxMenu.new=function(...)
        local self=BoxMenu.__gen3uiOriginalNew(...)
        if type(self)=="table" then
          local enabled=goldScreenEnabled("revampedPokemonPC")
          self.isOpaque=enabled and false or BoxMenu.__gen3uiOriginalOpaque
          self.__gen3uiGoldOverlayKind=enabled and "pc-box" or nil
        end
        return self
      end
    end
    if type(BoxMenu.__gen3uiOriginalUpdate)=="function" then
      BoxMenu.update=function(self,dt,...)
        if goldScreenEnabled("revampedPokemonPC") then
          self.isOpaque=false
          self.__gen3uiGoldOverlayKind="pc-box"
        end
        if goldScreenEnabled("revampedPokemonPC") and self.phase~="submenu" then
          local input=self.game and self.game.input
          local left=input and input:wasPressed("left")
          local right=input and input:wasPressed("right")
          local up=input and input:wasPressed("up")
          local down=input and input:wasPressed("down")
          if left or right or up or down then
            local list=self.list and self:list() or {}
            local gridCount=#list
            local cancelIndex=gridCount+1
            local index=math.max(1,math.min(tonumber(self.index) or 1,cancelIndex))
            local nextIndex=index
            local mode=tostring(self.mode or ""):lower()
            local verticalParty=(mode=="deposit")
            if not verticalParty and type(self.isParty)=="function" then
              local ok,isParty=pcall(self.isParty,self)
              verticalParty=ok and isParty==true
            end
            if verticalParty then
              -- This view is a vertical party list, so its input follows the
              -- records on screen. LEFT/RIGHT are retained as equivalent
              -- aliases for d-pads exposed as controller hat axes.
              if up or left then
                nextIndex=(index>1) and (index-1) or cancelIndex
              elseif down or right then
                nextIndex=(index<cancelIndex) and (index+1) or 1
              end
              if nextIndex<=gridCount then
                self.__colosseumPcLastBadge=nextIndex
              end
            elseif index==cancelIndex then
              if up then nextIndex=self.__colosseumPcLastBadge or math.max(1,gridCount-3) end
            else
              self.__colosseumPcLastBadge=index
              local col=(index-1)%4
              if left and col>0 then
                nextIndex=index-1
              elseif right and col<3 and index<gridCount then
                nextIndex=index+1
              elseif up and index>4 then
                nextIndex=index-4
              elseif down then
                if index+4<=gridCount then
                  nextIndex=index+4
                else
                  self.__colosseumPcLastBadge=index
                  nextIndex=cancelIndex
                end
              end
            end
            if nextIndex~=index then
              self.index=nextIndex
              self.scroll=0
              pcall(function()
                require("src.core.Sound").play(self.game.data,"Press_AB")
              end)
            end
            return
          end
        end
        return callOriginal(BoxMenu.__gen3uiOriginalUpdate,self,dt,...)
      end
    end
    BoxMenu.draw=function(self,...)
      if goldScreenEnabled("revampedPokemonPC") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pc-box"
        return
      end
      self.isOpaque=BoxMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(BoxMenu.__gen3uiOriginalDraw,self,...)
    end
    BoxMenu.drawWidescreen=function(self,winW,winH)
      if goldScreenEnabled("revampedPokemonPC") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pc-box"
        return
      end
      self.isOpaque=BoxMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(BoxMenu.__gen3uiOriginalDrawWidescreen,self,winW,winH)
    end
  end

  local okItem,ItemPcMenu=pcall(require,"src.ui.gen2.ItemPcMenu")
  if okItem and type(ItemPcMenu)=="table" and not ItemPcMenu.__gen3uiVisualPatched then
    ItemPcMenu.__gen3uiVisualPatched=true
    ItemPcMenu.__gen3uiOriginalOpaque=ItemPcMenu.isOpaque
    ItemPcMenu.__gen3uiOriginalNew=ItemPcMenu.new
    ItemPcMenu.isOpaque=false
    ItemPcMenu.__gen3uiOriginalUpdate=ItemPcMenu.update
    ItemPcMenu.__gen3uiOriginalDraw=ItemPcMenu.draw
    ItemPcMenu.__gen3uiOriginalDrawWidescreen=ItemPcMenu.drawWidescreen
    ItemPcMenu.__gen3uiOriginalDrawsWidescreen=ItemPcMenu.drawsWidescreen
    ItemPcMenu.__gen3uiOriginalWantsFillScale=ItemPcMenu.wantsFillScale
    ItemPcMenu.drawsWidescreen=function(self)
      if GoldCompat.itemPcPresentationEnabled() then return false end
      return callOriginal(ItemPcMenu.__gen3uiOriginalDrawsWidescreen,self)
    end
    ItemPcMenu.wantsFillScale=function(self)
      if GoldCompat.itemPcPresentationEnabled() then return false end
      return callOriginal(ItemPcMenu.__gen3uiOriginalWantsFillScale,self)
    end
    if type(ItemPcMenu.__gen3uiOriginalNew)=="function" then
      ItemPcMenu.new=function(...)
        local self=ItemPcMenu.__gen3uiOriginalNew(...)
        if type(self)=="table" then
          local enabled=GoldCompat.itemPcPresentationEnabled()
          self.isOpaque=enabled and false or ItemPcMenu.__gen3uiOriginalOpaque
          self.__gen3uiGoldOverlayKind=enabled and "pc-item" or nil
        end
        return self
      end
    end
    if type(ItemPcMenu.__gen3uiOriginalUpdate)=="function" then
      ItemPcMenu.update=function(self,dt,...)
        if GoldCompat.itemPcPresentationEnabled() then
          self.isOpaque=false
          self.__gen3uiGoldOverlayKind="pc-item"
        end
        if GoldCompat.itemPcPresentationEnabled()
            and self.phase=="menu" and not self.message
            and not self.qtyState and not self.confirm then
          local input=self.game and self.game.input
          local left=input and input:wasPressed("left")
          local right=input and input:wasPressed("right")
          if left or right then
            local count=#(self.entries or {})
            if count>0 then
              local previous=math.max(1,math.min(count,tonumber(self.index) or 1))
              if left then
                self.index=(previous>1) and previous-1 or count
              else
                self.index=(previous<count) and previous+1 or 1
              end
            end
            return
          end
        end
        return callOriginal(ItemPcMenu.__gen3uiOriginalUpdate,self,dt,...)
      end
    end
    ItemPcMenu.draw=function(self,...)
      if GoldCompat.itemPcPresentationEnabled() then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pc-item"
        return
      end
      self.isOpaque=ItemPcMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(ItemPcMenu.__gen3uiOriginalDraw,self,...)
    end
    ItemPcMenu.drawWidescreen=function(self,winW,winH)
      if GoldCompat.itemPcPresentationEnabled() then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pc-item"
        return
      end
      self.isOpaque=ItemPcMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(ItemPcMenu.__gen3uiOriginalDrawWidescreen,self,winW,winH)
    end
  end

  GoldCompat.serviceUiInstalled=true
end


function GoldCompat.countTruthy(t)
  local n=0
  for _,v in pairs(t or {}) do if v then n=n+1 end end
  return n
end

function GoldCompat.drawGoldSave(saveMenu)
  local Save2=require("src.core.gen2.Save")
  local summary=Save2.summary and Save2.summary(saveMenu.save) or nil
  local promptLines=saveMenu.prompt and saveMenu:prompt() or nil
  local prompt=type(promptLines)=="table" and table.concat(promptLines," ")
    or "Would you like to save your progress?"
  prompt=prompt:gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","")
  local choice=(saveMenu.phase=="confirm" or saveMenu.phase=="overwrite")
    and (saveMenu.choice or 1) or nil
  return GoldCompat.drawColosseumSavePanel(saveMenu.game,saveMenu.save,
    choice,summary,prompt~="" and prompt or nil)
end

function GoldCompat.goldOptionValue(menu,row)
  if row.frame then return "TYPE "..tostring(menu.options.frame or 1) end
  if row.text then
    local ok,v=pcall(row.text,menu.options)
    if ok then return tostring(v) end
  end
  if row.values then
    local v=menu.options[row.key]
    return tostring((row.display and row.display[v]) or v or "")
  end
  if type(row.value)=="function" then
    local ok,v=pcall(row.value,menu.game)
    if ok then return tostring(v) end
  end
  return ""
end

function GoldCompat.trainerPortraitShader()
  if GoldCompat.__trainerPortraitShader~=nil then
    return GoldCompat.__trainerPortraitShader or nil
  end
  local ok,shader=pcall(love.graphics.newShader,[[
    vec4 effect(vec4 color, Image tex, vec2 tc, vec2 sc) {
      vec4 px=Texel(tex,tc)*color;
      if (px.r>0.965 && px.g>0.965 && px.b>0.965) px.a=0.0;
      if (px.b>0.80 && px.b>px.r*1.35 && px.b>px.g*1.25) px.a=0.0;
      return px;
    }
  ]])
  GoldCompat.__trainerPortraitShader=ok and shader or false
  return GoldCompat.__trainerPortraitShader or nil
end

function GoldCompat.trainerOwnedCount(save)
  local n=#(save.party or {})
  for _,box in pairs(save.boxes or {}) do
    if type(box)=="table" then n=n+#box end
  end
  return n
end

function GoldCompat.drawNativeTrainerCanvas(card,forcedPage)
  local G=love.graphics
  local canvasKey=forcedPage and ("page"..tostring(forcedPage)) or "current"
  card.__gen3uiNativeCanvases=card.__gen3uiNativeCanvases or {}
  if not card.__gen3uiNativeCanvases[canvasKey] then
    local ok,c=pcall(G.newCanvas,160,144)
    if ok then
      card.__gen3uiNativeCanvases[canvasKey]=c
      if c.setFilter then pcall(c.setFilter,c,"nearest","nearest") end
    end
  end
  local canvas=card.__gen3uiNativeCanvases[canvasKey]
  if not canvas then return nil end

  local old=G.getCanvas()
  G.push("all")
  G.setCanvas(canvas)
  G.clear(1,1,1,1)
  G.origin()
  local Trainer=require("src.ui.gen2.TrainerCard")
  local savedPage=card.page
  if forcedPage then card.page=forcedPage end
  if Trainer.__gen3uiOriginalDrawPanel then
    pcall(Trainer.__gen3uiOriginalDrawPanel,card)
  end
  card.page=savedPage
  G.setCanvas(old)
  G.pop()
  return canvas
end

function GoldCompat.drawGoldUISettings(state)
  local rows=state.rows or {}
  local count=#rows
  if count<=0 then return end

  local index=math.max(1,math.min(count,state.index or 1))
  local visible=math.min(7,count)
  local first=math.max(1,(state.scroll or 0)+1)

  if index<first then first=index end
  if index>first+visible-1 then first=index-visible+1 end
  first=math.max(1,math.min(first,math.max(1,count-visible+1)))

  -- Deliberately self-contained: this renderer only uses helpers that already
  -- called a later local helper (gen1HangingFrame), which is not in lexical
  -- scope here and can resolve to nil at runtime.
  local G=love.graphics
  local ox,oy,sc=finalCanvas()

  local rowH=12
  local w=112
  local h=24+visible*rowH+11
  local x=44
  local y=math.max(4,math.floor((144-h)/2))

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)

  G.setColor(0.01,0.02,0.03,0.34)
  roundedRect("fill",x+2,y+3,w,h,6)
  G.setColor(0.025,0.09,0.12,0.84)
  roundedRect("fill",x,y,w,h,6)
  G.setColor(0.04,0.16,0.20,0.74)
  roundedRect("fill",x+2,y+2,w-4,h-4,5)
  G.setColor(0.39,0.69,0.70,0.96)
  G.setLineWidth(1.4)
  roundedRect("line",x,y,w,h,6)

  G.setColor(0.07,0.25,0.31,0.90)
  roundedRect("fill",x+4,y+4,w-8,12,3)

  -- Selected row.
  for r=1,visible do
    local idx=first+r-1
    if idx<=count then
      local yy=y+20+(r-1)*rowH
      if idx==index then
        G.setColor(0.11,0.28,0.38,1)
        roundedRect("fill",x+4,yy-1,w-8,rowH-1,2)
        G.setColor(1.00,0.36,0.16,1)
        G.rectangle("fill",x+4,yy-1,1.5,rowH-1)
      end
    end
  end
  G.pop()

  finalText("COLOSSEUM UI",x+8,y+6,4.2,{0.95,1.00,0.98,1},ox,oy,sc)

  for r=1,visible do
    local idx=first+r-1
    local row=rows[idx]
    if row then
      local yy=y+20+(r-1)*rowH
      local selected=idx==index
      local label=tostring(row.label or row.name or "")
      local value=DexUI.optionDisplay(row)

      finalTextFitted(label,x+8,yy+1,2.85,1.75,
        selected and {1,1,1,1} or {0.84,0.94,0.92,1},
        ox,oy,sc,"left",49,rowH-2)

      if value and tostring(value)~="" then
        finalTextFitted(tostring(value),x+59,yy+1,2.65,1.55,
          selected and {1,1,1,1} or {0.49,0.78,0.80,1},
          ox,oy,sc,"right",45,rowH-2)
      end
    end
  end

  if first>1 then
    finalText("▲",x+w-10,y+18,2.2,
      {0.32,0.32,0.29,1},ox,oy,sc)
  end
  if first+visible-1<count then
    finalText("▼",x+w-10,y+h-12,2.2,
      {0.32,0.32,0.29,1},ox,oy,sc)
  end

  finalText("A: CHANGE   B: BACK",x+8,y+h-6,2.15,
    {0.62,0.82,0.82,1},ox,oy,sc)
end


screenFeatureEnabled=function(key)
  return featureEnabled(key)
end

goldScreenEnabled=function(key)
  return GoldCompat.generation=="gen2" and screenFeatureEnabled(key)
end

callOriginal=function(method,self,...)
  if type(method)=="function" then
    return method(self,...)
  end
end


local function gen1HangingFrame(x,y,w,h,title)
  local g=love.graphics
  local ox,oy,sc=finalCanvas()
  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.01,0.02,0.03,0.34)
  roundedRect("fill",x+2,y+3,w,h,6)
  g.setColor(0.025,0.09,0.12,0.84)
  roundedRect("fill",x,y,w,h,6)
  g.setColor(0.04,0.16,0.20,0.74)
  roundedRect("fill",x+2,y+2,w-4,h-4,5)
  g.setColor(0.39,0.69,0.70,0.96)
  g.setLineWidth(1.4)
  roundedRect("line",x,y,w,h,6)

  g.setColor(0.07,0.25,0.31,0.90)
  roundedRect("fill",x+4,y+4,w-8,12,3)
  g.pop()

  finalText(title,x+8,y+6,4.3,{0.95,1.00,0.98,1},ox,oy,sc)
  return ox,oy,sc
end

function GoldCompat.gen1ManagerRows(manager)
  if manager.screen=="options" then
    return manager.optionRows or {}
  end
  if type(manager.rowsForScreen)=="function" then
    local ok,rows=pcall(manager.rowsForScreen,manager)
    if ok and type(rows)=="table" then return rows end
  end
  return manager.mods or {}
end

function GoldCompat.drawGen1OptionsHanging(menu)
  local rows=menu.rows or {}
  local total=#rows+1
  local index=math.max(1,math.min(total,menu.index or 1))
  local visible=math.min(7,total)
  local first=math.max(1,math.min(index-2,math.max(1,total-visible+1)))

  local rowH=12
  local w=108
  local h=22+visible*rowH+10
  local x=48
  local y=math.max(4,math.floor((144-h)/2))
  local ox,oy,sc=gen1HangingFrame(x,y,w,h,"OPTIONS")
  local g=love.graphics

  for r=1,visible do
    local idx=first+r-1
    if idx<=total then
      local row=rows[idx]
      local isCancel=idx==total
      local yy=y+19+(r-1)*rowH
      local selected=idx==index

      if selected then
        g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
        g.setColor(0.11,0.28,0.38,1)
        roundedRect("fill",x+4,yy-1,w-8,rowH-1,2)
        g.setColor(1.00,0.36,0.16,1)
        g.rectangle("fill",x+4,yy-1,1.5,rowH-1)
        g.pop()
      end

      local label=isCancel and "CANCEL" or tostring(row and row.label or "")
      local value=""
      if row then value=tostring(GoldCompat.goldOptionValue(menu,row) or "") end

      -- Full labels: give the label column most of the card instead of
      -- truncating it to ten 8px glyphs.
      finalTextFitted(label,x+8,yy+1,3.0,1.75,
        selected and {1,1,1,1} or {0.84,0.94,0.92,1},
        ox,oy,sc,"left",49,rowH-2)
      if value~="" then
        finalTextFitted(value,x+59,yy+1,2.85,1.55,
          selected and {1,1,1,1} or {0.49,0.78,0.80,1},
          ox,oy,sc,"right",45,rowH-2)
      end
    end
  end

  finalText("LEFT / RIGHT: CHANGE   A: SELECT   B: BACK",
    x+7,y+h-6,2.15,{0.62,0.82,0.82,1},ox,oy,sc,"left",w-14)
end

function GoldCompat.drawGen1ModManagerHanging(manager)
  local rows=GoldCompat.gen1ManagerRows(manager)
  local cursor=math.max(1,manager.cursor or 1)
  local visible=math.min(7,math.max(1,#rows))
  local first

  if manager.screen=="options" then
    first=math.max(1,(manager.scroll or 0)+1)
  else
    first=math.max(1,manager.scroll or 1)
  end
  if cursor<first+1 then first=math.max(1,cursor-1) end
  if cursor>first+visible-2 then first=math.max(1,cursor-visible+2) end
  first=math.min(first,math.max(1,#rows-visible+1))

  local rowH=11
  local w=112
  local h=34+visible*rowH+12
  local x=44
  local y=math.max(4,math.floor((144-h)/2))
  local ox,oy,sc=gen1HangingFrame(x,y,w,h,
    tostring(manager.banner or "MOD MANAGER"))
  local g=love.graphics

  if manager.screen=="list" then
    local tabs={"MODS","PROFILES","ERRORS"}
    for i,label in ipairs(tabs) do
      local tx=x+6+(i-1)*34
      local selected=i==(manager.tab or 1)
      g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
      g.setColor(selected and 0.11 or 0.04,
                 selected and 0.28 or 0.14,
                 selected and 0.38 or 0.18,selected and 1 or 0.82)
      roundedRect("fill",tx,y+18,31,8,1.5)
      g.pop()
      finalText(label,tx,y+20,2.25,
        selected and {1,1,1,1} or {0.62,0.84,0.84,1},
        ox,oy,sc,"center",31)
    end
  else
    local subtitle=tostring(manager.screen or "MODS"):upper()
    finalText(subtitle,x+8,y+20,2.5,{0.57,0.83,0.84,1},ox,oy,sc)
  end

  local baseY=y+31
  for r=1,visible do
    local idx=first+r-1
    local row=rows[idx]
    if row then
      local yy=baseY+(r-1)*rowH
      local selected=idx==cursor and not (type(row)=="table" and row.header)

      if selected then
        g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
        g.setColor(0.11,0.28,0.38,1)
        roundedRect("fill",x+4,yy-1,w-8,rowH-1,2)
        g.setColor(1.00,0.36,0.16,1)
        g.rectangle("fill",x+4,yy-1,1.5,rowH-1)
        g.pop()
      end

      local label
      if type(row)=="string" then label=row
      elseif type(row)=="table" then
        label=row.label or row.name or row.id or row.key or row.title or ""
      else label=tostring(row) end

      finalTextFitted(tostring(label),x+8,yy+1,
        (type(row)=="table" and row.header) and 2.55 or 2.85,1.65,
        selected and {1,1,1,1}
          or ((type(row)=="table" and row.header)
              and {0.46,0.75,0.76,1} or {0.84,0.94,0.92,1}),
        ox,oy,sc,"left",55,rowH-2)

      if type(row)=="table" and (row.value~=nil or row.status~=nil
          or row.key~=nil) then
        local raw=row.value~=nil and row.value or row.status

        -- ManagerState option rows may expose a getter closure rather than a
        -- pre-rendered value. Resolve it instead of printing "function: 0x...".
        if type(raw)=="function" then
          local ok,v=pcall(raw,row,manager)
          if not ok then ok,v=pcall(raw,manager) end
          if not ok then ok,v=pcall(raw) end
          raw=ok and v or nil
        end

        -- Our own registered rows can always be resolved from the live option
        -- store, which also guarantees toggles render as ON/OFF.
        if row.key and OPTION_DEFAULTS[row.key]~=nil then
          raw=optionValue(row.key)
        end

        local value=""
        if type(raw)=="boolean" then
          value=raw and "ON" or "OFF"
        elseif raw~=nil and type(raw)~="function" then
          local display=row.key and TEXT_PROFILE_DISPLAY[tostring(raw)]
          value=tostring(display or raw):upper()
        end

        if value~="" then
          finalTextFitted(value,x+65,yy+1,2.55,1.45,
            selected and {1,1,1,1} or {0.49,0.78,0.80,1},
            ox,oy,sc,"right",40,rowH-2)
        end
      end
    end
  end

  if #rows==0 then
    finalText("No entries available.",x+9,y+55,2.9,
      {0.62,0.82,0.82,1},ox,oy,sc)
  end

  finalText("A: SELECT   B: BACK",x+8,y+h-6,2.25,
    {0.62,0.82,0.82,1},ox,oy,sc)
end

function GoldCompat.drawGen1TrainerCardHanging(card)
  local game=card and card.game
  local save=(card and (card.save or (game and game.save))) or nil
  if not save then return end

  local x,y,w,h=30,12,126,120
  local ox,oy,sc=gen1HangingFrame(x,y,w,h,"TRAINER CARD")
  local g=love.graphics

  -- Two compact cards, visually matching Party/START rather than the old
  -- native full-screen Trainer Card.
  g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
  g.setColor(0.12,0.12,0.11,1)
  roundedRect("fill",x+5,y+20,47,88,3)
  roundedRect("fill",x+56,y+20,65,88,3)
  g.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",x+7,y+22,43,84,2)
  roundedRect("fill",x+58,y+22,61,84,2)
  g.setColor(0.76,0.62,0.30,1)
  roundedRect("line",x+8,y+23,41,82,2)
  roundedRect("line",x+59,y+23,59,82,2)
  g.pop()

  -- Native portrait artwork, but no native card chrome.
  if card.pic then
    g.push("all")
    g.origin()
    g.setColor(1,1,1,1)
    local iw,ih=card.pic:getDimensions()
    local targetH=42*sc
    local scale=targetH/math.max(1,ih)
    local dw=iw*scale
    local dx=math.floor(ox+(x+28.5)*sc-dw/2)
    local dy=math.floor(oy+(y+28)*sc)
    g.draw(card.pic,dx,dy,0,scale,scale)
    if card.picTrueColor then
      pcall(function()
        require("src.render.PaletteFX").markTrueColor(dx,dy,dw,targetH)
      end)
    end
    g.pop()
  end

  local player=save.player or {}
  local caught=0
  for _ in pairs(save.pokedex and save.pokedex.owned or {}) do caught=caught+1 end
  local t=math.floor(save.playTime or 0)
  local badgeCount=0
  pcall(function()
    badgeCount=require("src.inventory.Badges").count(game.data,save)
  end)

  finalText(tostring(player.name or "RED"),x+11,y+72,4.0,
    {0.06,0.06,0.06,1},ox,oy,sc)
  finalText("TRAINER ID",x+11,y+82,2.4,
    {0.36,0.36,0.32,1},ox,oy,sc)
  finalText(("%05d"):format(tonumber(player.id) or 0),x+11,y+89,3.0,
    {0.06,0.06,0.06,1},ox,oy,sc)
  finalText("MONEY",x+11,y+98,2.4,
    {0.36,0.36,0.32,1},ox,oy,sc)
  finalText(("$%d"):format(tonumber(save.money) or 0),x+29,y+98,2.8,
    {0.06,0.06,0.06,1},ox,oy,sc,"right",16)

  local rx=x+63
  finalText("POKéDEX",rx,y+29,2.5,{0.36,0.36,0.32,1},ox,oy,sc)
  finalText(tostring(caught).." CAUGHT",rx,y+37,3.1,
    {0.06,0.06,0.06,1},ox,oy,sc)
  finalText("PLAY TIME",rx,y+49,2.5,{0.36,0.36,0.32,1},ox,oy,sc)
  finalText(("%d:%02d"):format(math.floor(t/3600),math.floor(t/60)%60),
    rx,y+57,3.1,{0.06,0.06,0.06,1},ox,oy,sc)
  finalText("BADGES",rx,y+69,2.5,{0.36,0.36,0.32,1},ox,oy,sc)
  finalText(tostring(badgeCount).." / 8",rx,y+77,3.1,
    {0.06,0.06,0.06,1},ox,oy,sc)

  local okBadges,Badges=pcall(require,"src.inventory.Badges")
  local defs=okBadges and game and Badges.list(game.data) or {}
  if card.badges and card.faces and okBadges then
    for i=1,math.min(8,#defs) do
      local col=(i-1)%4
      local row=math.floor((i-1)/4)
      local bx=x+62+col*13
      local by=y+84+row*10
      local owned=save.inventory and save.inventory[Badges.itemFor(defs[i])]
      local sheet=owned and card.badges or card.faces
      local q=sheet and sheet.quads and sheet.quads[i-1]
      if q then
        g.push("all"); g.origin()
        g.setColor(1,1,1,owned and 1 or 0.38)
        g.draw(sheet.img,q,
          math.floor(ox+bx*sc),math.floor(oy+by*sc),0,0.48*sc,0.48*sc)
        g.pop()
      end
    end
  end

  finalText("B: BACK",x+8,y+h-6,2.25,
    {0.32,0.32,0.29,1},ox,oy,sc)
end

-- Keep the Gen 1 level-up card as a dedicated battle overlay. It is not an
-- overworld hanging menu, but use the proven final-window font renderer rather
-- than native 8x8 EngineFont text.

function GoldCompat.drawGen2TrainerCardHanging(card)
  local save=card and card.save or {}
  local player=save.player or {}
  local page=card and card.page or 1

  local x,y,w,h=30,12,126,120
  local ox,oy,sc=gen1HangingFrame(x,y,w,h,
    page==1 and "TRAINER CARD"
      or (page==2 and "JOHTO BADGES" or "KANTO BADGES"))
  local g=love.graphics

  g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
  g.setColor(0.12,0.12,0.11,1)
  roundedRect("fill",x+5,y+20,47,88,3)
  roundedRect("fill",x+56,y+20,65,88,3)
  g.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",x+7,y+22,43,84,2)
  roundedRect("fill",x+58,y+22,61,84,2)
  g.setColor(0.76,0.62,0.30,1)
  roundedRect("line",x+8,y+23,41,82,2)
  roundedRect("line",x+59,y+23,59,82,2)
  g.pop()

  local canvas=GoldCompat.drawNativeTrainerCanvas(card)
  if canvas then
    g.push("all")
    g.origin()
    g.setColor(1,1,1,1)
    if page==1 then
      local q=g.newQuad(112,8,40,56,160,144)
      local shader=GoldCompat.trainerPortraitShader()
      if shader then g.setShader(shader) end
      g.draw(canvas,q,ox+(x+10)*sc,oy+(y+27)*sc,0,0.62*sc,0.62*sc)
      g.setShader()
    else
      local q=g.newQuad(8,76,144,64,160,144)
      g.draw(canvas,q,ox+(x+61)*sc,oy+(y+37)*sc,0,0.39*sc,0.39*sc)
    end
    g.pop()
  end

  if page==1 then
    finalText(tostring(player.name or "GOLD"),x+11,y+72,4.0,
      {0.06,0.06,0.06,1},ox,oy,sc)
    finalText("TRAINER ID",x+11,y+82,2.4,
      {0.36,0.36,0.32,1},ox,oy,sc)
    finalText(("%05d"):format(tonumber(player.id) or 0),x+11,y+89,3.0,
      {0.06,0.06,0.06,1},ox,oy,sc)
    finalText("MONEY",x+11,y+98,2.4,
      {0.36,0.36,0.32,1},ox,oy,sc)
    finalText(("¥%d"):format(tonumber(player.money) or 0),x+28,y+98,2.8,
      {0.06,0.06,0.06,1},ox,oy,sc,"right",17)

    local caught=card.caughtCount and card:caughtCount() or 0
    local seen=GoldCompat.countTruthy((save.pokedex or {}).seen)
    local t=save.playTime or {}
    local badges=GoldCompat.countTruthy(player.badges)
    local owned=GoldCompat.trainerOwnedCount(save)
    local trades=GoldCompat.countTruthy(save.tradeFlags)
    local league=(save.hallOfFame and tonumber(save.hallOfFame.count)) or 0
    local rx=x+63

    finalText("POKéDEX",rx,y+29,2.5,{0.36,0.36,0.32,1},ox,oy,sc)
    finalText(("%d SEEN / %d CAUGHT"):format(seen,caught),
      rx,y+37,2.6,{0.06,0.06,0.06,1},ox,oy,sc,"left",51)
    finalText("PLAY TIME",rx,y+49,2.5,{0.36,0.36,0.32,1},ox,oy,sc)
    finalText(("%d:%02d"):format(t.hours or 0,t.minutes or 0),
      rx,y+57,3.1,{0.06,0.06,0.06,1},ox,oy,sc)
    finalText("JOHTO BADGES",rx,y+69,2.4,{0.36,0.36,0.32,1},ox,oy,sc)
    finalText(("%d / 8"):format(badges),rx,y+77,3.1,
      {0.06,0.06,0.06,1},ox,oy,sc)
    -- Career stats get their own compact block with a safe bottom inset.
    -- The previous y+103 LEAGUE line sat directly on the inner card border.
    finalText("OWNED "..tostring(owned),rx,y+85,2.35,
      {0.28,0.28,0.25,1},ox,oy,sc)
    finalText("TRADES "..tostring(trades),rx,y+92,2.35,
      {0.28,0.28,0.25,1},ox,oy,sc)
    finalText("LEAGUE "..tostring(league),rx,y+99,2.35,
      {0.28,0.28,0.25,1},ox,oy,sc)
  else
    local ownedBadges=page==2 and (player.badges or {}) or (player.kantoBadges or {})
    local count=GoldCompat.countTruthy(ownedBadges)
    finalText(("%d / 8 EARNED"):format(count),x+64,y+29,3.0,
      {0.06,0.06,0.06,1},ox,oy,sc)
    finalText("LEFT / RIGHT: PAGE",x+64,y+103,2.3,
      {0.30,0.30,0.27,1},ox,oy,sc)
  end

  finalText("B: BACK",x+8,y+h-6,2.25,
    {0.32,0.32,0.29,1},ox,oy,sc)
end

-- Native Colosseum PDA trainer card. Engine page input remains authoritative;
-- this screen hierarchy is purpose-built and does not reuse the donor layout.
function GoldCompat.trainerMetric(root,...)
  for i=1,select("#",...) do
    local value=root
    for key in tostring(select(i,...)):gmatch("[^.]+") do
      value=type(value)=="table" and value[key] or nil
      if value==nil then break end
    end
    value=tonumber(value)
    if value then return math.max(0,math.floor(value)) end
  end
  return nil
end

function GoldCompat.trainerCareer(card,gen2)
  local game=card and card.game
  local save=(card and (card.save or (game and game.save))) or {}
  local player=save.player or {}
  local dex=save.pokedex or {}
  local ownedDex=dex.caught or dex.owned or {}
  local caught=gen2 and card and card.caughtCount and card:caughtCount()
    or GoldCompat.countTruthy(ownedDex)
  local badges=gen2 and GoldCompat.trainerBadgeCount(player.badges) or 0
  if not gen2 then
    pcall(function()
      badges=require("src.inventory.Badges").count(game.data,save)
    end)
  end
  save.colosseumUI=save.colosseumUI or {}
  save.colosseumUI.records=save.colosseumUI.records or {}
  local records=save.colosseumUI.records
  records.battlesWon=tonumber(records.battlesWon) or 0
  records.pokemonFainted=tonumber(records.pokemonFainted) or 0
  if records.trackedFrom==nil then
    local t=save.playTime
    records.trackedFrom=type(t)=="table"
      and ((tonumber(t.hours) or 0)*3600+(tonumber(t.minutes) or 0)*60)
      or (tonumber(t) or 0)
  end
  local fainted=GoldCompat.trainerMetric(save,
    "colosseumUI.records.pokemonFainted",
    "stats.pokemonFainted","battleStats.pokemonFainted",
    "records.pokemonFainted","player.pokemonFainted",
    "player.faints")
  local hall=save.hallOfFame
  local league=GoldCompat.trainerMetric(save,"hallOfFame.count",
    "stats.leagueClears","records.leagueClears","player.leagueClears",
    "colosseumUI.records.leagueClears")
  if league==nil and type(hall)=="table" and #hall>0 then league=#hall end
  return {
    save=save,player=player,caught=caught or 0,badges=badges,
    wins=GoldCompat.trainerMetric(save,"colosseumUI.records.battlesWon",
      "stats.battlesWon",
      "stats.battleWins","battleStats.wins","records.battlesWon",
      "player.battlesWon","player.battleWins"),
    fainted=fainted,
    league=league or 0,
    trackedFrom=records.trackedFrom,
  }
end

function GoldCompat.resolvedTrainerCardPic(card)
  if not card then return nil end
  if card.__colosseumResolvedPlayerPic~=nil then
    return card.__colosseumResolvedPlayerPic or nil
  end

  -- Resolve the active player-sprite package before considering TrainerCard's
  -- native card artwork. The latter can include its patterned card backdrop,
  -- which is what produced the boxed/pink portrait seen in Gold.
  local game=card.game
  local ok,img,trueColor=pcall(function()
    local Sprites=require("src.pokemon.Sprites")
    local Assets=require("src.render.Assets")
    local player=game and game.save and game.save.player or {}
    local path,isTrueColor=Sprites.playerPath(game.data,"front",{
      kind="trainer_card",gender=player.gender or player.sex,
    })
    local image=path and Assets.image(path) or nil
    if image and image.setFilter then pcall(image.setFilter,image,"nearest","nearest") end
    return image,isTrueColor and true or false
  end)
  if ok and img then
    card.__colosseumResolvedPlayerPic=img
    card.__colosseumResolvedPlayerPicTrueColor=trueColor
    return img
  end

  local direct=card.customPic or card.playerPic
  card.__colosseumResolvedPlayerPic=
    (direct and type(direct.getDimensions)=="function") and direct or false
  card.__colosseumResolvedPlayerPicTrueColor=card.picTrueColor==true
  return card.__colosseumResolvedPlayerPic or nil
end

function GoldCompat.goldTrainerPortraitShader()
  if GoldCompat.__goldTrainerPortraitShader~=nil then
    return GoldCompat.__goldTrainerPortraitShader or nil
  end
  local ok,shader=pcall(love.graphics.newShader,[[
    extern vec3 lightTone;
    extern vec3 midTone;
    extern vec3 darkTone;
    vec4 effect(vec4 color, Image tex, vec2 tc, vec2 sc) {
      vec4 px=Texel(tex,tc);
      // Gold's trainer-card sheet is four opaque grayscale shades. The white
      // shade doubles as the portrait matte, so discard it before palette
      // mapping instead of carrying the card's dotted backing into our UI.
      if (px.r>0.94) return vec4(0.0);
      vec3 mapped=px.r>0.50 ? lightTone : (px.r>0.17 ? midTone : darkTone);
      return vec4(mapped,px.a)*color;
    }
  ]])
  GoldCompat.__goldTrainerPortraitShader=ok and shader or false
  return GoldCompat.__goldTrainerPortraitShader or nil
end

function GoldCompat.drawGoldTrainerPortraitTiles(card,ox,oy,sc,x,y,w,h)
  local sheet=card and card.card
  local image=sheet and sheet.image and sheet:image()
  local shader=GoldCompat.goldTrainerPortraitShader()
  if not (image and shader and sheet.quad) then return false end

  local colors=card.palette and card:palette(1) or nil
  local okPalette,GbcPalette=pcall(require,"src.render.GbcPalette")
  local function tone(index,fallback)
    local value
    if okPalette and GbcPalette and type(GbcPalette.color)=="function" then
      local ok,v=pcall(GbcPalette.color,colors,index)
      if ok then value=v end
    end
    value=value or fallback
    local r,g,b=tonumber(value[1]) or 0,tonumber(value[2]) or 0,
      tonumber(value[3]) or 0
    if math.max(r,g,b)>1 then r,g,b=r/255,g/255,b/255 end
    return {r,g,b}
  end
  pcall(shader.send,shader,"lightTone",tone(2,{218,154,112}))
  pcall(shader.send,shader,"midTone",tone(3,{126,76,62}))
  pcall(shader.send,shader,"darkTone",tone(4,{15,20,18}))

  -- ChrisPic is the first 35 tiles in the trainer-card atlas, stored in a
  -- 16-tile-wide sheet but displayed as a five-by-seven portrait.
  local scale=math.min(w*0.94/40,h*0.94/56)*sc
  local dx=ox+(x+w*0.5)*sc-20*scale
  local dy=oy+(y+h*0.97)*sc-56*scale
  local G=love.graphics
  G.push("all"); G.origin(); G.setColor(1,1,1,1); G.setShader(shader)
  for index=0,34 do
    local quad=sheet:quad(index)
    if quad then
      local col=index%5
      local row=math.floor(index/5)
      G.draw(image,quad,dx+col*8*scale,dy+row*8*scale,0,scale,scale)
    end
  end
  G.setShader(); G.pop()
  return true
end

function GoldCompat.drawColosseumTrainerPortrait(card,gen2,ox,oy,sc,x,y,w,h)
  local G=love.graphics
  -- Prefer the portrait resolved by the active TrainerCard/player-sprite
  -- package. This lets custom player art override the ROM-native panel crop.
  local resolvedPic=GoldCompat.resolvedTrainerCardPic(card)
  if resolvedPic and type(resolvedPic.getDimensions)=="function" then
    local cleaned,meta=GoldCompat.prepareCleanResolvedPortrait(resolvedPic,{
      trueColor=card.__colosseumResolvedPlayerPicTrueColor==true,
    })
    resolvedPic=cleaned or resolvedPic
    G.push("all"); G.origin(); G.setColor(1,1,1,1)
    local iw,ih=resolvedPic:getDimensions()
    local x0,y0,x1,y1=0,0,iw-1,ih-1
    if meta and meta.x0 and meta.x1 and meta.y0 and meta.y1 then
      x0,y0,x1,y1=meta.x0,meta.y0,meta.x1,meta.y1
    end
    local vw,vh=math.max(1,x1-x0+1),math.max(1,y1-y0+1)
    local scale=math.min(w*0.94*sc/vw,h*0.94*sc/vh)
    local dx=ox+(x+w*0.5)*sc-(x0+x1+1)*0.5*scale
    local dy=oy+(y+h*0.97)*sc-(y1+1)*scale
    G.draw(resolvedPic,dx,dy,0,scale,scale)
    if card.__colosseumResolvedPlayerPicTrueColor then pcall(function()
      require("src.render.PaletteFX").markTrueColor(dx,dy,iw*scale,ih*scale)
    end) end
    G.pop()
  elseif gen2 then
    if GoldCompat.drawGoldTrainerPortraitTiles(card,ox,oy,sc,x,y,w,h) then
      return
    end
    local canvas=GoldCompat.drawNativeTrainerCanvas(card)
    if not canvas then return end
    G.push("all"); G.origin(); G.setColor(1,1,1,1)
    local q=G.newQuad(108,5,48,62,160,144)
    local shader=GoldCompat.trainerPortraitShader()
    if shader then G.setShader(shader) end
    G.draw(canvas,q,ox+x*sc,oy+y*sc,0,w*sc/48,h*sc/62)
    G.setShader(); G.pop()
  end
end

function GoldCompat.trainerBadgeOwned(set,index,name)
  if type(set)=="number" then
    return math.floor(set/(2^(index-1)))%2==1
  end
  if type(set)~="table" then return false end
  local key=tostring(name or "")
  local compact=key:lower():gsub("[^%w]","")
  local value=set[index] or set[key] or set[key:upper()] or set[key:lower()]
    or set[compact]
  return value~=nil and value~=false and value~=0
end

function GoldCompat.trainerBadgeCount(set)
  if type(set)=="number" then
    local count=0
    for i=1,16 do
      if math.floor(set/(2^(i-1)))%2==1 then count=count+1 end
    end
    return count
  end
  return type(set)=="table" and GoldCompat.countTruthy(set) or 0
end

function GoldCompat.drawTrainerBadgeMedal(cx,cy,r,owned,color)
  local G=love.graphics
  local c=color or {0.50,0.70,0.55}
  G.setColor(0.01,0.03,0.02,0.92)
  G.circle("fill",cx+1,cy+1,r+1)
  G.setColor(owned and {c[1],c[2],c[3],1} or {0.12,0.19,0.16,0.95})
  G.circle("fill",cx,cy,r)
  G.setColor(owned and {0.85,1.00,0.86,0.95} or {0.28,0.39,0.33,0.85})
  G.setLineWidth(1)
  G.circle("line",cx,cy,r)
  G.circle("line",cx,cy,math.max(1,r-2))
end

GoldCompat.GEN2_JOHTO_BADGE_OAM_ORDER=GoldCompat.GEN2_JOHTO_BADGE_OAM_ORDER or {
  "ZEPHYR","HIVE","PLAIN","FOG","MINERAL","STORM","GLACIER","RISING",
}
GoldCompat.GEN2_JOHTO_BADGE_DISPLAY=GoldCompat.GEN2_JOHTO_BADGE_DISPLAY or {
  "ZEPHYR","HIVE","PLAIN","FOG","STORM","MINERAL","GLACIER","RISING",
}
GoldCompat.GEN2_KANTO_BADGE_DISPLAY=GoldCompat.GEN2_KANTO_BADGE_DISPLAY or {
  "BOULDER","CASCADE","THUNDER","RAINBOW","SOUL","MARSH","VOLCANO","EARTH",
}

GoldCompat.__kantoBadgeRender=GoldCompat.__kantoBadgeRender or false
function GoldCompat.kantoBadgeRenderSheet()
  if GoldCompat.__kantoBadgeRender ~= false then
    return GoldCompat.__kantoBadgeRender or nil
  end
  GoldCompat.__kantoBadgeRender=nil
  local ok,img=pcall(love.graphics.newImage,
    Assets.resolve("assets/generated/trainer_card/badges.png"))
  if ok and img then
    if img.setFilter then pcall(img.setFilter,img,"nearest","nearest") end
    GoldCompat.__kantoBadgeRender=img
  end
  return GoldCompat.__kantoBadgeRender
end

-- Draw one of Gold's eight real Johto badge sprites into an arbitrary monitor
-- slot.  The source sheet contains animation frames/OAM, so map the displayed
-- gym order back to the cart's OAM order rather than cropping leader faces.
function GoldCompat.drawJohtoBadgeRender(card,name,x,y,size,owned)
  local list=card and card.gfx and card.gfx.badgeOam
  local sheet=card and card.badges
  if not (list and sheet and sheet.available and sheet:available()) then return false end
  local obj
  for i,badgeName in ipairs(GoldCompat.GEN2_JOHTO_BADGE_OAM_ORDER) do
    if badgeName==name then obj=list[i]; break end
  end
  if not (obj and obj.frames) then return false end
  local frame=math.floor((tonumber(card.frames) or 0)/8)%8
  local tile=obj.frames[frame+1] or obj.frames[1]
  if tile==nil then return false end
  local flip=tile>=0x80
  local base=flip and (tile-0x80) or tile
  local sx=flip and -1 or 1
  local scale=(size or 12)/16
  local G=love.graphics
  local function body()
    G.setColor(owned and {1,1,1,1} or {0.30,0.36,0.33,0.48})
    for _,cell in ipairs({{0,0,0},{1,0,1},{0,1,2},{1,1,3}}) do
      local quad=sheet:quad(base+cell[3])
      if quad then
        local px=(flip and (1-cell[1]) or cell[1])*8
        G.draw(sheet:image(),quad,
          x+(px+(flip and 8 or 0))*scale,y+cell[2]*8*scale,0,sx*scale,scale)
      end
    end
  end
  local okPal,GbcPalette=pcall(require,"src.render.GbcPalette")
  if card.gfx.badgePalette and okPal and GbcPalette
      and GbcPalette.available and GbcPalette.available() then
    local ok=pcall(GbcPalette.with,card.gfx.badgePalette,body)
    if ok then return true end
  end
  body()
  return true
end

-- Red's generated trainer-card badge sheet is eight stacked [face,badge]
-- pairs.  The badge half is the canonical Kanto set, giving Gold's otherwise
-- duplicated page a genuinely different second bank without inventing icons.
function GoldCompat.drawKantoBadgeGlyph(index,x,y,size,owned,locked)
  local G=love.graphics
  local s=size or 12
  local cx,cy=x+s*0.5,y+s*0.5
  local alpha=locked and 0.28 or (owned and 1 or 0.48)
  local colors={
    {0.63,0.56,0.45},{0.30,0.72,0.96},{0.96,0.82,0.20},{0.76,0.42,0.92},
    {0.88,0.35,0.55},{0.75,0.46,0.78},{0.96,0.42,0.18},{0.28,0.72,0.42},
  }
  local c=colors[index] or {0.72,0.78,0.72}
  if locked then c={0.30,0.38,0.34} end
  G.setColor(c[1],c[2],c[3],alpha)
  G.setLineWidth(math.max(1,s*0.08))
  if index==1 then -- Boulder: cut stone
    G.polygon("fill",cx-s*.27,cy-s*.18,cx-s*.08,cy-s*.32,cx+s*.22,cy-s*.22,
      cx+s*.31,cy+s*.05,cx+s*.10,cy+s*.29,cx-s*.22,cy+s*.22,cx-s*.31,cy)
  elseif index==2 then -- Cascade: water drop
    G.polygon("fill",cx,cy-s*.35,cx+s*.25,cy,cx+s*.18,cy+s*.25,
      cx,cy+s*.34,cx-s*.18,cy+s*.25,cx-s*.25,cy)
  elseif index==3 then -- Thunder: lightning bolt
    G.polygon("fill",cx+s*.02,cy-s*.36,cx-s*.24,cy+s*.02,cx-s*.03,cy+s*.02,
      cx-s*.13,cy+s*.36,cx+s*.28,cy-s*.08,cx+s*.06,cy-s*.08)
  elseif index==4 then -- Rainbow: concentric medal rings
    G.circle("line",cx,cy,s*.31); G.circle("line",cx,cy,s*.21); G.circle("fill",cx,cy,s*.08)
  elseif index==5 then -- Soul: heart-like crest
    G.circle("fill",cx-s*.13,cy-s*.08,s*.15); G.circle("fill",cx+s*.13,cy-s*.08,s*.15)
    G.polygon("fill",cx-s*.27,cy-s*.05,cx+s*.27,cy-s*.05,cx,cy+s*.34)
  elseif index==6 then -- Marsh: eye/spiral disc
    G.ellipse("line",cx,cy,s*.34,s*.23); G.circle("fill",cx,cy,s*.09); G.circle("line",cx,cy,s*.17)
  elseif index==7 then -- Volcano: flame crest
    G.polygon("fill",cx,cy-s*.36,cx+s*.11,cy-s*.08,cx+s*.27,cy+s*.06,
      cx+s*.15,cy+s*.30,cx-s*.18,cy+s*.30,cx-s*.28,cy+s*.05,cx-s*.08,cy-s*.10)
  else -- Earth: faceted green gem
    G.polygon("fill",cx,cy-s*.35,cx+s*.29,cy-s*.10,cx+s*.22,cy+s*.24,
      cx,cy+s*.34,cx-s*.22,cy+s*.24,cx-s*.29,cy-s*.10)
    G.setColor(0.82,1.00,0.84,alpha*.75); G.line(cx,cy-s*.30,cx,cy+s*.28)
  end
  G.setColor(0.02,0.07,0.05,math.min(0.95,alpha+0.25))
  G.rectangle("line",x+s*.06,y+s*.06,s*.88,s*.88,1.5,1.5)
end

function GoldCompat.drawKantoBadgeRender(index,x,y,size,owned,locked)
  local img=GoldCompat.kantoBadgeRenderSheet()
  if not img then
    GoldCompat.drawKantoBadgeGlyph(index,x,y,size,owned,locked)
    return true
  end
  local iw,ih=img:getDimensions()
  local sy=16+(math.max(1,math.min(8,index))-1)*32
  if sy+16>ih then
    GoldCompat.drawKantoBadgeGlyph(index,x,y,size,owned,locked)
    return true
  end
  local q=love.graphics.newQuad(0,sy,16,16,iw,ih)
  local scale=(size or 12)/16
  local G=love.graphics
  if locked then
    G.setColor(0.24,0.32,0.29,0.30)
  elseif owned then
    G.setColor(0.96,0.96,0.88,1)
  else
    G.setColor(0.36,0.44,0.40,0.48)
  end
  G.draw(img,q,x,y,0,scale,scale)
  return true
end

function GoldCompat.drawColosseumTrainerCardNative(card,gen2)
  local career=GoldCompat.trainerCareer(card,gen2)
  local save,player=career.save,career.player
  local page=gen2 and (tonumber(card.page) or 1)
    or (tonumber(card.__colosseumPage) or 1)
  page=math.max(1,math.min(3,page))
  local ox,oy,sc=finalCanvas()
  local G=love.graphics
  local x,y,w,h=7,6,146,131
  local playerName=tostring(player.name or save.name or (gen2 and "GOLD" or "RED"))
  local labels={"PROFILE","RECORDS","BADGES"}

  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)

  -- Layered metal chassis and inset green monitor deliberately avoid the
  -- donor project's cream cards, teal bubbles, and red rounded selections.
  G.setColor(0.01,0.02,0.02,0.42)
  roundedRect("fill",x+2,y+3,w,h,5)
  G.setColor(0.16,0.19,0.18,0.96)
  roundedRect("fill",x,y,w,h,5)
  G.setColor(0.38,0.42,0.39,0.95)
  roundedRect("line",x,y,w,h,5)
  G.setColor(0.08,0.10,0.095,0.98)
  G.rectangle("fill",x+3,y+3,w-6,17)
  G.setColor(0.36,0.42,0.39,0.94)
  G.rectangle("fill",x+4,y+20,w-8,2)

  -- Green scanline field from Colosseum's player-data monitor.
  G.setColor(0.005,0.075,0.035,0.86)
  G.rectangle("fill",x+3,y+23,w-6,91)
  for sy=y+25,y+112,2 do
    G.setColor(0.06,0.42,0.18,0.16)
    G.rectangle("fill",x+4,sy,w-8,0.55)
  end

  -- Angled navigation rail.
  G.setColor(0.10,0.13,0.12,0.96)
  G.polygon("fill",x+5,y+27,x+38,y+27,x+42,y+31,
    x+42,y+107,x+38,y+111,x+5,y+111)
  G.setColor(0.34,0.40,0.37,0.95)
  G.line(x+42,y+31,x+42,y+107)

  -- Page monitor and footer strip.
  G.setColor(0.005,0.025,0.018,0.86)
  G.polygon("fill",x+46,y+27,x+138,y+27,x+141,y+30,
    x+141,y+108,x+138,y+111,x+46,y+111,x+43,y+108,x+43,y+30)
  G.setColor(0.16,0.48,0.28,0.78)
  G.line(x+46,y+28,x+138,y+28)
  G.line(x+46,y+110,x+138,y+110)
  G.setColor(0.035,0.06,0.05,0.98)
  G.rectangle("fill",x+3,y+116,w-6,11)
  G.setColor(0.25,0.31,0.29,0.95)
  G.line(x+3,y+116,x+w-3,y+116)

  -- Chassis fasteners.
  for _,bolt in ipairs({{x+5,y+5},{x+w-5,y+5},{x+5,y+h-5},{x+w-5,y+h-5}}) do
    G.setColor(0.04,0.05,0.05,1); G.circle("fill",bolt[1],bolt[2],1.6)
    G.setColor(0.55,0.59,0.55,1); G.circle("line",bolt[1],bolt[2],1.2)
  end

  -- Selected page is a luminous chevron/underline, not a donor selection box.
  for i=1,3 do
    local yy=y+39+(i-1)*22
    if i==page then
      G.setColor(0.20,1.00,0.38,1)
      G.polygon("fill",x+13,yy+3,x+8,yy,x+8,yy+6)
      G.rectangle("fill",x+15,yy+8,21,1)
    end
  end
  G.pop()

  finalText(playerName,x+10,y+8,4.0,{0.30,1.00,0.42,1},ox,oy,sc,"left",77)
  finalText("PLAYER DATA",x+86,y+9,2.0,{0.68,0.82,0.72,1},ox,oy,sc)
  finalText("B  CANCEL",x+113,y+8,2.2,{0.95,0.98,0.94,1},ox,oy,sc)
  for i,label in ipairs(labels) do
    finalText(label,x+16,y+38+(i-1)*22,2.55,
      i==page and {0.40,1.00,0.52,1} or {0.66,0.82,0.70,1},
      ox,oy,sc,"left",23)
  end

  if page==1 then
    finalText("PROFILE",x+49,y+31,3.25,{0.34,1.00,0.46,1},ox,oy,sc)
    G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
    G.setColor(0.12,0.16,0.14,0.98); G.rectangle("fill",x+49,y+40,31,38)
    G.setColor(0.45,0.50,0.46,1); G.rectangle("line",x+49,y+40,31,38)
    G.pop()
    GoldCompat.drawColosseumTrainerPortrait(card,gen2,ox,oy,sc,x+51,y+42,27,34)
    finalText(playerName,x+84,y+42,3.5,{0.32,1.00,0.44,1},ox,oy,sc,"left",51)
    finalText("ID No. "..("%05d"):format(tonumber(player.id) or 0),x+84,y+52,2.35,
      {0.94,0.98,0.94,1},ox,oy,sc,"left",51)
    local money=tonumber(gen2 and player.money or save.money) or 0
    finalText((gen2 and "¥" or "$")..tostring(money),x+84,y+63,2.8,
      {0.94,0.98,0.94,1},ox,oy,sc,"left",51)
    local play
    if type(save.playTime)=="table" then
      play=("%d:%02d"):format(save.playTime.hours or 0,save.playTime.minutes or 0)
    else
      local seconds=math.floor(tonumber(save.playTime) or 0)
      play=("%d:%02d"):format(math.floor(seconds/3600),math.floor(seconds/60)%60)
    end
    finalText("POKéMON CAUGHT",x+51,y+84,1.95,{0.40,0.86,0.53,1},ox,oy,sc)
    finalText(tostring(career.caught),x+91,y+84,2.55,{0.96,0.98,0.95,1},ox,oy,sc)
    finalText("BADGES",x+51,y+94,1.95,{0.40,0.86,0.53,1},ox,oy,sc)
    finalText(tostring(career.badges),x+91,y+94,2.55,{0.96,0.98,0.95,1},ox,oy,sc)
    finalText("PLAY TIME",x+105,y+84,1.95,{0.40,0.86,0.53,1},ox,oy,sc)
    finalText(play,x+105,y+94,2.55,{0.96,0.98,0.95,1},ox,oy,sc)
  elseif page==2 then
    finalText("RECORDS",x+49,y+31,3.25,{0.34,1.00,0.46,1},ox,oy,sc)
    local play
    if type(save.playTime)=="table" then
      play=("%d:%02d"):format(save.playTime.hours or 0,save.playTime.minutes or 0)
    else
      local seconds=math.floor(tonumber(save.playTime) or 0)
      play=("%d:%02d"):format(math.floor(seconds/3600),math.floor(seconds/60)%60)
    end
    local rows={
      {"BATTLES WON",career.wins},{"POKéMON FAINTED",career.fainted},
      {"LEAGUE CLEARS",career.league},{"POKéMON CAUGHT",career.caught},
      {"BADGES",career.badges},{"PLAY TIME",play},
    }
    for i,row in ipairs(rows) do
      local col=(i-1)%2
      local rr=math.floor((i-1)/2)
      local rx=x+49+col*45
      local ry=y+42+rr*22
      G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
      G.setColor(0.01,0.055,0.03,0.86); G.rectangle("fill",rx,ry,41,18)
      G.setColor(0.11,0.34,0.19,0.9); G.rectangle("line",rx,ry,41,18)
      G.pop()
      finalText(row[1],rx+3,ry+3,1.75,{0.39,0.87,0.51,1},ox,oy,sc,"left",35)
      finalText(row[2]==nil and "--" or tostring(row[2]),rx+3,ry+9,3.0,
        {0.96,0.99,0.95,1},ox,oy,sc,"right",35)
    end
  else
    finalText("BADGES",x+49,y+31,3.25,{0.34,1.00,0.46,1},ox,oy,sc)
    if gen2 then
      -- Present the first sixteen badges as badge renders, not leader-face
      -- crops. Johto uses Gold's real animated badge sheet; Kanto uses Red's
      -- real Kanto badge sheet so the two regions have distinct silhouettes.
      -- Kanto remains visible before the Elite Four, but dimmed/locked.
      local regions={
        {label="JOHTO",set=player.badges or {},names=GoldCompat.GEN2_JOHTO_BADGE_DISPLAY},
        {label="KANTO",set=player.kantoBadges or {},names=GoldCompat.GEN2_KANTO_BADGE_DISPLAY},
      }
      local flags=save.flags or {}
      local kantoUnlocked=flags.HALL_OF_FAME==true
        or GoldCompat.trainerBadgeCount(player.kantoBadges or {})>0
      for regionIndex,region in ipairs(regions) do
        local ry=y+41+(regionIndex-1)*34
        local locked=(regionIndex==2 and not kantoUnlocked)
        finalText(region.label,x+50,ry,2.1,{0.42,0.90,0.55,1},ox,oy,sc)
        if locked then
          finalText("LOCKED",x+116,ry,1.75,{0.48,0.62,0.54,1},ox,oy,sc,"right",22)
        else
          finalText(tostring(GoldCompat.trainerBadgeCount(region.set)).." / 8",
            x+116,ry,2.1,{0.92,0.98,0.93,1},ox,oy,sc,"right",22)
        end

        for i,name in ipairs(region.names) do
          local col=(i-1)%4
          local row=math.floor((i-1)/4)
          local bx=x+53+col*21.5
          local by=ry+7+row*11
          local owned=GoldCompat.trainerBadgeOwned(region.set,i,name)
          G.push("all"); G.origin()
          local px=ox+bx*sc
          local py=oy+by*sc
          local badgeSize=9.5*sc
          local drew
          if regionIndex==1 then
            drew=GoldCompat.drawJohtoBadgeRender(card,name,px,py,badgeSize,owned)
          else
            drew=GoldCompat.drawKantoBadgeRender(i,px,py,badgeSize,owned,locked)
          end
          if not drew then
            G.translate(ox,oy); G.scale(sc,sc)
            GoldCompat.drawTrainerBadgeMedal(bx+4.7,by+4.7,3.5,owned,
              regionIndex==1 and {0.30,0.85,0.52} or {0.82,0.64,0.22})
          end
          G.pop()
        end
      end
    else
      local names={"BOULDER","CASCADE","THUNDER","RAINBOW",
        "SOUL","MARSH","VOLCANO","EARTH"}
      local defs={}
      local Badges
      pcall(function()
        Badges=require("src.inventory.Badges")
        defs=Badges.list(card.game.data) or {}
      end)
      finalText(tostring(career.badges).." / 8 EARNED",x+91,y+32,2.3,
        {0.92,0.98,0.93,1},ox,oy,sc,"right",43)
      for i=1,8 do
        local col=(i-1)%4
        local rr=math.floor((i-1)/4)
        local bx=x+52+col*22
        local by=y+47+rr*30
        local def=defs[i]
        local name=tostring((def and def.name) or names[i])
        local owned=false
        if Badges and def and save.inventory then
          local ok,item=pcall(Badges.itemFor,def)
          local value=ok and save.inventory[item] or nil
          owned=value~=nil and value~=false and value~=0
        end
        -- Gen 1's TrainerCard already loads the correct eight badge/faded-face
        -- sheets, including replacements supplied by compatible sprite mods.
        local sheet=owned and card.badges or card.faces
        local q=sheet and sheet.quads and sheet.quads[i-1]
        if sheet and sheet.img and q then
          G.push("all"); G.origin(); G.setColor(1,1,1,owned and 1 or 0.50)
          G.draw(sheet.img,q,ox+(bx+1)*sc,oy+(by+1)*sc,0,0.72*sc,0.72*sc)
          G.pop()
        else
          G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
          GoldCompat.drawTrainerBadgeMedal(bx+8,by+8,6,owned,
            {0.36+col*0.10,0.76-rr*0.12,0.38+rr*0.20})
          G.pop()
        end
        local short=name:upper():sub(1,7)
        finalText(short,bx,by+18,1.55,owned and {0.88,0.98,0.89,1}
          or {0.38,0.50,0.42,1},ox,oy,sc,"center",17)
      end
    end
  end

  finalText("↑/↓  SELECT PAGE",x+8,y+119,2.15,{0.42,0.95,0.56,1},ox,oy,sc)
  finalText("B  BACK",x+116,y+119,2.15,{0.78,0.88,0.80,1},ox,oy,sc)
end

-- Purpose-built Player screens; native TrainerCard states still own closing,
-- save data, portrait resources, and all game transitions.
GoldCompat.drawGen1TrainerCardHanging=function(card)
  return GoldCompat.drawColosseumTrainerCardNative(card,false)
end
GoldCompat.drawGen2TrainerCardHanging=function(card)
  return GoldCompat.drawColosseumTrainerCardNative(card,true)
end

function GoldCompat.drawGen1LevelUpBox(box)
  if not featureEnabled("revampedLevelUpUI") then return false end
  local mon=box and box.mon
  local game=box and box.game
  if not (mon and game and mon.stats) then return false end

  local level=tonumber(mon.level) or 1
  local def=game.data and game.data.pokemon and game.data.pokemon[mon.species]
  local old={}
  local okStats,Stats=pcall(require,"src.pokemon.Stats")
  if okStats and Stats and type(Stats.calc)=="function" and def then
    local ok,v=pcall(Stats.calc,def,math.max(1,level-1),
      mon.dvs or {},mon.statExp or {})
    if ok and type(v)=="table" then old=v end
  end

  local ox,oy,sc=finalCanvas()
  local g=love.graphics
  local x,y,w,h=52,7,58,100

  -- The normal UI Box Size setting is allowed to overscan the 160x144 canvas
  -- slightly for large hanging menus. The level-up card is much taller and
  -- should never inherit that overscan: clamp only this overlay to the real
  -- display bounds while preserving its centered logical placement.
  local sw,sh=love.graphics.getDimensions()
  local safeMargin=6
  local maxCardScale=math.min(
    (sw-safeMargin*2)/w,
    (sh-safeMargin*2)/h
  )
  if sc>maxCardScale then
    sc=maxCardScale
    ox=(sw-160*sc)*0.5
    oy=(sh-144*sc)*0.5
  end

  -- If the centered 160x144 canvas would still place the tall card outside the
  -- screen, shift the canvas just enough to keep the card fully visible.
  local cardTop=oy+y*sc
  local cardBottom=oy+(y+h)*sc
  if cardTop<safeMargin then
    oy=oy+(safeMargin-cardTop)
  end
  if cardBottom>sh-safeMargin then
    oy=oy-((cardBottom)-(sh-safeMargin))
  end

  g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
  g.setColor(0.04,0.04,0.04,0.34)
  roundedRect("fill",x+2,y+2,w,h,4)
  g.setColor(0.075,0.085,0.08,0.98)
  roundedRect("fill",x,y,w,h,4)
  g.setColor(0.36,0.39,0.36,1)
  roundedRect("line",x,y,w,h,4)
  g.setColor(0.79,0.64,0.20,1)
  g.rectangle("fill",x+5,y+5,w-10,1.2)
  g.setColor(0.14,0.15,0.14,1)
  roundedRect("fill",x+6,y+19,w-12,12,2)
  g.pop()

  local white={0.98,0.98,0.95,1}
  local muted={0.70,0.72,0.68,1}
  finalText("LEVEL UP!",x+7,y+9,3.8,white,ox,oy,sc)
  finalText("Lv. "..tostring(level),x+w-20,y+9,2.8,
    {0.89,0.79,0.42,1},ox,oy,sc,"right",14)

  local name=mon.nickname or (def and def.name) or tostring(mon.species)
  finalText(name,x+9,y+22,2.9,white,ox,oy,sc,"left",w-18)

  local rows={{"HP","hp"},{"ATTACK","attack"},{"DEFENSE","defense"},
              {"SP. ATK","special"},{"SP. DEF","special"},{"SPEED","speed"}}
  for i,row in ipairs(rows) do
    local key=row[2]
    local value=tonumber(mon.stats[key]) or 0
    local prior=tonumber(old[key]) or value
    local d=value-prior
    local yy=y+38+(i-1)*8
    finalText(row[1],x+8,yy,2.25,muted,ox,oy,sc)
    finalText(tostring(value),x+w-20,yy,2.7,white,
      ox,oy,sc,"right",10)
    finalText((d>=0 and "+" or "")..tostring(d),x+w-8,yy,2.15,
      d>0 and {0.34,0.85,0.49,1} or muted,
      ox,oy,sc,"right",7)
  end
  finalText("A  CONTINUE",x+w-27,y+h-8,1.9,muted,
    ox,oy,sc,"right",23)
  return true
end

function GoldCompat.installGen1ModernScreens()
  if GoldCompat.generation~="gen1" or GoldCompat.gen1ModernScreensInstalled then return end

  local okOptions,OptionsMenu=pcall(require,"src.ui.OptionsMenu")
  if okOptions and type(OptionsMenu)=="table"
      and not OptionsMenu.__gen3uiModernPatched then
    OptionsMenu.__gen3uiModernPatched=true
    OptionsMenu.__gen3uiOriginalNew=OptionsMenu.new
    OptionsMenu.__gen3uiOriginalDraw=OptionsMenu.draw
    OptionsMenu.__gen3uiOriginalUpdate=OptionsMenu.update
    OptionsMenu.__gen3uiOriginalOpaque=OptionsMenu.isOpaque
    OptionsMenu.isOpaque=false
    if type(OptionsMenu.__gen3uiOriginalNew)=="function" then
      OptionsMenu.new=function(...)
        local self=OptionsMenu.__gen3uiOriginalNew(...)
        if screenFeatureEnabled("revampedOptionsUI") then
          self.isOpaque=false
          self.__gen3uiHangingOptions=true
          State.activeGen1Options=self
        else
          self.isOpaque=OptionsMenu.__gen3uiOriginalOpaque
          self.__gen3uiHangingOptions=nil
        end
        return self
      end
    end
    if type(OptionsMenu.__gen3uiOriginalUpdate)=="function" then
      OptionsMenu.update=function(self,...)
        if screenFeatureEnabled("revampedOptionsUI") then
          self.isOpaque=false
          self.__gen3uiHangingOptions=true
        end
        return callOriginal(OptionsMenu.__gen3uiOriginalUpdate,self,...)
      end
    end

    OptionsMenu.draw=function(self,...)
      if screenFeatureEnabled("revampedOptionsUI") then
        self.__gen3uiHangingOptions=true
        self.isOpaque=false
        State.activeGen1Options=self
        return
      end
      self.isOpaque=OptionsMenu.__gen3uiOriginalOpaque
      self.__gen3uiHangingOptions=nil
      State.activeGen1Options=nil
      return callOriginal(OptionsMenu.__gen3uiOriginalDraw,self,...)
    end
  end

  local okManager,ManagerState=pcall(require,"src.mods.ManagerState")
  if okManager and type(ManagerState)=="table"
      and not ManagerState.__gen3uiGoldVisualPatched then
    ManagerState.__gen3uiGoldVisualPatched=true
    ManagerState.__gen3uiOriginalNew=ManagerState.new
    ManagerState.__gen3uiOriginalDraw=ManagerState.draw
    ManagerState.__gen3uiOriginalOpaque=ManagerState.isOpaque
    ManagerState.isOpaque=false
    if type(ManagerState.__gen3uiOriginalNew)=="function" then
      ManagerState.new=function(...)
        local self=ManagerState.__gen3uiOriginalNew(...)
        if screenFeatureEnabled("revampedModsUI") then
          self.isOpaque=false
          self.__gen3uiHangingMods=true
          State.activeGen1Mods=self
        else
          self.isOpaque=ManagerState.__gen3uiOriginalOpaque
          self.__gen3uiHangingMods=nil
        end
        return self
      end
    end
    ManagerState.draw=function(self,...)
      if screenFeatureEnabled("revampedModsUI") then
        self.__gen3uiHangingMods=true
        self.isOpaque=false
        State.activeGen1Mods=self
        return
      end
      self.isOpaque=ManagerState.__gen3uiOriginalOpaque
      self.__gen3uiHangingMods=nil
      State.activeGen1Mods=nil
      return callOriginal(ManagerState.__gen3uiOriginalDraw,self,...)
    end
  end

  local okTrainer,TrainerCard=pcall(require,"src.ui.TrainerCard")
  if okTrainer and type(TrainerCard)=="table"
      and not TrainerCard.__gen3uiModernPatched then
    TrainerCard.__gen3uiModernPatched=true
    TrainerCard.__gen3uiOriginalNew=TrainerCard.new
    TrainerCard.__gen3uiOriginalDraw=TrainerCard.draw
    TrainerCard.__gen3uiOriginalUpdate=TrainerCard.update
    TrainerCard.__gen3uiOriginalOpaque=TrainerCard.isOpaque
    -- Opacity is queried before draw(). Mark both the class and new instances
    -- up front; doing this only inside draw left the late HUD card behind an
    -- already-claimed opaque native frame, producing a completely blank view.
    TrainerCard.isOpaque=false
    if type(TrainerCard.__gen3uiOriginalNew)=="function" then
      TrainerCard.new=function(...)
        local self=TrainerCard.__gen3uiOriginalNew(...)
        if screenFeatureEnabled("revampedTrainerCardUI") then
          self.isOpaque=false
          self.__gen3uiHangingTrainer=true
        else
          self.isOpaque=TrainerCard.__gen3uiOriginalOpaque
          self.__gen3uiHangingTrainer=nil
        end
        return self
      end
    end
    if type(TrainerCard.__gen3uiOriginalUpdate)=="function" then
      TrainerCard.update=function(self,...)
        if screenFeatureEnabled("revampedTrainerCardUI") then
          self.isOpaque=false
          self.__gen3uiHangingTrainer=true
          local input=self.game and self.game.input
          local left=input and input:wasPressed("left")
          local right=input and input:wasPressed("right")
          local up=input and input:wasPressed("up")
          local down=input and input:wasPressed("down")
          if left or right or up or down then
            local delta=(left or up) and -1 or 1
            self.__colosseumPage=((self.__colosseumPage or 1)-1+delta)%3+1
            pcall(function()
              require("src.core.Sound").play(self.game.data,"Press_AB")
            end)
            return
          end
        end
        return callOriginal(TrainerCard.__gen3uiOriginalUpdate,self,...)
      end
    end

    TrainerCard.draw=function(self,...)
      if screenFeatureEnabled("revampedTrainerCardUI") then
        self.__gen3uiHangingTrainer=true
        self.isOpaque=false
        State.activeGen1TrainerCard=self
        return
      end
      self.isOpaque=TrainerCard.__gen3uiOriginalOpaque
      self.__gen3uiHangingTrainer=nil
      State.activeGen1TrainerCard=nil
      return callOriginal(TrainerCard.__gen3uiOriginalDraw,self,...)
    end
  end

  local okBattle,BattleState=pcall(require,"src.battle.BattleState")
  local StatBox=okBattle and BattleState and BattleState.StatBox
  if StatBox and not StatBox.__gen3uiModernPatched then
    StatBox.__gen3uiModernPatched=true
    StatBox.__gen3uiOriginalDraw=StatBox.draw
    StatBox.__gen3uiOriginalNew=StatBox.new

    -- StatBox is a pushed battle state. Its native draw happens on the GB
    -- battle canvas, while our modern card belongs in the late HUD pass.
    -- Mark ownership here and render it after the battlefield instead.
    StatBox.draw=function(self,...)
      if screenFeatureEnabled("revampedLevelUpUI") then
        self.__gen3uiLevelUpBox=true
        State.activeGen1LevelUpBox=self
        return
      end
      if featureEnabled("hideNativeBattleUI") then
        self.__gen3uiLevelUpBox=nil
        if State.activeGen1LevelUpBox==self then
          State.activeGen1LevelUpBox=nil
        end
        return runDrawInvisible(StatBox.__gen3uiOriginalDraw,self,...)
      end
      self.__gen3uiLevelUpBox=nil
      if State.activeGen1LevelUpBox==self then
        State.activeGen1LevelUpBox=nil
      end
      return callOriginal(StatBox.__gen3uiOriginalDraw,self,...)
    end

    -- Instance-level belt-and-suspenders protection for engines/mods that
    -- capture StatBox.draw during construction.
    if type(StatBox.__gen3uiOriginalNew)=="function" then
      StatBox.new=function(...)
        local box=StatBox.__gen3uiOriginalNew(...)
        box.__gen3uiLevelUpBox=true
        return box
      end
    end
  end

  GoldCompat.gen1ModernScreensInstalled=true
end

function GoldCompat.installCoreMenuUI()
  if GoldCompat.generation~="gen2" or GoldCompat.coreMenusInstalled then return end

  local okStart,StartMenu=pcall(require,"src.ui.gen2.StartMenu")
  if okStart and type(StartMenu)=="table" and not StartMenu.__gen3uiVisualPatched then
    StartMenu.__gen3uiVisualPatched=true
    StartMenu.__gen3uiOriginalDraw=StartMenu.draw

    -- Same ownership model as Gen 1 START: suppress native Gold chrome, keep
    -- the state/input fully native, and render the mature final-window START UI
    -- later in render.hud over the still-visible overworld.
    StartMenu.draw=function(self,...)
      if not featureEnabled("revampedOverworldMenus") then
        self.__gen3uiStart=nil
        if State.activeStartMenu==self then State.activeStartMenu=nil end
        return callOriginal(StartMenu.__gen3uiOriginalDraw,self,...)
      end
      -- Match the ownership contract used by the Gen 1 Start menu so
      -- clearStaleOverworldOwnership() recognizes this as a valid active menu.
      self.__gen3uiStart=true
      GoldCompat.prepareGoldStartMenu(self)
      return
    end
  end

  local okSave,SaveMenu=pcall(require,"src.ui.gen2.SaveMenu")
  if okSave and type(SaveMenu)=="table" and not SaveMenu.__gen3uiVisualPatched then
    SaveMenu.__gen3uiVisualPatched=true
    SaveMenu.__gen3uiOriginalNew=SaveMenu.new
    SaveMenu.__gen3uiOriginalDraw=SaveMenu.draw
    SaveMenu.__gen3uiOriginalDrawWidescreen=SaveMenu.drawWidescreen
    SaveMenu.__gen3uiOriginalDrawsWidescreen=SaveMenu.drawsWidescreen
    SaveMenu.__gen3uiOriginalWantsFillScale=SaveMenu.wantsFillScale
    SaveMenu.__gen3uiOriginalIsOpaque=SaveMenu.isOpaque

    SaveMenu.drawsWidescreen=function(self,...)
      if goldScreenEnabled("revampedSaveUI") then return false end
      return callOriginal(SaveMenu.__gen3uiOriginalDrawsWidescreen,self,...)
    end
    SaveMenu.wantsFillScale=function(self,...)
      if goldScreenEnabled("revampedSaveUI") then return false end
      return callOriginal(SaveMenu.__gen3uiOriginalWantsFillScale,self,...)
    end
    SaveMenu.new=function(...)
      local self=SaveMenu.__gen3uiOriginalNew(...)
      if goldScreenEnabled("revampedSaveUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="save"
        -- Gold's native constructor starts on an informational prompt page.
        -- Enter its own confirmation phase immediately; update/callback logic
        -- remains native after this presentation-only initial-state advance.
        if self.phase~="confirm" and self.phase~="overwrite" then
          self.phase="confirm"
          self.choice=self.choice or 1
        end
      else
        self.isOpaque=SaveMenu.__gen3uiOriginalIsOpaque
        self.__gen3uiGoldOverlayKind=nil
      end
      return self
    end
    SaveMenu.draw=function(self,...)
      if goldScreenEnabled("revampedSaveUI") then
        self.__gen3uiGoldOverlayKind="save"
        return
      end
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(SaveMenu.__gen3uiOriginalDraw,self,...)
    end
    SaveMenu.drawWidescreen=function(self,...)
      if goldScreenEnabled("revampedSaveUI") then
        self.__gen3uiGoldOverlayKind="save"
        return
      end
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(SaveMenu.__gen3uiOriginalDrawWidescreen,self,...)
    end
  end

  local okOptions,OptionsMenu=pcall(require,"src.ui.gen2.OptionsMenu")
  if okOptions and type(OptionsMenu)=="table"
      and not OptionsMenu.__gen3uiVisualPatched then
    OptionsMenu.__gen3uiVisualPatched=true
    OptionsMenu.__gen3uiOriginalNew=OptionsMenu.new
    OptionsMenu.__gen3uiOriginalDraw=OptionsMenu.draw
    OptionsMenu.__gen3uiOriginalDrawWidescreen=OptionsMenu.drawWidescreen
    OptionsMenu.__gen3uiOriginalDrawsWidescreen=OptionsMenu.drawsWidescreen
    OptionsMenu.__gen3uiOriginalWantsFillScale=OptionsMenu.wantsFillScale
    OptionsMenu.__gen3uiOriginalOpaque=OptionsMenu.isOpaque

    OptionsMenu.isOpaque=false
    OptionsMenu.drawsWidescreen=function(self,...)
      if goldScreenEnabled("revampedOptionsUI") then return false end
      return callOriginal(OptionsMenu.__gen3uiOriginalDrawsWidescreen,self,...)
    end
    OptionsMenu.wantsFillScale=function(self,...)
      if goldScreenEnabled("revampedOptionsUI") then return false end
      return callOriginal(OptionsMenu.__gen3uiOriginalWantsFillScale,self,...)
    end

    if type(OptionsMenu.new)=="function" then
      OptionsMenu.new=function(...)
        local self=OptionsMenu.__gen3uiOriginalNew(...)
        if goldScreenEnabled("revampedOptionsUI") then
          self.isOpaque=false
          self.__gen3uiGoldOverlayKind="options"
        else
          self.isOpaque=OptionsMenu.__gen3uiOriginalOpaque
          self.__gen3uiGoldOverlayKind=nil
        end
        return self
      end
    end

    OptionsMenu.draw=function(self,...)
      if goldScreenEnabled("revampedOptionsUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="options"
        return
      end
      self.isOpaque=OptionsMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(OptionsMenu.__gen3uiOriginalDraw,self,...)
    end

    OptionsMenu.drawWidescreen=function(self,...)
      if goldScreenEnabled("revampedOptionsUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="options"
        return
      end
      self.isOpaque=OptionsMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(
        OptionsMenu.__gen3uiOriginalDrawWidescreen,self,...)
    end
  end

  local okTrainer,TrainerCard=pcall(require,"src.ui.gen2.TrainerCard")
  if okTrainer and type(TrainerCard)=="table"
      and not TrainerCard.__gen3uiVisualPatched then
    TrainerCard.__gen3uiVisualPatched=true
    TrainerCard.__gen3uiOriginalNew=TrainerCard.new
    TrainerCard.__gen3uiOriginalDraw=TrainerCard.draw
    TrainerCard.__gen3uiOriginalUpdate=TrainerCard.update
    TrainerCard.__gen3uiOriginalDrawPanel=TrainerCard.drawPanel
    TrainerCard.__gen3uiOriginalDrawWidescreen=TrainerCard.drawWidescreen
    TrainerCard.__gen3uiOriginalDrawsWidescreen=TrainerCard.drawsWidescreen
    TrainerCard.__gen3uiOriginalWantsFillScale=TrainerCard.wantsFillScale
    TrainerCard.__gen3uiOriginalOpaque=TrainerCard.isOpaque

    TrainerCard.isOpaque=false
    TrainerCard.drawsWidescreen=function(self,...)
      if goldScreenEnabled("revampedTrainerCardUI") then return false end
      return callOriginal(TrainerCard.__gen3uiOriginalDrawsWidescreen,self,...)
    end
    TrainerCard.wantsFillScale=function(self,...)
      if goldScreenEnabled("revampedTrainerCardUI") then return false end
      return callOriginal(TrainerCard.__gen3uiOriginalWantsFillScale,self,...)
    end

    if type(TrainerCard.__gen3uiOriginalUpdate)=="function" then
      TrainerCard.update=function(self,...)
        if goldScreenEnabled("revampedTrainerCardUI") then
          local input=self.game and self.game.input
          local left=input and input:wasPressed("left")
          local right=input and input:wasPressed("right")
          local up=input and input:wasPressed("up")
          local down=input and input:wasPressed("down")
          if left or right or up or down then
            local delta=(left or up) and -1 or 1
            self.page=((tonumber(self.page) or 1)-1+delta)%3+1
            pcall(function()
              require("src.core.Sound").play(self.game.data,"Press_AB")
            end)
            return
          end
        end
        return callOriginal(TrainerCard.__gen3uiOriginalUpdate,self,...)
      end
    end

    if type(TrainerCard.new)=="function" then
      TrainerCard.new=function(...)
        local self=TrainerCard.__gen3uiOriginalNew(...)
        if goldScreenEnabled("revampedTrainerCardUI") then
          self.isOpaque=false
          self.__gen3uiGoldOverlayKind="trainer"
        else
          self.isOpaque=TrainerCard.__gen3uiOriginalOpaque
          self.__gen3uiGoldOverlayKind=nil
        end
        return self
      end
    end

    TrainerCard.draw=function(self,...)
      if goldScreenEnabled("revampedTrainerCardUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="trainer"
        return
      end
      self.isOpaque=TrainerCard.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(TrainerCard.__gen3uiOriginalDraw,self,...)
    end

    TrainerCard.drawWidescreen=function(self,...)
      if goldScreenEnabled("revampedTrainerCardUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="trainer"
        return
      end
      self.isOpaque=TrainerCard.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(
        TrainerCard.__gen3uiOriginalDrawWidescreen,self,...)
    end
  end

  -- ManagerState stays completely native for navigation/actions. Gold now
  -- routes it through the same service-overlay seam as Pack/Mart/Save.
  local okManager,ManagerState=pcall(require,"src.mods.ManagerState")
  if okManager and type(ManagerState)=="table"
      and not ManagerState.__gen3uiGoldVisualPatched then
    ManagerState.__gen3uiGoldVisualPatched=true
    ManagerState.__gen3uiOriginalNew=ManagerState.new
    ManagerState.__gen3uiOriginalDraw=ManagerState.draw
    ManagerState.__gen3uiOriginalDrawWidescreen=ManagerState.drawWidescreen
    ManagerState.__gen3uiOriginalDrawsWidescreen=ManagerState.drawsWidescreen
    ManagerState.__gen3uiOriginalWantsFillScale=ManagerState.wantsFillScale
    ManagerState.__gen3uiOriginalOpaque=ManagerState.isOpaque

    ManagerState.isOpaque=false
    ManagerState.drawsWidescreen=function(self,...)
      if goldScreenEnabled("revampedModsUI") then return false end
      return callOriginal(ManagerState.__gen3uiOriginalDrawsWidescreen,self,...)
    end
    ManagerState.wantsFillScale=function(self,...)
      if goldScreenEnabled("revampedModsUI") then return false end
      return callOriginal(ManagerState.__gen3uiOriginalWantsFillScale,self,...)
    end

    if type(ManagerState.new)=="function" then
      ManagerState.new=function(...)
        local self=ManagerState.__gen3uiOriginalNew(...)
        if goldScreenEnabled("revampedModsUI") then
          self.isOpaque=false
          self.__gen3uiGoldOverlayKind="mods"
        else
          self.isOpaque=ManagerState.__gen3uiOriginalOpaque
          self.__gen3uiGoldOverlayKind=nil
        end
        return self
      end
    end

    ManagerState.draw=function(self,...)
      if goldScreenEnabled("revampedModsUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="mods"
        return
      end
      self.isOpaque=ManagerState.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(ManagerState.__gen3uiOriginalDraw,self,...)
    end

    ManagerState.drawWidescreen=function(self,...)
      if goldScreenEnabled("revampedModsUI") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="mods"
        return
      end
      self.isOpaque=ManagerState.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(
        ManagerState.__gen3uiOriginalDrawWidescreen,self,...)
    end
  end

  local okParty,PartyMenu=pcall(require,"src.ui.gen2.PartyMenu")
  if okParty and type(PartyMenu)=="table" and not PartyMenu.__gen3uiVisualPatched then
    PartyMenu.__gen3uiVisualPatched=true
    PartyMenu.__gen3uiOriginalNew=PartyMenu.new
    PartyMenu.__gen3uiOriginalUpdate=PartyMenu.update
    PartyMenu.__gen3uiOriginalDraw=PartyMenu.draw
    PartyMenu.__gen3uiOriginalDrawWidescreen=PartyMenu.drawWidescreen
    PartyMenu.__gen3uiOriginalDrawsWidescreen=PartyMenu.drawsWidescreen
    PartyMenu.__gen3uiOriginalWantsFillScale=PartyMenu.wantsFillScale
    PartyMenu.drawsWidescreen=function(self)
      if featureEnabled("colosseumPokemonMenu") then return false end
      return callOriginal(PartyMenu.__gen3uiOriginalDrawsWidescreen,self)
    end
    PartyMenu.wantsFillScale=function(self)
      if featureEnabled("colosseumPokemonMenu") then return false end
      return callOriginal(PartyMenu.__gen3uiOriginalWantsFillScale,self)
    end
    if type(PartyMenu.new)=="function" then
      PartyMenu.new=function(...)
        local self=PartyMenu.__gen3uiOriginalNew(...)
        if featureEnabled("colosseumPokemonMenu") then
          self.isOpaque=false
          self.__gen3uiColosseumParty=true
        end
        return self
      end
    end
    PartyMenu.update=function(self,dt)
      if featureEnabled("colosseumPokemonMenu") then self.isOpaque=false end
      if not featureEnabled("colosseumPokemonMenu") then
        return PartyMenu.__gen3uiOriginalUpdate(self,dt)
      end

      local input=self.game and self.game.input
      local party=self.party or {}
      if not input or self.submenu or #party<1 then
        return PartyMenu.__gen3uiOriginalUpdate(self,dt)
      end

      local direction=input:wasPressed("left") and "left"
        or input:wasPressed("right") and "right"
        or input:wasPressed("up") and "up"
        or input:wasPressed("down") and "down"
      if not direction then
        return PartyMenu.__gen3uiOriginalUpdate(self,dt)
      end

      local pressed=input.pressed or {}
      local saved={
        left=pressed.left,right=pressed.right,
        up=pressed.up,down=pressed.down,
      }
      pressed.left=nil; pressed.right=nil; pressed.up=nil; pressed.down=nil
      local ok,result=pcall(PartyMenu.__gen3uiOriginalUpdate,self,dt)
      pressed.left=saved.left; pressed.right=saved.right
      pressed.up=saved.up; pressed.down=saved.down
      if not ok then error(result) end

      self.index=GoldCompat.colosseumPartyGridIndex(
        self.index,#party,direction)
      if type(self.storeCursor)=="function" then pcall(self.storeCursor,self) end
      return result
    end
    PartyMenu.draw=function(self,...)
      if featureEnabled("colosseumPokemonMenu") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="party"
        return
      end
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PartyMenu.__gen3uiOriginalDraw,self,...)
    end
    PartyMenu.drawWidescreen=function(self,winW,winH)
      if featureEnabled("colosseumPokemonMenu") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="party"
        return
      end
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PartyMenu.__gen3uiOriginalDrawWidescreen,self,winW,winH)
    end
  end

  local okSummary,SummaryMenu=pcall(require,"src.ui.gen2.SummaryMenu")
  if okSummary and type(SummaryMenu)=="table"
      and not SummaryMenu.__gen3uiVisualPatched then
    SummaryMenu.__gen3uiVisualPatched=true
    SummaryMenu.__gen3uiOriginalOpaque=SummaryMenu.isOpaque
    SummaryMenu.__gen3uiOriginalNew=SummaryMenu.new
    SummaryMenu.isOpaque=false
    SummaryMenu.__gen3uiOriginalUpdate=SummaryMenu.update
    SummaryMenu.__gen3uiOriginalDraw=SummaryMenu.draw
    SummaryMenu.__gen3uiOriginalDrawWidescreen=SummaryMenu.drawWidescreen
    SummaryMenu.__gen3uiOriginalDrawsWidescreen=SummaryMenu.drawsWidescreen
    SummaryMenu.__gen3uiOriginalWantsFillScale=SummaryMenu.wantsFillScale
    SummaryMenu.drawsWidescreen=function(self)
      if GoldCompat.pokemonPresentationEnabled() then return false end
      return callOriginal(SummaryMenu.__gen3uiOriginalDrawsWidescreen,self)
    end
    SummaryMenu.wantsFillScale=function(self)
      if GoldCompat.pokemonPresentationEnabled() then return false end
      return callOriginal(SummaryMenu.__gen3uiOriginalWantsFillScale,self)
    end
    if type(SummaryMenu.__gen3uiOriginalNew)=="function" then
      SummaryMenu.new=function(...)
        local self=SummaryMenu.__gen3uiOriginalNew(...)
        if type(self)=="table" then
          self.isOpaque=GoldCompat.pokemonPresentationEnabled()
            and false or SummaryMenu.__gen3uiOriginalOpaque
        end
        return self
      end
    end

    SummaryMenu.update=function(self,dt)
      if GoldCompat.pokemonPresentationEnabled() then self.isOpaque=false end
      local input=self.game and self.game.input
      if GoldCompat.pokemonPresentationEnabled() and input
          and self.__colosseumMoveManager then
        if GoldCompat.moveManagerPresentationEnabled() then
          return GoldCompat.updateMoveManager(self,input)
        end
        self.__colosseumMoveManager=nil
      end
      if not GoldCompat.pokemonPresentationEnabled() or not input
          or not self.mon or self.mon.isEgg or self.moveDetail then
        return SummaryMenu.__gen3uiOriginalUpdate(self,dt)
      end

      -- The rebuilt three-tier summary is a direct navigation surface:
      -- left/right select STATUS, MOVES, or PROFILE; up/down change Pokémon;
      -- B returns. The cartridge's extra A-to-advance/close fallthrough is
      -- intentionally removed so a single accidental press cannot skip a tier
      -- or dismiss the screen.
      if input:wasPressed("b") then
        if type(self.close)=="function" then self:close() end
        return
      elseif input:wasPressed("left") then
        if type(self.turnPage)=="function" then self:turnPage(-1) end
        self.__colosseumTmPage=1
        return
      elseif input:wasPressed("right") then
        if type(self.turnPage)=="function" then self:turnPage(1) end
        self.__colosseumTmPage=1
        return
      elseif input:wasPressed("up") then
        if type(self.switchMon)=="function" then self:switchMon(-1) end
        self.__colosseumTmPage=1
        return
      elseif input:wasPressed("down") then
        if type(self.switchMon)=="function" then self:switchMon(1) end
        self.__colosseumTmPage=1
        return
      elseif input:wasPressed("select")
          and self.page==(SummaryMenu.GREEN_PAGE or 2)
          and GoldCompat.moveManagerPresentationEnabled() then
        GoldCompat.openMoveManager(self)
        return
      elseif input:wasPressed("select") and self.page==3 then
        local pages=math.max(1,tonumber(self.__colosseumTmPages) or 1)
        self.__colosseumTmPage=((tonumber(self.__colosseumTmPage) or 1)%pages)+1
        return
      elseif input:wasPressed("a") then
        return
      end
    end

    SummaryMenu.draw=function(self,...)
      if GoldCompat.pokemonPresentationEnabled() then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="summary"
        return
      end
      self.isOpaque=SummaryMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(SummaryMenu.__gen3uiOriginalDraw,self,...)
    end
    SummaryMenu.drawWidescreen=function(self,winW,winH)
      if GoldCompat.pokemonPresentationEnabled() then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="summary"
        return
      end
      self.isOpaque=SummaryMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(SummaryMenu.__gen3uiOriginalDrawWidescreen,self,winW,winH)
    end
  end

  local okDex,PokedexMenu=pcall(require,"src.ui.gen2.PokedexMenu")
  if okDex and type(PokedexMenu)=="table" and not PokedexMenu.__gen3uiVisualPatched then
    PokedexMenu.__gen3uiVisualPatched=true
    PokedexMenu.__gen3uiOriginalOpaque=PokedexMenu.isOpaque
    PokedexMenu.isOpaque=false
    PokedexMenu.__gen3uiOriginalNew=PokedexMenu.new
    PokedexMenu.__gen3uiOriginalUpdate=PokedexMenu.update
    PokedexMenu.__gen3uiOriginalDraw=PokedexMenu.draw
    PokedexMenu.__gen3uiOriginalDrawPanel=PokedexMenu.drawPanel
    PokedexMenu.__gen3uiOriginalDrawWidescreen=PokedexMenu.drawWidescreen
    PokedexMenu.__gen3uiOriginalDrawsWidescreen=PokedexMenu.drawsWidescreen
    PokedexMenu.__gen3uiOriginalWantsFillScale=PokedexMenu.wantsFillScale
    PokedexMenu.drawsWidescreen=function(self)
      if goldScreenEnabled("revampedPokedex") then return false end
      return callOriginal(PokedexMenu.__gen3uiOriginalDrawsWidescreen,self)
    end
    PokedexMenu.wantsFillScale=function(self)
      if goldScreenEnabled("revampedPokedex") then return false end
      return callOriginal(PokedexMenu.__gen3uiOriginalWantsFillScale,self)
    end

    PokedexMenu.update=function(self,dt)
      if goldScreenEnabled("revampedPokedex") and not self.newEntry then
        local input=self.game and self.game.input

        -- The native SELECT shortcut opens the cartridge-era PokéDex Option
        -- screen (NEW/OLD/A-Z modes). It has no place in the rebuilt dossier
        -- workflow and was also leaking an unthemed fullscreen state.
        if input and input:wasPressed("select") then return end

        if self.view=="list" and input and self.__colosseumDexAction then
          if input:wasPressed("up") or input:wasPressed("left") then
            self.__colosseumDexActionIndex=1
            return
          elseif input:wasPressed("down") or input:wasPressed("right") then
            self.__colosseumDexActionIndex=2
            return
          elseif input:wasPressed("b") then
            self.__colosseumDexAction=nil
            self.__colosseumDexActionIndex=nil
            return
          elseif input:wasPressed("a") then
            local action=self.__colosseumDexActionIndex or 1
            self.__colosseumDexAction=nil
            self.__colosseumDexActionIndex=nil
            if action==2 then
              self.view="locations"
              self.__gen3uiDexLocationScroll=0
            else
              self.view="entry"
            end
            return
          end
          return
        elseif self.view=="list" and input and input:wasPressed("a") then
          self.__colosseumDexAction=true
          self.__colosseumDexActionIndex=1
          return
        elseif self.view=="entry" and input then
          if input:wasPressed("a") then
            self.view="list"
            return
          elseif input:wasPressed("b") then
            self.view="list"
            return
          end
          -- PAGE/AREA/CRY/PRNT are replaced by the modern DATA -> LOCATIONS
          -- workflow, so no native action-bar input leaks through.
          return
        elseif self.view=="locations" and input then
          local rows=self.__gen3uiDexLocationRows
            or GoldCompat.dexCatchLocations(self,
              self:current() and self:current().species)
          local visible=7
          local maxScroll=math.max(0,#rows-visible)

          if input:wasPressed("up") then
            self.__gen3uiDexLocationScroll=math.max(0,
              (self.__gen3uiDexLocationScroll or 0)-1)
            return
          elseif input:wasPressed("down") then
            self.__gen3uiDexLocationScroll=math.min(maxScroll,
              (self.__gen3uiDexLocationScroll or 0)+1)
            return
          elseif input:wasPressed("a") or input:wasPressed("b") then
            self.view="entry"
            self.__gen3uiDexLocationScroll=0
            return
          end
          return
        end
      end
      return PokedexMenu.__gen3uiOriginalUpdate(self,dt)
    end

    PokedexMenu.draw=function(self,...)
      if goldScreenEnabled("revampedPokedex") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pokedex"
        return
      end
      self.isOpaque=PokedexMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PokedexMenu.__gen3uiOriginalDraw,self,...)
    end
    PokedexMenu.drawWidescreen=function(self,winW,winH)
      if goldScreenEnabled("revampedPokedex") then
        self.isOpaque=false
        self.__gen3uiGoldOverlayKind="pokedex"
        return
      end
      self.isOpaque=PokedexMenu.__gen3uiOriginalOpaque
      self.__gen3uiGoldOverlayKind=nil
      return callOriginal(PokedexMenu.__gen3uiOriginalDrawWidescreen,self,winW,winH)
    end

    -- Belt-and-suspenders instance override: Screens may have resolved the
    -- Gen2PokedexMenu factory before this patch, but new instances still pass
    -- through this constructor and receive our widescreen renderer directly.
    PokedexMenu.new=function(...)
      local self=PokedexMenu.__gen3uiOriginalNew(...)
      if not goldScreenEnabled("revampedPokedex") then
        self.isOpaque=PokedexMenu.__gen3uiOriginalOpaque
        return self
      end
      self.isOpaque=false
      self.__gen3uiGoldOverlayKind="pokedex"
      self.draw=function(inst)
        inst.isOpaque=false
        inst.__gen3uiGoldOverlayKind="pokedex"
      end
      self.drawWidescreen=function(inst,winW,winH)
        inst.isOpaque=false
        inst.__gen3uiGoldOverlayKind="pokedex"
      end
      self.update=PokedexMenu.update
      self.drawsWidescreen=function() return false end
      self.wantsFillScale=function() return false end
      return self
    end
  end

  GoldCompat.coreMenusInstalled=true
end

function GoldCompat.incomingCallerBox(game)
  local states=game and game.stack and game.stack.states or {}
  for i=#states,1,-1 do
    local state=states[i]
    if state and (state.gen2CallerBox or state.__colosseumIncomingCall) then
      return state
    end
  end
  return nil
end

function GoldCompat.drawIncomingCallerBox(box)
  if not box then return false end
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  local x,y,w,h=38,5,84,25
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0,0,0,0.30)
  roundedRect("fill",x+2,y+2,w,h,5)
  G.setColor(0.008,0.035,0.038,0.96)
  roundedRect("fill",x,y,w,h,5)
  G.setColor(0.28,0.60,0.57,0.98)
  G.setLineWidth(1.0)
  roundedRect("line",x,y,w,h,5)
  G.setColor(0.03,0.20,0.15,0.98)
  roundedRect("fill",x+4,y+4,18,h-8,3)
  G.setColor(0.28,1.00,0.56,1)
  G.circle("line",x+13,y+12.5,5)
  G.line(x+10.5,y+9.5,x+15.5,y+15.5)
  G.pop()

  finalText("INCOMING CALL",x+26,y+4,1.45,{0.33,1.00,0.58,1},ox,oy,sc)
  finalTextFitted(tostring(box.name or "UNKNOWN"),x+26,y+10,2.45,1.55,
    {0.96,1.00,0.97,1},ox,oy,sc,"left",50,7.0)
  finalTextFitted(tostring((box.className and box.className~="" and box.className)
      or "POKéGEAR PHONE"),x+26,y+18,1.28,0.95,{0.58,0.76,0.71,1},
    ox,oy,sc,"left",50,4.5)
  return true
end

function GoldCompat.installPokegearUI()
  if GoldCompat.generation~="gen2" or GoldCompat.pokegearInstalled then return end

  local ok,Pokegear=pcall(require,"src.ui.gen2.Pokegear")
  if not ok or type(Pokegear)~="table" then return end
  if Pokegear.__gen3uiPatched then
    GoldCompat.pokegearInstalled=true
    return
  end

  Pokegear.__gen3uiPatched=true
  Pokegear.__gen3uiOriginalOpaque=Pokegear.isOpaque
  Pokegear.__gen3uiOriginalNew=Pokegear.new
  Pokegear.isOpaque=false
  Pokegear.__gen3uiOriginalDrawPanel=Pokegear.drawPanel
  Pokegear.__gen3uiOriginalDrawWidescreen=Pokegear.drawWidescreen
  Pokegear.__gen3uiOriginalUpdate=Pokegear.update

  if type(Pokegear.__gen3uiOriginalNew)=="function" then
    Pokegear.new=function(...)
      local self=Pokegear.__gen3uiOriginalNew(...)
      if type(self)=="table" then
        self.isOpaque=goldScreenEnabled("revampedPokegearUI")
          and false or Pokegear.__gen3uiOriginalOpaque
      end
      return self
    end
  end

  -- Incoming calls use a separate native CallerBox state, not the Pokégear
  -- screen itself. Suppress only that cartridge strip while the Pokégear UI
  -- option is active; renderHudUnderlays paints our caller card underneath the
  -- still-native call text/script lifecycle.
  local okCaller,CallerBox=pcall(require,"src.ui.gen2.CallerBox")
  if okCaller and CallerBox and type(CallerBox.draw)=="function"
      and not CallerBox.__gen3uiPatched then
    CallerBox.__gen3uiPatched=true
    CallerBox.__gen3uiOriginalDraw=CallerBox.draw
    CallerBox.draw=function(self,...)
      if goldScreenEnabled("revampedPokegearUI") then
        self.__colosseumIncomingCall=true
        return
      end
      return callOriginal(CallerBox.__gen3uiOriginalDraw,self,...)
    end
  end

  -- drawPanel is used whenever a phone script/dialogue state sits above the
  -- PokéGear. Keep our themed underlying surface there too so calls never
  -- expose Gold's cartridge UI.
  Pokegear.drawPanel=function(self,...)
    if goldScreenEnabled("revampedPokegearUI") then
      return GoldCompat.withColosseumSkin(GoldCompat.drawPokegearPanel,self)
    end
    return callOriginal(Pokegear.__gen3uiOriginalDrawPanel,self,...)
  end

  -- Gold's clock card is mostly informational, but the original UI's prompt
  -- still lets the player leave/switch it. Our widescreen shell previously
  -- opened a dead card. Restore useful navigation without taking ownership of
  -- Phone/Map/Radio logic from the engine.
  Pokegear.update=function(self,dt,...)
    if goldScreenEnabled("revampedPokegearUI") and not self.fly
        and self.mode=="card" then
      local card=self.card and self:card() or nil
      if card and card.id=="clock" then
        local input=self.game and self.game.input
        if input then
          if input:wasPressed("right") then
            self:switchCard("map","phone","radio")
            return
          elseif input:wasPressed("left") then
            self:switchCard("radio","phone","map")
            return
          elseif input:wasPressed("a") or input:wasPressed("b") then
            self.mode="strip"
            return
          end
        end
      end
    end
    return callOriginal(Pokegear.__gen3uiOriginalUpdate,self,dt,...)
  end

  Pokegear.drawWidescreen=function(self,winW,winH)
    if goldScreenEnabled("revampedPokegearUI") then
      return GoldCompat.withColosseumSkin(
        GoldCompat.drawPokegearWidescreen,self,winW,winH)
    end
    self.isOpaque=Pokegear.__gen3uiOriginalOpaque
    return callOriginal(
      Pokegear.__gen3uiOriginalDrawWidescreen,self,winW,winH)
  end

  GoldCompat.pokegearInstalled=true
end


function GoldCompat.buildLevelUpPopup(state,event)
  local battle=state and state.battle
  local mon=battle and battle.party and event and event.index
      and battle.party[event.index]
  if not mon then return nil end

  local okMon,Mon=pcall(require,"src.battle.gen2.Mon")
  local def=state.pokemon and mon.species and state.pokemon[mon.species]
  local newStats=mon.stats or {}
  local oldStats={}
  if okMon and Mon and def and type(Mon.stats)=="function" then
    local ok,stats=pcall(Mon.stats,def.baseStats,mon.dvs,
      math.max(1,(event.level or mon.level or 1)-1),mon.statExp)
    if ok and type(stats)=="table" then oldStats=stats end
  end

  local function row(label,key)
    local now=tonumber(newStats[key]) or 0
    local old=tonumber(oldStats[key]) or now
    return {label=label,value=now,delta=now-old}
  end

  return {
    mon=mon,
    name=mon.nickname or mon.name or mon.species or "POKéMON",
    level=event.level or mon.level or 1,
    rows={
      row("HP","hp"),
      row("ATTACK","attack"),
      row("DEFENSE","defense"),
      row("SP. ATK","specialAttack"),
      row("SP. DEF","specialDefense"),
      row("SPEED","speed"),
    },
  }
end

function GoldCompat.drawGoldBattleLevelUp(state)
  if not featureEnabled("revampedLevelUpUI") then
    if state then state.__gen3uiLevelPopup=nil end
    return false
  end
  local pop=state and state.__gen3uiLevelPopup
  if not pop then return false end
  local G=love.graphics
  local ox,oy,sc=finalCanvas()
  -- Keep the card centered but pull both side edges inward. At widescreen
  -- scales the previous 62-unit width grazed the two portrait/status frames.
  local x,y,w,h=53,18,54,96

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(0.02,0.03,0.03,0.52)
  roundedRect("fill",x+2,y+2,w,h,4)
  G.setColor(0.075,0.085,0.08,0.98)
  roundedRect("fill",x,y,w,h,4)
  G.setColor(0.32,0.35,0.32,1)
  roundedRect("line",x,y,w,h,4)
  G.setColor(0.79,0.64,0.20,1)
  G.rectangle("fill",x+5,y+5,w-10,1.2)
  G.setColor(0.14,0.15,0.14,1)
  roundedRect("fill",x+6,y+18,w-12,12,2)
  G.pop()

  finalText("LEVEL UP!",x+7,y+8,3.8,{0.97,0.97,0.93,1},ox,oy,sc)
  finalText("Lv. "..tostring(pop.level),x+w-22,y+8,2.9,
    {0.89,0.79,0.42,1},ox,oy,sc,"right",15)
  finalText(pop.name,x+10,y+21,2.9,{0.97,0.97,0.94,1},
    ox,oy,sc,"left",w-20)

  for i,row in ipairs(pop.rows or {}) do
    local yy=y+36+(i-1)*8
    finalText(row.label,x+9,yy,2.35,{0.70,0.72,0.68,1},ox,oy,sc)
    finalText(tostring(row.value),x+w-23,yy,2.8,
      {0.97,0.97,0.94,1},ox,oy,sc,"right",11)
    local d=tonumber(row.delta) or 0
    finalText((d>=0 and "+" or "")..tostring(d),x+w-13,yy,2.05,
      d>0 and {0.34,0.85,0.49,1} or {0.62,0.64,0.61,1},
      ox,oy,sc,"right",8)
  end

  finalText("A  CONTINUE",x+w-27,y+h-8,1.9,
    {0.70,0.72,0.68,1},ox,oy,sc,"right",23)
  return true
end

function GoldCompat.enemyBallsRemaining(state)
  local party=state and state.battle and state.battle.enemyParty or {}
  local n=0
  for _,mon in ipairs(party) do
    if mon and not mon.isEgg and (mon.hp or 0)>0 then n=n+1 end
  end
  return n,#party
end

function GoldCompat.cbeOwnsEnemyTrainer(state)
  if not (state and state.battle and not state.battle.wild) then return false end
  if not (modRef and type(modRef.find)=="function") then return false end
  local ok,handle=pcall(modRef.find,"COLOSSEUM_BATTLE_ENVIRONMENTS")
  if not ok or not handle then
    ok,handle=pcall(modRef.find,modRef,"COLOSSEUM_BATTLE_ENVIRONMENTS")
  end
  if not (ok and handle and type(handle.exports)=="table"
      and type(handle.exports.status)=="function") then return false end
  local statusOk,status=pcall(handle.exports.status)
  if not (statusOk and type(status)=="table") then return false end
  local trainer=status.trainer
  return type(trainer)=="table" and trainer.active==true
end

function GoldCompat.drawGoldTrainerSwitchOverlay(state)
  -- CBE already owns native trainer-picture suppression when its 3D enemy
  -- actor is live. Do not bypass that contract by redrawing Gold's raw
  -- trainer frontpic during the KO/replacement handoff.
  if GoldCompat.cbeOwnsEnemyTrainer(state) then
    if state then state.__gen3uiTrainerSwitch=nil end
    return false
  end
  local tr=state and state.__gen3uiTrainerSwitch
  if not (tr and state.enemyTrainerImage) then return false end

  local G=love.graphics
  local ox,oy,sc=finalCanvas()
  local frames=12
  local phase=math.min(1,(tr.frame or 0)/frames)
  local t=(tr.mode=="out") and (1-phase) or phase
  t=math.max(0,math.min(1,t))

  local img=state.enemyTrainerImage
  local iw,ih=img:getDimensions()

  -- Exact Gen 2 enemy pic box used by the intro: tile (12,0), 7x7.
  local boxX,boxY,boxSize=96,0,56
  local scale=1
  if type(state.picScale)=="function" then
    local ok,value=pcall(state.picScale,state,state.enemyTrainerPath,nil,false)
    if ok and tonumber(value) then scale=tonumber(value) end
  end

  local px=boxX+(boxSize-iw*scale)/2
  local py=boxY+(boxSize-ih*scale)
  -- Slide from the right into the normal battle-intro position.
  px=px+(1-t)*boxSize

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  G.setColor(1,1,1,1)

  local drew=false
  local okPal,Palettes=pcall(require,"src.world.gen2.Palettes")
  local okGbc,GbcPalette=pcall(require,"src.render.GbcPalette")
  local colors=okPal and state.palettes and
    Palettes.trainerColors(state.palettes,state.enemyTrainerClass) or nil

  local function body()
    G.draw(img,px,py,0,scale,scale)
  end
  if colors and okGbc and GbcPalette and GbcPalette.available
      and GbcPalette.available() then
    local ok=pcall(GbcPalette.with,colors,body)
    drew=ok
  end
  if not drew then body() end

  -- Party balls already live above the permanent battle HUD. Never redraw a
  -- second set during a trainer switch; the duplicate overlapped player HP.
  G.pop()
  return true
end

function GoldCompat.drawEnemyTrainerPartyIndicator(state)
  -- Intro only.  During replacement switches the already-working
  -- drawGoldTrainerSwitchOverlay owns this indicator instead.
  if not (state and state.battle and not state.battle.wild
      and state.enemyTrainerImage and state.showEnemyTrainer
      and state.phase=="intro" and not state.__gen3uiTrainerSwitch) then
    return false
  end

  local remaining,total=GoldCompat.enemyBallsRemaining(state)
  if total<=0 then return false end

  local G=love.graphics
  local ox,oy,sc=finalCanvas()
  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)

  local ballY=12
  local ballX=10
  for i=1,total do
    local alive=i<=remaining
    local cx=ballX+(i-1)*7
    local r=2.35

    if alive then
      G.setColor(0.90,0.18,0.14,1)
      G.arc("fill","pie",cx,ballY,r,math.pi,math.pi*2)
      G.setColor(0.98,0.98,0.94,1)
      G.arc("fill","pie",cx,ballY,r,0,math.pi)
      G.setColor(0.08,0.08,0.07,1)
      G.setLineWidth(0.7)
      G.circle("line",cx,ballY,r)
      G.line(cx-r,ballY,cx+r,ballY)
      G.setColor(0.98,0.98,0.94,1)
      G.circle("fill",cx,ballY,r*0.28)
    else
      G.setColor(0.38,0.39,0.37,0.52)
      G.setLineWidth(0.7)
      G.circle("line",cx,ballY,r)
      G.line(cx-r,ballY,cx+r,ballY)
    end
  end

  G.pop()
  return true
end

function GoldCompat.drawGoldBattleChoice(state)
  if not state then return false end
  local asking=state.phase=="ask-shift"
      or state.phase=="ask-nickname"
      or state.phase=="ask-forget"
      or state.phase=="stop-learning"
  if not asking or (state.messageTimer or 0)>0 then return false end

  local index=state.phase=="ask-shift" and (state.shiftIndex or 1)
      or state.phase=="ask-nickname" and (state.nicknameIndex or 1)
      or (state.forgetChoice or 1)

  local G=love.graphics
  local ox,oy,sc=finalCanvas()
  local x,y,w,h=119,56,37,31

  G.push("all")
  G.translate(ox,oy)
  G.scale(sc,sc)
  -- Compact branch of the same flat, translucent console used by START and
  -- battle commands. No cream donor card or rounded Gen 3 selection capsule.
  drawColosseumRunoffPanel(x,y,w,h,0)

  for i=1,2 do
    local yy=y+4+(i-1)*11
    if index==i then
      drawColosseumRunoffSelection(x+2,yy-1,w-2,9)
    end
  end
  G.pop()

  finalText("YES",x+10,y+5,2.8,
    index==1 and {1,1,1,1} or {0.74,0.87,0.82,1},ox,oy,sc)
  finalText("NO",x+10,y+16,2.8,
    index==2 and {1,1,1,1} or {0.74,0.87,0.82,1},ox,oy,sc)
  return true
end

function GoldCompat.installGoldBattlePresentation()
  if GoldCompat.generation~="gen2" or goldBattleScrubInstalled then return end
  goldBattleScrubInstalled=true

  local ok,GoldBattleState=pcall(require,"src.ui.gen2.BattleState")
  if not (ok and GoldBattleState and type(GoldBattleState.drawPanel)=="function")
      then return end
  if GoldBattleState.__gen3uiPanelScrubbed then return end
  GoldBattleState.__gen3uiPanelScrubbed=true

  local original=GoldBattleState.drawPanel
  GoldBattleState.__gen3uiOriginalAdvanceQueue=GoldBattleState.advanceQueue
  GoldBattleState.__gen3uiOriginalOfferShiftSwitch=GoldBattleState.offerShiftSwitch
  GoldBattleState.__gen3uiOriginalUpdate=GoldBattleState.update

  -- Gold's native level-up stats page is a separate draw path outside the
  -- regular HUD rectangles. Keep its call alive for compatibility, but block
  -- every pixel while our level card or the strict native-UI option owns it.
  if type(GoldBattleState.drawStatsBox)=="function"
      and not GoldBattleState.__gen3uiStatsScrubbed then
    GoldBattleState.__gen3uiStatsScrubbed=true
    local originalStatsBox=GoldBattleState.drawStatsBox
    GoldBattleState.drawStatsBox=function(self,...)
      if GoldCompat.battlePresentationEnabledFor(self)
          or featureEnabled("hideNativeBattleUI") then
        return runDrawInvisible(originalStatsBox,self,...)
      end
      return originalStatsBox(self,...)
    end
  end

  GoldBattleState.advanceQueue=function(self,...)
    -- The next native queue item is still visible here, before the engine
    -- removes it. Capture LEVEL at the same moment the "grew to level" line
    -- becomes current.
    local event=self.queue and self.queue[1]
    -- Gold commits rewards in Battle:resolveFaints before its presentation
    -- queue drains. Freeze at the lethal damage event and release only when
    -- the authoritative `experience` event becomes current: that is the same
    -- step which displays "X gained N EXP. Points!", after faint animation/text.
    if event and event.kind=="damage" and event.side=="enemy"
        and tonumber(event.hp or 1)<=0
        and self.__gen3uiKoExpHold==nil then
      self.__gen3uiKoExpHold=self.shownExp or 0
    elseif event and event.kind=="experience" then
      self.__gen3uiKoExpHold=nil
    elseif event and event.kind=="send" and event.side=="enemy" then
      self.__gen3uiKoExpHold=nil
    end
    if self.__gen3uiLevelPopup and (not event or event.kind~="level") then
      self.__gen3uiLevelPopup=nil
    end
    if event and event.kind=="level" and featureEnabled("revampedLevelUpUI") then
      self.__gen3uiLevelPopup=GoldCompat.buildLevelUpPopup(self,event)
    elseif event and event.kind=="level" then
      self.__gen3uiLevelPopup=nil
    end
    return GoldBattleState.__gen3uiOriginalAdvanceQueue(self,...)
  end

  GoldBattleState.offerShiftSwitch=function(self,mon,...)
    -- Keep the stock Gold trainer-switch flourish only when no external 3D
    -- trainer provider owns the enemy actor. CBE's live trainer must remain
    -- authoritative through lethal damage, the shift prompt and send-out.
    if GoldCompat.cbeOwnsEnemyTrainer(self) then
      self.__gen3uiTrainerSwitch=nil
    else
      self.__gen3uiTrainerSwitch={mode="in",frame=0}
    end
    return GoldBattleState.__gen3uiOriginalOfferShiftSwitch(self,mon,...)
  end

  GoldBattleState.update=function(self,...)
    -- The level-up stat card is a real acknowledgement screen, not a timed
    -- animation.  Hold the underlying Gold battle state here so emulator/game
    -- speed cannot race past it. A (or B) dismisses and then native queue
    -- processing resumes on the following frame.
    if self.__gen3uiLevelPopup then
      local input=self.game and self.game.input
      if input and (input:wasPressed("a") or input:wasPressed("b")) then
        self.__gen3uiLevelPopup=nil
        self.messageTimer=0
        -- Forward this same acknowledgement into Gold's native queue. The old
        -- wrapper consumed it, exposing the native stat page underneath and
        -- forcing a second A press before battle could resume.
        return GoldBattleState.__gen3uiOriginalUpdate(self,...)
      end
      return
    end

    -- Gold's native battle selectors are vertical lists, while the Colosseum
    -- command and move consoles are displayed as 2x2 grids. Own only the four
    -- direction edges for these phases, update the engine's real cursor field,
    -- and then let the native update handle A/B and every battle action.
    local input=self.game and self.game.input
    local gridField
    local gridCount=4
    if GoldCompat.battlePresentationEnabledFor(self) then
      if self.phase=="menu" then
        gridField="menuIndex"
      elseif self.phase=="moves" then
        gridField="moveIndex"
        local shown=self.shownMon and self.shownMon.player
        local live=self.battle and self.battle.player
        local moves=(shown and shown.moves) or (live and live.moves) or {}
        gridCount=math.max(1,math.min(4,#moves))
      elseif self.phase=="choose-forget" then
        gridField="forgetIndex"
      end
    end

    if gridField and input then
      local direction=input:wasPressed("left") and "left"
        or input:wasPressed("right") and "right"
        or input:wasPressed("up") and "up"
        or input:wasPressed("down") and "down"
      if direction then
        local index=math.max(1,math.min(gridCount,tonumber(self[gridField]) or 1))
        local nextIndex=index
        if self.phase=="choose-forget" then
          if direction=="left" or direction=="up" then
            nextIndex=index>1 and index-1 or gridCount
          else
            nextIndex=index<gridCount and index+1 or 1
          end
        else
          local col=(index-1)%2
          if direction=="left" and col==1 then
            nextIndex=index-1
          elseif direction=="right" and col==0 and index+1<=gridCount then
            nextIndex=index+1
          elseif direction=="up" and index>2 then
            nextIndex=index-2
          elseif direction=="down" and index+2<=gridCount then
            nextIndex=index+2
          end
        end
        self[gridField]=nextIndex

        -- choose-forget is wholly represented by this horizontal four-cell
        -- Party strip. Do not forward the same direction to Gold's vertical
        -- list reader; update its authoritative cursor once and wait for the
        -- next frame's A/B confirmation.
        if self.phase=="choose-forget" then
          if nextIndex~=index then
            pcall(function()
              require("src.core.Sound").play(self.game.data,"Press_AB")
            end)
          end
          return
        end

        -- Prevent Gold's list cursor from applying a second, conflicting move.
        local pressed=input.pressed or {}
        local saved={left=pressed.left,right=pressed.right,
          up=pressed.up,down=pressed.down}
        pressed.left=nil; pressed.right=nil
        pressed.up=nil; pressed.down=nil
        local okUpdate,result=pcall(GoldBattleState.__gen3uiOriginalUpdate,self,...)
        pressed.left=saved.left; pressed.right=saved.right
        pressed.up=saved.up; pressed.down=saved.down
        if not okUpdate then error(result) end
        return result
      end
    end

    local before=self.phase
    local result=GoldBattleState.__gen3uiOriginalUpdate(self,...)
    -- replacement prompt. Repair that state without touching native hide/show
    -- behavior for faint/send-out animation phases.
    if self.__gen3uiShiftPicHidden~=nil then
      if self.picHidden and self.enemy and self.enemy.mon
          and self.phase~="enemy-faint" and self.phase~="enemy-sendout" then
        self.picHidden.enemy=false
      end
      self.__gen3uiShiftPicHidden=nil
    end
    local tr=self.__gen3uiTrainerSwitch
    if tr then
      if before=="ask-shift" and self.phase~="ask-shift" and tr.mode=="in" then
        tr.mode="out"
        tr.frame=0
      else
        tr.frame=(tr.frame or 0)+1
      end
      if tr.mode=="out" and tr.frame>=12 then
        self.__gen3uiTrainerSwitch=nil
      end
    end
    return result
  end

end

local function battleOverlayHook(next,battle)
  -- Never paint over the completed battlefield. Wide/native HUD suppression is
  -- handled before those UI primitives draw; this hook only preserves overlay
  -- chaining and active battle ownership.
  next(battle)
  State.activeBattle=battle
end

local function clearStaleOverworldOwnership(game)
  local topNow=topState(game)
  if topNow and not GoldCompat.supportedOverworldMenuState(topNow)
      and not topNow.__gen3uiStart
      and getmetatable(topNow)~=TextBox
      and getmetatable(topNow)~=ChoiceBox
      and getmetatable(topNow)~=NamingScreen
      and topNow~=State.activeBattle then
    State.activeStartMenu=nil
    State.activeBagMenu=nil
    State.activeBagActionMenu=nil
  end
end


function GoldCompat.renderMartForeground(mod,game)
  if not featureEnabled("revampedPokeMartUI") then return false end

  local shopTop=topState(game)
  if not shopTop then return false end

  if shopTop.__gen3uiMartRenderFailed then return false end

  if shopTop.__gen3uiShopMain then
    State.activeShopMenu=shopTop
    State.activeShopList=nil
    State.activeShopQuantity=nil
    local ok,err=pcall(drawShopMainFinal,game,shopTop)
    if not ok then
      shopTop.__gen3uiMartRenderFailed=true
      State.activeShopMenu=nil
      if mod.log then
        mod.log("error","Gen 3 UI Mart main failed; falling back native: "..tostring(err))
      end
      return false
    end
    return true
  end

  if shopTop.__gen3uiShopList then
    State.activeShopList=shopTop
    State.activeShopMenu=nil
    State.activeShopQuantity=nil

    local renderer=shopTop.__gen3uiShopSell
        and drawShopSellBagFinal or drawShopListFinal
    local ok,err=pcall(renderer,game,shopTop)
    if not ok then
      shopTop.__gen3uiMartRenderFailed=true
      if mod.log then
        mod.log("error","Gen 3 UI Mart list failed; falling back native: "
          ..tostring(err))
      end
      return false
    end
    return true
  end

  if shopTop.__gen3uiShopQuantity then
    local under=shopStateInStack(game)
    if under and under.__gen3uiShopList then
      State.activeShopQuantity=shopTop
      local ok,err=pcall(GoldCompat.drawShopQuantityFinal,game,under,shopTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI Mart quantity failed: "..tostring(err))
      end
      return true
    end
  end

  return false
end

function GoldCompat.renderMartUnderlay(game)
  if not featureEnabled("revampedPokeMartUI") then return end
  if not (State.activeDialogueBox or State.activeChoiceBox) then return end

  local shopUnder=shopStateInStack(game)
  if not shopUnder then return end

  if shopUnder.__gen3uiShopList then
    if shopUnder.__gen3uiShopSell then
      pcall(drawShopSellBagFinal,game,shopUnder)
    else
      pcall(drawShopListFinal,game,shopUnder)
    end
  elseif shopUnder.__gen3uiShopMain then
    pcall(drawShopMainFinal,game,shopUnder)
  end
end


function GoldCompat.drawSafariZoneHud(game)
  if not GoldCompat.safariPresentationEnabled() then return false end
  if not (game and game.save and game.save.safari) then return false end
  if battleStateInStack(game) then return false end
  local st=game.save.safari
  local ox,oy,sc=safeFullCanvas()
  local G=love.graphics
  -- Reserve the upper-left safe corner for the persistent Safari budget. The
  -- hanging Start menu occupies the center/right side of the logical canvas.
  local x,y,w,h=5,5,58,18
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  G.setColor(0,0,0,0.30); roundedRect("fill",x+2,y+2,w,h,4)
  G.setColor(0.010,0.050,0.050,0.93); roundedRect("fill",x,y,w,h,4)
  G.setColor(0.22,0.51,0.49,0.96); G.setLineWidth(0.9); roundedRect("line",x,y,w,h,4)
  G.pop()
  finalText("SAFARI ZONE",x+5,y+3,1.75,{0.48,1.00,0.66,1},ox,oy,sc)
  finalText("SNAG "..tostring(math.max(0,tonumber(st.balls) or 0)),x+5,y+10,1.45,
    {0.76,0.87,0.82,1},ox,oy,sc)
  finalText("STEPS "..tostring(math.max(0,tonumber(st.steps) or 0)),x+25,y+10,1.45,
    {0.76,0.87,0.82,1},ox,oy,sc,"right",w-30)
  return true
end

function GoldCompat.nativeOverlayRenderHidden(state)
  if not state then return false end
  local game=state.game or (modRef and modRef.game) or GoldCompat.game
  if not game then return false end
  local stack=game.stack and game.stack.states
  local top=type(stack)=="table" and stack[#stack] or nil

  -- Dialogue/YES-NO is rendered in render.hud, after every world/renderer pass.
  -- Hiding the native state here removes both its pixels and its opacity/palette
  -- ownership while preserving update/input on the real state stack.
  -- Gen I needs the hard final-state kill switch because several renderer
  -- stacks can redraw the native TextBox after our normal adapters. Gen II
  -- already uses the shared TextBox/ChoiceBox adapter; hiding its top state
  -- here prevents that adapter from publishing the active dialogue at all.
  -- Let Gold's real dialogue state reach its themed draw wrapper, while still
  -- suppressing mirrored native underlays below it.
  if GoldCompat.generation=="gen1"
      and featureEnabled("revampedDialogueBoxes") and state==top then
    if GoldCompat.isDialogueTextState(state)
        or GoldCompat.isDialogueChoiceState(state,
          type(stack)=="table" and stack[#stack-1] or nil) then
      return true
    end
  end

  -- When a themed dialogue is sitting over one of our explicitly mirrored
  -- hanging surfaces, omit the native underlay too. renderHudUnderlays redraws
  -- the same authoritative state later, so a renderer mod cannot resurrect its
  -- white/black backing behind our glass UI by changing isOpaque or draw order.
  local dialogueTop=top and (GoldCompat.isDialogueTextState(top)
    or GoldCompat.isDialogueChoiceState(top,
      type(stack)=="table" and stack[#stack-1] or nil))
  if dialogueTop then
    if state==State.activeParty and GoldCompat.pokemonPresentationEnabled() then
      return true
    end
    if (state.__gen3uiBag or state.__gen3uiBagAction)
        and GoldCompat.bagPresentationEnabled() then
      return true
    end
    if (state.__gen3uiPCAccess or state.__gen3uiPCMain or state.__gen3uiPCList
        or state.__gen3uiPCAction or state.__gen3uiPCItemRoot
        or state.__gen3uiPCItemList)
        and featureEnabled("revampedPokemonPC") then
      return true
    end
  end
  return false
end

function GoldCompat.renderHudUnderlays(mod,game)
  clearStaleOverworldOwnership(game)

  -- Incoming phone calls are not a Pokégear screen: Gold pushes CallerBox
  -- beneath the call's text pages. Keep that engine-owned state for timing and
  -- caller identity, but replace its native four-row strip with our hanging
  -- Pokégear caller card.
  if GoldCompat.generation=="gen2" and goldScreenEnabled("revampedPokegearUI") then
    local caller=GoldCompat.incomingCallerBox(game)
    if caller then pcall(GoldCompat.drawIncomingCallerBox,caller) end
  end

  -- Unknown/mod-provided naming screens still fail soft to their own complete
  -- foreground. Patched Gen I/II naming and mail-composition states opt into
  -- the cross-generation Colosseum presentation below.
  local foregroundTop=topState(game)

  -- Player/rival naming can occur before a brand-new Gen I save has finished
  -- constructing its normal overworld/save structures.  While our naming
  -- flow owns the top of the stack, do not let any of the ordinary HUD/menu
  -- underlay probes inspect that half-initialized game.  The base renderer has
  -- already drawn Oak's intro scene; renderCrossgenFlowOverlay paints only the
  -- hanging name-entry deck over it on the next stage.
  if foregroundTop and foregroundTop.__colosseumFlowKind=="naming"
      and GoldCompat.flowPresentationEnabled("naming") then
    State.activeDialogueBox=nil
    State.activeChoiceBox=nil
    clearOverworldMenuState()
    clearPokemonUIState()
    State.activeBattleMoveLearn=nil
    State.activeBattleMoveParty=nil
    State.activeBattleStatBox=nil
    clearShopUIState()
    clearPCUIState()
    return false
  end

  if GoldCompat.namingScreenOwnsForeground(game)
      and not (foregroundTop and foregroundTop.__colosseumFlowKind) then
    State.activeDialogueBox=nil
    State.activeChoiceBox=nil
    clearOverworldMenuState()
    clearPokemonUIState()
    State.activeBattleMoveLearn=nil
    State.activeBattleMoveParty=nil
    State.activeBattleStatBox=nil
    clearShopUIState()
    clearPCUIState()
    return true
  end


  -- Gold compatibility mode leaves unsupported non-battle Gen II
  -- screens native so Gen I-specific renderers never assume structures
  -- that Gold does not provide.
  if GoldCompat.isGen2Game(game) then
    State.activeParty=nil
    State.activeTMParty=nil
    State.activeItemTargetParty=nil
    State.activeMoveLearn=nil
    State.activeTMPromptFlow=nil
    State.activeBagMenu=nil
    State.activeBagActionMenu=nil
    State.activePCMenu=nil
    State.activePCList=nil
    State.activePCActionMenu=nil
    State.activePCAccessMenu=nil
    State.activeShopMenu=nil
    State.activeShopList=nil
    State.activeShopQuantity=nil

    -- Gold START and our Pack/Mart/Center-PC service overlays are
    -- presentation-suppressed and rendered later in render.hud over the live
    -- overworld. Do not consume those screens in the native Gold guard.
    local goldTop=topState(game)
    if goldTop and (goldTop.__gen3uiGoldOverlayKind
        or goldTop.__colosseumFlowKind) then
      return false
    end
    if State.activeStartMenu and uiTopState(game,State.activeStartMenu) then
      return false
    end

    -- Gold performs mid-battle ForgetMove inside BattleState itself rather than
    -- pushing MoveLearnMenu. Replace its normal active-battler move grid with
    -- the Party deck, selected on pendingLearn.index (which may be a bench mon).
    local goldBattle=battleStateInStack(game)
    goldBattle=GoldCompat.sourceBattleState(goldBattle) or goldBattle
    if goldBattle and goldBattle.phase=="choose-forget"
        and goldBattle.pendingLearn
        and GoldCompat.pokemonPresentationEnabled() then
      local partyState,learnAdapter=makeGoldBattleMovePartyState(game,goldBattle)
      if partyState and learnAdapter then
        State.activeGoldBattleMoveLearn=learnAdapter
        State.activeBattleMoveParty=partyState
        local okForget,errForget=pcall(GoldCompat.drawGoldPartyMenu,partyState,
          love.graphics.getWidth(),love.graphics.getHeight())
        if okForget then return true end
        if mod.log then
          mod.log("error","Colosseum Gold choose-forget Party failed: "..
            tostring(errForget))
        end
      end
    else
      State.activeGoldBattleMoveLearn=nil
      if State.activeBattleMoveParty
          and State.activeBattleMoveParty.__gen3uiGoldBattleMoveParty then
        State.activeBattleMoveParty=nil
      end
    end

    -- Shared Gold TextBox/ChoiceBox owns the foreground. Its native draw is
    -- suppressed by installDialogueThemeDirect(), so allow the next HUD stage
    -- to render the existing Gen 3 dialogue/choice presentation.  This check
    -- follows choose-forget because that phase can retain a dialogue owner
    -- while its Party-based replacement picker must be the visible foreground.
    if State.activeDialogueBox or State.activeChoiceBox then
      return false
    end

    -- A Gen II level-up MoveLearnMenu is pushed above the battle. Handle that
    -- foreground before battleOwnsForeground() rejects the covered battle, and
    -- render the same Party/move-replacement deck used by TM/HM teaching. The
    -- native MoveLearnMenu continues to own cursor input and callbacks.
    local goldMoveLearn=State.activeBattleMoveLearn
    local goldMoveTop=topState(game)
    if goldMoveLearn and goldMoveTop==goldMoveLearn
        and stateExistsInStack(game,goldMoveLearn)
        and GoldCompat.pokemonPresentationEnabled() then
      if not State.activeBattleMoveParty
          or State.activeBattleMoveParty.__moveLearnOwner~=goldMoveLearn then
        State.activeBattleMoveParty=makeBattleMovePartyState(game,goldMoveLearn)
        if State.activeBattleMoveParty then
          State.activeBattleMoveParty.__moveLearnOwner=goldMoveLearn
        end
      end
      if State.activeBattleMoveParty then
        local okLearn,errLearn=pcall(drawPartyFinal,game,State.activeBattleMoveParty)
        if okLearn then return true end
        State.activeBattleMoveParty=nil
        if mod.log then
          mod.log("error","Colosseum Gold battle MoveLearn Party failed: "..
            tostring(errLearn))
        end
      end
    elseif goldMoveLearn and not stateExistsInStack(game,goldMoveLearn) then
      State.activeBattleMoveLearn=nil
      State.activeBattleMoveParty=nil
    end

    local battle=State.activeBattle
    -- Safari encounter setup does not consistently emit battle.overlay on all
    -- engine/generation paths. Recover the authoritative state from the stack
    -- so presentation can begin without taking ownership of battle creation.
    if not battle then
      local stackedBattle=battleStateInStack(game)
      local stackedVisual=GoldCompat.presentBattleState(stackedBattle)
      if stackedBattle and GoldCompat.resolvedSafariState(stackedVisual or stackedBattle) then
        battle=stackedBattle
        State.activeBattle=stackedBattle
      end
    end
    if not GoldCompat.battlePresentationEnabledFor(battle) then
      State.activeBattle=nil
      return true
    end
    if not battleInStack(game,battle) or not battleOwnsForeground(game,battle) then
      return true
    end

    local visualBattle=GoldCompat.presentBattleState(battle)

    -- Colosseum is routed HERE on Gold because the Gen 2 compatibility layer
    -- consumes battle rendering inside renderHudUnderlays before the generic
    -- renderHudBattleLayer is reached. Safari deliberately uses its dedicated
    -- presentation-only path so the native Safari encounter can initialize
    -- without being treated as a normal player-vs-enemy battle.
    if featureEnabled("colosseumBattleUI")
        and GoldCompat.safariPresentationEnabled()
        and GoldCompat.ColosseumUI
        and visualBattle and GoldCompat.resolvedSafariState(visualBattle)
        and type(GoldCompat.ColosseumUI.drawSafari)=="function" then
      if GoldCompat.ColosseumUI.setIconsEnabled then
        pcall(GoldCompat.ColosseumUI.setIconsEnabled,
          featureEnabled("colosseumIcons"))
      end
      local okSafari,drewSafari=pcall(
        GoldCompat.ColosseumUI.drawSafari,game,visualBattle,battle
      )
      if not okSafari and mod.log then
        mod.log("error","Colosseum Gold Safari renderer failed: "..tostring(drewSafari))
      end
      if okSafari and drewSafari then return true end
      -- Fail soft into the existing Safari renderer if presentation fails.
    elseif featureEnabled("colosseumBattleUI")
        and GoldCompat.ColosseumUI
        and GoldCompat.ColosseumUI.supported(visualBattle) then
      if GoldCompat.ColosseumUI.setIconsEnabled then
        pcall(GoldCompat.ColosseumUI.setIconsEnabled,
          featureEnabled("colosseumIcons"))
      end
      local okCol,drewCol=pcall(
        GoldCompat.ColosseumUI.draw,game,visualBattle,battle
      )
      if not okCol and mod.log then
        mod.log("error","Colosseum Gold renderer failed: "..tostring(drewCol))
      end
      if okCol and drewCol then
        -- These are native Gold flow overlays layered above the common
        -- Colosseum HUD. They must run before this successful-render return;
        -- otherwise level-up stats, switch animation, trainer party balls and
        -- YES/NO battle prompts disappear only in Gen II.
        local okExtra,errExtra=pcall(function()
          GoldCompat.drawEnemyTrainerPartyIndicator(battle)
          GoldCompat.drawGoldTrainerSwitchOverlay(battle)
          GoldCompat.drawGoldBattleChoice(battle)
          GoldCompat.drawGoldBattleLevelUp(battle)
        end)
        if not okExtra and mod.log then
          mod.log("error","Colosseum Gold supplemental overlay failed: "..
            tostring(errExtra))
        end
        return true
      end
      -- Fail soft to the standard Gen 3-inspired Gold renderer.
    end

    local cmd=commandGeometry()
    local s=hudScale()

    love.graphics.push("all")
    local okStatus,errStatus=pcall(function()
      if shouldDrawStatusHUD(game,visualBattle) then
        drawEnemyHUD(visualBattle,s)
        drawPlayerHUD(visualBattle,s,cmd)
      end
    end)

    -- Gender is purely decorative and isolated from the core HP/name/EXP pass.
    -- A gender-render failure can no longer suppress either battle HUD.
    if okStatus and shouldDrawStatusHUD(game,visualBattle) then
      pcall(GoldCompat.drawBattleGenderOverlay,visualBattle,s,cmd)
    end
    love.graphics.pop()

    love.graphics.push("all")
    local okUI,errUI=pcall(function()
      drawDialogue(visualBattle)
      drawCommandMenu(visualBattle)
      drawMoveSelect(visualBattle)
      GoldCompat.drawEnemyTrainerPartyIndicator(battle)
      GoldCompat.drawGoldTrainerSwitchOverlay(battle)
      GoldCompat.drawGoldBattleChoice(battle)
      GoldCompat.drawGoldBattleLevelUp(battle)
    end)
    love.graphics.pop()

    if mod.log then
      if not okStatus then
        mod.log("error","Gen 3 UI Gold battle HUD failed: "..tostring(errStatus))
      end
      if not okUI then
        mod.log("error","Gen 3 UI Gold battle panels failed: "..tostring(errUI))
      end
    end
    return true
  end

  if GoldCompat.renderMartForeground(mod,game) then return true end

  local pushedBattle=battleStateInStack(game)
  local topForBattle=topState(game)

  if State.activeBattleMoveLearn
      and topForBattle==State.activeBattleMoveLearn
      and pushedBattle
      and GoldCompat.battlePresentationEnabledFor(pushedBattle)
      and GoldCompat.pokemonPresentationEnabled() then
    State.activeBattle=pushedBattle

    if not State.activeBattleMoveParty then
      State.activeBattleMoveParty=makeBattleMovePartyState(game,State.activeBattleMoveLearn)
    end

    if State.activeBattleMoveParty then
      local okParty,errParty=pcall(drawPartyFinal,game,State.activeBattleMoveParty)
      if not okParty then
        State.activeBattleMoveParty=nil
        if mod.log then
          mod.log("error","Gen 3 UI battle MoveLearn Party failed; native fallback: "
            ..tostring(errParty))
        end
        -- Do not terminate the HUD pass on a presentation failure.
      else
        return true
      end
    end
  elseif State.activeBattleMoveLearn
      and not stateExistsInStack(game,State.activeBattleMoveLearn) then
    State.activeBattleMoveLearn=nil
    State.activeBattleMoveParty=nil
  end


  -- Bill's PC / storage screens use the same full-resolution visual
  -- language as Party. Only explicitly marked PC states are intercepted.
  local pcTop=topState(game)
  if pcTop and GoldCompat.itemPcPresentationEnabled() then
    local itemUnder=pcItemListStateInStack(game)
    if pcTop.__gen3uiPCItemQuantity and itemUnder then
      pcall(drawPCItemStorageFinal,game,itemUnder,false)
      pcall(drawPCItemQuantityOverlay,pcTop)
      return true
    elseif pcTop.__gen3uiPCItemChoice and itemUnder then
      pcall(drawPCItemStorageFinal,game,itemUnder,false)
      pcall(drawPCItemChoiceOverlay,pcTop)
      return true
    end
  end

  if pcTop and isPCOwnedState(pcTop) and featureEnabled("revampedPokemonPC") then
    if pcTop.__gen3uiPCItemRoot and GoldCompat.itemPcPresentationEnabled() then
      local ok,err=pcall(drawPCItemStorageFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Colosseum Item Storage root renderer failed: "..tostring(err))
      end
      return true
    elseif pcTop.__gen3uiPCItemList and GoldCompat.itemPcPresentationEnabled() then
      local ok,err=pcall(drawPCItemStorageFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Colosseum Item Storage list renderer failed: "..tostring(err))
      end
      return true
    elseif pcTop.__gen3uiPCAccess then
      State.activePCAccessMenu=pcTop
      State.activePCMenu=nil
      State.activePCList=nil
      State.activePCActionMenu=nil
      local ok,err=pcall(drawPCAccessFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC access renderer failed: "..tostring(err))
      end
      return true
    elseif pcTop.__gen3uiPCMain then
      State.activePCMenu=pcTop
      State.activePCAccessMenu=nil
      State.activePCList=nil
      State.activePCActionMenu=nil
      local ok,err=pcall(drawPCMainFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC main renderer failed: "..tostring(err))
      end
      return true
    elseif pcTop.__gen3uiPCList then
      State.activePCList=pcTop
      State.activePCAccessMenu=nil
      State.activePCMenu=nil
      State.activePCActionMenu=nil
      local ok,err=pcall(drawPCListFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC list renderer failed: "..tostring(err))
      end
      return true
    elseif pcTop.__gen3uiPCAction then
      State.activePCActionMenu=pcTop
      local ok,err=pcall(drawPCActionFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC action renderer failed: "..tostring(err))
      end
      return true
    end
  end

  if State.activeMoveLearn and not stateExistsInStack(game, State.activeMoveLearn) then
    State.activeMoveLearn = nil
  end
  if State.activeTMPromptFlow and not stateExistsInStack(game, State.activeTMPromptFlow) then
    State.activeTMPromptFlow = nil
  end

  -- Generic Bag item target picker: stones, medicine, PP items, etc.
  local itemPartyTop=topState(game)
  if itemPartyTop
      and (itemPartyTop.__gen3uiItemTarget
        or itemPartyTop.__gen3uiKeepTMBackground)
      and GoldCompat.pokemonPresentationEnabled() then
    State.activeItemTargetParty=itemPartyTop
    State.activeParty=itemPartyTop
    State.activeBagActionMenu=nil
    State.activeBagMenu=nil

    local okItemParty,errItemParty=pcall(drawPartyFinal,game,itemPartyTop)
    if not okItemParty then
      if mod.log then
        mod.log("error","Gen 3 UI item-target Party renderer failed: "
          ..tostring(errItemParty))
      end
    else
      return true
    end
  elseif State.activeItemTargetParty
      and not stateExistsInStack(game,State.activeItemTargetParty) then
    State.activeItemTargetParty=nil
  end

  -- Bag-owned USE/TOSS menu. Detect the actual top state directly so the
  -- themed Bag+action overlay exists on the very first frame, before Menu.draw
  -- has had any chance to set ownership.
  local bagActionTop=topState(game)
  if bagActionTop
      and bagActionTop.__gen3uiBagAction
      and GoldCompat.bagPresentationEnabled() then
    State.activeBagActionMenu=bagActionTop
    local bag=bagStateForMenu(game)

    if bag then
      local okBagBg,errBagBg=pcall(drawBagFinal,game,bag)
      if (not okBagBg) and mod.log then
        mod.log("error","Gen 3 UI Bag action background failed: "..tostring(errBagBg))
      end

      local okAction,errAction=pcall(GoldCompat.drawBagActionFinal,game,bagActionTop)
      if (not okAction) and mod.log then
        mod.log("error","Gen 3 UI Bag action overlay failed: "..tostring(errAction))
      end
      return true
    end
  elseif State.activeBagActionMenu
      and not stateExistsInStack(game,State.activeBagActionMenu) then
    State.activeBagActionMenu=nil
  end

  -- Mart SELL keeps the exact custom Bag visible while quantity and YES/NO
  -- states sit above it.  These top states are native transaction controls;
  -- only their chrome is replaced, so selling behavior stays authoritative.
  local sellTop=topState(game)
  if sellTop and (sellTop.__gen3uiShopSellQuantity or sellTop.__gen3uiShopSellChoice)
      and GoldCompat.bagPresentationEnabled() then
    local sellBag=bagStateForMenu(game)
    if sellBag and sellBag.__gen3uiShopSellBag then
      pcall(drawBagFinal,game,sellBag)
      if sellTop.__gen3uiShopSellQuantity then
        local ox,oy,sc=finalCanvas()
        local g=love.graphics
        g.push("all"); g.translate(ox,oy); g.scale(sc,sc)
        g.setColor(0.015,0.04,0.045,0.97); roundedRect("fill",87,77,66,26,4)
        g.setColor(0.30,0.61,0.58,0.96); roundedRect("line",87,77,66,26,4)
        g.pop()
        finalText("HOW MANY?",92,81,3.0,{0.82,0.94,0.90,1},ox,oy,sc)
        finalText(("×%02d"):format(sellTop.qty or 1),93,90,4.4,{1,1,1,1},ox,oy,sc)
        if sellTop.unitPrice then
          local total=(sellTop.qty or 1)*sellTop.unitPrice
          finalText(("¥%d"):format(total),121,90,3.8,{0.72,0.92,0.85,1},ox,oy,sc)
        end
      end
    end
  end

  -- During TM/HM boot-up dialogue the actual Bag ListMenu is still in
  -- game.stack underneath the TextBox. Draw THAT live state directly.
  -- This is intentionally independent of whether ListMenu.draw ran this frame.
  if State.activeDialogueBox
      and GoldCompat.bagPresentationEnabled()
      and not (State.activeParty and partyTopState(game,State.activeParty)) then
    local bagUnderDialogue = findBagStateInStack(game)
    if bagUnderDialogue then
      local okBagBg, errBagBg = pcall(drawBagFinal, game, bagUnderDialogue)
      if (not okBagBg) and mod.log then
        mod.log("error","Gen 3 UI live Bag underlay failed: "..tostring(errBagBg))
      end
    end
  end

  -- TM/HM Party is a persistent BACKGROUND layer. It must render before
  -- dialogue/teach overlays, because those overlays may return from this HUD pass.
  if State.activeTMParty then
    local tmBackgroundWanted =
      partyShouldRenderBehindTM(game, State.activeTMParty)
      or (State.activeTMPromptFlow and stateExistsInStack(game, State.activeTMParty))

    if GoldCompat.pokemonPresentationEnabled() and tmBackgroundWanted then
      local okTMParty, errTMParty = pcall(drawPartyFinal, game, State.activeTMParty)
      if (not okTMParty) and mod.log then
        mod.log("error", "Colosseum UI TM Party background failed: "..tostring(errTMParty))
      end
    elseif not partyInStack(game, State.activeTMParty) then
      State.activeTMParty = nil
    end
  end

  -- PC-owned TextBox/ChoiceBox prompts sit above BoxMenu/ListMenu on the
  -- native stack. Re-render the nearest marked PC state here so confirmation
  -- and transfer messages retain our custom PC background, never native chrome.
  local underlayTop=topState(game)
  local underlayStates=game and game.stack and game.stack.states
  local underlayDialogue=underlayTop and (
    GoldCompat.isDialogueTextState(underlayTop)
    or GoldCompat.isDialogueChoiceState(underlayTop,
      type(underlayStates)=="table" and underlayStates[#underlayStates-1] or nil))
  if (State.activeDialogueBox or State.activeChoiceBox or underlayDialogue)
      and featureEnabled("revampedPokemonPC") then
    local pcUnder=pcStateInStack(game)
    if pcUnder then
      if (pcUnder.__gen3uiPCItemRoot or pcUnder.__gen3uiPCItemList)
          and GoldCompat.itemPcPresentationEnabled() then
        pcall(drawPCItemStorageFinal,game,pcUnder,true)
      elseif pcUnder.__gen3uiPCAccess then
        pcall(drawPCAccessFinal,game,pcUnder,true)
      elseif pcUnder.__gen3uiPCMain then
        pcall(drawPCMainFinal,game,pcUnder,true)
      elseif pcUnder.__gen3uiPCList then
        pcall(drawPCListFinal,game,pcUnder,true)
      elseif pcUnder.__gen3uiPCAction then
        pcall(drawPCActionFinal,game,pcUnder,true)
      end
    end
  end


  GoldCompat.renderMartUnderlay(game)

  -- Safari exploration is one continuous UI mode, not just a gate prompt.
  -- Keep the remaining balls/step budget visible in the same hanging language
  -- while the player is inside the zone. Battle has its own Safari status rail.
  if featureEnabled("revampedDialogueBoxes")
      and GoldCompat.safariPresentationEnabled() then
    pcall(GoldCompat.drawSafariZoneHud,game)
  end

  return false
end

function GoldCompat.renderHudDialogueLayer(mod,game)
  -- API v2 may hide a state through screen.render_visible before its draw
  -- method gets a chance to publish the old activeDialogueBox/activeChoiceBox
  -- marker.  Recover the foreground owner from the authoritative stack every
  -- frame.  This closes the one-frame Gen I gap where the palette-composited
  -- base (red in Red's boot-ROM palette) could be presented by itself during
  -- chained dialogue and TextBox -> ChoiceBox handoffs.
  local stack=game and game.stack and game.stack.states
  local top=type(stack)=="table" and stack[#stack] or nil
  if State.activeDialogueBox
      and not stateExistsInStack(game,State.activeDialogueBox) then
    State.activeDialogueBox=nil
  end
  if State.activeChoiceBox
      and not stateExistsInStack(game,State.activeChoiceBox) then
    State.activeChoiceBox=nil
  end
  if featureEnabled("revampedDialogueBoxes") and top then
    if GoldCompat.isDialogueTextState(top) then
      State.activeDialogueBox=top
    elseif GoldCompat.isDialogueChoiceState(top,stack[#stack-1]) then
      State.activeChoiceBox=top
      local owner=stack[#stack-1]
      if GoldCompat.isDialogueTextState(owner) then
        State.activeDialogueBox=owner
      end
    end
  end

  -- Render ONLY the themed version now, outside the palette compositor.
  --
  -- Gen I caught-mon AskName is slightly different from ordinary script
  -- dialogue: on some battle-stack routes the ChoiceBox can become the top
  -- state before its draw hook gets a chance to tag presentation ownership.
  -- Safari happened to hide this because its zone-wide ChoiceBox tag supplied
  -- a second route. Recover the nickname choice directly from the authoritative
  -- stack so ordinary wild catches receive the same visible YES/NO prompt.
  if not State.activeChoiceBox and GoldCompat.flowPresentationEnabled("naming") then
    local topChoice=topState(game)
    if topChoice and getmetatable(topChoice)==ChoiceBox then
      local states=game and game.stack and game.stack.states
      local under=type(states)=="table" and states[#states-1] or nil
      if under and under.__colosseumNicknamePrompt then
        topChoice.__colosseumNicknameChoice=true
        State.activeChoiceBox=topChoice
      end
    end
  end
  local drewDialogue = false
  local starterOwnsPanel=State.activeChoiceBox
    and State.activeChoiceBox.__colosseumStarterSpecies
    and GoldCompat.starterPresentationEnabled()

  if State.activeDialogueBox and featureEnabled("revampedDialogueBoxes")
      and not starterOwnsPanel then
    local box = State.activeDialogueBox
    State.activeDialogueBox = nil

    local okDialogue, errDialogue = pcall(GoldCompat.drawDialogueThemeFinal, box)
    if not okDialogue then
      if mod.log then
        mod.log("error","Gen 3 UI final dialogue overlay failed: "..tostring(errDialogue))
      end
    end
    drewDialogue=okDialogue
  else
    State.activeDialogueBox = nil
  end

  if State.activeChoiceBox and (featureEnabled("revampedDialogueBoxes")
      or (State.activeChoiceBox.__colosseumStarterSpecies
        and GoldCompat.starterPresentationEnabled())
      or (State.activeChoiceBox.__colosseumNicknameChoice
        and GoldCompat.flowPresentationEnabled("naming"))) then
    local choice = State.activeChoiceBox
    State.activeChoiceBox = nil

    -- Battle sayChoice pushes ChoiceBox ABOVE BattleState while keeping the
    -- completed prompt in battle.current. Draw that prompt explicitly before
    -- the choice; otherwise our normal battle renderer yields to the pushed
    -- state and the user sees the previous "about to use" page freeze.
    local battleUnderChoice=State.activeBattle
    if battleInStack(game,battleUnderChoice)
        and battleUnderChoice.phase=="messages"
        and battleUnderChoice.current then
      local okPrompt,errPrompt=pcall(drawDialogue,battleUnderChoice)
      if (not okPrompt) and mod.log then
        mod.log("error","Gen 3 UI battle choice prompt failed: "..tostring(errPrompt))
      end
    end

    local okChoice, errChoice = pcall(GoldCompat.drawChoiceThemeFinal, choice)
    if (not okChoice) and mod.log then
      mod.log("error","Gen 3 UI final choice overlay failed: "..tostring(errChoice))
    end
    return true
  else
    State.activeChoiceBox = nil
  end

  if drewDialogue then
    return true
  end


  return false
end

function GoldCompat.renderGoldServiceOverlay(mod,game)
  if GoldCompat.generation~="gen2" then return false end
  local top=topState(game)
  if not top or not top.__gen3uiGoldOverlayKind then return false end

  local kind=top.__gen3uiGoldOverlayKind
  local ok,err
  if kind=="pack" then
    if not GoldCompat.bagPresentationEnabled() then return false end
    ok,err=pcall(GoldCompat.drawGoldPack,top,
      love.graphics.getWidth(),love.graphics.getHeight(),false)
  elseif kind=="mart" then
    if not goldScreenEnabled("revampedPokeMartUI") then return false end
    ok,err=pcall(GoldCompat.drawGoldMart,top,
      love.graphics.getWidth(),love.graphics.getHeight())
  elseif kind=="centerpc" then
    if not goldScreenEnabled("revampedPokemonPC") then return false end
    ok,err=pcall(GoldCompat.drawGoldCenterPc,top,
      love.graphics.getWidth(),love.graphics.getHeight())
  elseif kind=="save" then
    if not featureEnabled("revampedSaveUI") then return false end
    ok,err=pcall(GoldCompat.drawGoldSave,top)
  elseif kind=="options" then
    if not goldScreenEnabled("revampedOptionsUI") then return false end
    ok,err=pcall(GoldCompat.drawGen1OptionsHanging,top)
  elseif kind=="mods" then
    if not goldScreenEnabled("revampedModsUI") then return false end
    ok,err=pcall(GoldCompat.drawGen1ModManagerHanging,top)
  elseif kind=="trainer" then
    if not goldScreenEnabled("revampedTrainerCardUI") then return false end
    ok,err=pcall(GoldCompat.drawGen2TrainerCardHanging,top)
  elseif kind=="ui-settings" then
    ok,err=pcall(GoldCompat.drawGoldUISettings,top)
  elseif kind=="party" then
    if not featureEnabled("colosseumPokemonMenu") then return false end
    ok,err=pcall(GoldCompat.drawGoldPartyMenu,top,
      love.graphics.getWidth(),love.graphics.getHeight())
  elseif kind=="summary" then
    if not GoldCompat.pokemonPresentationEnabled() then return false end
    ok,err=pcall(GoldCompat.drawGoldSummary,top,
      love.graphics.getWidth(),love.graphics.getHeight())
  elseif kind=="pokedex" then
    if not goldScreenEnabled("revampedPokedex") then return false end
    ok,err=pcall(GoldCompat.drawGoldPokedex,top,
      love.graphics.getWidth(),love.graphics.getHeight())
  elseif kind=="pc-root" then
    if not goldScreenEnabled("revampedPokemonPC") then return false end
    ok,err=pcall(GoldCompat.drawGoldPcRoot,top)
  elseif kind=="pc-box" then
    if not goldScreenEnabled("revampedPokemonPC") then return false end
    ok,err=pcall(GoldCompat.drawGoldBoxMenu,top)
  elseif kind=="pc-item" then
    if not GoldCompat.itemPcPresentationEnabled() then return false end
    ok,err=pcall(GoldCompat.drawGoldItemPc,top,
      love.graphics.getWidth(),love.graphics.getHeight())
  else
    return false
  end

  if not ok and mod.log then
    mod.log("error","Gen 3 UI Gold overlay failed ("..tostring(kind).."): "..tostring(err))
  end
  return ok and true or false
end

function GoldCompat.renderCrossgenFlowOverlay(mod,game)
  local top=topState(game)
  local flow=top
  local ownsForeground=true

  -- Evolution completion and a few service operations push the shared
  -- TextBox/ChoiceBox above their owning flow. Repaint that flow as an underlay
  -- and let the normal Colosseum dialogue pass remain the foreground.
  if not (flow and flow.__colosseumFlowKind) then
    ownsForeground=false
    if not (State.activeDialogueBox or State.activeChoiceBox) then return false end
    local states=game and game.stack and game.stack.states or {}
    for i=#states,1,-1 do
      if states[i].__colosseumFlowKind then
        flow=states[i]
        break
      end
    end
  end
  if not (flow and flow.__colosseumFlowKind) then return false end

  local kind=flow.__colosseumFlowKind
  if not GoldCompat.flowPresentationEnabled(kind) then return false end
  local ok,err=pcall(GoldCompat.drawGenericFlow,flow,kind)
  if not ok then
    flow.__colosseumRenderFailed=true
    if mod.log then
      mod.log("error","Colosseum cross-generation flow failed ("..
        tostring(kind).."): "..tostring(err))
    end
    return false
  end
  flow.__colosseumRenderFailed=nil
  return ownsForeground
end

function GoldCompat.drawStrictGenericMenu(menu)
  if not menu then return end
  local G=love.graphics
  local ox,oy,sc=finalCanvas()
  local items=menu.items or {}
  local visible=(menu.maxVisible and math.min(menu.maxVisible,#items)) or #items
  visible=math.max(1,math.min(8,visible))
  local w=math.max(58,math.min(118,(tonumber(menu.tw) or 10)*8+8))
  local h=20+visible*13
  local x=math.max(4,154-w)
  local y=math.max(5,math.min(132-h,(tonumber(menu.ty) or 0)*8+5))
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(x,y,w,h,13)
  for row=1,visible do
    local idx=(tonumber(menu.scroll) or 0)+row
    local entry=items[idx]
    if entry then
      local yy=y+17+(row-1)*13
      if idx==(tonumber(menu.index) or 1) then
        drawColosseumRunoffSelection(x+4,yy-2,w-9,11)
      end
    end
  end
  G.pop()
  finalText("MENU",x+8,y+5,3.0,{0.48,1.00,0.72,1},ox,oy,sc)
  for row=1,visible do
    local idx=(tonumber(menu.scroll) or 0)+row
    local entry=items[idx]
    if entry then
      finalText(tostring(entry.label or entry.value or "—"),x+13,y+18+(row-1)*13,3.1,
        idx==(tonumber(menu.index) or 1) and {1,1,1,1} or {0.76,0.88,0.84,1},
        ox,oy,sc,"left",w-18)
    end
  end
end

function GoldCompat.drawStrictGenericList(list)
  if not list then return end
  local G=love.graphics
  local ox,oy,sc=finalCanvas()
  local items=list.items or {}
  local rows=math.max(1,math.min(7,tonumber(list.rows) or 7))
  local x,y,w,h=14,14,142,112
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(x,y,w,h,15)
  for row=1,rows do
    local idx=(tonumber(list.scroll) or 0)+row
    local entry=items[idx]
    if entry then
      local yy=y+20+(row-1)*12
      if idx==(tonumber(list.index) or 1) then
        drawColosseumRunoffSelection(x+4,yy-2,w-8,10)
      end
    end
  end
  G.pop()
  finalText(tostring(list.title or list.kind or "MENU"),x+8,y+5,3.2,{0.48,1.00,0.72,1},ox,oy,sc,"left",w-16)
  for row=1,rows do
    local idx=(tonumber(list.scroll) or 0)+row
    local entry=items[idx]
    if entry then
      local yy=y+20+(row-1)*12
      local selected=idx==(tonumber(list.index) or 1)
      finalText(tostring(entry.label or entry.value or "—"),x+13,yy,2.9,selected and {1,1,1,1} or {0.76,0.88,0.84,1},ox,oy,sc,"left",88)
      if entry.right~=nil then
        finalText(tostring(entry.right),x+w-11,yy,2.7,selected and {1,0.78,0.42,1} or {0.56,0.74,0.68,1},ox,oy,sc,"right",36)
      end
    end
  end
  if list.footer then finalText(tostring(list.footer):gsub("\n","   "),x+8,y+h-10,2.0,{0.58,0.76,0.70,1},ox,oy,sc,"left",w-16) end
end

function GoldCompat.drawStrictTownMap(tm)
  local G=love.graphics; local ox,oy,sc=finalCanvas()
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(5,7,150,126,15)
  G.setColor(0.008,0.035,0.040,0.88); roundedRect("fill",12,29,136,78,3)
  G.setColor(0.18,0.45,0.42,0.55); G.rectangle("line",13,30,134,76,3,3)
  local locs=tm.locs or {}
  local minx,maxx,miny,maxy=999,-999,999,-999
  for _,loc in ipairs(locs) do if loc.x and loc.y then minx=math.min(minx,loc.x); maxx=math.max(maxx,loc.x); miny=math.min(miny,loc.y); maxy=math.max(maxy,loc.y) end end
  for i,loc in ipairs(locs) do
    if loc.x and loc.y and maxx>=minx and maxy>=miny then
      local px=18+(loc.x-minx)/math.max(1,maxx-minx)*122
      local py=35+(loc.y-miny)/math.max(1,maxy-miny)*64
      local sel=i==(tonumber(tm.sel) or 1)
      G.setColor(sel and {1.00,0.34,0.16,1} or {0.35,0.90,0.68,0.92})
      G.circle("fill",px,py,sel and 2.7 or 1.7)
    end
  end
  G.pop()
  local sel=(tm.locs or {})[tonumber(tm.sel) or 1]
  finalText(tm.fly and "FLY MAP" or (tm.nestSpecies and "AREA" or "TOWN MAP"),12,13,3.2,{0.48,1.00,0.72,1},ox,oy,sc)
  finalText(sel and tostring(tm:bannerText(sel)) or "KANTO",15,112,3.4,{1,1,1,1},ox,oy,sc,"left",130)
  finalText(tm.fly and "A: FLY   B: BACK" or "D-PAD: MOVE   B: BACK",15,123,2.2,{0.58,0.76,0.70,1},ox,oy,sc,"left",130)
end

function GoldCompat.drawStrictPicBox(pb)
  local G=love.graphics; local ox,oy,sc=finalCanvas()
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(45,28,72,80,13)
  G.setColor(0.006,0.026,0.030,0.90); roundedRect("fill",53,46,56,50,3)
  if pb.image then
    local w,h=pb.image:getDimensions(); local k=math.min(46/math.max(1,w),42/math.max(1,h),1.7)
    G.setColor(1,1,1,1); G.draw(pb.image,81,71,0,k,k,w/2,h/2)
  end
  G.pop(); finalText("POKéMON",53,35,3.0,{0.48,1.00,0.72,1},ox,oy,sc)
end

function GoldCompat.drawStrictDiploma(d)
  local ox,oy,sc=finalCanvas(); local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(10,12,145,119,16)
  G.setColor(0.010,0.040,0.042,0.84); roundedRect("fill",18,36,129,76,3)
  G.setColor(0.30,0.62,0.56,0.7); roundedRect("line",19,37,127,74,3)
  G.pop()
  finalText("DIPLOMA",18,19,3.8,{1.00,0.72,0.28,1},ox,oy,sc)
  finalText("PLAYER  "..tostring(d.game and d.game.save and d.game.save.player and d.game.save.player.name or "TRAINER"),24,45,3.2,{1,1,1,1},ox,oy,sc,"left",116)
  finalText("Congratulations!",24,61,3.0,{0.48,1.00,0.72,1},ox,oy,sc)
  finalText("Your POKéDEX completion",24,74,2.65,{0.80,0.90,0.86,1},ox,oy,sc)
  finalText("has been officially certified.",24,84,2.45,{0.80,0.90,0.86,1},ox,oy,sc)
  finalText("GAME FREAK",92,101,2.8,{1.00,0.72,0.28,1},ox,oy,sc,"right",48)
  finalText("A/B: CLOSE",20,119,2.2,{0.58,0.76,0.70,1},ox,oy,sc)
end

function GoldCompat.drawStrictHallOfFame(hof)
  local ox,oy,sc=finalCanvas(); local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(5,7,150,126,15)
  G.setColor(0.006,0.026,0.030,0.88); roundedRect("fill",12,30,136,78,3)
  G.pop()
  finalText("HALL OF FAME",12,13,3.5,{1.00,0.72,0.28,1},ox,oy,sc)
  local mon=hof.game and hof.game.save and hof.game.save.party and hof.game.save.party[hof.index or 1]
  if mon then
    finalText(tostring(mon.nickname or mon.species or "POKéMON"),20,42,4.0,{1,1,1,1},ox,oy,sc,"left",110)
    finalText("Lv."..tostring(mon.level or "?"),20,57,3.0,{0.48,1.00,0.72,1},ox,oy,sc)
    finalText("No. "..tostring(hof.index or 1),20,70,2.7,{0.70,0.82,0.78,1},ox,oy,sc)
  else
    local player=hof.game and hof.game.save and hof.game.save.player or {}
    finalText(tostring(player.name or "TRAINER"),20,48,4.2,{1,1,1,1},ox,oy,sc)
    finalText("LEAGUE CHAMPION",20,65,3.0,{0.48,1.00,0.72,1},ox,oy,sc)
  end
  finalText("A: CONTINUE",18,118,2.2,{0.58,0.76,0.70,1},ox,oy,sc)
end

function GoldCompat.drawStrictBindings(bind)
  GoldCompat.drawStrictGenericList(bind)
  if not bind.capture then return end
  local ox,oy,sc=finalCanvas(); local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc)
  drawColosseumRunoffPanel(37,48,112,49,13); G.pop()
  finalText("INPUT CAPTURE",45,55,3.0,{1.00,0.72,0.28,1},ox,oy,sc)
  finalText("PRESS A BUTTON",45,70,3.3,{1,1,1,1},ox,oy,sc)
  finalText("RELEASE TO SET",45,83,2.3,{0.58,0.76,0.70,1},ox,oy,sc)
end

function GoldCompat.drawStrictQuarantine(q)
  local ox,oy,sc=finalCanvas(); local G=love.graphics
  G.push("all"); G.translate(ox,oy); G.scale(sc,sc); drawColosseumRunoffPanel(7,8,148,126,15); G.pop()
  finalText("LOAD REPORT",15,14,3.3,{1.00,0.72,0.28,1},ox,oy,sc)
  for row=1,11 do
    local line=q.lines and q.lines[(q.offset or 0)+row]
    if line then finalText(tostring(line),15,34+(row-1)*7.2,2.25,{0.78,0.88,0.84,1},ox,oy,sc,"left",132) end
  end
  finalText("A: CONTINUE",15,121,2.2,{0.58,0.76,0.70,1},ox,oy,sc)
end

function GoldCompat.renderHudMenuLayer(mod,game)
  -- Strict fallback ownership for otherwise-unclaimed gameplay states.
  local strictTop=topState(game)
  -- Gen I PP-item move selection is a native ListMenu logically, but visually
  -- remains inside the custom Party deck. Drawing the kept Party object here
  -- gives PP UP / ETHER the same uninterrupted Bag -> Party -> Move flow as
  -- every other modernized item action.
  if State.activePPMoveList then
    local pp=State.activePPMoveList
    if topState(game)==pp and GoldCompat.pokemonPresentationEnabled() then
      local party=pp.__gen3uiPPParty or State.activeItemTargetParty
      if party then
        party.__gen3uiPPMoveParty=true
        party.isOpaque=false
        local okPP,errPP=pcall(GoldCompat.drawColosseumParty,game,party)
        if not okPP and mod.log then
          mod.log("error","Colosseum PP-item move picker failed: "..tostring(errPP))
        end
        return okPP
      end
    elseif not stateExistsInStack(game,pp) then
      local party=pp.__gen3uiPPParty
      if party then party.__gen3uiPPMoveParty=nil end
      State.activePPMoveList=nil
    end
  end

  local strictStates={
    {"activeTownMap",GoldCompat.drawStrictTownMap},
    {"activePicBox",GoldCompat.drawStrictPicBox},
    {"activeDiploma",GoldCompat.drawStrictDiploma},
    {"activeHallOfFame",GoldCompat.drawStrictHallOfFame},
    {"activeBindings",GoldCompat.drawStrictBindings},
    {"activeQuarantine",GoldCompat.drawStrictQuarantine},
    {"activeGenericMenu",GoldCompat.drawStrictGenericMenu},
    {"activeGenericList",GoldCompat.drawStrictGenericList},
  }
  for _,entry in ipairs(strictStates) do
    local st=State[entry[1]]
    if st then
      if st==strictTop then
        local okStrict,errStrict=pcall(entry[2],st)
        if not okStrict and mod.log then mod.log("error","Colosseum strict UI fallback failed: "..tostring(errStrict)) end
        return okStrict
      elseif not stateExistsInStack(game,st) then
        State[entry[1]]=nil
      end
    end
  end

  -- Gen 1 level-up StatBox is a pushed battle UI state. Render its modern
  -- card here, after the battlefield, while leaving native A/B dismissal and
  -- queue sequencing completely untouched.
  if GoldCompat.generation=="gen1" and State.activeGen1LevelUpBox then
    local top=topState(game)
    if top==State.activeGen1LevelUpBox
        and featureEnabled("revampedLevelUpUI") then
      local ok,err=pcall(GoldCompat.drawGen1LevelUpBox,
        State.activeGen1LevelUpBox)
      if not ok and mod.log then
        mod.log("error","Gen 1 level-up box failed: "..tostring(err))
      end
      return ok
    else
      State.activeGen1LevelUpBox=nil
    end
  end

  -- Gen 1 Options / Mods / Trainer Card use the same hanging-over-overworld
  -- ownership model as START. Native states keep all input and actions.
  if GoldCompat.generation=="gen1" then
    local top=topState(game)

    if State.activeGen1Options then
      if top==State.activeGen1Options
          and featureEnabled("revampedOptionsUI") then
        local ok,err=pcall(GoldCompat.drawGen1OptionsHanging,
          State.activeGen1Options)
        if not ok and mod.log then
          mod.log("error","Gen 1 hanging Options failed: "..tostring(err))
        end
        return ok
      else
        State.activeGen1Options=nil
      end
    end

    if State.activeGen1Mods then
      if top==State.activeGen1Mods
          and featureEnabled("revampedModsUI") then
        local ok,err=pcall(GoldCompat.drawGen1ModManagerHanging,
          State.activeGen1Mods)
        if not ok and mod.log then
          mod.log("error","Gen 1 hanging Mod Manager failed: "..tostring(err))
        end
        return ok
      else
        State.activeGen1Mods=nil
      end
    end

    if State.activeGen1TrainerCard then
      if top==State.activeGen1TrainerCard
          and featureEnabled("revampedTrainerCardUI") then
        local ok,err=pcall(GoldCompat.drawGen1TrainerCardHanging,
          State.activeGen1TrainerCard)
        if not ok and mod.log then
          mod.log("error","Gen 1 hanging Trainer Card failed: "..tostring(err))
        end
        return ok
      else
        State.activeGen1TrainerCard=nil
      end
    end
  end

  -- Gold service overlays are intentionally drawn here, after the overworld
  -- pass, exactly like the working Gen 1 START overlay.
  if GoldCompat.renderGoldServiceOverlay(mod,game) then return true end

  -- START / Bag draw after the palettized screen pass, like Party.
  if State.activeStartMenu and uiTopState(game, State.activeStartMenu) then
    local okStart, errStart = pcall(GoldCompat.drawStartFinal, game, State.activeStartMenu)

    -- Gold START display uses a copied label table only; restore engine-owned
    -- items immediately so selection/actions never operate on presentation data.
    if GoldCompat.generation=="gen2"
        and State.activeStartMenu.__gen3uiOriginalItems then
      State.activeStartMenu.items=State.activeStartMenu.__gen3uiOriginalItems
    end

    if okStart and GoldCompat.generation=="gen2"
        and State.activeStartMenu.phase=="confirm" then
      pcall(GoldCompat.drawGoldStartConfirm,State.activeStartMenu)
    end
    if (not okStart) and mod.log then
      mod.log("error","Colosseum UI START renderer failed: "..tostring(errStart))
    end
    return true
  elseif State.activeStartMenu then
    State.activeStartMenu = nil
  end

  if State.activeBagMenu and uiTopState(game, State.activeBagMenu) then
    local okBag, errBag = pcall(drawBagFinal, game, State.activeBagMenu)
    if (not okBag) and mod.log then
      mod.log("error","Colosseum UI Bag renderer failed: "..tostring(errBag))
    end
    return true
  elseif State.activeBagMenu then
    State.activeBagMenu = nil
  end

  -- STATS / MOVES use the engine's native SummaryMenu state and input.
  -- Only its presentation is replaced here.
  if DexUI.summary then
    if topState(game)==DexUI.summary
        and GoldCompat.pokemonPresentationEnabled() then
      local okSummary,errSummary=pcall(DexUI.drawPartySummary,game,DexUI.summary)
      if not okSummary and mod.log then
        mod.log("error","Gen 3 UI Summary renderer failed: "..tostring(errSummary))
      end
      return true
    elseif not stateExistsInStack(game,DexUI.summary) then
      DexUI.summary=nil
    end
  end

  -- Draw Party after the palettized screen pass, preserving true neutral colors.
  if State.activeParty and partyTopState(game, State.activeParty) then
    local okParty, errParty = pcall(drawPartyFinal, game, State.activeParty)
    if (not okParty) and mod.log then
      mod.log("error", "Colosseum UI Party renderer failed: "..tostring(errParty))
    end
    return true
  elseif State.activeParty and partyShouldRenderBehindTM(game, State.activeParty) then
    -- Kept-open TM/HM Party backgrounds are already drawn at the beginning
    -- of render.hud so dialogue/teach overlays can safely render on top.
    State.activeTMParty = State.activeParty
  elseif State.activeParty then
    if State.activeItemTargetParty==State.activeParty
        and not partyInStack(game,State.activeParty) then
      State.activeItemTargetParty=nil
    end
    State.activeParty = nil
  end


  return false
end

function GoldCompat.drawOpeningTrainerPartyIndicator(battle)
  if not (battle and battle.introBalls and type(battle.enemyParty)=="table"
      and #battle.enemyParty>0 and GoldCompat.battlePresentationEnabledFor(battle)) then
    return false
  end
  local ox,oy,sc=finalCanvas()
  local wide=false
  if battle.wideLayout then
    local ok,value=pcall(battle.wideLayout,battle)
    wide=ok and value or false
  end
  local x0=wide and 88 or 64
  local y0=wide and 40 or 16
  local gap=-8
  local r=3.2
  local g=love.graphics
  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)
  g.setColor(0.10,0.10,0.10,0.95)
  g.rectangle("fill",wide and 41 or 17,wide and 46 or 22,54,2)
  for i=1,6 do
    local mon=battle.enemyParty[i]
    local cx=x0+(i-1)*gap
    if mon then
      local alive=(mon.hp or 0)>0
      g.setColor(alive and {0.92,0.18,0.14,1}
                       or {0.42,0.42,0.40,0.85})
      g.arc("fill","pie",cx,y0,r,math.pi,math.pi*2)
      g.setColor(0.96,0.96,0.92,1)
      g.arc("fill","pie",cx,y0,r,0,math.pi)
      g.setColor(0.08,0.08,0.08,1)
      g.setLineWidth(0.8)
      g.circle("line",cx,y0,r)
      g.line(cx-r,y0,cx+r,y0)
      g.setColor(0.98,0.98,0.95,1)
      g.circle("fill",cx,y0,0.9)
      g.setColor(0.08,0.08,0.08,1)
      g.circle("line",cx,y0,0.9)
    else
      g.setColor(0.32,0.32,0.30,0.55)
      g.setLineWidth(0.8)
      g.circle("line",cx,y0,r)
    end
  end
  g.pop()
  return true
end

function GoldCompat.renderHudBattleLayer(mod,game)
  -- A renderer may hot-swap a battle method after battle.started. Reasserting
  -- the tiny predicate/HUD guards here is effectively free when nothing moved
  -- and guarantees our UI remains the final presentation layer.
  if battleStateInStack(game) then GoldCompat.installBattleUiFirewall() end

  -- Battle-only pushed UI states own the foreground, but should still feel
  -- like part of the current battle rather than dropping back to classic boxes.
  local pushedBattle=battleStateInStack(game)
  local topForBattle=topState(game)

  if State.activeBattleMoveLearn
      and topForBattle==State.activeBattleMoveLearn
      and pushedBattle
      and GoldCompat.battlePresentationEnabledFor(pushedBattle) then
    local cmd=commandGeometry()
    local s=hudScale()
    pcall(function()
      if shouldDrawStatusHUD(game,pushedBattle) then
        drawEnemyHUD(pushedBattle,s)
        drawPlayerHUD(pushedBattle,s,cmd)
      end
    end)
    local ok,err=pcall(drawBattleMoveLearnFinal,pushedBattle,State.activeBattleMoveLearn)
    if (not ok) and mod.log then
      mod.log("error","Gen 3 UI battle MoveLearn renderer failed: "..tostring(err))
    end
    return true
  elseif State.activeBattleMoveLearn and not stateExistsInStack(game,State.activeBattleMoveLearn) then
    State.activeBattleMoveLearn=nil
  end

  local battle = State.activeBattle
  -- Gen I Safari can reach render.hud without passing through battle.overlay.
  -- Discover only Safari this way; normal battles retain the established
  -- overlay-owned lifecycle and its compatibility behavior.
  if not battle then
    local stackedBattle=battleStateInStack(game)
    local stackedVisual=GoldCompat.presentBattleState(stackedBattle)
    if stackedBattle and GoldCompat.resolvedSafariState(stackedVisual or stackedBattle) then
      battle=stackedBattle
      State.activeBattle=stackedBattle
    end
  end
  if not GoldCompat.battlePresentationEnabledFor(battle) then
    State.activeBattle = nil
    return true
  end
  if not battleInStack(game, battle) then
    State.activeBattle = nil
    return true
  end

  -- If Bag / Party / Summary / another pushed state owns the foreground,
  -- preserve State.activeBattle but draw none of our battle UI over that screen.
  if not battleOwnsForeground(game, battle) then
    return true
  end

  local visualBattle=GoldCompat.presentBattleState(battle)

  -- The opening trainer-party row used to require wrapping BattleState.draw.
  -- Draw it here in the final UI layer instead so renderer/camera mods keep
  -- unrestricted ownership of the battle draw pipeline.
  pcall(GoldCompat.drawOpeningTrainerPartyIndicator,battle)

  -- Unified render path: Colosseum is a presentation sub-mode of Battle UI,
  -- not a second competing mod. The unified mod keeps all lifecycle,
  -- suppression, and compatibility ownership; only the final battle HUD/menu/message renderer
  -- is swapped here.
  if featureEnabled("colosseumBattleUI")
      and GoldCompat.safariPresentationEnabled()
      and GoldCompat.ColosseumUI
      and visualBattle and GoldCompat.resolvedSafariState(visualBattle)
      and type(GoldCompat.ColosseumUI.drawSafari)=="function" then
    local sourceBattle=GoldCompat.sourceBattleState(visualBattle) or battle
    if GoldCompat.ColosseumUI.setIconsEnabled then
      pcall(GoldCompat.ColosseumUI.setIconsEnabled,
        featureEnabled("colosseumIcons"))
    end
    local okSafari,drewSafari=pcall(
      GoldCompat.ColosseumUI.drawSafari,game,visualBattle,sourceBattle
    )
    if not okSafari and mod.log then
      mod.log("error","Colosseum Safari renderer failed: "..tostring(drewSafari))
    end
    if okSafari and drewSafari then return false end
    -- If the Safari presentation ever fails, fall through to the proven
    -- shared renderer rather than affecting gameplay or encounter ownership.
  elseif featureEnabled("colosseumBattleUI")
      and GoldCompat.ColosseumUI
      and GoldCompat.ColosseumUI.supported(visualBattle) then
    -- Cross-generation presentation path:
    -- Gen 1 uses its BattleState directly. Gen 2 uses the normalized Gold
    -- presentation proxy for drawing while lifecycle is checked against the
    -- real Gen 2 state stored on the game stack.
    local sourceBattle=GoldCompat.sourceBattleState(visualBattle) or battle
    if GoldCompat.ColosseumUI.setIconsEnabled then
      pcall(GoldCompat.ColosseumUI.setIconsEnabled,
        featureEnabled("colosseumIcons"))
    end
    local okCol,drewCol=pcall(
      GoldCompat.ColosseumUI.draw,game,visualBattle,sourceBattle
    )
    if not okCol and mod.log then
      mod.log("error","Colosseum Battle UI renderer failed: "..tostring(drewCol))
    end
    if okCol and drewCol then
      -- Defensive parity path: Gold normally renders earlier in underlays, but
      -- if another state routes it here its native supplemental screens must
      -- still remain visible above the shared Colosseum HUD.
      if GoldCompat.isGen2BattleState(sourceBattle) then
        local okExtra,errExtra=pcall(function()
          GoldCompat.drawEnemyTrainerPartyIndicator(sourceBattle)
          GoldCompat.drawGoldTrainerSwitchOverlay(sourceBattle)
          GoldCompat.drawGoldBattleChoice(sourceBattle)
          GoldCompat.drawGoldBattleLevelUp(sourceBattle)
        end)
        if not okExtra and mod.log then
          mod.log("error","Colosseum Gold battle extras failed: "..tostring(errExtra))
        end
      end
      return false
    end
    -- Fail soft into the normal Gen 3-inspired battle renderer.
  end

  local cmd = commandGeometry()
  local s = hudScale()

  -- Preserve intro / replacement party-count information hidden with the
  -- native HUD. This is presentation only; battle party data stays native.
  -- Status HUD remains visible for normal battle messages and the main
  -- FIGHT/POKEMON/BAG/RUN prompt, but yields the screen to full move select.
  love.graphics.push("all")
  local okStatus, errStatus = pcall(function()
    if shouldDrawStatusHUD(game, visualBattle) then
      drawEnemyHUD(visualBattle, s)
      drawPlayerHUD(visualBattle, s, cmd)
    end
  end)
  love.graphics.pop()

  love.graphics.push("all")
  local okUI, errUI = pcall(function()
    drawDialogue(visualBattle)
    drawSafariBattleRail(visualBattle)
    drawCommandMenu(visualBattle)
    drawMoveSelect(visualBattle)
  end)
  love.graphics.pop()

  if mod.log then
    if not okStatus then
      mod.log("error", "Colosseum UI status HUD failed: "..tostring(errStatus))
    end
    if not okUI then
      mod.log("error", "Colosseum UI battle renderer failed: "..tostring(errUI))
    end
  end
  return false
end

function GoldCompat.careerRecordsForBattle(battle)
  local source=GoldCompat.sourceBattleState(battle) or battle
  local activeSource=GoldCompat.sourceBattleState(State.activeBattle)
    or State.activeBattle
  local game=(source and source.game) or (battle and battle.game)
    or (activeSource and activeSource.game) or GoldCompat.game
  local save=game and game.save
  if type(save)~="table" then return nil end
  save.colosseumUI=save.colosseumUI or {}
  save.colosseumUI.records=save.colosseumUI.records or {}
  local records=save.colosseumUI.records
  if records.trackedFrom==nil then
    local t=save.playTime
    records.trackedFrom=type(t)=="table"
      and ((tonumber(t.hours) or 0)*3600+(tonumber(t.minutes) or 0)*60)
      or (tonumber(t) or 0)
  end
  records.battlesWon=tonumber(records.battlesWon) or 0
  records.pokemonFainted=tonumber(records.pokemonFainted) or 0
  return records
end

function GoldCompat.enemyPartyDefeated(battle)
  if not battle then return false end
  local party=battle.enemyParty
  if type(party)=="table" and #party>0 then
    for _,entry in ipairs(party) do
      local mon=type(entry)=="table" and (entry.mon or entry) or nil
      if mon and (tonumber(mon.hp) or 0)>0 then return false end
    end
    return true
  end
  local enemy=battle.enemy
  local mon=type(enemy)=="table" and (enemy.mon or enemy) or nil
  return mon and (tonumber(mon.hp) or 0)<=0 or false
end

function GoldCompat.recordBattleFaint(payload)
  local battle=payload and payload.battle
  local side=payload and payload.side
  local battler=payload and payload.battler
  if not battle then return end
  local records=GoldCompat.careerRecordsForBattle(battle)
  if not records then return end

  local sideIndex=side and tonumber(side.index)
  local enemyFainted=sideIndex==2 or side==battle.enemy
    or battler==battle.enemy or (type(battler)=="table" and battler.isPlayer==false)
  -- Player Data's POKéMON FAINTED is the career tally of opponents defeated,
  -- not the number of times the player's own party has gone down. Count every
  -- enemy faint; BATTLES WON remains a separate final-party defeat counter.
  if enemyFainted then
    records.pokemonFainted=records.pokemonFainted+1
    if not battle.__colosseumWinCounted
        and GoldCompat.enemyPartyDefeated(battle) then
      battle.__colosseumWinCounted=true
      records.battlesWon=records.battlesWon+1
    end
  end
end

local function renderHudHook(mod,next,game,viewport)
  GoldCompat.game=game or GoldCompat.game
  next(game,viewport)
  if not (love and love.graphics) then return end

  -- Donor-screen skinning deliberately maps old warm panels into the
  -- Colosseum accent palette. Keep it around inherited menu underlays, but
  -- never run the purpose-built battle console through it: that conversion is
  -- what turned the neutral charcoal dialogue surface into the legacy red box.
  -- Gold's compatibility renderer still owns its battle pass inside
  -- renderHudUnderlays(). Run that one path directly: passing it through the
  -- donor palette adapter remapped the purpose-built charcoal message console
  -- to the old red Gen 3 surface. Non-battle donor underlays retain the adapter.
  local goldBattleDirect=GoldCompat.generation=="gen2"
    and State.activeBattle
    and battleInStack(game,State.activeBattle)
    and battleOwnsForeground(game,State.activeBattle)
    and not State.activeDialogueBox
    and not State.activeChoiceBox
  local underlayOwnsFrame
  if goldBattleDirect then
    underlayOwnsFrame=GoldCompat.renderHudUnderlays(mod,game)
  else
    underlayOwnsFrame=GoldCompat.withColosseumSkin(function()
      return GoldCompat.renderHudUnderlays(mod,game)
    end)
  end
  if underlayOwnsFrame then return true end

  local flowOwnsFrame=GoldCompat.renderCrossgenFlowOverlay(mod,game)
  if GoldCompat.renderHudDialogueLayer(mod,game) then return true end
  if flowOwnsFrame then return true end

  -- The Save screen is purpose-built cobalt UI. Like the battle console, it
  -- must bypass the donor palette converter or its blues can be remapped into
  -- inherited Gen 3 colors.
  local saveTop=topState(game)
  if GoldCompat.generation=="gen2" and saveTop
      and saveTop.__gen3uiGoldOverlayKind=="save"
      and featureEnabled("revampedSaveUI") then
    local okSave,errSave=pcall(GoldCompat.drawGoldSave,saveTop)
    if (not okSave) and mod.log then
      mod.log("error","Colosseum Save overlay failed: "..tostring(errSave))
    end
    if okSave then return true end
  end

  -- Purpose-built hanging menus use their own material palette and draw their
  -- artwork in full color. Rendering them directly also prevents the adapter
  -- from desaturating custom player sprites and native badge canvases.
  local menuOwnsFrame=GoldCompat.renderHudMenuLayer(mod,game)
  if menuOwnsFrame then return true end

  -- The battle HUD was purpose-built with its own charcoal, steel and warm
  -- metallic palette. Running it through the donor-screen material adapter
  -- turned its status-box ridge and neutral bevels red. Keep battle rendering
  -- outside that adapter to restore the original Colosseum box treatment.
  return GoldCompat.renderHudBattleLayer(mod,game)
end

State.Installers = State.Installers or {}
State.Installers.installVerifiedOptions = installVerifiedOptions
State.Installers.installPCIntegration = installPCIntegration
State.Installers.installMartUI = installMartUI
State.Installers.installDialogueThemeDirect = installDialogueThemeDirect
State.Installers.handleModOptionChanged = handleModOptionChanged
State.Installers.patchVanillaTextDrawing = patchVanillaTextDrawing
State.Installers.installOverworldUI = installOverworldUI
State.Installers.installGoldBattlePresentation = GoldCompat.installGoldBattlePresentation


-- -------------------------------------------------------------------------
-- Colosseum title presentation
-- -------------------------------------------------------------------------
-- The native Red/Blue/Yellow and Gold title screens stay authoritative. This
-- layer only covers the first title appearance of a process with a short
-- vector Poké Ball reveal, then fades away to expose the already-running
-- native title state underneath. The optional music record contains the
-- supplied track with the approved front trim baked into the asset.
GoldCompat.titleMusicId="COLOSSEUM_UI_TITLE"

function GoldCompat.titleExperienceEnabled()
  return featureEnabled("colosseumTitleIntro")
end

function GoldCompat.drawTitleIntroOverlay(state)
  if not (state and state.__colosseumTitleIntro) then return end
  local elapsed=tonumber(state.__colosseumTitleIntroTime) or 0
  local duration=2.85
  if elapsed>=duration then
    state.__colosseumTitleIntro=false
    return
  end

  local G=love and love.graphics
  if not G then return end
  local okPush=pcall(G.push,"all")
  if not okPush then G.push() end
  pcall(G.origin)

  -- TitleState can be invoked while the engine has a low-resolution game
  -- canvas bound (160x144 in both generation frontends). love.graphics
  -- getDimensions() reports the desktop/window size, not that active canvas.
  -- Sizing the reveal from the window while drawing into the game canvas puts
  -- almost all geometry outside the render target and leaves only clipped
  -- pixel fragments. Resolve the dimensions of the currently bound canvas
  -- first, falling back to the window only when TitleState is drawing directly.
  local w,h
  local activeCanvas=nil
  if type(G.getCanvas)=="function" then
    local okCanvas,canvas=pcall(G.getCanvas)
    if okCanvas then activeCanvas=canvas end
  end
  local function canvasDimensions(canvas)
    if canvas and type(canvas.getDimensions)=="function" then
      local ok,cw,ch=pcall(canvas.getDimensions,canvas)
      if ok and tonumber(cw) and tonumber(ch) and cw>0 and ch>0 then
        return cw,ch
      end
    end
    return nil,nil
  end
  w,h=canvasDimensions(activeCanvas)
  if not w and type(activeCanvas)=="table" then
    w,h=canvasDimensions(activeCanvas[1] or activeCanvas.canvas)
  end
  if not w then w,h=G.getDimensions() end

  local fadeOut=1
  if elapsed>1.65 then fadeOut=math.max(0,1-(elapsed-1.65)/(duration-1.65)) end
  local ballIn=math.max(0,math.min(1,(elapsed-0.10)/0.55))
  local ballOut=1
  if elapsed>1.72 then ballOut=math.max(0,1-(elapsed-1.72)/0.70) end
  local ballAlpha=ballIn*ballOut
  local bgAlpha=0.985*fadeOut

  -- Near-black blue/teal field: intentionally restrained so the native title
  -- appearing through the crossfade is the visual payoff.
  G.setColor(0.008,0.020,0.026,bgAlpha)
  G.rectangle("fill",0,0,w,h)

  if ballAlpha>0 then
    local cx,cy=w*0.5,h*0.49
    local base=math.min(w,h)*0.145
    local ease=1-math.pow(1-ballIn,3)
    local r=base*(0.82+0.18*ease)
    local pulse=0.5+0.5*math.sin(elapsed*5.8)

    -- Soft outer halo.
    G.setColor(0.18,0.64,0.65,0.10*ballAlpha)
    G.circle("fill",cx,cy,r*1.18)

    -- Lower shell first, then clip a muted red upper shell into the circle.
    G.setColor(0.055,0.075,0.080,0.98*ballAlpha)
    G.circle("fill",cx,cy,r)
    G.setScissor(math.floor(cx-r-3),math.floor(cy-r-3),
      math.ceil(r*2+6),math.ceil(r+3))
    G.setColor(0.20,0.045,0.050,0.94*ballAlpha)
    G.circle("fill",cx,cy,r)
    G.setScissor()

    G.setLineWidth(math.max(2,r*0.045))
    G.setColor(0.25,0.66,0.66,0.92*ballAlpha)
    G.circle("line",cx,cy,r)

    local band=math.max(4,r*0.13)
    G.setColor(0.010,0.018,0.020,0.98*ballAlpha)
    G.rectangle("fill",cx-r,cy-band*0.5,r*2,band)

    local buttonR=r*0.235
    G.setColor(0.015,0.028,0.030,0.98*ballAlpha)
    G.circle("fill",cx,cy,buttonR*1.25)
    G.setColor(0.30,0.72,0.69,(0.72+0.18*pulse)*ballAlpha)
    G.circle("line",cx,cy,buttonR*1.25)
    G.setColor(0.70,0.88,0.82,(0.72+0.20*pulse)*ballAlpha)
    G.circle("fill",cx,cy,buttonR*0.58)
  end

  G.setColor(1,1,1,1)
  G.setLineWidth(1)
  G.setScissor()
  G.pop()
end

function GoldCompat.startTitleMusicSession(state)
  if not (GoldCompat.titleExperienceEnabled() and State.titleMusicRegistered) then
    State.titleMusicSession=false
    return
  end
  State.titleMusicSession=true
  local okMusic,Music=pcall(require,"src.core.Music")
  local data=(state and state.game and state.game.data)
    or (GoldCompat.game and GoldCompat.game.data)
  if okMusic and Music and type(Music.play)=="function" and data then
    -- Start the finalized title asset from its own sample zero.
    -- Its approved trim is baked into the OGG; no runtime seek/start
    -- argument is used, so menu navigation cannot re-time or restart it.
    pcall(Music.play,data,GoldCompat.titleMusicId,true,{reason="title"})
  end
end

function GoldCompat.endTitleMusicSession()
  if not State.titleMusicSession then return end
  State.titleMusicSession=false
  local okMusic,Music=pcall(require,"src.core.Music")
  if okMusic and Music and type(Music.stop)=="function" then
    pcall(Music.stop)
  end
end

function GoldCompat.wrapTitleLoadCallback(state,key)
  if not (state and type(state[key])=="function") then return end
  local native=state[key]
  state[key]=function(...)
    GoldCompat.endTitleMusicSession()
    return native(...)
  end
end

function GoldCompat.patchTitleClass(TitleClass,generation)
  if not (TitleClass and type(TitleClass)=="table") then return end
  if TitleClass.__colosseumTitleExperiencePatched then return end
  TitleClass.__colosseumTitleExperiencePatched=true

  if type(TitleClass.new)=="function" then
    local nativeNew=TitleClass.new
    TitleClass.new=function(...)
      local state=nativeNew(...)
      if state and GoldCompat.titleExperienceEnabled() and not State.titleIntroShown then
        State.titleIntroShown=true
        state.__colosseumTitleIntro=true
        state.__colosseumTitleIntroTime=0
      end
      -- In Gen I these callbacks are the actual NEW GAME / CONTINUE handoff,
      -- so this is the exact boundary where the persistent menu music may end.
      -- Gen II's title onContinue only opens MainMenu and must NOT stop it.
      if generation=="gen1" then
        GoldCompat.wrapTitleLoadCallback(state,"onNewGame")
        GoldCompat.wrapTitleLoadCallback(state,"onContinue")
      end
      return state
    end
  end

  if type(TitleClass.enter)=="function" then
    local nativeEnter=TitleClass.enter
    TitleClass.enter=function(self,...)
      local result={nativeEnter(self,...)}
      GoldCompat.startTitleMusicSession(self)
      return unpack(result)
    end
  end

  if type(TitleClass.update)=="function" then
    local nativeUpdate=TitleClass.update
    TitleClass.update=function(self,dt,...)
      if self and self.__colosseumTitleIntro then
        self.__colosseumTitleIntroTime=(tonumber(self.__colosseumTitleIntroTime) or 0)
          +(tonumber(dt) or 1/60)
        if self.__colosseumTitleIntroTime>=2.85 then
          self.__colosseumTitleIntro=false
        end
      end
      return nativeUpdate(self,dt,...)
    end
  end

  -- Draw after the native title. In Gen II the widescreen method is the final
  -- presentation pass; Gen I uses draw(). This avoids touching any native
  -- logos, Pokémon art, animation sequencing or title input callbacks.
  if type(TitleClass.drawWidescreen)=="function" then
    local nativeWide=TitleClass.drawWidescreen
    TitleClass.drawWidescreen=function(self,...)
      local result={nativeWide(self,...)}
      GoldCompat.drawTitleIntroOverlay(self)
      return unpack(result)
    end
  elseif type(TitleClass.draw)=="function" then
    local nativeDraw=TitleClass.draw
    TitleClass.draw=function(self,...)
      local result={nativeDraw(self,...)}
      GoldCompat.drawTitleIntroOverlay(self)
      return unpack(result)
    end
  end
end

function GoldCompat.patchGen2MainMenu(MainMenu)
  if not (MainMenu and type(MainMenu)=="table" and type(MainMenu.new)=="function") then
    return
  end
  if MainMenu.__colosseumTitleMusicSessionPatched then return end
  MainMenu.__colosseumTitleMusicSessionPatched=true
  local nativeNew=MainMenu.new
  MainMenu.new=function(...)
    local state=nativeNew(...)
    -- Gold's TitleState -> MainMenu transition is still part of the title/menu
    -- experience. Only these two callbacks actually leave the menu flow and
    -- load a save or begin a new game.
    GoldCompat.wrapTitleLoadCallback(state,"onNewGame")
    GoldCompat.wrapTitleLoadCallback(state,"onContinue")
    return state
  end
end

function GoldCompat.installTitleExperience(mod)
  if not mod then return end

  -- Register the finalized title audio with its approved trim baked into
  -- the asset. Playback never depends on runtime seeking or on
  -- whichever title/menu state happens to request it.
  local assetPath=nil
  if mod.assets and type(mod.assets.path)=="function" then
    local ok,path=pcall(mod.assets.path,mod.assets,"assets/audio/colosseum_title.ogg")
    if ok then assetPath=path end
  end
  if assetPath and mod.content and mod.content.music
      and type(mod.content.music.register)=="function" then
    local ok,err=pcall(mod.content.music.register,mod.content.music,
      GoldCompat.titleMusicId,{file=assetPath})
    State.titleMusicRegistered=ok and true or false
    if not ok and mod.log then
      mod.log:warn("Colosseum UI title music registration failed: "..tostring(err))
    end
  end

  -- While the title/menu session is alive, EVERY music request resolves to
  -- the one already-playing Colosseum stream. Music.play's own current-song
  -- dedupe then turns title -> Poké Ball -> main-menu -> option/menu transitions
  -- into true no-ops instead of restarts. This specifically neutralizes Gold's
  -- native Music_MainMenu request without muting UI SFX or changing input.
  if State.titleMusicRegistered and mod.hooks and type(mod.hooks.wrap)=="function" then
    mod.hooks:wrap("music.select",function(next,song,ctx)
      local selected=next(song,ctx)
      if GoldCompat.titleExperienceEnabled()
          and (State.titleMusicSession
            or (type(ctx)=="table" and ctx.reason=="title")
            or selected=="Music_TitleScreen" or song=="Music_TitleScreen") then
        return GoldCompat.titleMusicId
      end
      return selected
    end,900)
  end

  -- Patch both title classes fail-open. The unused generation's require may not
  -- be available in a particular boot, which is fine.
  local ok1,Title1=pcall(require,"src.ui.TitleState")
  if ok1 then GoldCompat.patchTitleClass(Title1,"gen1") end
  local ok2,Title2=pcall(require,"src.ui.gen2.TitleState")
  if ok2 then GoldCompat.patchTitleClass(Title2,"gen2") end

  -- Gold owns a separate MainMenu state whose enter() normally replaces title
  -- music with Music_MainMenu. Keep that screen inside the same session and end
  -- the track only when NEW GAME or CONTINUE actually loads gameplay.
  local okMenu,MainMenu=pcall(require,"src.ui.gen2.MainMenu")
  if okMenu then GoldCompat.patchGen2MainMenu(MainMenu) end
end

return function(mod)
  local liveGame=mod and mod.game or nil
  GoldCompat.game=liveGame
  GoldCompat.generation=GoldCompat.isGen2Game(liveGame) and "gen2" or "gen1"
  if mod.log then
    mod.log:info("Colosseum UI runtime compatibility: "..tostring(GoldCompat.generation))
  end

  State.Installers.installVerifiedOptions(mod)
  GoldCompat.installTitleExperience(mod)

  -- Gen I's original 20-distinct-item cartridge limit conflicts with the
  -- expanded categorized Bag and with saves that already contain more slots.
  -- Bag.add is the shared authority for Mart purchases, pickups, PC withdrawal
  -- and script grants, so lift capacity here once instead of patching each
  -- caller. Keep Gen II's authentic per-pocket capacities and the shared
  -- 99-per-item quantity cap untouched.
  if GoldCompat.generation=="gen1" and not BagInventory.__colosseumUnlimited then
    BagInventory.__colosseumUnlimited=true
    BagInventory.__colosseumOriginalCapacity=BagInventory.capacity
    BagInventory.capacity=function(data,pocket)
      return 2147483647
    end
  end
  spritePortraitResolver.install(mod)
  GoldCompat.ColosseumUI.install(mod)

  -- Keep this palette-safe wrapper as a fallback for third-party naming
  -- screens. The built-in Gen I and Gen II classes are replaced later by the
  -- dedicated cross-generation name-entry surface.
  if NamingScreen and type(NamingScreen.draw)=="function"
      and not NamingScreen.__colosseumUiSkinned then
    NamingScreen.__colosseumUiSkinned=true
    local nativeNamingDraw=NamingScreen.draw
    NamingScreen.draw=function(self,...)
      if not GoldCompat.namingPresentationEnabled() then
        return nativeNamingDraw(self,...)
      end
      return GoldCompat.withColosseumSkin(nativeNamingDraw,self,...)
    end
    if type(NamingScreen.drawWidescreen)=="function" then
      local nativeNamingWide=NamingScreen.drawWidescreen
      NamingScreen.drawWidescreen=function(self,...)
        if not GoldCompat.namingPresentationEnabled() then
          return nativeNamingWide(self,...)
        end
        return GoldCompat.withColosseumSkin(nativeNamingWide,self,...)
      end
    end
  end

  -- The legacy concrete-menu patchers below are Gen I-only. Gen II receives
  -- generation-specific adapters with the same Colosseum presentation
  -- contract; native logic remains authoritative in both generations.
  if GoldCompat.generation=="gen1" then
    State.Installers.installPCIntegration()
    State.Installers.installMartUI()
  end

  -- Colosseum's move panel is a 2x2 grid. Keep move execution native; only
  -- advertise the engine's grid navigation mode while the presentation toggle
  -- is active.
  if GoldCompat.generation=="gen1"
      and BattleState.moveGridNavigation
      and not BattleState.__gen3uiColosseumGridPatched then
    BattleState.__gen3uiColosseumGridPatched=true
    local nativeMoveGridNavigation=BattleState.moveGridNavigation
    BattleState.moveGridNavigation=function(self,...)
      if GoldCompat.battlePresentationEnabledFor(self)
          and self.phase=="moveSelect"
          and not GoldCompat.resolvedSafariState(self) and not self.demo then
        return true
      end
      return nativeMoveGridNavigation(self,...)
    end
  end

  -- Gold uses the shared TextBox / ChoiceBox path for overworld dialogue.
  -- This is a genuine cross-generation seam, so reuse the proven Gen 3
  -- dialogue presentation instead of leaving Gold dialogue vanilla.
  State.Installers.installDialogueThemeDirect(mod)
  if mod.events and mod.events.on then
    mod.events:on("mod.options_changed", function(payload)
      State.Installers.handleModOptionChanged(mod,payload)
    end)

    -- Gen1Recomp does not expose stable lifetime battle/faint totals on every
    -- generation/save schema. Track them forward inside the save itself from
    -- the authoritative faint event; final-enemy detection counts one win.
    mod.events:on("battle.fainted", GoldCompat.recordBattleFaint)

    -- Persist individual move history from ordinary level-up/TM/service flows
    -- whenever the engine exposes the learned-move event.  This supplements
    -- the deterministic level-up reminder list with moves that cannot be
    -- reconstructed from species data alone.
    mod.events:on("pokemon.move_learned", function(payload)
      payload=type(payload)=="table" and payload or {}
      local mon=payload.mon or payload.pokemon
      if not mon and payload.partyIndex and mod.game and mod.game.save
          and type(mod.game.save.party)=="table" then
        mon=mod.game.save.party[tonumber(payload.partyIndex)]
      end
      local move=payload.moveId or payload.move or payload.id
      if type(move)=="table" then move=move.id or move.moveId or move.move end
      if mon and move then GoldCompat.moveManagerRememberId(mon,move) end
    end)
  end
  -- Battle Arts 1.8+ exposes an official presentation contract. This standalone
  -- mod cannot rely on the old Gen 3 overhaul ID, so native suppression remains
  -- installed while Battle Arts retains ownership of its sprite presentation.
  -- Read-only compatibility contract for presentation mods that want to
  -- cooperate without knowing our implementation details.
  mod.exports=mod.exports or {}
  mod.exports.uiOwnership={
    apiVersion=1,
    ownsBattleUi=function(state) return GoldCompat.ownsNativeBattleLayer(state) end,
    nativeBattleUiVisible=function(state) return not GoldCompat.ownsNativeBattleLayer(state) end,
    presentation="final-ui-layer",
  }

  local baHandle = mod.find and mod.find("BATTLE_ART_VOXEL_FORK") or nil
  local baPresentation = baHandle and baHandle.exports
      and baHandle.exports.battlePresentation or nil
  local baNativeContract = baPresentation
      and tonumber(baPresentation.apiVersion or 0) >= 1

  -- Battle Art draws through its own compositor, after the engine methods that
  -- patchVanillaTextDrawing() can wrap. Claim its documented native surfaces
  -- through the exported runtime hook; merely detecting this descriptor does
  -- not suppress anything. Fail open when our presentation is disabled.
  if baNativeContract and type(baPresentation.suppressHook)=="string"
      and mod.hooks and type(mod.hooks.wrap)=="function" then
    mod.hooks:wrap(baPresentation.suppressHook,function(next,request)
      local battle=type(request)=="table"
        and (request.battle or request.state or request.source) or nil
      if GoldCompat.battlePresentationEnabledFor(battle) then return true end
      return next(request)
    end,1000)
  end

  -- Launcher API v2 is the primary native-HUD ownership seam. The method
  -- firewall below is only a compatibility fallback for renderers that cache
  -- or replace battle methods after the normal mod-load phase.
  if mod.hooks and type(mod.hooks.wrap)=="function" then
    mod.hooks:wrap("battle.bottom_ui_visible",function(next,state)
      if GoldCompat.ownsNativeBattleLayer(state) then return false end
      return next(state)
    end,12000)
    mod.hooks:wrap("battle.status_hud_visible",function(next,state)
      if GoldCompat.ownsNativeBattleLayer(state) then return false end
      return next(state)
    end,12000)

    -- Final state-stack ownership seam for hanging overlays. This executes
    -- outside renderer-specific draw functions, so changing isOpaque or
    -- reordering another mod's compositor cannot expose the native box beneath.
    mod.hooks:wrap("screen.render_visible",function(next,state)
      local visible=next(state)
      if visible==false then return false end
      if GoldCompat.nativeOverlayRenderHidden(state) then return false end
      return visible
    end,20000)
  end

  State.Installers.patchVanillaTextDrawing()

  if mod.events and type(mod.events.on)=="function" then
    -- mods.loaded is the true "everyone has installed their wrappers" seam.
    -- Run at the end of that event, then again at the end of battle.started
    -- because StadiumBattleFX deliberately reattaches its presentation host
    -- at the battle boundary.
    mod.events:on("mods.loaded",function()
      GoldCompat.installBattleUiFirewall()
    end,-20000)
    mod.events:on("battle.started",function(payload)
      local battle=payload and (payload.battle or payload.state)
      if battle then State.activeBattle=battle end
      GoldCompat.installBattleUiFirewall()
    end,-20000)
  end
  if baNativeContract and mod.log then
    mod.log:info("Colosseum UI: using Battle Arts 1.8 native presentation contract")
  end

  -- Reassert the UI-only compatibility firewall after every renderer that
  -- loaded before us has installed its battle presentation wrappers.
  GoldCompat.installBattleUiFirewall()

  if GoldCompat.generation=="gen1" then
    State.Installers.installOverworldUI(mod)
    GoldCompat.installGen1ModernScreens()
  else
    GoldCompat.installCoreMenuUI()
    GoldCompat.installGoldServiceUI()
    GoldCompat.installPokegearUI()
    State.Installers.installGoldBattlePresentation()
  end
  GoldCompat.installCrossgenFlowUI()

  -- Native START-menu extension seam: insert UI immediately before OPTION.
  mod.hooks:wrap("ui.start_menu.items", function(next,game,items)
    local out=next(game,items)
    if type(out)~="table" then return items end

    for _,entry in ipairs(out) do
      if tostring(entry.label or ""):upper()=="UI" then return out end
    end

    local at=#out+1
    for i,entry in ipairs(out) do
      if tostring(entry.label or ""):upper()=="OPTION" then
        at=i
        break
      end
    end
    local row={
      label="UI",
      keepOpen=true,
      __gen3uiUIEntry=true,
    }
    if GoldCompat.isGen2Game(game) then
      row.onSelect=function(g) GoldCompat.openGoldUISettings(g or game) end
    end
    table.insert(out,at,row)
    return out
  end,500)

  -- Add a read-only MOVES shortcut beside STATS in the field Party submenu.
  -- Existing generic MOVES entries are normalized instead of duplicated.
  mod.hooks:wrap("ui.party.submenu", function(next,game,items,mon,ctx)
    local out=next(game,items,mon,ctx)
    -- Gold's native party submenu already owns STATS, held items/mail, field
    -- moves and its own move-management paths. Do not inject the Gen 1
    -- SummaryMenu shortcut into that richer menu.
    if GoldCompat.isGen2Game(game) then return out end
    if not GoldCompat.pokemonPresentationEnabled()
        or (ctx and ctx.battle)
        or type(out)~="table" then
      return out
    end

    local function openMoves(target,g)
      local SummaryMenu=require("src.ui.SummaryMenu")
      local summary=SummaryMenu.new(g,target)
      summary.page=2
      g.stack:push(summary)
    end

    local statsIndex=nil
    local movesIndex=nil
    for i,entry in ipairs(out) do
      local label=tostring(entry and entry.label or ""):upper()
      if label=="STATS" then statsIndex=i end
      if label=="MOVES" then movesIndex=i end
    end

    if movesIndex then
      -- Generic MOVES is informational in this UI: preserve the surrounding
      -- submenu but route it through the same native SummaryMenu page.
      out[movesIndex].action=nil
      out[movesIndex].onSelect=openMoves
    else
      local entry={label=Strings("MOVES"),onSelect=openMoves}
      table.insert(out,(statsIndex and statsIndex+1) or (#out+1),entry)
    end
    return out
  end, 500)

  -- Gen I API-v2 dialogue palette guard. Preserve every other mod's zone
  -- edits first, then deterministically resolve the underlying state's zones
  -- under the save's COLORS mode while our themed dialogue owns the top.
  mod.hooks:wrap("render.zones", function(next,game,zones)
    local out=next(game,zones)
    if out==nil then out=zones end
    return GoldCompat.repairGen1TransientZones(game,out)
  end, 12000)
  if mod.log then
    mod.log:info("Colosseum UI 1.1.0: Gen I UI/world palette safety locks active")
  end

  mod.hooks:wrap("battle.overlay", battleOverlayHook, 9000)
  mod.hooks:wrap("render.hud", function(next,game,viewport)
    return renderHudHook(mod,next,game,viewport)
  end, 10000)

  mod.hooks:wrap("render.hud", GoldCompat.locationBannerHud, 10900)
  mod.hooks:wrap("render.hud", DexUI.hud, 11000)

end
